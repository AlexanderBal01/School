# https://dodona.be/nl/courses/4195/series/46783/activities/2071746302

def SchikAppels(aantalAppels):
    aantalKisten = aantalAppels // 20
    aantalPalletten = aantalKisten // 35
    aantalOverigeKisten = aantalKisten % 35
    aantalOverigeAppels = aantalAppels % 20
    
    return aantalPalletten, aantalOverigeKisten, aantalOverigeAppels

inputAantalAppels = int(input("Geef het aantal appels: "))

aantalPalletten, aantalOverigeKisten, aantalOverigeAppels = SchikAppels(inputAantalAppels)

print(aantalPalletten)
print(aantalOverigeKisten)
print(aantalOverigeAppels)
