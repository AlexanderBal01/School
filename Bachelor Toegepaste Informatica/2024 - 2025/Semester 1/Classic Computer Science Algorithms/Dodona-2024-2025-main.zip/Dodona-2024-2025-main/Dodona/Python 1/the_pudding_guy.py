# https://dodona.be/nl/courses/4195/series/46783/activities/761303597

def TotaalBetaaldVoorAantalMijlen(gekochteStuks, kostprijsPerStuk, aantalBarcodesFlyerCoupon, aantalMijlFlyerCoupon):
    totaalBetaald = gekochteStuks * kostprijsPerStuk

    aantalFlyerCoupons = (gekochteStuks / aantalBarcodesFlyerCoupon).__floor__()
    aantalMijlen = aantalFlyerCoupons * aantalMijlFlyerCoupon

    return totaalBetaald, aantalMijlen

inputGekochteStuks = int(input("Geef het aantal gekochte stuks: "))
inputKostprijsPerStuk = float(input("Geef de kostprijs per stuk: "))
inputAantalBarcodesFlyerCoupon = int(
    input("Geef het aantal barcodes dat nodig zijn voor de flyer coupon: "))
inputAantalMijlFlyerCoupon = int(
    input("Geef het aantal mijlen dat 1 flyer coupon waard is: "))

totaalBetaald, aantalMijlen = TotaalBetaaldVoorAantalMijlen(inputGekochteStuks, inputKostprijsPerStuk, inputAantalBarcodesFlyerCoupon, inputAantalMijlFlyerCoupon)

print(
    f"Phillips spendeerde ${totaalBetaald} voor {aantalMijlen} frequent flyer mijlen.")
