# https://dodona.be/nl/courses/4195/series/46783/activities/933531418

def BerekenTemp(tjirpsPerMinuut):
    temperatuurCelsius = 10 + ((int(tjirpsPerMinuut) - 40) / 7)

    temperatuurFahrenheit = 50 + ((int(tjirpsPerMinuut) - 40) / 4)

    return temperatuurCelsius, temperatuurFahrenheit
    
inputTjirpsPerMinuut = input("Geef het aantal tjirps per minuut: ")

temperatuurCelsius, temperatuurFahrenheit = BerekenTemp(inputTjirpsPerMinuut)

print("temperatuur (Fahrenheit): " + str(temperatuurFahrenheit))

print("temperatuur (Celsius): " + str(temperatuurCelsius))
