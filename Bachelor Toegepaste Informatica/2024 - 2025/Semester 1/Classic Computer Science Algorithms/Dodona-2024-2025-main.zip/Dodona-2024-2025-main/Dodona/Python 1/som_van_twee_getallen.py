# https://dodona.be/nl/courses/4195/series/46783/activities/1555355466

def Som2Getallen(getal1, getal2):
    return getal1 + getal2

inputGetal1, inputGetal2 = int(input()), int(input())
print(Som2Getallen(inputGetal1, inputGetal2))