# https://dodona.be/nl/courses/4195/series/46783/activities/567405275

def BerekenVerbruik100Km(beginKm, eindKm, liters):
    aantalKilometersGereden = eindKm - beginKm
    verbruik1Kilometer = liters / aantalKilometersGereden
    verbruik100Kilometer = verbruik1Kilometer * 100

    return verbruik100Kilometer

b = float(input("Geef het aantal kilometers bij het begin van de huuring: "))
e = float(input("Geef het aantal kilometers bij het einde van de huuring: "))
l = float(input("Geef het aantal liter bijgetankte brandstof: "))

print(BerekenVerbruik100Km(b, e, l))
