# https://dodona.be/nl/courses/4195/series/46783/activities/1886659767

def PrijsBestellingBoeken(aantalBoeken, winkelPrijsBoek, kortingInkoopPercent, kostVerschepingEersteBoek, kostVerschepingBoek):
    totaalprijs = (winkelPrijsBoek * ((100 - kortingInkoopPercent) / 100) * aantalBoeken) + kostVerschepingEersteBoek + (kostVerschepingBoek * (aantalBoeken - 1))

    return totaalprijs

print(PrijsBestellingBoeken(60, 24.95, 40, 3, 0.75))