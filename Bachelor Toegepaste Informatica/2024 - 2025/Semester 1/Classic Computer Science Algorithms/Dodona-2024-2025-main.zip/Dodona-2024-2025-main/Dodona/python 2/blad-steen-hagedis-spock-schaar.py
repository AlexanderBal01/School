# https://dodona.be/nl/courses/4195/series/46782/activities/1647887074

def MaakSpelers():
    speler1 = input("Geef een naam van het handgebaar van speler1: ")
    speler2 = input("Geef een naam van het handgebaar van speler 2: ")
    return speler1, speler2

def SpeelSpel(speler1, speler2):
    if speler1 == speler2:
        return "gelijkspel"
    elif speler1 == "schaar" and (speler2 == "blad" or speler2 == "hagedis"):
        return "speler1 wint"
    elif speler1 == "blad" and (speler2 == "steen" or speler2 == "Spock"):
        return "speler1 wint"
    elif speler1 == "steen" and (speler2 == "hagedis" or speler2 == "schaar"):
        return "speler1 wint"
    elif speler1 == "hagedis" and (speler2 == "Spock" or speler2 == "blad"):
        return "speler1 wint"
    elif speler1 == "Spock" and (speler2 == "schaar" or speler2 == "steen"):
        return "speler1 wint"
    elif speler2 == "schaar" and (speler1 == "blad" or speler1 == "hagedis"):
        return "speler2 wint"
    elif speler2 == "blad" and (speler1 == "steen" or speler1 == "Spock"):
        return "speler2 wint"
    elif speler2 == "steen" and (speler1 == "hagedis" or speler1 == "schaar"):
        return "speler2 wint"
    elif speler2 == "hagedis" and (speler1 == "Spock" or speler1 == "blad"):
        return "speler2 wint"
    elif speler2 == "Spock" and (speler1 == "schaar" or speler1 == "steen"):
        return "speler2 wint"
    else:
        return "gelijkspel"

speler1, speler2 = MaakSpelers()
print(SpeelSpel(speler1, speler2))
