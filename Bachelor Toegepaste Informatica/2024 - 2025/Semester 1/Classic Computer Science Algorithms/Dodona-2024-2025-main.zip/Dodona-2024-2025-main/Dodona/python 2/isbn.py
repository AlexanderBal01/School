# https://dodona.be/nl/courses/4195/series/46782/activities/182880102

def GetalInvoer():
    i = 0
    getallen = []
    while i < 10:
        getal = input("geef een getal: ")
        if int(getal) >= 0 and int(getal) <= 9:
            getallen.append(int(getal))
            i = i + 1
    return getallen

def ControleerGetal10(getallen): 
    controleGetal = (getallen[0] + 2*getallen[1] + 3*getallen[2] + 4*getallen[3] + 5*getallen[4] + 6*getallen[5] + 7*getallen[6] + 8*getallen[7] + 9*getallen[8]) % 11
    
    return "OK" if controleGetal == getallen[9] else "FOUT"

getallen = GetalInvoer()
print(ControleerGetal10(getallen))
