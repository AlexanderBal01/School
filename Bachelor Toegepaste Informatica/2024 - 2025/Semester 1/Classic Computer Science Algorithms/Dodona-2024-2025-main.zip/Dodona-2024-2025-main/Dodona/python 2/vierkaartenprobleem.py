# https://dodona.be/nl/courses/4195/series/46782/activities/1345385696

def VierKaartenProbleem():
    zijdeKaart = input("Geef de zijde dat naar boven ligt van de kaart: ")

    if zijdeKaart == "kleur":
        kleurKaart = input("Geef de kleur van de kaart: ")
        moetKaartDraaien = input("Moet de kaart gedraaid worden? ")

        if kleurKaart == "rood" and moetKaartDraaien == "nee":
            antwoord = "Juist: kaarten met kleur rood moeten niet gedraaid worden."
            return antwoord
        elif kleurKaart == "rood" and moetKaartDraaien == "ja":
            antwoord = "Fout: kaarten met kleur rood moeten niet gedraaid worden."
            return antwoord
        elif kleurKaart != "rood" and moetKaartDraaien == "nee":
            antwoord = "Fout: kaarten met kleur " + str(kleurKaart) + " moeten gedraaid worden."
            return antwoord
        elif kleurKaart != "rood" and moetKaartDraaien == "ja":
            antwoord = "Juist: kaarten met kleur " + str(kleurKaart) + " moeten gedraaid worden."
            return antwoord
    elif zijdeKaart == "waarde":
        waardeKaart = int(input("Geef de waarde van de kaart: "))
        moetKaartDraaien = input("Moet de kaart gedraaid worden? ")

        if (waardeKaart % 2) == 0 and moetKaartDraaien == "nee":
            antwoord = "Fout: kaarten met waarde " + str(waardeKaart) + " moeten gedraaid worden."
            return antwoord
        elif (waardeKaart % 2) == 0 and moetKaartDraaien == "ja":
            antwoord = "Juist: kaarten met waarde " + str(waardeKaart) + " moeten gedraaid worden."
            return antwoord
        elif (waardeKaart % 2) != 0 and moetKaartDraaien == "nee":
            antwoord = "Juist: kaarten met waarde " + str(waardeKaart) + " moeten niet gedraaid worden."
            return antwoord
        elif (waardeKaart % 2) != 0 and moetKaartDraaien == "ja":
            antwoord = "Fout: kaarten met waarde " + str(waardeKaart) + " moeten niet gedraaid worden."
            return antwoord

print(VierKaartenProbleem())
