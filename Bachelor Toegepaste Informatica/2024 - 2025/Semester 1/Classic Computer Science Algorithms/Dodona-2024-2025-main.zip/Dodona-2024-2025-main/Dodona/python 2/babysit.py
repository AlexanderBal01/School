# https://dodona.be/nl/courses/4195/series/46782/activities/1797346540

def VraagUren():
    inputBeginUur = int(input("Geef het begin uur: "))
    inputBeginMinuut = int(input("Geef het begin minuut: "))
    inputEinduur = int(input("Geef het eind uur: "))
    inputEindMinuut = int(input("Geef het eind minuut: "))

    beginUur = inputBeginUur + inputBeginMinuut / 60.0
    eindUur = inputEinduur + inputEindMinuut / 60.0

    return beginUur, eindUur

def BerekenResultaat(beginUur, eindUur):
    Uur18 = 18.0
    Uur2130 = 21.5

    if beginUur < Uur18 or eindUur < beginUur:
        return "ongeldige invoer"

    if eindUur < Uur2130:
        tijd1 = eindUur - beginUur
        tijd2 = tijd2 = 0
    elif beginUur < Uur2130:
        tijd1 = Uur2130 - beginUur
        tijd2 = eindUur - Uur2130
    else:
        tijd1 = 0
        tijd2 = eindUur - beginUur

    resultaat = 2*tijd1 + 4*tijd2
    return resultaat

beginUur, eindUur = VraagUren()
print(BerekenResultaat(beginUur, eindUur))
