# https://dodona.be/nl/courses/4195/series/46782/activities/408865752

def VervalsteMunt():
    standWeegschaalWeging1 = input("Geef de stand van de weegschaal: ")
    standWeegschaalWeging2 = input("Geef de stand van de weegschaal: ")

    if standWeegschaalWeging1 == "links":
        if standWeegschaalWeging2 == "evenwicht":
            return "muntstuk #6 is vervalst"
        if standWeegschaalWeging2 == "rechts":
            return "muntstuk #4 is vervalst"
        if standWeegschaalWeging2 == "links":
            return "muntstuk #5 is vervalst"
    elif standWeegschaalWeging1 == "evenwicht":
        if standWeegschaalWeging2 == "evenwicht":
            return "muntstuk #9 is vervalst"
        if standWeegschaalWeging2 == "rechts":
            return "muntstuk #7 is vervalst"
        if standWeegschaalWeging2 == "links":
            return "muntstuk #8 is vervalst"
    elif standWeegschaalWeging1 == "rechts":
        if standWeegschaalWeging2 == "evenwicht":
            return "muntstuk #3 is vervalst"
        if standWeegschaalWeging2 == "rechts":
            return "muntstuk #1 is vervalst"
        if standWeegschaalWeging2 == "links":
            return "muntstuk #2 is vervalst"

print(VervalsteMunt())
