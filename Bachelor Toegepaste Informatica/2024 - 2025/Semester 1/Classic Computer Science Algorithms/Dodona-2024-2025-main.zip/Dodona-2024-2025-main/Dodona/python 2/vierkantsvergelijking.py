# https://dodona.be/nl/courses/4195/series/46782/activities/1437422481

def Vierkantsvergelijking(a, b, c):
    discriminant = b**2 - 4*a*c
    if discriminant < 0:
        return "geen wortels", None, None
    if discriminant == 0:
        wortel1 = -b / (2*a)
        return "een wortel", wortel1, None
    if discriminant > 0:
        wortel1 = (-b + discriminant**0.5) / (2*a)
        wortel2 = (-b - discriminant**0.5) / (2*a)
        if wortel1 < wortel2:
            return "twee wortels", wortel1, wortel2
        return "twee wortels", wortel2, wortel1

def GenerateOutput(aantalWortels, wortel1, wortel2):
    print(aantalWortels)
    if wortel1 and wortel2 is None:
        print(wortel1)
    elif wortel1 and wortel2:
        print(wortel1)
        print(wortel2)

a = float(input("Geef een getal voor a: "))
b = float(input("Geef een getal voor b: "))
c = float(input("Geef een getal voor c: "))

aantalWortels, wortel1, wortel2 = Vierkantsvergelijking(a, b, c)
GenerateOutput(aantalWortels, wortel1, wortel2)
