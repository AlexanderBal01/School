# https://dodona.be/nl/courses/4195/series/46782/activities/1301141031

def MaakRechthoek(lx, ly, rx, ry):
    if lx < rx and ly < ry:
        return [[lx, ly], [rx, ly], [lx, ry], [rx, ry]]
    if lx > rx and ly > ry:
        return [[rx, ry], [lx, ry], [rx, ly], [lx, ly]]
    if lx > rx and ly < ry:
        return [[rx, ly], [lx, ly], [rx, ry], [lx, ry]]
    if lx < rx and ly > ry:
        return [[lx, ry], [rx, ry], [ly, ly], [rx, ly]]

def ZoekBotsing(rechthoek1, rechthoek2):
    if rechthoek1[0][0] < rechthoek2[1][0] and  rechthoek1[1][0] > rechthoek2[0][0] and rechthoek1[0][1] < rechthoek2[2][1] and rechthoek1[2][1] > rechthoek2[0][1]:
        return 'botsing'
    return 'geen botsing'

rechthoek1FirstPointX = int(input())
rechthoek1FirstPointY = int(input())
rechthoek1SecondPointX = int(input())
rechthoek1SecondPointY = int(input())

rechthoek2FirstPointX = int(input())
rechthoek2FirstPointY = int(input())
rechthoek2SecondPointX = int(input())
rechthoek2SecondPointY = int(input())

rechthoek1 = MaakRechthoek(rechthoek1FirstPointX, rechthoek1FirstPointY, rechthoek1SecondPointX, rechthoek1SecondPointY)
rechthoek2 = MaakRechthoek(rechthoek2FirstPointX, rechthoek2FirstPointY, rechthoek2SecondPointX, rechthoek2SecondPointY)

print(ZoekBotsing(rechthoek1, rechthoek2))
