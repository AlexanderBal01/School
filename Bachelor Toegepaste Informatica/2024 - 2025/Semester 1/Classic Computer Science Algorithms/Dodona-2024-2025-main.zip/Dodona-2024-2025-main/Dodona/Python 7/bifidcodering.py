# https://dodona.be/nl/courses/4195/series/46776/activities/1225527836

class Bifid:
    def __init__(self, n, symbolen):
        if 2 <= n <= 10:
            self.n = n
        else:
            raise AssertionError("er moet gelden dat 2 <= n <= 10")
        
        if len(symbolen) == n ** 2:
            self.symbolen = symbolen
        else:
            raise AssertionError("aantal symbolen komt niet overeen met grootte van het rooster")
    
    def symbool(self, rij, kolom):
        if 0 <= rij < self.n and 0 <= kolom < self.n:
            return self.symbolen[self.n * rij + kolom]
        raise AssertionError("ongeldige positie in rooster")
        
    def positie(self, symbool):
        if len(symbool) != 1:
            raise AssertionError("symbool moet uit 1 karakter bestaan")
        
        if symbool not in self.symbolen:
            raise AssertionError(f"onbekend symbool: '{symbool}'")
        
        return (self.symbolen.index(symbool) // self.n, self.symbolen.index(symbool) % self.n)
    
    def codeer(self, tekst):        
        tekstRij = ""
        tekstKolom = ""
        gecodeerd = ""
        for i in range(0, len(tekst)):
            rij, kolom = self.positie(tekst[i])
            tekstRij += str(rij)
        
        for i in range(0, len(tekst)):
            rij, kolom = self.positie(tekst[i])
            tekstKolom += str(kolom)
        
        tekstRijKolom = tekstRij + tekstKolom

        for i in range(0, len(tekstRijKolom), 2):
            gecodeerd += self.symbool(int(tekstRijKolom[i]), int(tekstRijKolom[i + 1]))
        
        
        return gecodeerd
    
    def decodeer(self, tekst):
        origeneleRij = ""
        origeneleKolom = ""
        gedecodeerd = ""
        RijKolom = ""
        for i in range(0, len(tekst)):
            rij, kolom = self.positie(tekst[i])
            RijKolom += str(rij) + str(kolom)
        
        quotient, remainder = divmod(len(RijKolom), 2)
        origeneleRij = RijKolom[:quotient + remainder]
        origeneleKolom = RijKolom[quotient + remainder:]

        for i in range(0, len(origeneleRij)):
            gedecodeerd += self.symbool(int(origeneleRij[i]), int(origeneleKolom[i]))
        
        return gedecodeerd
