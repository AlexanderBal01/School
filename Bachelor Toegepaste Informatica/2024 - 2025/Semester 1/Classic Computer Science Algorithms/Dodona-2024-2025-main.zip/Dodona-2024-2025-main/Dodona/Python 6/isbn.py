# https://dodona.be/nl/courses/4195/series/46777/activities/933472639

def overzicht(codes):
    engelstalige_boeken = 0
    franstalige_boeken = 0
    duitstalige_boeken = 0
    japanstalige_boeken = 0
    russischtalige_boeken = 0
    chinestalige_boeken = 0
    overige_talige_boeken = 0
    fouten = 0
    for code in codes:
        o = int(code[0]) + int(code[2]) + int(code[4]) + int(code[6]) + int(code[8]) + int(code[10])
        e = int(code[1]) + int(code[3]) + int(code[5]) + int(code[7]) + int(code[9]) + int(code[11])
        code13 = (10 - (o + 3 * e) % 10) % 10

        if code13 == int(code[12]) and (int(code[0:3]) == 978 or int(code[0:3]) == 979):
            if code[3] == '0' or code[3] == '1':
                engelstalige_boeken += 1
            elif code[3] == '2':
                franstalige_boeken += 1
            elif code[3] == '3':
                duitstalige_boeken += 1
            elif code[3] == '4':
                japanstalige_boeken += 1
            elif code[3] == '5':
                russischtalige_boeken += 1
            elif code[3] == '7':
                chinestalige_boeken += 1
            elif code[3] == '6' or code[3] == '8' or code[3] == '9':
                overige_talige_boeken += 1
        else:
            fouten += 1
        
    print('Engelstalige landen: {}'.format(engelstalige_boeken))
    print('Franstalige landen: {}'.format(franstalige_boeken))
    print('Duitstalige landen: {}'.format(duitstalige_boeken))
    print('Japan: {}'.format(japanstalige_boeken))
    print('Russischtalige landen: {}'.format(russischtalige_boeken))
    print('China: {}'.format(chinestalige_boeken))
    print('Overige landen: {}'.format(overige_talige_boeken))
    print('Fouten: {}'.format(fouten))
