# https://dodona.be/nl/courses/4195/series/46777/activities/531231333

def dubbel(lijstGetallen):
    for i in lijstGetallen:
        aantal = lijstGetallen.count(i)
        if aantal == 2:
            return i
    
    return None

def dubbels(getallen):
    eenmaal_voorkomend = set()
    meer_dan_eenmaal_voorkomend = set()
    
    teller = {}
    
    for num in getallen:
        if num in teller:
            teller[num] += 1
        else:
            teller[num] = 1

    for num, count in teller.items():
        if count == 1:
            eenmaal_voorkomend.add(num)
        else:
            meer_dan_eenmaal_voorkomend.add(num)

    return eenmaal_voorkomend, meer_dan_eenmaal_voorkomend
