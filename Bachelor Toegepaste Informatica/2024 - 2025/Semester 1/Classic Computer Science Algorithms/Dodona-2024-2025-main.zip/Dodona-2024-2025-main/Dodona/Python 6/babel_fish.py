# https://dodona.be/nl/courses/4195/series/46777/activities/431253538

def vertalingToevoegen(vreemdeTaal, nederlands, woordenboek):
    woordenboek.update({vreemdeTaal: nederlands})

def vertaling(vreemdeTaal, woordenboek):
    if vreemdeTaal in woordenboek:
        return woordenboek[vreemdeTaal]
    else:
        return '???'
