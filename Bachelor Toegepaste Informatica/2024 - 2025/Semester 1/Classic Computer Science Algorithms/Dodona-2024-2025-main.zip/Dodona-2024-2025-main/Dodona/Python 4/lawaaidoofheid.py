# https://dodona.be/nl/courses/4195/series/46780/activities/1563511392

def maximale_blootstelling(geluidsniveau):
    standaardDuur = 8

    if geluidsniveau <  80:
        return -1.0

    if geluidsniveau in range(80, 83):
        return float(standaardDuur * 60 * 60)
    elif geluidsniveau in range(83, 86):
        standaardDuur = standaardDuur / 2
        return float(standaardDuur * 60 * 60)
    elif geluidsniveau in range(86, 89):
        standaardDuur = standaardDuur / 2**2
        return float(standaardDuur * 60 * 60)
    elif geluidsniveau in range(89, 92):
        standaardDuur = standaardDuur / 2**3
        return float(standaardDuur * 60 * 60)
    elif geluidsniveau in range(92, 95):
        standaardDuur = standaardDuur / 2**4
        return float(standaardDuur * 60 * 60)
    elif geluidsniveau in range(95, 98):
        standaardDuur = standaardDuur / 2**5
        return float(standaardDuur * 60 * 60)
    elif geluidsniveau in range(98, 101):
        standaardDuur = standaardDuur / 2**6
        return float(standaardDuur * 60 * 60)
    elif geluidsniveau in range(101, 104):
        standaardDuur = standaardDuur / 2**7
        return float(standaardDuur * 60 * 60)
    elif geluidsniveau in range(104, 107):
        standaardDuur = standaardDuur / 2**8
        return float(standaardDuur * 60 * 60)
    elif geluidsniveau in range(107, 110):
        standaardDuur = standaardDuur / 2**9
        return float(standaardDuur * 60 * 60)    
    elif geluidsniveau in range(110, 113):
        standaardDuur = standaardDuur / 2**10
        return float(standaardDuur * 60 * 60)    
    elif geluidsniveau in range(113, 116):
        standaardDuur = standaardDuur / 2**11
        return float(standaardDuur * 60 * 60)    
    elif geluidsniveau in range(116, 119):
        standaardDuur = standaardDuur / 2**12
        return float(standaardDuur * 60 * 60)    
    elif geluidsniveau in range(119, 122):
        standaardDuur = standaardDuur / 2**13
        return float(standaardDuur * 60 * 60)