# https://dodona.be/nl/courses/4195/series/46780/activities/1131866318

big_mac_prijs_verenigde_staten = 4.07

def waardering(bigMacPrijs, reeleWisselkoers):
    wisselkoersBigMac = float(bigMacPrijs / big_mac_prijs_verenigde_staten)
    v = ((wisselkoersBigMac-reeleWisselkoers)/reeleWisselkoers) *100
    if v <= -25:
        return "sterk ondergewaardeerd"
    elif -25 < v <= -5:
        return "ondergewaardeerd"
    elif -5 < v <= 5:
        return "ongeveer gelijk"
    elif 5 < v <= 25:
        return "overgewaardeerd"
    else:
        return "sterk overgewaardeerd"

def wisselkoersanalyse(prijsBigMac, reeleWisselkoers):
    splitPrijsBigMac = prijsBigMac.split(" ", 1)
    prijsBigMacFloat = float(splitPrijsBigMac[0])

    waarderingWaarde = waardering(prijsBigMacFloat, reeleWisselkoers)

    return f"De {splitPrijsBigMac[1]} is {waarderingWaarde} ten opzichte van de dollar."
