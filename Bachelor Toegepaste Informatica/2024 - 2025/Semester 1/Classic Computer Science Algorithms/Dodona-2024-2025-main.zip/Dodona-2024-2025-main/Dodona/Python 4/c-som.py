# https://dodona.be/nl/courses/4195/series/46780/activities/1706631167

def csom(getal):
    final_getal = getal
    while True:
        cijfers = [int(cijfer) for cijfer in str(final_getal)]
        if 1 <= sum(cijfers) <= 9:
            return sum(cijfers)
        else:
            final_getal = sum(cijfers)
