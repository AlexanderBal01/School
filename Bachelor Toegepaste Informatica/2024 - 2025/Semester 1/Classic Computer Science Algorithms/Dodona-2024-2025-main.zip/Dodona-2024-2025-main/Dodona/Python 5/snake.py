# https://dodona.be/nl/courses/4195/series/46778/activities/1333299580

def beweeg(xy, richting):
    xyList = list(xy)
    if richting == '<':
        xyList[0] -= 1
    elif richting == '>':
        xyList[0] += 1
    elif richting == '^':
        xyList[1] += 1
    elif richting == 'v':
        xyList[1] -= 1
    return tuple(xyList)

def teruggekeerd(richting):
    if richting[0] == ">" and richting[1] == "<":
        return True
    if richting[0] == "<" and richting[1] == ">":
        return True
    if richting[0] == "^" and richting[1] == "v":
        return True
    if richting[0] == "v" and richting[1] == "^":
        return True
    return False

def laatste_levende_positie(richtingen):
    if len(richtingen) == 0:
        return None
    xy = [0, 0]
    vorigeRichting = richtingen[0]
    teller = 0
    for i in range(len(richtingen)):
        if teruggekeerd([vorigeRichting, richtingen[i]]):
            break
        xy = list(beweeg(xy, richtingen[i]))
        teller += 1
        vorigeRichting = richtingen[i]

    returnvalue = (teller, xy[0], xy[1])
    return returnvalue
