# https://dodona.be/nl/courses/4195/series/46778/activities/117689921

def alfabetisch(zin):
    woorden = zin.split()
    gesorteerdeZin = " ".join(sorted(woorden))
    return gesorteerdeZin
