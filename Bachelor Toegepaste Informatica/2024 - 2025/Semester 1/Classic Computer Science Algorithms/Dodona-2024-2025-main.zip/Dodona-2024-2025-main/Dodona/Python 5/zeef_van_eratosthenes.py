# https://dodona.be/nl/courses/4195/series/46778/activities/197813628

def vulLijst(n):
    lijst = []
    for i in range(2, n+1):
        lijst.append(i)
    return lijst

def zeef(n):
    return zeefRecursief(vulLijst(n))

def zeefRecursief(lijstgetallen, m=0):
    for i in range(len(lijstgetallen)):
        if m == 0:
            m = lijstgetallen[i]

        if len(lijstgetallen) > i:
            if lijstgetallen[i] != m and lijstgetallen[i] % m == 0:
                lijstgetallen.pop(i)
        else:
            break
    if m == lijstgetallen[-1]:
        return lijstgetallen
    m_volgende = lijstgetallen[lijstgetallen.index(m)+1]
    return zeefRecursief(lijstgetallen, m_volgende)
    

print(zeef(52))
