# https://dodona.be/nl/courses/4195/series/46778/activities/565313929

def eerste(oplossing):
    rijLengte = len(oplossing)
    kolomLengte = len(oplossing[0])
    for kolom in range(kolomLengte):
        for rij in range(rijLengte):
            if oplossing[rij][kolom] == 1:
                return (rij, kolom)

def opvolger(oplossing, rijnummer, kolomnummer):
    rijLengte = len(oplossing)
    kolomLengte = len(oplossing[0])
    huidigGetal = oplossing[rijnummer][kolomnummer]
    if kolomLengte > rijLengte:
        for kolom in range(kolomLengte):
            for rij in range(rijLengte):
                if oplossing[rij][kolom] == huidigGetal + 1 and ((rij == rijnummer+1 and kolom == kolomnummer) or (rij == rijnummer+1 and kolom == kolomnummer+1) or (rij == rijnummer+1 and kolom == kolomnummer-1) or (rij == rijnummer and kolom == kolomnummer+1) or (rij == rijnummer and kolom == kolomnummer-1) or (rij == rijnummer-1 and kolom == kolomnummer) or (rij == rijnummer-1 and kolom == kolomnummer+1) or (rij == rijnummer-1 and kolom == kolomnummer-1)):
                    return (rij, kolom)
    else:
        for rij in range(rijLengte):
            for kolom in range(kolomLengte):
                if oplossing[rij][kolom] == huidigGetal + 1 and ((rij == rijnummer+1 and kolom == kolomnummer) or (rij == rijnummer+1 and kolom == kolomnummer+1) or (rij == rijnummer+1 and kolom == kolomnummer-1) or (rij == rijnummer and kolom == kolomnummer+1) or (rij == rijnummer and kolom == kolomnummer-1) or (rij == rijnummer-1 and kolom == kolomnummer) or (rij == rijnummer-1 and kolom == kolomnummer+1) or (rij == rijnummer-1 and kolom == kolomnummer-1)):
                    return (rij, kolom)
    return (None, None)

def laatste(oplossing):
    rijLengte = len(oplossing)
    kolomLengte = len(oplossing[0])
    aantalGetallen = rijLengte * kolomLengte
    Getalxy = list(eerste(oplossing))
    vorigeGetalxy = Getalxy
    huidigGetal = 1
    while Getalxy[0] != None and Getalxy[1] != None and huidigGetal != aantalGetallen:
        Getalxy = list(opvolger(oplossing, Getalxy[0], Getalxy[1]))
        if Getalxy == [None, None]:
            Getalxy = vorigeGetalxy
            break
        huidigGetal += 1
        vorigeGetalxy = Getalxy 
    return tuple(Getalxy)

def hidato(oplossing):
    rijLengte = len(oplossing)
    kolomLengte = len(oplossing[0])
    aantalGetallen = rijLengte * kolomLengte
    laatstexy = list(laatste(oplossing))
    LaatsteGetal = oplossing[laatstexy[0]][laatstexy[1]]
    if LaatsteGetal == aantalGetallen:
        return True
    else:
        return False
