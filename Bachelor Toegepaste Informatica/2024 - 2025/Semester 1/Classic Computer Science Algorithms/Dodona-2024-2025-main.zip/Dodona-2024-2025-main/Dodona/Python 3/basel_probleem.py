# https://dodona.be/nl/courses/4195/series/46781/activities/32506927

def BaselProbleem():
    n = 100
    i = 1
    som = 0
    while i <= n:
        som = som + (1 / (i ** 2))
        i = i + 1
    print(round(som, 11))

    print(100)

BaselProbleem()
