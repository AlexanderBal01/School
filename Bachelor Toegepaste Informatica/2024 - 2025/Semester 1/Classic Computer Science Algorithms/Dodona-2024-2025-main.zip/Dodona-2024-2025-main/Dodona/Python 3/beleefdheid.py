# https://dodona.be/nl/courses/4195/series/46781/activities/2134730675

def IsPowerOfTwo(n):
    if (n == 0):
        return False
    while (n != 1):
        if (n % 2 != 0):
            return False
        n = n // 2
    return True


def TelOpeenvolgendeSommen(getal):
    count = 0
    som = 0
    i = 1
    iCounter = i
    if IsPowerOfTwo(getal):
        return 0
    while som < getal and i < getal:
        som = som + i
        if som == getal:
            count = count + 1
            som = 0
            iCounter = iCounter + 1
            i = iCounter
        elif som > getal:
            som = 0
            iCounter = iCounter + 1
            i = iCounter
        elif som < getal:
            i = i + 1

    return count


getal = int(input("Voer een getal in: "))
print(TelOpeenvolgendeSommen(getal))
