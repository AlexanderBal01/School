# https://dodona.be/nl/courses/4195/series/46781/activities/1047652305

def BerekenAantalRozen(aantalRodeEnWitteRozen, aantalWitteEnBlauweRozen, operator):
    AantalRodeRozen = 2
    AantalWitteRozen = 2
    AantalBlauweRozen = 2

    while AantalWitteRozen <= aantalRodeEnWitteRozen - 2:
        AantalRodeRozen = aantalRodeEnWitteRozen - AantalWitteRozen
        AantalBlauweRozen = aantalWitteEnBlauweRozen - AantalWitteRozen

        if operator == '>':
            if AantalBlauweRozen + AantalRodeRozen > AantalBlauweRozen + AantalWitteRozen:
                break
        else:
            if AantalBlauweRozen + AantalRodeRozen < AantalBlauweRozen + AantalWitteRozen:
                break

        AantalWitteRozen += 1
    
    return AantalBlauweRozen, AantalWitteRozen, AantalRodeRozen


aantalRodeEnWitteRozen = int(input())
aantalWitteEnBlauweRozen = int(input())
operator = input()

AantalBlauweRozen, AantalWitteRozen, AantalRodeRozen = BerekenAantalRozen(aantalRodeEnWitteRozen, aantalWitteEnBlauweRozen, operator)

print(AantalBlauweRozen)
print(AantalWitteRozen)
print(AantalRodeRozen)
