# https://dodona.be/nl/courses/4195/series/46781/activities/654951832

def Resultaat(aantalpiraten, aantalKokosnoten):
    i = 1
    while i <= aantalPiraten:
        aantalOudeKokosnoten = aantalKokosnoten
        tussenAantalKokosnoten = aantalOudeKokosnoten // aantalPiraten
        aantalKokosnotenAap = aantalOudeKokosnoten % aantalPiraten
        if aantalKokosnotenAap == 0:
            print(str(aantalOudeKokosnoten) + " noten = " + str(tussenAantalKokosnoten) +
                " noten voor piraat#" + str(i) + " en geen noten voor de aap")
            aantalKokosnoten = (aantalOudeKokosnoten - tussenAantalKokosnoten)
        elif aantalKokosnotenAap == 1:
            print(str(aantalOudeKokosnoten) + " noten = " + str(tussenAantalKokosnoten) +
                " noten voor piraat#" + str(i) + " en 1 noot voor de aap")
            aantalKokosnoten = (aantalOudeKokosnoten - tussenAantalKokosnoten - 1)
        elif aantalKokosnotenAap >= 2:
            print(str(aantalOudeKokosnoten) + " noten = " + str(tussenAantalKokosnoten) +
                " noten voor piraat#" + str(i) + " en " + str(aantalKokosnotenAap) + " noten voor de aap")
            aantalKokosnoten = (aantalOudeKokosnoten -
                                tussenAantalKokosnoten - aantalKokosnotenAap)
        i = i + 1

    aantalNotenPiraat = aantalKokosnoten // aantalPiraten
    aantalNotenAap = aantalKokosnoten % aantalPiraten

    if aantalNotenAap == 0:
        print("elke piraat krijgt " + str(aantalNotenPiraat) +
            " noten en geen noten voor de aap")
    elif aantalNotenAap == 1:
        print("elke piraat krijgt " + str(aantalNotenPiraat) +
            " noten en 1 noot voor de aap")
    elif aantalNotenAap >= 2:
        print("elke piraat krijgt " + str(aantalNotenPiraat) +
            " noten en " + str(aantalNotenAap) + " noten voor de aap")

aantalPiraten = int(input())
aantalKokosnoten = int(input())

Resultaat(aantalPiraten, aantalKokosnoten)
