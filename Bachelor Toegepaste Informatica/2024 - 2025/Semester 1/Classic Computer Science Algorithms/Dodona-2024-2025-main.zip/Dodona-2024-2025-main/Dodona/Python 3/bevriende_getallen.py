# https://dodona.be/nl/courses/4195/series/46781/activities/1258720912

def BevriendeGetallen(getal):
    i = 1
    som = 0
    while i < getal:
        if getal % i == 0:
            som = som + i
        i = i + 1
    return som


getal1 = int(input("Voer een getal in: "))
getal2 = int(input("Voer een getal in: "))
uitkomstBevriendGetal1 = BevriendeGetallen(getal1)
uitkomstBevriendGetal2 = BevriendeGetallen(getal2)

if uitkomstBevriendGetal1 == getal2 and uitkomstBevriendGetal2 == getal1:
    print(str(getal1) + " en " + str(getal2) + " zijn bevriende getallen")
else:
    print(str(getal1) + " en " + str(getal2) + " zijn geen bevriende getallen")
