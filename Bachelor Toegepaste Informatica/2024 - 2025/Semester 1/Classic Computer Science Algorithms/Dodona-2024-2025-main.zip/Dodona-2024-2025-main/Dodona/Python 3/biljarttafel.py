# https://dodona.be/nl/courses/4195/series/46781/activities/364433585

def Biljarttafel(hoogte, breedte):
    x = 0
    y = 0
    inPocket = False
    isBotsing = False
    rechtsLinks = "rechts"
    bovenOnder = "boven"
    

    while not inPocket:
        veranderingRichting = False
        if rechtsLinks == "rechts" and bovenOnder == "boven":
            while not isBotsing and not inPocket and not veranderingRichting:   
                x += 1
                y += 1
                if y == hoogte and 0 < x < breedte:
                    print("bovenband (" + str(x) + ", " + str(y) + ")")
                    bovenOnder = "onder"
                    veranderingRichting = True
                    isBotsing = True
                elif x == breedte and 0 < y < hoogte:
                    print("rechterband (" + str(x) + ", " + str(y) + ")")
                    veranderingRichting = True
                    rechtsLinks = "links"
                    isBotsing = True
                if y in (hoogte, 0) and x in (breedte, 0):
                    inPocket = True
            if not inPocket:
                isBotsing = False
            else:
                isBotsing = True
        if rechtsLinks == "rechts" and bovenOnder == "onder":
            while not isBotsing and not inPocket and not veranderingRichting:
                x += 1
                y -= 1
                if y == 0 and 0 < x < breedte:
                    print("onderband (" + str(x) + ", " + str(y) + ")")
                    veranderingRichting = True
                    bovenOnder = "boven"
                    isBotsing = True
                elif x == breedte and 0 < y < hoogte:
                    print("rechterband (" + str(x) + ", " + str(y) + ")")
                    veranderingRichting = True
                    rechtsLinks = "links"
                    isBotsing = True
                if y in (hoogte, 0) and x in (breedte, 0):
                    inPocket = True
            if not inPocket:
                isBotsing = False
            else:
                isBotsing = True
        elif rechtsLinks == "links" and bovenOnder == "boven":
            while not isBotsing and not inPocket and not veranderingRichting:
                x -= 1
                y += 1
                if y == hoogte and 0 < x < breedte:
                    print("bovenband (" + str(x) + ", " + str(y) + ")")
                    veranderingRichting = True
                    bovenOnder = "onder"
                    isBotsing = True
                elif x == 0 and 0 < y < hoogte:
                    print("linkerband (" + str(x) + ", " + str(y) + ")")
                    veranderingRichting = True
                    rechtsLinks = "rechts"
                    isBotsing = True
                if y in (hoogte, 0) and x in (breedte, 0):
                    inPocket = True
            if not inPocket:
                isBotsing = False
            else:
                isBotsing = True
        elif rechtsLinks == "links" and bovenOnder == "onder":
            while not isBotsing and not inPocket and not veranderingRichting:
                x -= 1
                y -= 1
                if y == 0 and 0 < x < breedte:
                    print("onderband (" + str(x) + ", " + str(y) + ")")
                    veranderingRichting = True
                    bovenOnder = "boven"
                    isBotsing = True
                elif x == 0 and 0 < y < hoogte:
                    print("linkerband (" + str(x) + ", " + str(y) + ")")
                    veranderingRichting = True
                    rechtsLinks = "rechts"
                    isBotsing = True
                if y in (hoogte, 0) and x in (breedte, 0):
                    inPocket = True
            if not inPocket:
                isBotsing = False
            else:
                isBotsing = True
    if inPocket and y == hoogte and x == breedte:
        print("rechterbovenpocket (" + str(x) + ", " + str(y) + ")")
    if inPocket and y == hoogte and x == 0:
        print("linkerbovenpocket (" + str(x) + ", " + str(y) + ")")
    if inPocket and y == 0 and x == breedte:
        print("rechteronderpocket (" + str(x) + ", " + str(y) + ")")
    if inPocket and y == 0 and x == 0:
        print("linkeronderpocket (" + str(x) + ", " + str(y) + ")")

hoogte = int(input())
breedte = int(input())

Biljarttafel(hoogte, breedte)