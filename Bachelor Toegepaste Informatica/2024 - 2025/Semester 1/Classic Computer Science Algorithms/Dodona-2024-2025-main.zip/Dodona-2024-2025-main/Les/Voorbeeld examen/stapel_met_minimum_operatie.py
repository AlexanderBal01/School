# https://dodona.be/nl/courses/4195/series/46769/activities/609397992

class Stack:

    def __init__(self):
        self._data = []

    def push(self, item):
        self._data.append(item)

    def pop(self):
        return self._data.pop()

    def peek(self):
        return self._data[-1]

    def empty(self):
        return len(self._data) == 0

class StackMin:

    def __init__(self):
        self._data = Stack()
        self._kleinsteElement = Stack()

    def peek(self):
        if not self.empty():
            return self._data.peek()

    def get_minimum(self):
        return self._kleinsteElement.peek()

    def pop(self):
        if not self.empty():
            return self._data.pop()

    def push(self, item):
        self._data.push(item)
        if  :
            self._kleinsteElement.push(item)

    def empty(self):
        return self._data.empty()




    

