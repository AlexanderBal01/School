# https://dodona.be/nl/courses/4195/series/46769/activities/1581351276



class Node:

    def __init__(self, data=None, next_node=None):
        """ data     : de gegevens die je wil opslaan in deze `Node`.
            next_node: de volgende `Node` in de lineair gelinkte lijst.
        """
        self.data = data
        self.next = next_node

def print_list(head):
    items = []
    knoop = head
    while knoop is not None:
        items.append(knoop.data)
        knoop = knoop.next
        
    print("[" + ",".join(str(_) for _ in items ) + "]")

def merge(head_1, head_2):
    anker = Node()
    huidige = anker
    while head_1 is not None and head_2 is not None:
        if head_1.data <= head_2.data:
            huidige.next = head_1
            head_1 = head_1.next
        else:
            huidige.next = head_2
            head_2 = head_2.next
    if head_1 is None:
        huidige.next = head_2
    elif head_2 is None:
        huidige.next = head_1
    return anker.next

def split(head):
    slow = head
    fast = head
    while fast is not None:
        before_slow = slow
        slow = slow.next
        fast = fast.next
        if fast is not None:
            fast = fast.next
    
    before_slow.next = None
    return head, slow

def merge_sort(head):
    if head is None or head.next is None:
        return head
    (head1, head2) = split(head)
    sorted1 = merge_sort(head1)
    sorted2 = merge_sort(head2)
    return merge(sorted1, sorted2)