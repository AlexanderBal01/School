# https://dodona.be/nl/courses/4195/series/46775/activities/875119571

def zoekBinair(rij, zoekItem):
    l = 0
    r = len(rij) - 1
    while l != r:
        print(str(l) + ", " + str(r))
        m = (l + r) // 2
        if rij[m] < zoekItem:
            l = m + 1
        else:
            r = m
    if rij[l] == zoekItem:
        index = l
    else:
        index = -1
    return index

index = zoekBinair([0, 10, 20, 30, 40, 50, 60, 70, 80, 90], 70)
print(f"index = {index}")
