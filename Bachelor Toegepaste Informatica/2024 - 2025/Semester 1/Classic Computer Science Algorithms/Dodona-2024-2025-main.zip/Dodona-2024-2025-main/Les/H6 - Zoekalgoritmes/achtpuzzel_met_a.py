# https://dodona.be/nl/courses/4195/series/46770/activities/369146716

import heapq

class AchtPuzzel:

    BUREN = {0 : {("R", 1),("O", 3)},   1 : {("L", 0),("R", 2),("O", 4)},   2 : {("L",1),("O",5)}, 
             3 : {("B",0),("R",4),("O",6)}, 4 : {("B",1),("L", 3),("R", 5),("O",7)}, 5 : {("B",2),("L", 4),("O",8)},
             6 : {("B",3),("R",7)},   7 : {("B",4),("L",6),("R",8)},   8 : {("B",5),("L",7)}
            }

    def __init__(self, bord="123456780"):
        self.bord = bord

    def __str__(self):
        return self.bord[:3] +  "\n" + self.bord[3:6] + "\n" + self.bord[6:]

    def __repr__(self):
        return f"AchtPuzzel(bord='{self.bord}')"

    def __eq__(self, other):
        if isinstance(other, AchtPuzzel):
            return self.bord == other.bord
        return False

    def __hash__(self):
        return hash(self.bord)

    def opvolgers(self):
        indexLeegVakje = self.bord.index("0")
        resultaat = set()
        for (actie, indexLeegVakjeNieuw) in AchtPuzzel.BUREN[indexLeegVakje]:
            nieuwBord = list(self.bord)
            nieuwBord[indexLeegVakjeNieuw], nieuwBord[indexLeegVakje] = nieuwBord[indexLeegVakje], nieuwBord[indexLeegVakjeNieuw]
            nieuwBord = "".join(nieuwBord)
            resultaat.add((actie, AchtPuzzel(nieuwBord)))
        return resultaat

    def aantal_verkeerd(self, other):
        aantal = 0
        for i in range(len(self.bord)):
            if self.bord[i] != "0":
                if self.bord[i] != other.bord[i]:
                    aantal += 1
        return aantal

    def manhattan_heuristiek(self, other):
        aantal = 0
        for index in range(len(self.bord)):
            letter = self.bord[index]
            if letter != "0":
                indexLetterAnderePuzzel = other.bord.index(letter)
                r1, k1 = index // 3, index % 3
                r2, k2 = indexLetterAnderePuzzel // 3, indexLetterAnderePuzzel % 3
                manhattan_afstand = abs(r2-r1) + abs(k2-k1)
                aantal += manhattan_afstand
        return aantal


class Plan:

    def __init__(self, toestand, voorganger=None, actie=None, kost=0, h_waarde=float("inf")):
        self.toestand = toestand
        self.voorganger = voorganger
        self.actie = actie
        self.kost = kost
        self.h = h_waarde

    ## Vergelijk op basis van cost + heuristic
    def __lt__(self, other):
        return self.h + self.kost < other.h + other.kost

    def geef_actie_sequentie(self):
        acties = []
        huidig = self
        while huidig is not None:
            if huidig.actie is not None:
                acties.append(huidig.actie)
            huidig = huidig.voorganger
        acties.reverse()
        return acties
    
def a_ster_zoeken(start_toestand, is_doel, heuristiek, kost= lambda s,a : 1):
    f = []
    closed = []
    start_plan = Plan(start_toestand, None, None, 0, heuristiek(start_toestand))
    heapq.heappush(f, start_plan)
    while len(f) > 0:
        huidig_plan = heapq.heappop(f)
        if is_doel(huidig_plan.toestand):
            return (huidig_plan.geef_actie_sequentie(), huidig_plan.kost)
        if huidig_plan.toestand not in closed:
            closed.append(huidig_plan.toestand)
            for actie, nieuwBord in huidig_plan.toestand.opvolgers():
                nieuw_plan = Plan(nieuwBord, huidig_plan, actie, huidig_plan.kost+kost(huidig_plan.toestand, actie), heuristiek(nieuwBord))
                heapq.heappush(f, nieuw_plan)
    return None
