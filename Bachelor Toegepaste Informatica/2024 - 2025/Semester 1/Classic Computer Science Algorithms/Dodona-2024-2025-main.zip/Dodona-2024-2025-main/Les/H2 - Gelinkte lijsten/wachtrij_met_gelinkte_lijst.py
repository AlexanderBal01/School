# https://dodona.be/nl/courses/4195/series/46774/activities/936085588

class QueueList:
    class Knoop:
        def __init__(self, data=None, volgende= None):
            self.data = data
            self.volgende = volgende
    
    def __init__(self):
        self.k = None
        self.s = None
    
    def empty(self):
        return self.k is None
    
    def enqueue(self, x):
        hulp = QueueList.Knoop()
        hulp.data = x
        if self.empty():
            self.k = hulp
        else:
            self.s.volgende= hulp
        self.s = hulp
    
    def dequeue(self):
        if self.empty():
            return None
        x = self.k.data
        if self.k == self.s:
            self.k = None
            self.s = None
        else:
            self.k = self.k.volgende
        return x
    
    def front(self):
        if self.empty():
            return None
        return self.k.data
    
    def invert(self):
        vorige = None
        ref = self.k
        while ref is not None:
            volgende = ref.volgende
            ref.volgende = vorige
            vorige = ref
            ref = volgende
        self.k, self.s = self.s, self.k
