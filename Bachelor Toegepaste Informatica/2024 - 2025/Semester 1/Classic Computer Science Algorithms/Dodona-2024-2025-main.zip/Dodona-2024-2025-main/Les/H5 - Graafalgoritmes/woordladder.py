# https://dodona.be/nl/courses/4195/series/46771/activities/1200279845

ONEINDIG = 99999999

def precies_een_verschillend(woord1, woord2):
    if len(woord1) != len(woord2):
        return False
    aantal_verschillend = 0
    for i in range(len(woord1)):
        if woord1[i] != woord2[i]:
            aantal_verschillend += 1
    return aantal_verschillend == 1

def maak_graaf(woorden):
    graaf = {woord:set() for woord in woorden}
    for woord1 in woorden:
        for woord2 in woorden:
            if precies_een_verschillend(woord1, woord2):
                graaf[woord1].add(woord2)
    return graaf

def kortste_pad(graaf, start):
    D = {woord:ONEINDIG for woord in graaf.keys()}
    P = {woord:None for woord in graaf}
    D[start] = 0
    P[start] = start
    Q = []
    Q.append(start)

    while len(Q) > 0:
        v = Q.pop(0)
        for w in sorted(graaf[v]):
            if D[w] == ONEINDIG:
                D[w] = D[v] + 1
                P[w] = v
                Q.append(w)
    return P

def geef_pad(P, doel):
    knoop = doel
    pad = []
    while knoop != P[knoop]:
        pad.append(knoop)
        knoop = P[knoop]
    pad.append(knoop)
    pad.reverse()
    return pad