# https://dodona.be/nl/courses/4195/series/46773/activities/963734754

def twoSum(a, sum):
    n = len(a)
    for i in range(0,n-1):
        for j in range(i+1,n):
            if a[i] + a[j] == sum:
                return (i,j)

def twoSumHash(a, sum):
    n = len(a)
    dictionairy = dict()
    for i in range(0,n):
        complement = sum - a[i]
        if complement in dictionairy:
            j = dictionairy[complement]
            return (j, i)
        else:
            dictionairy[a[i]] = i

