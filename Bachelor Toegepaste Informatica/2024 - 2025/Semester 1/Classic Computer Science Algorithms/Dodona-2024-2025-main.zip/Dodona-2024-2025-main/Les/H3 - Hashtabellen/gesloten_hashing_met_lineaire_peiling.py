# https://dodona.be/nl/courses/4195/series/46773/activities/1385084508

class HashSet:
    flag = -9999
    def __init__(self, max_size=10):
        self.arr = [None] * max_size
        self.max_size = max_size
        self.nb = 0

    def add(self, item):
        # Controleer of de collectie vol is
        if self.nb >= self.max_size:
            raise ValueError("achterliggende array is vol")

        # Controleer of item niet de 'flag' waarde is
        if item == HashSet.flag:
            raise ValueError("flag used to indicate deleted values cannot be used as value to add")

        # Bereken de startindex met behulp van de hash van het item
        index = hash(item) % self.max_size
        
        # Zoek een lege positie of een positie met een verwijderd item (HashSet.flag)
        while self.arr[index] is not None and self.arr[index] != HashSet.flag:
            # Print de huidige index voor verificatie
            print(index)
            index = (index + 1) % self.max_size

        # Voeg het item toe aan de array
        self.arr[index] = item
        self.nb += 1

        # Return de toegevoegde index
        return index

    def index_of(self, item):
        index = hash(item) % self.max_size
        firstIndex = index
        while self.arr[index] is not None and item != self.arr[index]:
            print(index)
            index = (index + 1) % self.max_size
            if firstIndex == index:
                return -1
        
        if item == self.arr[index]:
            return index
        return -1

    def delete(self, item):
        index = self.index_of(item=item)
        if index == -1:
            return False
        self.arr[index] = HashSet.flag
        self.nb = self.nb - 1
        return True   
