package com.example.festivals2024;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Festivals2024ApplicationTests {

    @Test
    void contextLoads() {
    }

}
