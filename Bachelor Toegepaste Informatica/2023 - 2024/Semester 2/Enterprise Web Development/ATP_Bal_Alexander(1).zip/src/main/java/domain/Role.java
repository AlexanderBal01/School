package domain;

public enum Role {
    USER, ADMIN;
}
