# https://dodona.be/nl/courses/2901/series/31288/activities/818147392

def driehoek(n):
    inarr=[]
    if (not isinstance(n, int) or n<0):
        raise AssertionError('ongeldig aantal rijen')
    else:
        for i in range(n):
            if i<2:
                inarr.append([1 for i in range(i+1)])
            else:
                hulparr=[1 for i in range(i+1)]
                for j in range(1,i):
                    hulparr[j]=int(inarr[-1][j-1])+int(inarr[-1][j])
                inarr.append(hulparr)
        return inarr
        
def zeshoek(rij,kol):
    hulparr=driehoek(rij+2)
    rij-=1
    kol-=1
    if rij<2:
        raise AssertionError("ongeldig interne positie")
    return([hulparr[rij-1][kol-1],hulparr[rij-1][kol],hulparr[rij][kol+1],hulparr[rij+1][kol+1],hulparr[rij+1][kol],hulparr[rij][kol-1]])
    