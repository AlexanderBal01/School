# https://dodona.be/nl/courses/2901/series/31288/activities/117689921

def alfabetisch(zin):
    woorden = zin.split()
    gesorteerdeZin = " ".join(sorted(woorden))
    return gesorteerdeZin
