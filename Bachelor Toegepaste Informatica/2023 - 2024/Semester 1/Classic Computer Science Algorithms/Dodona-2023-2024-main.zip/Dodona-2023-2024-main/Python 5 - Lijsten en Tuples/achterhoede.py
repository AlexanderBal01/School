# https://dodona.be/nl/courses/2901/series/31288/activities/1067717366

def zien(kleuren):
    kleurHoofd = []
    aantalZien = 0
    for i in range(len(kleuren)):
        if aantalZien == 0 or aantalZien % 2 == 0:
            kleurHoofd.append("B")
        else:
            kleurHoofd.append("R")
        if kleuren[i] == "R":
            aantalZien += 1
    return tuple(kleurHoofd)

def zeggen(kleuren):
    reversedKleuren = []
    if isinstance(kleuren, str):
        for i in kleuren[::-1]:
            reversedKleuren.append(i)
    elif isinstance(kleuren, tuple):
        reversedKleuren = list(kleuren[::-1])
    else:
        reversedKleuren = kleuren[::-1]
    kleurHoofd = []
    i=0
    while i < len(reversedKleuren):
        kleurHoofd.append(reversedKleuren[i])
        vorigekleur = reversedKleuren.pop(i)
        if vorigekleur == "R":
            for j in range(len(reversedKleuren)):
                if reversedKleuren[j] == "B":
                    reversedKleuren[j] = "R"
                else:
                    reversedKleuren[j] = "B"

    return tuple(kleurHoofd[::-1])

print(zeggen('BRRBR'))
