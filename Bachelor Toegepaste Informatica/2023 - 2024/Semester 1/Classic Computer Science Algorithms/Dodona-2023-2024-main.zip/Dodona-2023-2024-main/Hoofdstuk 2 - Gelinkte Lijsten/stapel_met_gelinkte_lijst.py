# https://dodona.be/nl/courses/2901/series/31284/activities/2064046031

class StackList:

    class Knoop:
        def __init__(self, data=None, volgende=None):
            self.data = data
            self.volgende = volgende

    def __init__(self):
        self.t = None

    def empty(self):
        return self.t == None

    def push(self, data):
        hulp = StackList.Knoop(data)
        hulp.volgende = self.t
        self.t = hulp

    def peek(self):
        if self.t == None:
            return None
        else:
            return self.t.data

    def pop(self):
        if self.t == None:
            return None
        else:
            x = self.t.data
            self.t = self.t.volgende
            return x


s = StackList()
s.empty()

s.push("This")
s.empty()

s.peek()

s.push("Is")
s.push("A Test")
s.peek()

s.pop()

s.pop()

s.empty()

s.pop()

s.empty()
