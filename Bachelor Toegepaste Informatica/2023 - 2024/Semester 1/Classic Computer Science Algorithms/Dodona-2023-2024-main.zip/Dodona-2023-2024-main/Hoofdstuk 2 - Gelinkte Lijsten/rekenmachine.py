# https://dodona.be/nl/courses/2901/series/31284/activities/1458138173

operators = ['+', '-', '*', '/', '(', ')']


def evalueer_postfix(expressie):
    s = []

    for token in expressie:
        if token.isnumeric():
            s.append(float(token))
        elif token in operators:
            getal2 = s.pop()
            getal1 = s.pop()
            uitkomst = bereken_uitkomst(token, getal1, getal2)
            s.append(uitkomst)
    return s.pop()


def bereken_uitkomst(operator, getal1, getal2):
    match (operator):
        case '+':
            return getal1 + getal2
        case '-':
            return getal1 - getal2
        case '*':
            return getal1 * getal2
        case '/':
            return getal1 / getal2


def infix_naar_postfix(expressie):
    postfix_strings = []
    s = []

    for token in expressie:
        if token.isnumeric():
            postfix_strings.append(token)
        elif token in operators:
            if token == ")":
                while s[-1] != "(":
                    postfix_strings.append(s.pop())
                s.pop()
            elif len(s) == 0 or token == "(" or priority(token) > priority(s[-1]):
                s.append(token)
            else:
                while len(s) > 0 and priority(s[-1]) >= priority(token):
                    postfix_strings.append(s.pop())
                s.append(token)
    while len(s) > 0:
        postfix_strings.append(s.pop())
    return postfix_strings


def priority(operator):
    if operator not in operators:
        return -1
    elif operator in ["(", ")"]:
        return 0
    elif operator in ["+", "-"]:
        return 1
    elif operator in ["/", "*"]:
        return 2


def rekenmachine(s):
    infix_tokens = s.split()
    postfix_tokens = infix_naar_postfix(infix_tokens)
    uitkomst = evalueer_postfix(postfix_tokens)
    return uitkomst
