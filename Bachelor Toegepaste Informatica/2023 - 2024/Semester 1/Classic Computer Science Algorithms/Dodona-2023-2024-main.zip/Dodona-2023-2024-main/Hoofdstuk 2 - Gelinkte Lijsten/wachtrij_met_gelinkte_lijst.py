# https://dodona.be/nl/courses/2901/series/31284/activities/936085588

class QueueList:

    class Knoop:
        def __init__(self, data=None, volgende=None):
            self.data = data
            self.volgende = volgende

    def __init__(self):
        self.k = None
        self.s = None

    def empty(self):
        return self.k is None

    def enqueue(self, data):
        hulp = self.Knoop(data)
        if self.empty():
            self.k = hulp
            self.s = hulp
        else:
            self.s.volgende = hulp
            self.s = hulp

    def front(self):
        return self.k.data

    def dequeue(self):
        x = self.k.data
        if self.k == self.s:
            self.k = None
            self.s = None
        else:
            self.k = self.k.volgende
        return x

    def invert(self):
        if not self.empty():
            hulp = self.k
            vorig = None
            while hulp.volgende is not None:
                volgende = hulp.volgende
                hulp.volgende = vorig
                vorig = hulp
                hulp = volgende
            hulp.volgende = vorig
            hulp2 = self.k
            self.k = self.s
            self.s = hulp2
