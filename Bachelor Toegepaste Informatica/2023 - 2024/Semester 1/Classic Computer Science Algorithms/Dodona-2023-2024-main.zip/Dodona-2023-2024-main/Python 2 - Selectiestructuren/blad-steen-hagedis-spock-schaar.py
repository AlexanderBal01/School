# https://dodona.be/nl/courses/2901/series/31292/activities/1647887074
speler1 = input("Geef een naam van het handgebaar van speler1: ")
speler2 = input("Geef een naam van het handgebaar van speler 2: ")

if speler1 == speler2:
    print("gelijkspel")
elif speler1 == "schaar" and (speler2 == "blad" or speler2 == "hagedis"):
    print("speler1 wint")
elif speler1 == "blad" and (speler2 == "steen" or speler2 == "Spock"):
    print("speler1 wint")
elif speler1 == "steen" and (speler2 == "hagedis" or speler2 == "schaar"):
    print("speler1 wint")
elif speler1 == "hagedis" and (speler2 == "Spock" or speler2 == "blad"):
    print("speler1 wint")
elif speler1 == "Spock" and (speler2 == "schaar" or speler2 == "steen"):
    print("speler1 wint")
elif speler2 == "schaar" and (speler1 == "blad" or speler1 == "hagedis"):
    print("speler2 wint")
elif speler2 == "blad" and (speler1 == "steen" or speler1 == "Spock"):
    print("speler2 wint")
elif speler2 == "steen" and (speler1 == "hagedis" or speler1 == "schaar"):
    print("speler2 wint")
elif speler2 == "hagedis" and (speler1 == "Spock" or speler1 == "blad"):
    print("speler2 wint")
elif speler2 == "Spock" and (speler1 == "schaar" or speler1 == "steen"):
    print("speler2 wint")
else:
    print("gelijkspel")
