# https://dodona.be/nl/courses/2901/series/31292/activities/1437422481
a = float(input("Geef een getal voor a: "))
b = float(input("Geef een getal voor b: "))
c = float(input("Geef een getal voor c: "))
discriminant = b**2 - 4*a*c
if discriminant < 0:
    print("geen wortels")
elif discriminant == 0:
    wortel1 = -b / (2*a)
    print("een wortel")
    print(wortel1)
elif discriminant > 0:
    wortel1 = (-b + discriminant**0.5) / (2*a)
    wortel2 = (-b - discriminant**0.5) / (2*a)
    print("twee wortels")
    if wortel1 < wortel2:
        print(wortel1)
        print(wortel2)
    else:
        print(wortel2)
        print(wortel1)
