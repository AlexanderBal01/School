# https://dodona.be/nl/courses/2901/series/31292/activities/182880102
def GetalInvoer():
    i = 0
    numbers = []
    while i < 10:
        getal = input("Geef een getal: ")
        if int(getal) >= 0 and int(getal) <= 9:
            numbers.append(int(getal))
            i += 1
    return numbers


getallen = GetalInvoer()
controleGetal = (getallen[0] + 2*getallen[1] + 3*getallen[2] + 4*getallen[3] + 5 *
                 getallen[4] + 6*getallen[5] + 7*getallen[6] + 8*getallen[7] + 9*getallen[8]) % 11
antwoord = "OK" if controleGetal == getallen[9] else "FOUT"
print(antwoord)
