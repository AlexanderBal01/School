# https://dodona.be/nl/courses/2901/series/31292/activities/1345385696
zijdeKaart = input("Geef de zijde dat naar boven ligt van de kaart: ")
if zijdeKaart == "kleur":
    kleurKaart = input("Geef de kleur van de kaart: ")
    moetKaartDraaien = input("Moet de kaart gedraaid worden? ")
    if kleurKaart == "rood" and moetKaartDraaien == "nee":
        print("Juist: kaarten met kleur rood moeten niet gedraaid worden.")
    elif kleurKaart == "rood" and moetKaartDraaien == "ja":
        print("Fout: kaarten met kleur rood moeten niet gedraaid worden.")
    elif kleurKaart != "rood" and moetKaartDraaien == "nee":
        print("Fout: kaarten met kleur " +
              str(kleurKaart) + " moeten gedraaid worden.")
    elif kleurKaart != "rood" and moetKaartDraaien == "ja":
        print("Juist: kaarten met kleur " +
              str(kleurKaart) + " moeten gedraaid worden.")
elif zijdeKaart == "waarde":
    waardeKaart = int(input("Geef de waarde van de kaart: "))
    moetKaartDraaien = input("Moet de kaart gedraaid worden? ")
    if (waardeKaart % 2) == 0 and moetKaartDraaien == "nee":
        print("Fout: kaarten met waarde " +
              str(waardeKaart) + " moeten gedraaid worden.")
    elif (waardeKaart % 2) == 0 and moetKaartDraaien == "ja":
        print("Juist: kaarten met waarde " +
              str(waardeKaart) + " moeten gedraaid worden.")
    elif (waardeKaart % 2) != 0 and moetKaartDraaien == "nee":
        print("Juist: kaarten met waarde " +
              str(waardeKaart) + " moeten niet gedraaid worden.")
    elif (waardeKaart % 2) != 0 and moetKaartDraaien == "ja":
        print("Fout: kaarten met waarde " + str(waardeKaart) +
              " moeten niet gedraaid worden.")
