# https://dodona.be/nl/courses/2901/series/31292/activities/1301141031
def rectangle(lx, ly, rx, ry):
    if lx < rx and ly < ry:
        return [[lx, ly], [rx, ly], [lx, ry], [rx, ry]]
    elif lx > rx and ly > ry:
        return [[rx, ry], [lx, ry], [rx, ly], [lx, ly]]
    elif lx > rx and ly < ry:
        return [[rx, ly], [lx, ly], [rx, ry], [lx, ry]]
    elif lx < rx and ly > ry:
        return [[lx, ry], [rx, ry], [ly, ly], [rx, ly]]


rectAFirstPointX = int(input())
rectAFirstPointY = int(input())
rectASecondPointX = int(input())
rectASecondPointY = int(input())

rectBFirstPointX = int(input())
rectBFirstPointY = int(input())
rectBSecondPointX = int(input())
rectBSecondPointY = int(input())

firstRect = rectangle(rectAFirstPointX, rectAFirstPointY,
                      rectASecondPointX, rectASecondPointY)
secondRect = rectangle(rectBFirstPointX, rectBFirstPointY,
                       rectBSecondPointX, rectBSecondPointY)

if firstRect[0][0] < secondRect[1][0] and \
        firstRect[1][0] > secondRect[0][0] and \
        firstRect[0][1] < secondRect[2][1] and \
        firstRect[2][1] > secondRect[0][1]:
    print('botsing')
else:
    print('geen botsing')
