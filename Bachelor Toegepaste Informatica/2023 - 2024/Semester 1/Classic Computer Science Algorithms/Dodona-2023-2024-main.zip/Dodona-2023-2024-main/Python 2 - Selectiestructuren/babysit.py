# https://dodona.be/nl/courses/2901/series/31292/activities/1797346540
beginUur = int(input("Geef het begin uur: "))
beginMinuut = int(input("Geef het begin minuut: "))
einduur = int(input("Geef het eind uur: "))
eindMinuut = int(input("Geef het eind minuut: "))

beginUur = beginUur + beginMinuut / 60.0
einduur = einduur + eindMinuut / 60.0

Uur18 = 18.0
Uur2130 = 21.5

if beginUur < Uur18 or einduur < beginUur:
    print("ongeldige invoer")
else:
    if einduur < Uur2130:
        tijd1 = einduur - beginUur
        tijd2 = tijd2 = 0
    elif beginUur < Uur2130:
        tijd1 = Uur2130 - beginUur
        tijd2 = einduur - Uur2130
    else:
        tijd1 = 0
        tijd2 = einduur - beginUur

    resultaat = 2*tijd1 + 4*tijd2
    print(resultaat)
