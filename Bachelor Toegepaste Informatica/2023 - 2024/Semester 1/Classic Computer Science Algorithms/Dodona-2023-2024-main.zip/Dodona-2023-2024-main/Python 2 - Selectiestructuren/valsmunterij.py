# https://dodona.be/nl/courses/2901/series/31292/activities/408865752
standWeegschaalWeging1 = input("Geef de stand van de weegschaal: ")
standWeegschaalWeging2 = input("Geef de stand van de weegschaal: ")
if standWeegschaalWeging1 == "links":
    if standWeegschaalWeging2 == "evenwicht":
        print("muntstuk #6 is vervalst")
    elif standWeegschaalWeging2 == "rechts":
        print("muntstuk #4 is vervalst")
    elif standWeegschaalWeging2 == "links":
        print("muntstuk #5 is vervalst")
elif standWeegschaalWeging1 == "evenwicht":
    if standWeegschaalWeging2 == "evenwicht":
        print("muntstuk #9 is vervalst")
    elif standWeegschaalWeging2 == "rechts":
        print("muntstuk #7 is vervalst")
    elif standWeegschaalWeging2 == "links":
        print("muntstuk #8 is vervalst")
elif standWeegschaalWeging1 == "rechts":
    if standWeegschaalWeging2 == "evenwicht":
        print("muntstuk #3 is vervalst")
    elif standWeegschaalWeging2 == "rechts":
        print("muntstuk #1 is vervalst")
    elif standWeegschaalWeging2 == "links":
        print("muntstuk #2 is vervalst")
