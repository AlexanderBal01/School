# https://dodona.be/nl/courses/2901/series/31290/activities/522641350

import string


def varkenswoord(woord):
    if woord[0] in "aeiouAEIOU":
        return woord + "way"
    else:
        if woord[0].isupper():
            for i in range(len(woord)):
                if woord[i] in "aeiou":
                    if woord[i-1] in "Qq" and woord[i] in "uU":
                        if woord[i+1].isupper():
                            return woord[i+1].upper() + woord[i+2:] + woord[0].lower() + woord[1:i+1] + "ay"
                        else:
                            return woord[i+1:] + woord[0].lower() + woord[1:i+1] + "ay"
                    else:
                        return woord[i].upper() + woord[i+1:] + woord[0].lower() + woord[1:i] + "ay"
                elif woord[i] in "AEIOUQ":
                    if woord[i-1] in "Qq" and woord[i] in "uU":
                        if woord[i+1].isupper():
                            return woord[i+1:] 
                        else:
                            return woord[i+1:] + woord[0].lower() + woord[1:i+1] + "ay"
                    else:
                        return woord[i:] + woord[0].upper() + woord[1:i] + "ay"
        else:
            for i in range(len(woord)):
                if woord[i] in "q" and woord[i+1] in "u":
                    return woord[i+2:] + woord[:i+2] + "ay"
                if woord[i] in "aeiouAEIOU":
                    return woord[i:] + woord[:i] + "ay"
            return woord + "ay"
                
def varkenslatijn(zin):
    woorden = zin.split()
    for i in range(len(woorden)):
        for j in woorden[i]:
            if j in ".,:;!?'-":
                if j != "-":
                    second_woorden = woorden[i].split(j)
                    aantal_tekens = ""
                    for s in second_woorden:
                        if not s:
                            aantal_tekens += j
                        elif s:
                            aantal_tekens = j*1
                    k=0
                    while k <= len(second_woorden) - 1 and "" in second_woorden[k]:
                        if not second_woorden[k]:
                            second_woorden.remove(second_woorden[k])
                            k = k - 1
                        else:
                            k = k + 1
                    if len(second_woorden) == 1:
                        aantal_tekens = aantal_tekens[:-1]
                        woorden[i] = varkenswoord(second_woorden[0]) + aantal_tekens
                        break
                    else:
                        woorden[i] = varkenswoord(second_woorden[0]) + aantal_tekens + varkenswoord(second_woorden[1])
                        break
                else:
                    second_woorden = woorden[i].split(j)
                    aantal_tekens = ""
                    for s in second_woorden:
                        if not s:
                            aantal_tekens += j
                        elif s:
                            aantal_tekens = j*1
                    k=0
                    while k <= len(second_woorden) - 1 and "" in second_woorden[k]:
                        if not second_woorden[k]:
                            second_woorden.remove(second_woorden[k])
                            k = k - 1
                        else:
                            k = k + 1
                    if len(second_woorden) == 1:
                        aantal_tekens = aantal_tekens[:-1]
                        woorden[i] = varkenswoord(second_woorden[0]) + aantal_tekens
                        break
                    else:
                        woorden[i] = varkenswoord(second_woorden[0]) + aantal_tekens + varkenswoord(second_woorden[1])
                        break

        if not bevat_leestekens(woorden[i]):
            woorden[i] = varkenswoord(woorden[i])
    return " ".join(woorden)

def bevat_leestekens(tekst):
    for teken in tekst:
        if teken in string.punctuation or teken in "-":
            return True
    return False
