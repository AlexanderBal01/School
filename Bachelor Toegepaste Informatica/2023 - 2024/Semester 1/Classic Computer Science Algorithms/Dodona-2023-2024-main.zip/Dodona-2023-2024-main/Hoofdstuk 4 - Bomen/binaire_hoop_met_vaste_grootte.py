# https://dodona.be/nl/courses/2901/series/31282/activities/1394891023

class BinaryHeap:

    def __init__(self, max_size=10):
        self.max_size = max_size
        self.heap = []*max_size

    def empty(self):
        return len(self.heap) == 0
    
    def get_min_elem(self):
        if self.empty():
            return None
        return self.heap[0]

    def insert_elem(self, item):
        self.heap.append(item)
        index = len(self.heap) - 1
        while index > 0 and item < self.heap[(index-1)//2]:
            ouder = self.heap[(index-1)//2]
            self.heap[index], self.heap[(index - 1)//2] = ouder, item
            index = (index - 1)//2

    def remove_min_elem(self):
        if len(self.heap) == 0:
            return None
        wortel = self.heap[0]
        self.heap[0] = self.heap[-1]
        self.heap.pop()
        index = 0
        while (2*index+1 < len(self.heap) and self.heap[2*index+1] < self.heap[index]) or (2*index+2 < len(self.heap) and self.heap[2*index+2] < self.heap[index]):
            indexKleinste = 2*index+1
            if 2*index+2 < len(self.heap) and self.heap[2*index+2] < self.heap[2*index+1]:
                indexKleinste = 2*index+2
            self.heap[index], self.heap[indexKleinste] = self.heap[indexKleinste], self.heap[index]
            index = indexKleinste

        return wortel

    def __str__(self):
        return str(self.heap)
