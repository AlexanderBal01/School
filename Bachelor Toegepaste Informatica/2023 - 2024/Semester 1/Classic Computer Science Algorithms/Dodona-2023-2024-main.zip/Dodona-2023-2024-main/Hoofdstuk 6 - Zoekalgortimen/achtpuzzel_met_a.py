# https://dodona.be/nl/courses/2901/series/31280/activities/369146716
import heapq

class AchtPuzzel:

    BUREN = {0 : {("R", 1),("O", 3)},   1 : {("L", 0),("R", 2),("O", 4)},   2 : {("L",1),("O",5)},
             3 : {("B",0),("R",4),("O",6)}, 4 : {("B",1),("L", 3),("R", 5),("O",7)}, 5 : {("B",2),("L", 4),("O",8)},
             6 : {("B",3),("R",7)},   7 : {("B",4),("L",6),("R",8)},   8 : {("B",5),("L",7)} 
            }

    def __init__(self, bord="123456780"):
        self.bord = bord


    def __str__(self):
        return self.bord[:3] +  "\n" + self.bord[3:6] + "\n" + self.bord[6:]

    def __repr__(self):
        return f"AchtPuzzel(bord='{self.bord}')"


    def __eq__(self, other):
        if isinstance(other, AchtPuzzel):
            return self.bord == other.bord
        return False


    def __hash__(self):
        return hash(self.bord)

    
    def opvolgers(self):
        opvolgers = set()
        indexLegeVakje = self.bord.index("0")
        for actie, index in AchtPuzzel.BUREN[indexLegeVakje]:
            anderGetal = self.bord[index]
            nieuwBord = self.bord.replace(anderGetal, "9")
            nieuwBord = nieuwBord.replace("0", anderGetal)
            nieuwBord = nieuwBord.replace("9", "0")
            nieuwePuzzel = AchtPuzzel(nieuwBord)
            opvolgers.add((actie, nieuwePuzzel))
        return opvolgers
    
    def aantal_verkeerd(self, other):
        aantal = 0
        for index, getal in enumerate(self.bord):
            getal2 = other.bord[index]
            if getal != "0" and getal != getal2:
                aantal += 1
        return aantal 


    def manhattan_heuristiek(self, other):
        aantal = 0
        for index, getal in enumerate(self.bord):
            index2 = other.bord.index(getal)
            if getal != "0" :
                r1, k1 = index // 3, index % 3
                r2, k2 = index2 // 3, index2 % 3
                manhattan_afstand = abs(r2-r1) + abs(k2-k1)
                aantal += manhattan_afstand
        return aantal


class Plan:

    def __init__(self, toestand, voorganger=None, actie=None, kost=0, h_waarde=float("inf")):
        self.toestand = toestand
        self.voorganger = voorganger
        self.actie = actie
        self.kost = kost
        self.h_waarde = h_waarde

    ## Vergelijk op basis van cost + heuristic
    def __lt__(self, other):
        return self.kost + self.h_waarde < other.kost  +other.h_waarde

    def geef_actie_sequentie(self):
        actiesequentie = []
        huidige = self
        while huidige is not None:
            actiesequentie.append(huidige.actie)
            huidige = huidige.voorganger
        actiesequentie.pop()
        actiesequentie.reverse()
        return actiesequentie
    
def a_ster_zoeken(start_toestand, is_doel, heuristiek, kost= lambda s,a : 1):
    open = []
    closed = []
    open.append(Plan(start_toestand))
    while len(open) > 0:
        huidigPlan = heapq.heappop(open)
        if is_doel(huidigPlan.toestand):
            return (huidigPlan.geef_actie_sequentie(), huidigPlan.kost)
        else:
            if huidigPlan.toestand not in closed:
                closed.append(huidigPlan.toestand)
                for actie, nieuwePuzzel in sorted(huidigPlan.toestand.opvolgers()):
                    heapq.heappush(open, Plan(nieuwePuzzel, huidigPlan, actie, huidigPlan.kost + kost(huidigPlan.toestand, actie), heuristiek(nieuwePuzzel)))
    return None

print(AchtPuzzel())