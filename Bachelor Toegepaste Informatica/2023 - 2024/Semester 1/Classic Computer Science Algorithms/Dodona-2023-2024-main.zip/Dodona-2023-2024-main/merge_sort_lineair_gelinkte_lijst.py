# https://dodona.be/nl/courses/2901/series/31277/activities/1581351276



class Node:

    def __init__(self, data=None, next_node=None):
        """ data     : de gegevens die je wil opslaan in deze `Node`.
            next_node: de volgende `Node` in de lineair gelinkte lijst.
        """
        self.data = data
        self.next = next_node

def print_list(head):
    items = [] # aan te passen

    ### BEGIN JOUW CODE
    ref = head
    while ref is not None:
        items.append(ref.data)
        ref = ref.next
    ### EINDE JOUW CODE

    print("[" + ",".join(str(_) for _ in items) + "]")

def merge(head_1, head_2):
    ref1 = head_1
    ref2 = head_2
    head_3 = Node()
    ref3 = head_3
    while ref1 is not None and ref2 is not None:
        if ref1.data < ref2.data:
            ref3.next = ref1
            ref1 = ref1.next
        else:
            ref3.next = ref2
            ref2 = ref2.next
        ref3 = ref3.next

    if ref1 is None:
        ref3.next = ref2
    else:
        ref3.next = ref1
    
    return head_3.next

def split(head):
    pass

def merge_sort(head):
    pass
