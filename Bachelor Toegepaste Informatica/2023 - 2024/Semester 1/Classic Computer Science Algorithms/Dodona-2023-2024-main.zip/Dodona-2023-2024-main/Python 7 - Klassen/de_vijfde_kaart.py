# https://dodona.be/nl/courses/2901/series/31286/activities/1162195102

def tupleToList(a):
    b = []
    for kaart in a:
        b.append(kaart)
    return b


def geef_kaarten_kleuren(kaarten):
    kaarten_kleuren = []
    for kaart in kaarten:
        kaarten_kleuren.append(kaart.kleur)
    return kaarten_kleuren


def vijfdeKaart(kaarten):
    if isinstance(kaarten, tuple):
        kaarten = tupleToList(kaarten)
    kleur_van_verborgen_kaart = kaarten[0].kleur
    startpunt = rangen.index(kaarten[0].rang) + 1
    kaart_rang_niet = kaarten[0].rang

    kaarten_dict = {}

    for i in rangen:
        if i != kaart_rang_niet:
            kaarten_dict.update({(rangen.index(i) + 1): i})

    kaarten.pop(0)
    # kaarten.sort(key=lambda kaart: rangen.index(
    #     kaart.rang))
    # kaarten.sort(key=lambda kaart: kleuren.index(
    #     kaart.kleur))

    aantal_stappen = 0

    if kaarten[0].rang <= kaarten[1].rang <= kaarten[2].rang:
        aantal_stappen = 1
    elif (kaarten[0].rang <= kaarten[1].rang) and (kaarten[0].rang <= kaarten[2].rang) and (kaarten[1].rang >= kaarten[2].rang):
        aantal_stappen = 2
    elif (kaarten[0].rang >= kaarten[1].rang) and (kaarten[0].rang <= kaarten[2].rang) and (kaarten[1].rang <= kaarten[2].rang):
        aantal_stappen = 3
    elif (kaarten[0].rang <= kaarten[1].rang) and (kaarten[0].rang >= kaarten[2].rang) and (kaarten[1].rang >= kaarten[2].rang):
        aantal_stappen = 4
    elif (kaarten[0].rang >= kaarten[1].rang) and (kaarten[0].rang >= kaarten[2].rang) and (kaarten[1].rang <= kaarten[2].rang):
        aantal_stappen = 5
    elif kaarten[0].rang >= kaarten[1].rang >= kaarten[2].rang:
        aantal_stappen = 6

    if startpunt + aantal_stappen > 13:
        rang_van_verborgen_kaart = kaarten_dict[startpunt + aantal_stappen - 13]
    else:
        rang_van_verborgen_kaart = kaarten_dict[startpunt + aantal_stappen]

    return Kaart(rang_van_verborgen_kaart, kleur_van_verborgen_kaart)


# Voorbeeldgebruik:
rangen = ["aas", "2", "3", "4", "5", "6", "7",
          "8", "9", "10", "boer", "vrouw", "heer"]
kleuren = ["klaveren", "ruiten", "harten", "schoppen"]


class Kaart:
    def __init__(self, rang, kleur):
        if rang not in rangen or kleur not in kleuren:
            raise AssertionError("ongeldige kaart")
        self.rang = rang
        self.kleur = kleur

    def __str__(self) -> str:
        return f"{self.kleur} {self.rang}"

    def __repr__(self) -> str:
        return f"Kaart(rang='{self.rang}', kleur='{self.kleur}')"

    def __eq__(self, other):
        return self.rang == other.rang

    def __ne__(self, other):
        return self.rang != other.rang

    def __lt__(self, other):
        return rangen.index(self.rang) < rangen.index(other.rang)

    def __le__(self, other):
        return rangen.index(self.rang) <= rangen.index(other.rang)

    def __gt__(self, other):
        return rangen.index(self.rang) > rangen.index(other.rang)

    def __ge__(self, other):
        return rangen.index(self.rang) >= rangen.index(other.rang)
