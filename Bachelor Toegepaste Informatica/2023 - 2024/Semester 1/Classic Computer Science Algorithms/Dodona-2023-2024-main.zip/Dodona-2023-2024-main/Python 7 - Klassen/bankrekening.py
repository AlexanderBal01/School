# https://dodona.be/nl/courses/2901/series/31286/activities/2096226599

class BankRekening:

    def __init__(self, rekeningHouder, rekeningnummer, initieelBedrag=0):
        self.rekeninghouder = rekeningHouder
        self.rekeningnummer = rekeningnummer
        self.initeelBedrag = initieelBedrag

    def __str__(self) -> str:
        return f'{self.rekeninghouder}, {self.rekeningnummer}, bedrag: {self.initeelBedrag}'

    def __repr__(self) -> str:
        strBankRekening = self.__str__()
        strBankRekening = strBankRekening.replace(
            self.rekeninghouder, f"'{self.rekeninghouder}'")
        strBankRekening = strBankRekening.replace(
            self.rekeningnummer, f"'{self.rekeningnummer}'")
        strBankRekening = strBankRekening.replace("bedrag: ", "")

        return f'BankRekening({strBankRekening})'

    def storten(self, n):
        self.initeelBedrag += n

    def afhalen(self, n):
        self.initeelBedrag -= n


b1 = BankRekening('Peter Peeters', '842457894511', 10000)

b1.afhalen(300)

print(repr(b1))
