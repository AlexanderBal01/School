# https://dodona.be/nl/courses/2901/series/31289/activities/546000908

def fib(n):
    return fib(n-1) + fib(n-2) if n > 1 else n
