# https://dodona.be/nl/courses/2901/series/31281/activities/1200279845

def precies_een_verschillend(woord1, woord2):
    verschillend = 0
    for letter1,letter2 in zip(woord1,woord2):
        if letter1 != letter2:
            verschillend +=1
    return verschillend == 1

def maak_graaf(lijstwoorden):
    graaf = { woord:set() for woord in lijstwoorden }
    for woord in lijstwoorden:
        for woord2 in lijstwoorden:
            if precies_een_verschillend(woord,woord2):
                graaf[woord].add(woord2)

    return graaf

def kortste_pad(graaf, start):
    # ONEINDIG = 99999
    P = { woord:None for woord in graaf }
    # D = { woord:ONEINDIG for woord in graaf }
    # D[start] = 0
    P[start] = start
    Q = [start]
    while len(Q) > 0:
        v = Q.pop(0)
        for w in sorted(graaf[v]):
            # if D[w] == ONEINDIG:
            if P[w] is None:
                # D[w] = D[v] + 1
                P[w] = v
                Q.append(w)
    return P

def geef_pad(voorgangers, einde):
    voorganger = einde
    pad = []
    while voorganger != voorgangers[voorganger]:
        pad.append(voorganger)
        voorganger = voorgangers[voorganger]
    pad.append(voorganger)
    pad.reverse()
    return pad
