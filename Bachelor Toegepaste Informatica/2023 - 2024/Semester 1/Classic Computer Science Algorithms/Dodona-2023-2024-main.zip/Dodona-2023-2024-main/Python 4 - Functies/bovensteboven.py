# https://dodona.be/nl/courses/2901/series/31290/activities/581452346

def bovensteboven(n):
    ongeldigeKarakters = ["2", "3", "4", "5", "7"]
    dubbelgangers = {"0": "0", "1": "1", "6": "9", "8": "8", "9": "6"}
    if [i for i in ongeldigeKarakters if (i in str(n))]:
        return False
    else:
        for i in range(len(str(n)) // 2):
            if str(n)[len(str(n)) - 1 - i] == dubbelgangers.get(str(n)[i]):
                n_omgekeerd_als_string = str(n)[::-1]
                n_omgekeerd_als_string_tijdelijk = n_omgekeerd_als_string.replace("6", "X")
                n_omgekeerd_als_string_tijdelijk = n_omgekeerd_als_string_tijdelijk.replace("9", "Y")
                n_omgekeerd_als_string_tijdelijk = n_omgekeerd_als_string_tijdelijk.replace("X", "9")
                n_omgekeerd_als_string = n_omgekeerd_als_string_tijdelijk.replace("Y", "6")
                if str(n) == n_omgekeerd_als_string:
                    return True
                else:
                    return False
            else:
                return False

def volgende(n):
    gevonden = False
    getal = n + 1

    while not gevonden:
        if bovensteboven(getal):
            gevonden = True
            return getal
        else:
            getal += 1
            