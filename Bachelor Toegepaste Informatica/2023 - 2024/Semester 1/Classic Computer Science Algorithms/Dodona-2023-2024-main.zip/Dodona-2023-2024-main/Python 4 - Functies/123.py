# https://dodona.be/nl/courses/2901/series/31290/activities/192047393

even_getallen = [0, 2, 4, 6, 8]
oneven_getallen = [1, 3, 5, 7, 9]

def even_oneven(getal):
    string_getal = str(getal)
    aantal_even = 0
    aantal_oneven = 0
    list_even_oneven =[]
    for i in string_getal:
        if int(i) in even_getallen:
            aantal_even += 1
        else:
            aantal_oneven += 1
        
    list_even_oneven.append(aantal_even)
    list_even_oneven.append(aantal_oneven)
    return tuple(list_even_oneven)

def volgende(getal):
    even, oneven = even_oneven(getal)
    lengte = even + oneven
    str_getal = str(even) + str(oneven) + str(lengte)
    return int(str_getal)

def stappen(getal):
    uitkomst = 0
    while getal != 123:
        even, oneven = even_oneven(getal)
        lengte = even + oneven
        str_getal = str(even) + str(oneven) + str(lengte)
        getal = int(str_getal)
        uitkomst += 1
    return uitkomst

if __name__ == '__main__':
    import doctest
    doctest.testmod()
 