# https://dodona.be/nl/courses/2901/series/31290/activities/862295437

alfabet = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"]

def codeer(t, s):
    t_list = list(t)
    codeer_dict = {}
    t_return =""
    for i in range(len(t)):
        for j in range(len(s)):
            if i == j:
                codeer_dict[i] = j -1
            elif i > j:
                k = i
                while k > len(s):
                    k = k - len(s) - 1
                codeer_dict[i] = k
    
    for x, y in codeer_dict.items():
        if t[x].isupper() and t[x] in alfabet:
            v = (alfabet.index(t[x]) + alfabet.index(s[y])) % 26
            t_list[x] = alfabet[v]
    
    for i in t_list:
        t_return += i
    return t_return
                    
# print(codeer("DIT IS EXTREEM GEHEIM!", "ZODIAK"))