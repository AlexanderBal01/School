# https://dodona.be/nl/courses/2901/series/31290/activities/1563511392

def maximale_blootstelling(db):
    if db < 80:
        return -1.0
    
    standaard_duur = 8
    
    if db in range(80, 83):
        return float(standaard_duur * 60 * 60)
    elif db in range(83, 86):
        standaard_duur = standaard_duur / 2
        return float(standaard_duur * 60 * 60)
    elif db in range(86, 89):
        standaard_duur = standaard_duur / 2**2
        return float(standaard_duur * 60 * 60)
    elif db in range(89, 92):
        standaard_duur = standaard_duur / 2**3
        return float(standaard_duur * 60 * 60)
    elif db in range(92, 95):
        standaard_duur = standaard_duur / 2**4
        return float(standaard_duur * 60 * 60)
    elif db in range(95, 98):
        standaard_duur = standaard_duur / 2**5
        return float(standaard_duur * 60 * 60)
    elif db in range(98, 101):
        standaard_duur = standaard_duur / 2**6
        return float(standaard_duur * 60 * 60)
    elif db in range(101, 104):
        standaard_duur = standaard_duur / 2**7
        return float(standaard_duur * 60 * 60)
    elif db in range(104, 107):
        standaard_duur = standaard_duur / 2**8
        return float(standaard_duur * 60 * 60)
    elif db in range(107, 110):
        standaard_duur = standaard_duur / 2**9
        return float(standaard_duur * 60 * 60)    
    elif db in range(110, 113):
        standaard_duur = standaard_duur / 2**10
        return float(standaard_duur * 60 * 60)    
    elif db in range(113, 116):
        standaard_duur = standaard_duur / 2**11
        return float(standaard_duur * 60 * 60)    
    elif db in range(116, 119):
        standaard_duur = standaard_duur / 2**12
        return float(standaard_duur * 60 * 60)    
    elif db in range(119, 122):
        standaard_duur = standaard_duur / 2**13
        return float(standaard_duur * 60 * 60)
