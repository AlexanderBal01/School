# https://dodona.be/nl/courses/2901/series/31290/activities/1131866318
big_mac_prijs_verenigde_staten = 4.07

def waardering(big_mac_prijs, reele_wisselkoers):
    wisselkoers_big_mac = float(big_mac_prijs / big_mac_prijs_verenigde_staten)
    v = ((wisselkoers_big_mac-reele_wisselkoers)/reele_wisselkoers) *100
    if v <= -25:
        return "sterk ondergewaardeerd"
    elif -25 < v <= -5:
        return "ondergewaardeerd"
    elif -5 < v <= 5:
        return "ongeveer gelijk"
    elif 5 < v <= 25:
        return "overgewaardeerd"
    else:
        return "sterk overgewaardeerd"

def wisselkoersanalyse(prijs_big_mac, reele_wisselkoers):
    split_prijs_big_mac = prijs_big_mac.split(" ", 1)
    prijs_big_mac_float = float(split_prijs_big_mac[0])

    waardering_waarde = waardering(prijs_big_mac_float, reele_wisselkoers)

    return f"De {split_prijs_big_mac[1]} is {waardering_waarde} ten opzichte van de dollar."
