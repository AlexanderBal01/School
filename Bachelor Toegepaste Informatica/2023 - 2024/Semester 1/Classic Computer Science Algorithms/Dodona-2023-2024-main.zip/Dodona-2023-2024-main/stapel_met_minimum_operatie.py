# https://dodona.be/nl/courses/2901/series/31277/activities/609397992

class Stack:

    def __init__(self):
        self._data = []

    def push(self, item):
        self._data.append(item)

    def pop(self):
        return self._data.pop()

    def peek(self):
        return self._data[-1]

    def empty(self):
        return len(self._data) == 0

class StackMin:

    def __init__(self):
        self.stack_data = Stack()
        self.stack_min = Stack()

    def peek(self):
        return self.stack_data.peek()

    def get_minimum(self):
        if self.stack_min.empty():
            return None
        return self.stack_min.peek()

    def pop(self):
        item = None
        if self.empty() or self.stack_data:
            item = self.stack_data.pop()
        if item == self.get_minimum():
            self.stack_min.pop()
        return item

    def push(self, item):
        self.stack_data.push(item)
        if self.get_minimum() is None:
            self.stack_min.push(item)
        else:
            if item <= self.get_minimum():
                self.stack_min.push(item)

    def empty(self):
        return self.stack_data.empty()
