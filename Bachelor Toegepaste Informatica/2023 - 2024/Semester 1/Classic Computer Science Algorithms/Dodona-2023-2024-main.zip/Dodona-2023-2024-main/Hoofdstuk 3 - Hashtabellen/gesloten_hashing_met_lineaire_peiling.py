# https://dodona.be/nl/courses/2901/series/31283/activities/1385084508

class HashSet:
    DELETEFLAG = 99999999
    def __init__(self, max_size=10):
        self.max_size = max_size
        self.container = [None]*max_size
        self.count = 0

    def add(self, item):
        if self.count == self.max_size:
            raise ValueError("HashSet is vol")
        else:
            code = hash(item)
            index = code % self.max_size
            while self.container[index] is not None and self.container[index] is not HashSet.DELETEFLAG:
                print(index)
                index = (index + 1) % self.max_size
            self.container[index] = item
            self.count = self.count + 1
        
        return index


    def index_of(self, item):
        code = hash(item)
        index = code % self.max_size
        begin = index

        while self.container[index] is not None and self.container[index] != item:
            print(index)
            index = (index + 1) % self.max_size
            if index == begin:
                return -1

        if self.container[index] == item:
            return index
        else:
            return -1

    def delete(self, item):
        index = self.index_of(item)
        if index == -1:
            return False
        else:
            self.container[index] = HashSet.DELETEFLAG
            return True      


    






