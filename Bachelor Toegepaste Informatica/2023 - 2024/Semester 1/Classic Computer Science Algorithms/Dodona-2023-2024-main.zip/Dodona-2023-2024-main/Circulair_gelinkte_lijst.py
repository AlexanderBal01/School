class CirculaireLijst:

    class Knoop:
        def __init__(self, data=None, volgende=None):
            self.data = data
            self.volgende = volgende

    def __init__(self):
        self.laatste = None

    def is_leeg(self):
        return self.laatste is None

    # Voeg een nieuwe knoop met een gegeven waarde toe aan de lijst als laatste knoop.
    def voeg_toe(self, data):
        # Voeg hier je extra code toe
        if self.is_leeg():
            self.laatste = CirculaireLijst.Knoop()
            nieuwe_knoop = CirculaireLijst.Knoop(data,self.laatste.volgende)
            self.laatste.volgende = nieuwe_knoop
            self.laatste = nieuwe_knoop
        else:
            

    # Geef True/False terug naargelang de waarde gevonden werd in de lijst.
    def zoek(self,waarde):
        lijst = self
        while lijst.laatste is not None:
            if lijst.laatste.data == waarde:
                return True
            lijst.laatste = lijst.laatste.volgende
        
        return False

    # Verwijder de eerste knoop en geef de waarde ervan terug.
    def verwijder_eerste(self): 
        pass

    def check_waarde(self):
        return self.laatste.volgende

c_lijst = CirculaireLijst()
c_lijst.voeg_toe('A')
c_lijst.voeg_toe('B')
c_lijst.voeg_toe('C')
c_lijst.voeg_toe('D')
print(c_lijst.check_waarde())
# c_lijst.zoek('B')
# c_lijst.zoek('F')

