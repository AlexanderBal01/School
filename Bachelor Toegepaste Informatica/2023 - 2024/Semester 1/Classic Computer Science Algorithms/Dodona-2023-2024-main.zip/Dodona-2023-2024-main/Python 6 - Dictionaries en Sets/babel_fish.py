# https://dodona.be/nl/courses/2901/series/31287/activities/431253538
def vertalingToevoegen(vreemdeTaal, nederlands, woordenboek):
    woordenboek.update({vreemdeTaal: nederlands})

def vertaling(vreemdeTaal, woordenboek):
    if vreemdeTaal in woordenboek:
        return woordenboek[vreemdeTaal]
    else:
        return '???'
