# https://dodona.be/nl/courses/2901/series/31287/activities/1564830716

alle_noten = ['A', 'A#', 'B', 'C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G','G#']

def ontleding(akkoord):
    if "#" in akkoord:
        grondnoot = akkoord[0:2]
        akkoordsymbool = akkoord[2:]
    else: 
        grondnoot = akkoord[0]
        akkoordsymbool = akkoord[1:]
    return(grondnoot, akkoordsymbool)

def noten(grondnoot, lijst_akkoord):
    index = alle_noten.index(grondnoot)
    noten_van_akkoord = []
    for i in lijst_akkoord:
        if (index + i > 11):
            noten_van_akkoord.append(alle_noten[(index + i) - 12])
        else:
            noten_van_akkoord.append(alle_noten[(index + i)])
    return(noten_van_akkoord)

def akkoord(gegeven_akkoord, akkoordtypes, akkoordsymbolen):
    grondnoot, akkoordsymbool = ontleding(gegeven_akkoord)
    akkoordtype = akkoordsymbolen.get(akkoordsymbool)
    lijst_akkoord = akkoordtypes.get(akkoordtype)
    noten_van_akkoord = noten(grondnoot, lijst_akkoord)
    return tuple(noten_van_akkoord)