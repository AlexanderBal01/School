# https://dodona.be/nl/courses/2901/series/31287/activities/370184940

def letterfrequenties(tekst):
    tekst = tekst.lower()
    alle_letters = 'abcdefghijklmnopqrstuvwxyz'

    aantalLetters = {}
    split_tekst = tekst.split(',')
    letters = []
    for i in split_tekst:
        index = split_tekst.index(i)
        split_tekst[index] = i.strip()
    
    for i in split_tekst:
        index = split_tekst.index(i)
        letter = split_tekst[index].split("'")
        if letter[0][-1] in alle_letters:
            letters.append(letter[0][-1])

        if letter[-1][-2] in alle_letters:
            letters.append(letter[-1][-2])

    for i in letters:
        for j in tekst:
            if i == j:
                if i in aantalLetters:
                    aantalLetters[i] += 1
                else:
                    aantalLetters[i] = 1
    return aantalLetters

letterfrequenties("This sentence employs two a's, two c's, two d's, twenty-eight e's, five f's, three g's, eight h's, eleven i's, three l's, two m's, thirteen n's, nine o's, two p's, five r's, twenty-five s's, twenty-three t's, six v's, ten w's, two x's, five y's, and one z.")