# https://dodona.be/nl/courses/2901/series/31287/activities/1186776322

def omgekeerd(sleutel):
    omgekeerdeSleutel = {value: key for key, value in sleutel.items()}
    return omgekeerdeSleutel

def code39(bericht, sleutel):
    berichtInHoofdletters = bericht.upper()
    gecodeerd = ""

    for i in berichtInHoofdletters:
        letterCode = sleutel[i] + "s"
        gecodeerd = gecodeerd + letterCode
    gecodeerd = gecodeerd[:-1]
    return gecodeerd

def decode39(bericht, sleutel):
    bericht = bericht + "s"
    origineelBericht = ""
    gesplitstBericht = [(bericht[i:i+10]) for i in range(0, len(bericht), 10)]
    for i in gesplitstBericht:
        gecodeerdeLetter = i[:-1]
        gedecodeerdeLetter = list(sleutel.keys()) [list(sleutel.values()).index(gecodeerdeLetter)]
        origineelBericht = origineelBericht + gedecodeerdeLetter
    return origineelBericht