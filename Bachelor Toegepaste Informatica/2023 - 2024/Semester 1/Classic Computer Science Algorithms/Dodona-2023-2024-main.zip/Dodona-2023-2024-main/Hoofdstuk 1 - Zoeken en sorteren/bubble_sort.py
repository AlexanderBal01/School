# https://dodona.be/nl/courses/2901/series/31285/activities/277529356

def bubble_sort(a):
    n = len(a)
    teller = 0
    for i in range(0, n-1):
        for j in range(n-1, i, -1):
            teller = teller + 1
            if a[j] < a[j-1]:
                a[j], a[j-1] = a[j-1], a[j]
        print(a)
    print("Voor een rij van lengte " + str(n) +
          " werd het if-statement " + str(teller) + " keer uitgevoerd")


a = [int(_) for _ in input().split()]
bubble_sort(a)
