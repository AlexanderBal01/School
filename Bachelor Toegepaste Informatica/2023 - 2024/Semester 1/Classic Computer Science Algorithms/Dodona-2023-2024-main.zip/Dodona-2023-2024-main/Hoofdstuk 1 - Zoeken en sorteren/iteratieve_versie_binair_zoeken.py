# https://dodona.be/nl/courses/2901/series/31285/activities/875119571

def zoekBinair(rij, zoekItem):
    l = 0
    n = len(rij)
    r = n - 1
    while l != r:
        print(str(l) + ", " + str(r))
        m = (l + r) // 2
        if rij[m] < zoekItem:
            l = m + 1
        else:
            r = m
    if rij[l] == zoekItem:
        index = l
    else:
        index = -1
    return index
