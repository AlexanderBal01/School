# https://dodona.be/nl/courses/2901/series/31291/activities/257342570
aantal = int(input("kies een getal tussen 1 en 9: "))
i = 1
while i <= aantal:
    j = 1
    while j <= i:
        print(j, end="")
        j += 1
    print()
    i += 1
