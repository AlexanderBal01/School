# https://dodona.be/nl/courses/2901/series/31291/activities/32506927
n = 100
i = 1
som = 0
while i <= n:
    som = som + (1 / (i ** 2))
    i = i + 1
print(round(som, 11))

print(100)
