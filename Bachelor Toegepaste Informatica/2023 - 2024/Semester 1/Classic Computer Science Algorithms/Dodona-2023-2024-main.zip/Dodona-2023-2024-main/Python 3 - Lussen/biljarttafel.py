# https://dodona.be/nl/courses/2901/series/31291/activities/364433585
hoogte = int(input())
breedte = int(input())

rechterOnderPocket = [breedte, 0]
linkerBovenPocket = [0, hoogte]
rechterBovenPocket = [breedte, hoogte]
x = 0
y = 0
inPocket = False

while not inPocket:
    x = x + 1
    y = y + 1
    while not inPocket and x >= 0 and y >= 0 and x <= breedte and y <= hoogte:
        if x >= 0 and y >= 0 and x <= breedte and y <= hoogte:
            if y == hoogte:
                print("bovenband (" + str(x) + ", " + str(y) + ")")
                while not inPocket and x >= 0 and y >= 0 and x <= breedte and y <= hoogte:
                    x = x + 1
                    y = y - 1
                    if x >= 0 and y >= 0 and x <= breedte and y <= hoogte:
                        if x == breedte:
                            print("rechterband (" + str(x) + ", " + str(y) + ")")
                            while not inPocket and x >= 0 and y >= 0 and x <= breedte and y <= hoogte:
                                x = x - 1
                                y = y - 1
                                if x >= 0 and y >= 0 and x <= breedte and y <= hoogte:
                                    if y == 0:
                                        print(
                                            "onderband (" + str(x) + ", " + str(y) + ")")
                                        while not inPocket and x >= 0 and y >= 0 and x <= breedte and y <= hoogte:
                                            x = x - 1
                                            y = y + 1
                                            if x >= 0 and y >= 0 and x <= breedte and y <= hoogte:
                                                if x == 0:
                                                    print(
                                                        "linkerband (" + str(x) + ", " + str(y) + ")")
                                                    break
                                                else:
                                                    x = x - 1
                                                    y = y + 1
                                            else:
                                                break
                                    else:
                                        x = x - 1
                                        y = y - 1
                                else:
                                    break
                        else:
                            x = x + 1
                            y = y - 1
                    else:
                        break
            else:
                x = x + 1
                y = y + 1
        else:
            break
        if y == breedte and x == 0:
            print("linkerbovenpocket (" + str(x) + ", " + str(y) + ")")
            inPocket = True
        elif x == breedte and y == 0:
            print("rechteronderpocket (" + str(x) + ", " + str(y) + ")")
            inPocket = True
        elif x == breedte and y == hoogte:
            print("rechterbovenpocket (" + str(x) + ", " + str(y) + ")")
            inPocket = True
