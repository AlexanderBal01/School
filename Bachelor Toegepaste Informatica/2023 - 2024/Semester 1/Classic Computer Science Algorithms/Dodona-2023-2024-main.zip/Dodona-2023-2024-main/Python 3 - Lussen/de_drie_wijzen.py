# https://dodona.be/nl/courses/2901/series/31291/activities/113082360
t = float(input())
a = 0.00
b = 0.00
