# https://dodona.be/nl/courses/2901/series/31291/activities/1047652305
aantalRodeEnWitteRozen = int(input())
aantalWitteEnBlauweRozen = int(input())
operator = input()
aantalRodeRozen = 2
aantalWitteRozen = 2
aantalBlauweRozen = 2

while aantalWitteRozen <= aantalRodeEnWitteRozen - 2:
    aantalRodeRozen = aantalRodeEnWitteRozen - aantalWitteRozen
    aantalBlauweRozen = aantalWitteEnBlauweRozen - aantalWitteRozen

    if operator == '>':
        if aantalBlauweRozen + aantalRodeRozen > aantalBlauweRozen + aantalWitteRozen:
            break
    else:
        if aantalBlauweRozen + aantalRodeRozen < aantalBlauweRozen + aantalWitteRozen:
            break

    aantalWitteRozen += 1


print(aantalBlauweRozen)
print(aantalWitteRozen)
print(aantalRodeRozen)
