# https://dodona.be/nl/courses/2901/series/31291/activities/1319193582
state = True
somKaarten = 0
while state:
    kaart = input()
    somKaarten += int(kaart)
    if somKaarten == 21:
        print("Gewonnen!")
        state = False
    elif somKaarten > 21:
        print("Verbrand ({})".format(somKaarten))
        state = False
    elif int(kaart) == 0 and somKaarten < 21:
        print("Voorzichtig gespeeld ({})".format(somKaarten))
        state = False
