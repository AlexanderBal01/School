# https://dodona.be/nl/courses/2901/series/31288/activities/2038783829

def iszigzag(lijst):
    vorigGetal = lijst[0]
    for i in lijst[1:]:
        index = lijst.index(i)+1
        while index < len(lijst):
            if vorigGetal == lijst[0]:
                if vorigGetal >= i:
                    vorigGetal = i
                    break
                else:
                    return False
            if (vorigGetal >= i and i <= lijst[index]):
                vorigGetal = i
                break
            elif (vorigGetal <= i and i >= lijst[index]):
                vorigGetal = i
                break
            else:
                return False
  

    return True