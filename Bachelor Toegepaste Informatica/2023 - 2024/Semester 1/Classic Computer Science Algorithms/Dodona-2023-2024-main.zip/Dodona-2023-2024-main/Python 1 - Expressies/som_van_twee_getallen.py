# https://dodona.be/nl/courses/2901/series/31293/activities/1555355466
inputGetal1 = input("Geef een getal: ")
inputGetal2 = input("Geef een 2de getal: ")
som = int(inputGetal1) + int(inputGetal2)
print(som)
