# https://dodona.be/nl/courses/2901/series/31293/activities/2071746302
inputAantalAppels = int(input("Geef het aantal appels: "))
aantalKisten = inputAantalAppels // 20
aantalPalletten = aantalKisten // 35
aantalOverigeKisten = aantalKisten % 35
aantalOverigeAppels = inputAantalAppels % 20
print(aantalPalletten)
print(aantalOverigeKisten)
print(aantalOverigeAppels)
