# https://dodona.be/nl/courses/2901/series/31293/activities/558538104
inputGetal1 = int(input("Geef een getal: "))
inputGetal2 = int(input("Geef een 2de getal: "))
inputGetal3 = int(input("Geef een 3de getal: "))
print(f"{inputGetal3} {inputGetal2} {inputGetal1}")
