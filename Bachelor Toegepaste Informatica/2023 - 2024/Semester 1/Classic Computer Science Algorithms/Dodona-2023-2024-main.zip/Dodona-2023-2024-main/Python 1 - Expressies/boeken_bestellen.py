# https://dodona.be/nl/courses/2901/series/31293/activities/1886659767
winkelPrijs = 24.95
kortingInkoop = 0.4
prijsVerschepenEersteBoek = 3.00
prijsVerschepenVolgendeBoeken = 0.75
aantalBoeken = 60
uitkomst = (winkelPrijs * (1 - kortingInkoop) * aantalBoeken) + prijsVerschepenEersteBoek + (prijsVerschepenVolgendeBoeken * (aantalBoeken - 1))
print(uitkomst)