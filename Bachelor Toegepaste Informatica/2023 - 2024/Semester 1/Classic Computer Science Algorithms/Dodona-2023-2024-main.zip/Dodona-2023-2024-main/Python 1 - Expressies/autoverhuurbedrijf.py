# https://dodona.be/nl/courses/2901/series/31293/activities/567405275
b = float(input("Geef het aantal kilometers bij het begin van de huuring: "))
e = float(input("Geef het aantal kilometers bij het einde van de huuring: "))
l = float(input("Geef het aantal liter bijgetankte brandstof: "))
aantalKilometersGereden = e - b
verbruik1Kilometer = l / aantalKilometersGereden
verbruik100Kilometer = verbruik1Kilometer * 100
print(verbruik100Kilometer)
