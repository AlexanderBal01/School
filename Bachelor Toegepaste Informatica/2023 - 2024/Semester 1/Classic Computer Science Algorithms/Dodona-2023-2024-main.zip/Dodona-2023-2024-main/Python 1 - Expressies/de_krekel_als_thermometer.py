# https://dodona.be/nl/courses/2901/series/31293/activities/933531418
inputTjirpsPerMinuut = input("Geef het aantal tjirps per minuut: ")
temperatuurCelsius = 10 + ((int(inputTjirpsPerMinuut) - 40) / 7)
temperatuurFahrenheit = 50 + ((int(inputTjirpsPerMinuut) - 40) / 4)
print("temperatuur (Fahrenheit): " + str(temperatuurFahrenheit))
print("temperatuur (Celsius): " + str(temperatuurCelsius))
