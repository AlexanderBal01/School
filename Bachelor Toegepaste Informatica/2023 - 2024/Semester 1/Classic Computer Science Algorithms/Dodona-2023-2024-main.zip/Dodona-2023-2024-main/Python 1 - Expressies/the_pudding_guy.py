# https://dodona.be/nl/courses/2901/series/31293/activities/761303597
inputGekochteStuks = int(input("Geef het aantal gekochte stuks: "))
kostprijsPerStuk = float(input("Geef de kostprijs per stuk: "))
aantalBarcodesFlyerCoupon = int(
    input("Geef het aantal barcodes dat nodig zijn voor de flyer coupon: "))
aantalMijlFlyerCoupon = int(
    input("Geef het aantal mijlen dat 1 flyer coupon waard is: "))
totaalBetaald = inputGekochteStuks * kostprijsPerStuk
aantalFlyerCoupons = inputGekochteStuks / aantalBarcodesFlyerCoupon
aantalFlyerCoupons = aantalFlyerCoupons.__floor__()
aantalMijlen = aantalFlyerCoupons * aantalMijlFlyerCoupon
print(
    f"Phillips speendeerde ${totaalBetaald} voor {aantalMijlen} frequent flyer mijlen.")
