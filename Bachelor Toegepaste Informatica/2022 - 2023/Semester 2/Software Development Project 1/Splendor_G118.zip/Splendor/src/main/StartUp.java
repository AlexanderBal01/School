package main;

import cui.ConsoleApp;
import gui.GuiApp;
import javafx.application.Application;
import utils.MessageHelper;

public class StartUp {
    public static void main(String[] args) {
        MessageHelper.setLanguage("en");
        //ConsoleApp ca = new ConsoleApp();
        Application.launch(GuiApp.class, args);
    }
}
