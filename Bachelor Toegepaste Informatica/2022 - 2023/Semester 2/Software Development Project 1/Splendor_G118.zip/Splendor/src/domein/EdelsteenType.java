package domein;

import utils.MessageHelper;

/**
 * Representeert de verschillende types van edelstenen.
 */
public enum EdelsteenType {
    /**
     * Een enum constant voor het type van diamant.
     */
    DIAMANT(MessageHelper.getString("color_diamond")),
    /**
     * Een enum constant voor het type van de saffier.
     */
    SAFFIER(MessageHelper.getString("color_sapphire")),
    /**
     * Een enum constant voor het type van de smaragd.
     */
    SMARAGD(MessageHelper.getString("color_emerald")),
    /**
     * Een enum constant voor het type van de robijn.
     */
    ROBIJN(MessageHelper.getString("color_ruby")),
    /**
     * Een enum constant voor het type van de onyx.
     */
    ONYX(MessageHelper.getString("color_onyx"));

    private final String kleur;

    /**
     * constructor voor EdelsteenType.
     *
     * @param kleur de kleur van de edelsteen
     */
    EdelsteenType(String kleur) {
        this.kleur = kleur;
    }

    /**
     * Getter voor kleur.
     *
     * @return kleur als string
     */
    public String getKleur() {
        return kleur;
    }

}
