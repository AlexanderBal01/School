package domein;

import dto.*;
import exceptions.MaximumAantalSpelerException;
import exceptions.SpelerNietGevondenException;
import exceptions.SpelerZitInSpelException;
import utils.MessageHelper;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.stream.Collectors;

/**
 * domeinController klasse die de logica van het domein inhoudt.
 */
public class DomeinController {
    private final SpelerRepository spelerRepository;
    private Spel spel;
    private ArrayList<Speler> spelers;

    /**
     * domeinController constructor waar spelerRepository wordt gemaakt.
     */
    public DomeinController() {
        spelerRepository = new SpelerRepository();
    }

    //region Getters

    /**
     * Geeft Spel object terug
     *
     * @return Spel object
     */
    public Spel getSpel() {
        return spel;
    }

    /**
     * Geeft spelOverzicht terug
     *
     * @return spelOverzicht als een String
     */
    public String getSpelOverzicht() {
        return spel.toonSpelSituatie();
    }
    //endregion

    //region Setters
    private void setSpel(Spel spel) {
        this.spel = spel;
    }
    //endregion

    //region DTO methodes

    /**
     * Geeft een SpelerDTO terug via de gebruikersnaam.
     *
     * @param _gebruikersnaam Gebruikersnaam van de Speler.
     * @return SpelerDTO
     */
    public SpelerDTO geefSpelerDTO(String _gebruikersnaam) {
        Speler speler = spel
                .getSpelers()
                .stream()
                .filter(s -> s.getGebruikersnaam().equals(_gebruikersnaam))
                .findAny()
                .orElse(null);
        if (speler == null) return null;
        return new SpelerDTO(speler);
    }

    /**
     * Geeft een SpelerDTO terug via de id.
     *
     * @param index index van de Speler.
     * @return SpelerDTO
     */
    public SpelerDTO geefSpelerDTO(int index) {
        Speler speler = (Speler) spel
                .getSpelers()
                .toArray()[index];
        if (speler == null) return null;
        return new SpelerDTO(speler);
    }

    /**
     * Geeft een SpelerDTO terug via de Speler.
     *
     * @param speler Speler object van de Speler.
     * @return SpelerDTO
     */
    public SpelerDTO geefSpelerDTO(Speler speler) {
        return new SpelerDTO(speler);
    }

    /**
     * Geeft een Collection terug van alle SpelerDTO's.
     *
     * @return SpelerDTO lijst.
     */
    public Collection<SpelerDTO> geefSpelersDTO() {
        return spel
                .getSpelers()
                .stream()
                .map(speler -> new SpelerDTO(speler))
                .collect(Collectors.toList());
    }

    /**
     * Geeft een Collection terug van alle WinnaarDTO's.
     * @return WinnaarDTO lijst.
     */
    public Collection<SpelerDTO> geefWinnaarDTO() {
        return spel
                .getWinnaars()
                .stream()
                .map(speler -> new SpelerDTO(speler))
                .collect(Collectors.toList());
    }

    /**
     * Selecteer een speler, die nog niet in het spel is.
     *
     * @param gebruikersnaam Gebruikersnaam van de speler.
     * @return SpelerDTO
     */
    public SpelerDTO selecteerSpelerDtoUitDatabank(String gebruikersnaam) {
        try {
            Speler gevondenSpeler = spelerRepository.geefSpeler(gebruikersnaam);
            if (spelers == null) spelers = new ArrayList<>();
            if (isSpelerInSpel(gevondenSpeler))
                throw new SpelerZitInSpelException(String.format("%s!", MessageHelper.getString("exception_player_ingame")));
            if (spelers.size() > 3)
                throw new MaximumAantalSpelerException(String.format("%s!", MessageHelper.getString("exception_max_players")));
            spelers.add(gevondenSpeler);
            return new SpelerDTO(gevondenSpeler);
        } catch (SpelerNietGevondenException e) {
            throw new SpelerNietGevondenException(String.format("%s : %s", MessageHelper.getString("exception_player_notfound"), gebruikersnaam));
        }
    }

    /**
     * Geeft de huidige speler terug in DTO.
     *
     * @return SpelerDTO
     */
    public SpelerDTO geefHuidigeSpelerDTO() {
        return new SpelerDTO(spel.getHuidgeSpeler());
    }

    /**
     * Geeft als resultaat het spel in DTO.
     *
     * @return SpelDTO
     */
    public SpelDTO geefSpelDTO() {
        return new SpelDTO(spel);
    }

    /**
     * Geeft edelen terug als EdeleDTO's.
     *
     * @return EdeleDTO lijst.
     */
    public Collection<EdeleDTO> geefEdelenDTO() {
        return spel
                .getEdelen()
                .stream()
                .map(edele -> new EdeleDTO(edele))
                .collect(Collectors.toList());
    }

    /**
     * Geeft edelstenen terug als VoorraadKostDTO's.
     *
     * @return VoorraadKostDTO lijst.
     */
    public Collection<VoorraadKostDTO> geefEdelstenenDTO() {
        return spel
                .getEdelstenen()
                .stream()
                .map(voorraadKost -> new VoorraadKostDTO(voorraadKost))
                .collect(Collectors.toList());
    }

    /**
     * Geeft open ontwikkelingen I terug als een lijst van OntwikkelingDTO's.
     *
     * @return OntwikkelingDTO lijst.
     */
    public Collection<OntwikkelingDTO> geefOpenOntwikkelingIDTO() {
        return spel
                .getOpenOntwikelingI()
                .stream()
                .map(ontwk -> new OntwikkelingDTO(ontwk))
                .collect(Collectors.toList());
    }

    /**
     * Geeft open ontwikkeling II terug als een lijst van OntwikkelingDTO's.
     *
     * @return OntwikkelingDTO lijst.
     */
    public Collection<OntwikkelingDTO> geefOpenOntwikkelingIIDTO() {
        return spel
                .getOpenOntwikelingII()
                .stream()
                .map(ontwk -> new OntwikkelingDTO(ontwk))
                .collect(Collectors.toList());
    }

    /**
     * Geeft open ontwikkeling III terug als een lijst van OntwikkelingDTO's.
     *
     * @return OntwikkelingDTO lijst.
     */
    public Collection<OntwikkelingDTO> geefOpenOntwikkelingIIIDTO() {
        return spel
                .getOpenOntwikelingIII()
                .stream()
                .map(ontwk -> new OntwikkelingDTO(ontwk))
                .collect(Collectors.toList());
    }

    //endregion

    /**
     * Maakt een nieuw spel aan.
     */
    public void maakNieuwSpel() {
        Spel nieuweSpel = new Spel(spelers);
        setSpel(nieuweSpel);
    }

    /**
     * Kijkt of de speler al in het spel zit.
     *
     * @param speler Speler object van de speler.
     * @return Boolean of de speler al in het spel zit.
     */
    private boolean isSpelerInSpel(Speler speler) {
        return spelers.contains(speler);
    }

    /**
     * Verwijder een speler uit het spel volgens de gebruikersnaam.
     *
     * @param gebruikersnaam Gebruikersnaam van de speler.
     */
    public void verwijderSpelerInSpel(String gebruikersnaam) {
        spelers.removeIf(speler -> speler.getGebruikersnaam().equals(gebruikersnaam));
    }

    /**
     * Geeft of het spel al einde is.
     *
     * @return Boolean of het spel al einde is.
     */
    public boolean isEindeSpel() {
        return spel.getIsEinde();
    }

    /**
     * Bepaalt huidige speler in spel.
     */
    public void bepaalHuidigeSpelerInSpel() {
        spel.bepaalHuidigeSpeler();
    }

    /**
     * Pak twee edelstenen dezelfde kleur.
     *
     * @param edelsteenTypeDTO EdelsteenTypeDTO.
     * @return String van wat er toegevoegd is aan huidigeSpeler.
     */
    public String pakTweeEdelstenenDezelfdeKleur(EdelsteenTypeDTO edelsteenTypeDTO) {
        EdelsteenType edelsteenType = EdelsteenType.valueOf(edelsteenTypeDTO.type().toUpperCase());
        spel.pakTweeEdelstenenDezelfdeKleur(edelsteenType);
        return String.format(MessageHelper.getString("two_gems_added"), edelsteenTypeDTO.type().toUpperCase());
    }

    /**
     * Pak drie edelstenen verschillende kleur.
     *
     * @param edelsteenTypesDTO EdelsteenTypeDTO.
     * @return String dat er toegevoegd is aan huidigeSpeler.
     */
    public String pakDrieEdelstenenVeschillendeKleur(HashSet<EdelsteenTypeDTO> edelsteenTypesDTO) {
        for (int i = 0; i < edelsteenTypesDTO.size(); i++) {
            EdelsteenTypeDTO edelsteen = (EdelsteenTypeDTO) edelsteenTypesDTO.toArray()[i];
            EdelsteenType edelsteenType = EdelsteenType.valueOf(edelsteen.type().toUpperCase());
            spel.pakDrieEdelstenenVerschillendeKleur(edelsteenType);
        }
        return MessageHelper.getString("three_gems_added");
    }

    /**
     * Voeg een Ontwikkeling toe aan een speler.
     *
     * @param id     ID van Ontwikkeling.
     * @param niveau Niveau van Ontwikkeling.
     * @throws Exception Exception.
     */
    public void voegOntwikkelingToeAanSpeler(String id, String niveau) throws Exception {
        Ontwikkeling ontwikkeling = spel.geefOntwikkeling(id, niveau);
        ontwikkeling.getKosten().forEach(kost -> {
            VoorraadKost bonus = spel.getHuidgeSpeler().getEdelsteenBonussen().stream()
                    .filter(b -> b.getType().equals(kost.getType())).findFirst().get();
            int bonusAantal = bonus.getAantal();
            if (bonusAantal < kost.getAantal() && bonusAantal != 0) {
                int restKost = kost.getAantal() - bonusAantal;
                spel.getHuidgeSpeler().verwijderEdelsteen(kost.getType(), restKost);
                spel.voegEdelsteenToe(kost.getType(), restKost);
            } else if (bonusAantal >= kost.getAantal()) {

            } else {
                spel.getHuidgeSpeler().verwijderEdelsteen(kost.getType(), kost.getAantal());
                spel.voegEdelsteenToe(kost.getType(), kost.getAantal());
            }

        });

        spel.getHuidgeSpeler().voegOntwikkelingToe(ontwikkeling);
        spel.getHuidgeSpeler().voegPrestigePuntenToe(ontwikkeling.getPrestigePunten());
        spel.verwijderOpenOntwikkeling(id, niveau);
        spel.voegEenOntwikkelingToe(niveau);
    }

    /**
     * Voeg Ontwikkeling I toe aan Open Ontwikkeling I.
     *
     * @param id ID van Ontwikkeling.
     */
    public void voegOntwikkelingIToeAanOpenOntwikkelingI(String id) {
        for (int i = 0; i < spel.getOntwikkelingI().size(); i++) {
            Ontwikkeling ontwikkeling = spel.getOntwikkelingI().get(i);
            if (ontwikkeling.getId() == id) {
                spel.vulOpenOntwikelingI(ontwikkeling);
                spel.getOntwikkelingI().removeIf(o -> o.getId() == id);
                break;
            }
        }
    }

    /**
     * Voeg Ontwikkeling II toe aan Open Ontwikkeling II.
     *
     * @param id ID van Ontwikkeling.
     */
    public void voegOntwikkelingIIToeAanOpenOntwikkelingII(String id) {
        for (int i = 0; i < spel.getOntwikkelingII().size(); i++) {
            Ontwikkeling ontwikkeling = spel.getOntwikkelingII().get(i);
            if (ontwikkeling.getId() == id) {
                spel.vulOpenOntwikelingII(ontwikkeling);
                spel.getOntwikkelingII().removeIf(o -> o.getId() == id);
                break;
            }
        }
    }

    /**
     * Voeg Ontwikkeling III toe aan Open Ontwikkeling III.
     *
     * @param id ID van Ontwikkeling.
     */
    public void voegOntwikkelingIIIToeAanOpenOntwikkelingIII(String id) {
        for (int i = 0; i < spel.getOntwikkelingIII().size(); i++) {
            Ontwikkeling ontwikkeling = spel.getOntwikkelingIII().get(i);
            if (ontwikkeling.getId() == id) {
                spel.vulOpenOntwikelingIII(ontwikkeling);
                spel.getOntwikkelingIII().removeIf(o -> o.getId() == id);
                break;
            }
        }
    }

    /**
     * Kijk of speler een ontwikkeling met bepaalde ID kan kopen.
     *
     * @param id     ID van Ontwikkeling.
     * @param niveau Niveau van Ontwikkeling.
     * @return Boolean of speler een ontwikkeling kan kopen.
     */
    public boolean kanHuidigeSpelerOntwikkelingKopen(String id, String niveau) {
        return spel.kanHuidigeSpelerOntwikkelingKopen(id, niveau);
    }

    /**
     * Kijk of speler een edele met bepaalde ID kan krijgen
     *
     * @param id ID van Edele
     * @return Boolean of speler een edele kan krijgen
     */
    public boolean kanHuidigeSpelerEdeleKrijgen(String id) {
        return spel.kanHuidigeSpelerEdeleKrijgen(id);
    }

    /**
     * Voeg een edele toe aan speler.
     * @param id ID van Edele.
     */
    public void voegEdeleToeAanSpeler(String id) {
        Edele edele = spel.geefEdele(id);
        spel.getHuidgeSpeler().voegEdeleToe(edele);
    }
}