package domein;

import exceptions.OntwikkelingOngeldigeIdException;
import exceptions.OntwikkelingOngeldigeKostenException;
import exceptions.OntwikkelingOngeldigeNiveauException;
import utils.MessageHelper;

import java.util.ArrayList;

/**
 * Representeert een ontwikkeling met bijbehorende eigenschappen en functionaliteiten.
 */
public class Ontwikkeling {

    private String id;
    private int prestigePunten;
    private EdelsteenType bonusType;
    private int niveau;
    private ArrayList<VoorraadKost> kosten = new ArrayList<>();

    /**
     * Constructor voor ontwikkeling, waar alle eigenschappen opgegeven worden.
     *
     * @param id       ID van ontwikkeling
     * @param prestige Prestige van ontwikkeling
     * @param type     EdelsteenType van ontwikkeling
     * @param niveau   Niveau van ontwikkeling
     * @param kosten   Kosten van ontwikkeling
     */
    public Ontwikkeling(String id, int prestige, EdelsteenType type, int niveau, ArrayList<VoorraadKost> kosten) {
        setId(id);
        setPrestigePunten(prestige);
        setBonusType(type);
        setNiveau(niveau);
        setKosten(kosten);
    }

    // region Getters

    /**
     * Getter voor ID van ontwikkeling.
     *
     * @return ID van ontwikkeling in string
     */
    public String getId() {
        return id;
    }

    /**
     * Getter voor Prestige van ontwikkeling.
     *
     * @return Prestige van ontwikkeling in int
     */
    public int getPrestigePunten() {
        return prestigePunten;
    }

    /**
     * Getter voor EdelsteenType bonus van ontwikkeling.
     *
     * @return EdelsteenType bonus van ontwikkeling in EdelsteenType
     */
    public EdelsteenType getBonusType() {
        return bonusType;
    }

    /**
     * Getter voor Niveau van ontwikkeling.
     *
     * @return Niveau van ontwikkeling in int
     */
    public int getNiveau() {
        return niveau;
    }

    /**
     * Getter voor Kosten van ontwikkeling.
     *
     * @return Kosten van ontwikkeling in lijst VoorraadKosten
     */
    public ArrayList<VoorraadKost> getKosten() {
        return kosten;
    }
    // endregion

    // region Setters

    /**
     * Setter voor ID van ontwikkeling.
     *
     * @param id ID van ontwikkeling in string
     */
    private void setId(String id) {
        if (id.isEmpty() || id.isBlank())
            throw new OntwikkelingOngeldigeIdException(MessageHelper.getString("exception_developmentid_invalid"));
        this.id = id;
    }

    /**
     * Setter voor Prestige van ontwikkeling.
     *
     * @param niveau Prestige van ontwikkeling in int
     */
    private void setNiveau(int niveau) {
        if (niveau > 3 || niveau < 1)
            throw new OntwikkelingOngeldigeNiveauException(MessageHelper.getString("exception_developmentlevel_invalid"));
        this.niveau = niveau;
    }

    /**
     * Setter voor EdelsteenType bonus van ontwikkeling.
     *
     * @param bonusType EdelsteenType bonus van ontwikkeling in EdelsteenType
     */
    private void setBonusType(EdelsteenType bonusType) {
        this.bonusType = bonusType;
    }

    /**
     * Setter voor Prestige van ontwikkeling.
     *
     * @param punten Prestige van ontwikkeling in int
     */
    private void setPrestigePunten(int punten) {
        this.prestigePunten = punten;
    }

    /**
     * Setter voor Kosten van ontwikkeling.
     *
     * @param kosten kosten van ontwikkeling in lijst VoorraadKosten
     */
    public void setKosten(ArrayList<VoorraadKost> kosten) {
        if (kosten == null)
            throw new OntwikkelingOngeldigeKostenException(MessageHelper.getString("exception_developmentcosts_invalid"));
        this.kosten = kosten;
    }

    // endregion

    /**
     * toString methode voor ontwikkeling.
     *
     * @return String met ontwikkeling informatie
     */
    @Override
    public String toString() {
        String ontwikkelingLabel = MessageHelper.getString("card_development");
        String prestigeLabel = MessageHelper.getString("prestige_points");
        String typeLabel = MessageHelper.getString("type");
        String levelLabel = MessageHelper.getString("level");
        String kostenLabel = MessageHelper.getString("costs");

        StringBuilder kostenString = new StringBuilder();
        for (VoorraadKost kost : kosten) {
            kostenString.append(String.format("- %d %s%n", kost.getAantal(), kost.getType()));
        }

        return String.format("%s%n%s%n%s: %d%n%s: %s%n%s: %d%n%s:%n%s",
                ontwikkelingLabel, "----------------",
                prestigeLabel, prestigePunten,
                typeLabel, bonusType,
                levelLabel, niveau,
                kostenLabel, kostenString);
    }

}
