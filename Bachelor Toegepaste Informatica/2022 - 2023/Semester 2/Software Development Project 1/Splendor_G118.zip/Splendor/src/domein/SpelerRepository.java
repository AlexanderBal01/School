package domein;

import exceptions.SpelerNietGevondenException;
import persistentie.SpelerMapper;

/**
 * Representeert een spelerRepository om spelers uit de database te halen.
 */
public class SpelerRepository {
    private final SpelerMapper mapper;

    /**
     * Constructor voor een spelerRepository, waar de mapper wordt aangemaakt.
     */
    public SpelerRepository() {
        mapper = new SpelerMapper();
    }

    /** Geeft true terug als de gebruikersnaam al in de database staat.
     * @param gebruikersnaam gebruikersnaam van de speler
     * @return boolean of de gebruikersnaam al in de database staat.
     */
    private boolean bestaatSpeler(String gebruikersnaam) {
        return mapper.bestaatSpelerDB(gebruikersnaam);
    }

    /**
     * Geeft een speler terug als deze in de database staat.
     * @param gebruikersnaam gebruikersnaam van de speler
     * @throws SpelerNietGevondenException als de speler niet in de database staat.
     * @return Speler als de speler in de database staat.
     */
    public Speler geefSpeler(String gebruikersnaam) {
        if (!bestaatSpeler(gebruikersnaam)) {
            throw new SpelerNietGevondenException("Deze gebruikersnaam bestaat niet.");
        }
        return mapper.geefSpelerDB(gebruikersnaam);
    }
}
