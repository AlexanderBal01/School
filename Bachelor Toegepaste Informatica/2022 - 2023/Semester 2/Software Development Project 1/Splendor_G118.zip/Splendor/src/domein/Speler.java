package domein;

import exceptions.GeboortejaarException;
import exceptions.GebruikersnaamException;
import utils.MessageHelper;

import java.time.Year;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * Representeert een speler met bijbehorende eigenschappen en functionaliteiten.
 */
public class Speler {
    private String gebruikersnaam;
    private int geboortejaar;

    private boolean isStartSpeler;
    private boolean isMijnBeurt;

    private Set<VoorraadKost> edelstenen;
    private Set<VoorraadKost> edelsteenBonussen;

    private ArrayList<Edele> edelen;
    private ArrayList<Ontwikkeling> ontwikkelingen;

    private int prestigePunten;

    /**
     * Constructor voor een speler
     *
     * @param gebruikersnaam String met gebruikersnaam
     * @param geboortejaar   int met geboortejaar
     */
    public Speler(String gebruikersnaam, int geboortejaar) {
        setGebruikersnaam(gebruikersnaam);
        setGeboortejaar(geboortejaar);
        setEdelen(new ArrayList<>());
        setEdelstenen(vulEdelstenen());
        setOntwikkelingen(new ArrayList<>());
        setEdelsteenBonussen(vulEdelstenen());
        setPrestigePunten(0);
    }

    // region Getters

    /**
     * Getter voor gebruikersnaam
     *
     * @return String met gebruikersnaam
     */
    public String getGebruikersnaam() {
        return this.gebruikersnaam;
    }

    /**
     * Getter voor geboortejaar
     *
     * @return int met geboortejaar
     */
    public int getGeboortejaar() {
        return this.geboortejaar;
    }

    /**
     * Getter voor attribute of speler start speler is
     *
     * @return boolean met true als speler start speler is
     */
    public boolean isStartSpeler() {
        return isStartSpeler;
    }

    /**
     * Getter voor attribute of speler beurt is
     *
     * @return boolean met true als speler beurt is
     */
    public boolean isMijnBeurt() {
        return isMijnBeurt;
    }

    /**
     * Getter voor lijst van ontwikkelingen van speler
     *
     * @return lijst Ontwikkeling
     */
    public ArrayList<Ontwikkeling> getOntwikkelingen() {
        return ontwikkelingen;
    }

    /**
     * Getter voor lijst van edelen van speler
     *
     * @return lijst Edele
     */
    public ArrayList<Edele> getEdelen() {
        return edelen;
    }

    /**
     * Getter voor lijst van edelstenen van speler
     *
     * @return lijst VoorraadKost
     */
    public Set<VoorraadKost> getEdelstenen() {
        return edelstenen;
    }

    /**
     * Getter voor lijst van edelsteenBonussen van speler
     *
     * @return lijst voorraden
     */
    public Set<VoorraadKost> getEdelsteenBonussen() {
        return edelsteenBonussen;
    }

    /**
     * Getter voor prestigePunten
     *
     * @return prestigePunten
     */
    public int getPrestigePunten() {
        return prestigePunten;
    }

    // endregion

    // region Setters

    /**
     * Setter voor edelsteenBonussen van speler
     *
     * @param edelsteenBonussen lijst met voorraden
     */
    private void setEdelsteenBonussen(Set<VoorraadKost> edelsteenBonussen) {
        this.edelsteenBonussen = edelsteenBonussen;
    }

    /**
     * Setter voor edelen van speler
     *
     * @param edelen lijst met Edele
     */
    private void setEdelen(ArrayList<Edele> edelen) {
        this.edelen = edelen;
    }

    /**
     * Setter voor ontwikkelingen van speler
     *
     * @param ontwikkelingen lijst met Ontwikkeling
     */
    public void setOntwikkelingen(ArrayList<Ontwikkeling> ontwikkelingen) {
        this.ontwikkelingen = ontwikkelingen;
    }

    /**
     * Setter voor gebruikersnaam
     *
     * @param gebruikersnaam String met gebruikersnaam
     */
    private void setGebruikersnaam(String gebruikersnaam) {
        if (!isGeldigGebruikersnaam(gebruikersnaam))
            throw new GebruikersnaamException(MessageHelper.getString("exception_set_username"));
        this.gebruikersnaam = gebruikersnaam;
    }

    /**
     * Setter voor geboortejaar
     *
     * @param geboortejaar int met geboortejaar
     */
    private void setGeboortejaar(int geboortejaar) {
        if (!isGeldigGeboortejaar(geboortejaar))
            throw new GeboortejaarException(MessageHelper.getString("exception_set_birthyear"));
        this.geboortejaar = geboortejaar;
    }

    /**
     * Setter voor attribute of speler start speler is
     *
     * @param startSpeler boolean met true als speler start speler is
     */

    public void setStartSpeler(boolean startSpeler) {
        isStartSpeler = startSpeler;
    }

    /**
     * Setter voor attribute of speler beurt is
     *
     * @param mijnBeurt boolean met true als speler beurt is
     */
    public void setMijnBeurt(boolean mijnBeurt) {
        isMijnBeurt = mijnBeurt;
    }

    /**
     * Setter voor lijst van edelstenen van speler
     *
     * @param edelstenen Set met VoorraadKost
     */
    public void setEdelstenen(Set<VoorraadKost> edelstenen) {
        this.edelstenen = edelstenen;
    }

    /**
     * Setter voor prestigePunten
     *
     * @param prestigePunten int met 0
     */
    public void setPrestigePunten(int prestigePunten) {
        this.prestigePunten = prestigePunten;
    }
    // endregion

    /**
     * Voeg PrestigePunten toe aan speler
     *
     * @param prestigePunten int met PrestigePunten
     */
    public void voegPrestigePuntenToe(int prestigePunten) {
        this.prestigePunten += prestigePunten;
    }

    /**
     * Geeft aantal prestig punten van speler
     *
     * @return int met aantal prestig punten van Edelen
     */
    public int geefPrestigPuntenEdele() {
        return edelen.stream().mapToInt(Edele::getPrestigePunten).sum();
    }

    /**
     * Checkt of gebruikersnaam geldig is.
     *
     * @param gebruikersnaam String met gebruikersnaam
     * @return boolean met true als gebruikersnaam geldig is
     */
    private Boolean isGeldigGebruikersnaam(String gebruikersnaam) {
        Pattern regex = Pattern.compile("^[a-zA-Z][a-zA-Z0-9_\\s]*$");
        Matcher match = regex.matcher(gebruikersnaam);

        return match.find();
    }

    /**
     * Checkt of geboortejaar geldig is.
     *
     * @param geboortejaar int met geboortejaar
     * @return boolean met true als geboortejaar geldig is
     */
    private Boolean isGeldigGeboortejaar(Integer geboortejaar) {
        int currentYear = Year.now().getValue();
        int leeftijd = currentYear - geboortejaar;
        return leeftijd >= 6;
    }

    /**
     * Voeg een edelsteen toe aan de voorraad van een edelsteen type
     *
     * @param type   EdelsteenType
     * @param aantal gewenste aantal
     */
    public void voegEdelstenenToe(EdelsteenType type, int aantal) {
        edelstenen.stream()
                .filter(gem -> gem.getType() == type)
                .findFirst()
                .ifPresent(gem -> gem.setAantal(gem.getAantal() + aantal));
    }

    /**
     * Verwijder een edelsteen van de voorraad van een edelsteen type
     *
     * @param type   EdelsteenType
     * @param aantal gewenste aantal
     */
    public void verwijderEdelsteen(EdelsteenType type, int aantal) {
        edelstenen.stream()
                .filter(gem -> gem.getType() == type)
                .findFirst()
                .ifPresent(gem -> gem.setAantal(gem.getAantal() - aantal));
    }

    /**
     * Set edelstenen worden op 0 gezet.
     *
     * @return een nieuwe set met voorraadkosten van edelstenen
     */
    private Set<VoorraadKost> vulEdelstenen() {
        return new HashSet<>(List.of(
                new VoorraadKost(EdelsteenType.DIAMANT, 0),
                new VoorraadKost(EdelsteenType.SAFFIER, 0),
                new VoorraadKost(EdelsteenType.SMARAGD, 0),
                new VoorraadKost(EdelsteenType.ROBIJN, 0),
                new VoorraadKost(EdelsteenType.ONYX, 0)
        ));
    }

    /**
     * Voegt ontwikkeling toe aan speler
     *
     * @param ontwikkeling Ontwikkeling
     */
    public void voegOntwikkelingToe(Ontwikkeling ontwikkeling) {
        ontwikkelingen.add(ontwikkeling);
        voegBonusToe(ontwikkeling.getBonusType());

    }

    private void voegBonusToe(EdelsteenType bonusType) {
        edelsteenBonussen.stream()
                .filter(bonus -> bonus.getType().equals(bonusType))
                .findFirst()
                .ifPresent(bonus -> bonus.setAantal(bonus.getAantal() + 1));
    }

    /**
     * Overzicht van speler met alle eigenschappen
     *
     * @return String met alle eigenschappen van speler
     */
    public String spelerOverzicht() {
        String lblSpeler = MessageHelper.getString("player");
        String lblDiamant = MessageHelper.getString("gems_diamond");
        String lblSaffier = MessageHelper.getString("gems_sapphire");
        String lblSmaragd = MessageHelper.getString("gems_emerald");
        String lblRabijn = MessageHelper.getString("gems_ruby");
        String lblOnyx = MessageHelper.getString("gems_onxy");
        String lblOntwikkeling = MessageHelper.getString("card_developments");

        int aantalDiamant = edelstenen.stream()
                .filter(gem -> gem.getType() == EdelsteenType.DIAMANT)
                .findFirst()
                .map(gem -> gem.getAantal())
                .orElse(0);
        int aantalSaffier = edelstenen.stream()
                .filter(gem -> gem.getType() == EdelsteenType.SAFFIER)
                .findFirst()
                .map(gem -> gem.getAantal())
                .orElse(0);

        int aantalSmaragd = edelstenen.stream()
                .filter(gem -> gem.getType() == EdelsteenType.SAFFIER)
                .findFirst()
                .map(gem -> gem.getAantal())
                .orElse(0);

        int aantalRabijn = edelstenen.stream()
                .filter(gem -> gem.getType() == EdelsteenType.ROBIJN)
                .findFirst()
                .map(gem -> gem.getAantal())
                .orElse(0);
        int aantalOnyx = edelstenen.stream()
                .filter(gem -> gem.getType() == EdelsteenType.ONYX)
                .findFirst()
                .map(gem -> gem.getAantal())
                .orElse(0);

        String developmentCards = ontwikkelingen.stream()
                .map(Ontwikkeling::toString)
                .collect(Collectors.joining("\n "));

        String playerInfo = String.format("%s: %s (%d)",
                lblSpeler, gebruikersnaam, geboortejaar);

        String gemInfo = String.format(
                "- %s: %2d\t- %s: %2d%n" +
                        "- %s: %2d\t- %s: %4d\t- %s: %2d",
                lblDiamant, aantalDiamant,
                lblSaffier, aantalSaffier,
                lblSmaragd, aantalSmaragd,
                lblRabijn, aantalRabijn,
                lblOnyx, aantalOnyx
        );


        String developmentInfo = String.format("- %s: \n%s", lblOntwikkeling, developmentCards);

        return String.join("\n", playerInfo, gemInfo, developmentInfo);
    }

    // region Overrides
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Speler speler)) return false;
        return getGeboortejaar() == speler.getGeboortejaar() && Objects.equals(getGebruikersnaam(), speler.getGebruikersnaam());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getGebruikersnaam(), getGeboortejaar());
    }

    @Override
    public String toString() {
        return gebruikersnaam + " " + geboortejaar;
    }

    /**
     * Voegt een Edele toe aan de lijst met Edelen
     *
     * @param edele Edele
     */
    public void voegEdeleToe(Edele edele) {
        edelen.add(edele);
        voegPrestigePuntenToe(edele.getPrestigePunten());
    }
    //endregion
}