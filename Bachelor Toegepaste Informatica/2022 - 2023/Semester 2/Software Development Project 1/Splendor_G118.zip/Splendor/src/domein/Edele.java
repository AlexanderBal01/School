package domein;

import exceptions.EdelPrestigePuntenException;
import exceptions.EdelVereisteBonussenException;
import exceptions.EdeleOngeldigeIdException;
import utils.MessageHelper;

import java.util.ArrayList;

/**
 * Representeert een edele met bijbehorende eigenschappen en functionaliteiten.
 */
public class Edele {

    private String id;
    private int prestigePunten;
    private ArrayList<VoorraadKost> vereisteBonussen;

    /**
     * Constructor voor een Edele
     * @param prestigePunten PrestigePunten van de Edele
     * @param vereisteBonussen VereisteBonussen van de Edele
     * @param id Id van de Edele
     */
    public Edele(int prestigePunten, ArrayList<VoorraadKost> vereisteBonussen, String id) {
        setId(id);
        setPrestigePunten(prestigePunten);
        setVereisteBonussen(vereisteBonussen);
    }

    /**
     * Getter voor PrestigePunten
     *
     * @return PrestigePunten
     */
    public int getPrestigePunten() {
        return prestigePunten;
    }

    /**
     * Setter voor PrestigePunten
     *
     * @param prestigePunten PrestigePunten van de Edele
     * @throws EdelPrestigePuntenException Exception wanneer PrestigePunten niet 3 zijn
     */
    public void setPrestigePunten(int prestigePunten) {
        if (prestigePunten != 3)
            throw new EdelPrestigePuntenException(MessageHelper.getString("exception_noblepoints_invalid"));
        this.prestigePunten = prestigePunten;
    }

    /**
     * Getter voor VereisteBonussen
     *
     * @return VereisteBonussen
     */
    public ArrayList<VoorraadKost> getVereisteBonussen() {
        return vereisteBonussen;
    }

    /**
     * Setter voor VereisteBonussen
     *
     * @param vereisteBonussen VereisteBonussen van de Edele
     * @throws EdelVereisteBonussenException Exception wanneer VereisteBonussen null zijn
     */
    public void setVereisteBonussen(ArrayList<VoorraadKost> vereisteBonussen) {
        if (vereisteBonussen == null)
            throw new EdelVereisteBonussenException(MessageHelper.getString("exception_noblebonus_invalid"));
        this.vereisteBonussen = vereisteBonussen;
    }

    /**
     * Getter voor id
     *
     * @return id
     */
    public String getId() {
        return id;
    }

    /**
     * Setter voor id
     *
     * @param id id van de Edele
     */
    public void setId(String id) {
        if (id.isEmpty() || id.isBlank())
            throw new EdeleOngeldigeIdException(MessageHelper.getString("exception_nobleid_invalid"));
        this.id = id;
    }

    /**
     * toString methode voor een Edele
     *
     * @return Edele als String
     */
    @Override
    public String toString() {
        String edeleLabel = MessageHelper.getString("card_noble");
        String prestigeLabel = MessageHelper.getString("prestige_points");
        String kostenLabel = MessageHelper.getString("costs");

        StringBuilder kostenString = new StringBuilder();
        for (VoorraadKost kost : vereisteBonussen) {
            kostenString.append(String.format("- %d %s%n", kost.getAantal(), kost.getType()));
        }
        return String.format("%s%n%s%n%s: %d%n%s: %s",
                edeleLabel, "----------------",
                prestigeLabel, prestigePunten,
                kostenLabel, kostenString);

    }

}