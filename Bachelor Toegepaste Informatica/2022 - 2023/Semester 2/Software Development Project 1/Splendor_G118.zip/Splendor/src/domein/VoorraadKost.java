package domein;

/**
 * Representeert een voorraadKost met bijbehorende eigenschappen en functionaliteiten.
 */
public class VoorraadKost {
    private EdelsteenType type;
    private int aantal;

    /**
     * Constructor voor voorraadkost, waar het type en aantal worden ingevuld.
     * @param type EdelsteenType
     * @param aantal gewenste aantal van het type
     */
    public VoorraadKost(EdelsteenType type, int aantal) {
        setType(type);
        setAantal(aantal);
    }

    // region Getters

    /**
     * Getter voor type van edelsteen in voorraadkost.
     * @return EdelsteenType
     */
    public EdelsteenType getType() {
        return type;
    }

    /**
     * Getter voor aantal van edelsteen in voorraadkost.
     * @return int
     */
    public int getAantal() {
        return aantal;
    }
    // endregion

    // region Setters

    /**
     * Setter voor type van edelsteen in voorraadkost.
     * @param type EdelsteenType
     */
    public void setType(EdelsteenType type) {
        this.type = type;
    }

    /**
     * Setter voor aantal van edelsteen in voorraadkost.
     * @param aantal gewenste aantal van het type
     */
    public void setAantal(int aantal) {
        this.aantal = aantal;
    }
    // endregion

    // region overrides

    /**
     * toString voor voorraadkost.
     */
    @Override
    public String toString() {
        return "VoorraadKost{" +
                "type:" + type +
                ", aantal:" + aantal +
                '}';
    }
    // endregion
}
