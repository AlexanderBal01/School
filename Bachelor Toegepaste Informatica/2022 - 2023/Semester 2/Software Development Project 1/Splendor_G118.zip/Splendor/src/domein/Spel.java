package domein;

import exceptions.MaximumAantalSpelerException;
import exceptions.MinimumAantalSpelerException;
import exceptions.OnvoldoendeEdelstenenException;
import utils.MessageHelper;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

/**
 * Representeert een spel met bijbehorende eigenschappen en functionaliteiten.
 */
public class Spel {
    private final int MIN_AANTAL_SPELERS = 2;
    private final int MAX_AANTAL_SPELERS = 4;

    private ArrayList<Speler> spelers;
    private ArrayList<Speler> winnaars;
    private int rondeNummer = 0;
    private boolean isEinde;
    private Speler huidigeSpeler;

    private ArrayList<Edele> edelen;
    private Set<VoorraadKost> edelstenen;
    private ArrayList<Ontwikkeling> ontwikkelingI;
    private ArrayList<Ontwikkeling> ontwikkelingII;
    private ArrayList<Ontwikkeling> ontwikkelingIII;
    private ArrayList<Ontwikkeling> openOntwikelingI;
    private ArrayList<Ontwikkeling> openOntwikelingII;
    private ArrayList<Ontwikkeling> openOntwikelingIII;

    /**
     * Constructor van spel waar de spelers en de edelstenen worden ingevuld.
     *
     * @param spelers De spelers die toegevoegd zijn aan het spel.
     */
    public Spel(ArrayList<Speler> spelers) {
        setEinde(false);
        setSpelers(spelers);
        setOntwikkelingI(new ArrayList<>());
        setOntwikkelingII(new ArrayList<>());
        setOntwikkelingIII(new ArrayList<>());
        setEdelen(new ArrayList<>());
        setEdelstenen(new HashSet<>());
        setOpenOntwikelingI(new ArrayList<>());
        setOpenOntwikelingII(new ArrayList<>());
        setOpenOntwikelingIII(new ArrayList<>());
        setWinnaars(new ArrayList<>());

        switch (spelers.size()) {
            case 2 -> {
                VulEdelstenen(4, edelstenen);
                vulOntwikkeling(1, ontwikkelingI);
                vulOntwikkeling(2, ontwikkelingII);
                vulOntwikkeling(3, ontwikkelingIII);
                vulEdelen(3, edelen);
            }
            case 3 -> {
                VulEdelstenen(5, edelstenen);
                vulOntwikkeling(1, ontwikkelingI);
                vulOntwikkeling(2, ontwikkelingII);
                vulOntwikkeling(3, ontwikkelingIII);
                vulEdelen(4, edelen);
            }
            case 4 -> {
                VulEdelstenen(7, edelstenen);
                vulOntwikkeling(1, ontwikkelingI);
                vulOntwikkeling(2, ontwikkelingII);
                vulOntwikkeling(3, ontwikkelingIII);
                vulEdelen(5, edelen);
            }
        }
        Collections.shuffle(ontwikkelingI);
        Collections.shuffle(ontwikkelingII);
        Collections.shuffle(ontwikkelingIII);
        Collections.shuffle(edelen);
        bepaalHuidigeSpeler();
    }

    //region Getters

    /**
     * Getter voor min aantal spelers.
     *
     * @return Het minimum aantal spelers.
     */
    public int getMIN_AANTAL_SPELERS() {
        return MIN_AANTAL_SPELERS;
    }

    /**
     * Getter voor max aantal spelers.
     *
     * @return Het maximum aantal spelers.
     */
    public int getMAX_AANTAL_SPELERS() {
        return MAX_AANTAL_SPELERS;
    }

    /**
     * Getter voor huidige speler.
     *
     * @return Huidige speler.
     */
    public Speler getHuidgeSpeler() {
        return huidigeSpeler;
    }

    /**
     * Getter voor spelers.
     *
     * @return lijst van de spelers
     */
    public ArrayList<Speler> getSpelers() {
        return spelers;
    }

    /**
     * Getter voor ronde nummer.
     *
     * @return Het ronde nummer.
     */
    public int getRondeNummer() {
        return rondeNummer;
    }

    /**
     * Getter voor edelen.
     *
     * @return Edelen van de spel.
     */
    public ArrayList<Edele> getEdelen() {
        return edelen;
    }

    /**
     * Getter voor ontwikkelingI.
     *
     * @return ontwikkelingI van de spel.
     */
    public ArrayList<Ontwikkeling> getOntwikkelingI() {
        return ontwikkelingI;
    }

    /**
     * Getter voor ontwikkelingII.
     *
     * @return ontwikkelingII van de spel.
     */
    public ArrayList<Ontwikkeling> getOntwikkelingII() {
        return ontwikkelingII;
    }

    /**
     * Getter voor ontwikkelingIII.
     *
     * @return ontwikkelingIII van de spel.
     */
    public ArrayList<Ontwikkeling> getOntwikkelingIII() {
        return ontwikkelingIII;
    }

    /**
     * Getter voor winnaar.
     * Als er geen winnaar is, wordt null teruggegeven.
     *
     * @return Het winnaar van de spel.
     */
    public ArrayList<Speler> getWinnaars() {
        return winnaars;
    }

    /**
     * Getter voor isEinde.
     *
     * @return Boolean om te zien of de spel is afgelopen.
     */
    public boolean getIsEinde() {
        return isEinde;
    }

    /**
     * Getter voor edelstenen.
     *
     * @return Edelstenen van de spel.
     */
    public Set<VoorraadKost> getEdelstenen() {
        return edelstenen;
    }

    /**
     * Getter voor openOntwikelingI.
     *
     * @return Open ontwikkelingI van de spel.
     */
    public ArrayList<Ontwikkeling> getOpenOntwikelingI() {
        return openOntwikelingI;
    }

    /**
     * Getter voor openOntwikelingII.
     *
     * @return Open ontwikkelingII van de spel.
     */
    public ArrayList<Ontwikkeling> getOpenOntwikelingII() {
        return openOntwikelingII;
    }

    /**
     * Getter voor openOntwikelingIII.
     *
     * @return Open ontwikkelingIII van de spel.
     */
    public ArrayList<Ontwikkeling> getOpenOntwikelingIII() {
        return openOntwikelingIII;
    }

    //endregion

    //region Setters

    /**
     * Setter voor huidige speler.
     *
     * @param huidgeSpeler Huidige speler.
     */
    public void setHuidgeSpeler(Speler huidgeSpeler) {
        this.huidigeSpeler = huidgeSpeler;
    }

    /**
     * Setter voor spelers.
     *
     * @param spelers Spelers van de spel.
     */
    private void setSpelers(ArrayList<Speler> spelers) {
        if (spelers == null) throw new MinimumAantalSpelerException(MessageHelper.getString("exception_min_players"));
        if (spelers.size() > 4)
            throw new MaximumAantalSpelerException(MessageHelper.getString("exception_max_players"));
        if (spelers.size() < 2)
            throw new MinimumAantalSpelerException(MessageHelper.getString("exception_min_players"));
        this.spelers = (ArrayList<Speler>) sorteerSpelers(spelers);
    }

    /**
     * Setter voor ontwikkelingI van het spel.
     *
     * @param ontwikkelingI lijst van onwikkelingI kaarten
     */
    public void setOntwikkelingI(ArrayList<Ontwikkeling> ontwikkelingI) {
        this.ontwikkelingI = ontwikkelingI;
    }

    /**
     * Setter voor ontwikkelingII van het spel.
     *
     * @param ontwikkelingII lijst van onwikkelingII kaarten
     */
    public void setOntwikkelingII(ArrayList<Ontwikkeling> ontwikkelingII) {
        this.ontwikkelingII = ontwikkelingII;
    }

    /**
     * Setter voor ontwikkelingIII van het spel.
     *
     * @param ontwikkelingIII lijst van onwikkelingIII kaarten
     */
    public void setOntwikkelingIII(ArrayList<Ontwikkeling> ontwikkelingIII) {
        this.ontwikkelingIII = ontwikkelingIII;
    }

    /**
     * Setter voor edelen van het spel.
     *
     * @param edelen Edelen van het spel.
     */
    public void setEdelen(ArrayList<Edele> edelen) {
        this.edelen = edelen;
    }

    /**
     * Setter voor edelstenen van het spel.
     *
     * @param edelstenen Set met edelstenen van het spel.
     */
    private void setEdelstenen(Set<VoorraadKost> edelstenen) {
        this.edelstenen = edelstenen;
    }

    /**
     * Setter voor isEinde van het spel.
     *
     * @param einde Boolean om te zien of het spel is afgelopen.
     */
    private void setEinde(boolean einde) {
        isEinde = einde;
    }

    /**
     * Setter voor openOntwikelingI van het spel.
     *
     * @param openOntwikelingI lijst van open onwikkelingI kaarten
     */
    private void setOpenOntwikelingI(ArrayList<Ontwikkeling> openOntwikelingI) {
        this.openOntwikelingI = openOntwikelingI;
    }

    /**
     * Setter voor openOntwikelingII van het spel.
     *
     * @param openOntwikelingII lijst van open onwikkelingII kaarten
     */
    private void setOpenOntwikelingII(ArrayList<Ontwikkeling> openOntwikelingII) {
        this.openOntwikelingII = openOntwikelingII;
    }

    /**
     * Setter voor openOntwikelingIII van het spel.
     *
     * @param openOntwikelingIII lijst van open onwikkelingIII kaarten
     */
    private void setOpenOntwikelingIII(ArrayList<Ontwikkeling> openOntwikelingIII) {
        this.openOntwikelingIII = openOntwikelingIII;
    }

    private void setWinnaars(ArrayList<Speler> winnaars) {
        this.winnaars = winnaars;
    }
    //endregion

    //region vulMethoden

    /**
     * Vult de ontwikkeling met de juiste data.
     *
     * @param ontwikkelingNiveau Niveau van de ontwikkeling.
     * @param ontwikkeling       ArrayList met de ontwikkeling.
     */
    private void vulOntwikkeling(int ontwikkelingNiveau, ArrayList<Ontwikkeling> ontwikkeling) {
        try (BufferedReader br = new BufferedReader(new FileReader("./src/resources/ontwikkelingen.csv"))) {
            br.readLine();
            String line;
            while ((line = br.readLine()) != null) {
                String[] values = line.split(",");

                int niveau = Integer.parseInt(values[0]);
                if (niveau != ontwikkelingNiveau) continue;
                int prestige = Integer.parseInt(values[2]);
                EdelsteenType type = EdelsteenType.valueOf(values[1]);

                int aantalOnyx = Integer.parseInt(values[3]);
                int aantalSaffier = Integer.parseInt(values[4]);
                int aantalSmaragd = Integer.parseInt(values[5]);
                int aantalRobijn = Integer.parseInt(values[6]);
                int aantalDiamant = Integer.parseInt(values[7]);
                String id = values[8];

                ArrayList<VoorraadKost> kosten = new ArrayList<>();
                kosten.add(new VoorraadKost(EdelsteenType.ONYX, aantalOnyx));
                kosten.add(new VoorraadKost(EdelsteenType.SAFFIER, aantalSaffier));
                kosten.add(new VoorraadKost(EdelsteenType.SMARAGD, aantalSmaragd));
                kosten.add(new VoorraadKost(EdelsteenType.ROBIJN, aantalRobijn));
                kosten.add(new VoorraadKost(EdelsteenType.DIAMANT, aantalDiamant));

                ontwikkeling.add(new Ontwikkeling(id, prestige, type, niveau, kosten));
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Vult de edelen met de juiste data.
     *
     * @param aantalEdel Aantal edelen die worden ingeladen
     * @param edelen     ArrayList met de edelen.
     */
    private void vulEdelen(int aantalEdel, ArrayList<Edele> edelen) {
        try (BufferedReader br = new BufferedReader(new FileReader("./src/resources/edelen.csv"))) {
            br.readLine();
            String line;
            while ((line = br.readLine()) != null && edelen.size() < aantalEdel) {
                String[] values = line.split(",");

                int prestige = Integer.parseInt(values[0]);

                int aantalOnyx = Integer.parseInt(values[1]);
                int aantalSaffier = Integer.parseInt(values[2]);
                int aantalSmaragd = Integer.parseInt(values[3]);
                int aantalRobijn = Integer.parseInt(values[4]);
                int aantalDiamant = Integer.parseInt(values[5]);
                String id = values[6];

                ArrayList<VoorraadKost> vereisteBonussen = new ArrayList<>();
                vereisteBonussen.add(new VoorraadKost(EdelsteenType.ONYX, aantalOnyx));
                vereisteBonussen.add(new VoorraadKost(EdelsteenType.SAFFIER, aantalSaffier));
                vereisteBonussen.add(new VoorraadKost(EdelsteenType.SMARAGD, aantalSmaragd));
                vereisteBonussen.add(new VoorraadKost(EdelsteenType.ROBIJN, aantalRobijn));
                vereisteBonussen.add(new VoorraadKost(EdelsteenType.DIAMANT, aantalDiamant));

                edelen.add(new Edele(prestige, vereisteBonussen, id));
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Vult de edelstenen met de juiste data.
     *
     * @param aantal     aantal edelstenen die worden ingeladen.
     * @param edelstenen Set voorraadkosten voor de edelstenen.
     */
    private void VulEdelstenen(int aantal, Set<VoorraadKost> edelstenen) {
        EdelsteenType[] edelsteenTypes = EdelsteenType.values();
        for (EdelsteenType edelsteenType : edelsteenTypes) {
            edelstenen.add(new VoorraadKost(edelsteenType, aantal));
        }
    }

    /**
     * Vult open ontwikkelingen niveau I met een Ontwikkeling.
     *
     * @param openOntwikkeling Ontwikkeling die wordt toegevoegd aan de open ontwikkelingen.
     */
    public void vulOpenOntwikelingI(Ontwikkeling openOntwikkeling) {
        this.openOntwikelingI.add(openOntwikkeling);
    }

    /**
     * Vult open ontwikkelingen niveau II met een Ontwikkeling.
     *
     * @param openOntwikkeling Ontwikkeling die wordt toegevoegd aan de open ontwikkelingen.
     */
    public void vulOpenOntwikelingII(Ontwikkeling openOntwikkeling) {
        this.openOntwikelingII.add(openOntwikkeling);
    }

    /**
     * Vult open ontwikkelingen niveau III met een Ontwikkeling.
     *
     * @param openOntwikkeling Ontwikkeling die wordt toegevoegd aan de open ontwikkelingen.
     */
    public void vulOpenOntwikelingIII(Ontwikkeling openOntwikkeling) {
        this.openOntwikelingIII.add(openOntwikkeling);
    }
    //endregion

    /**
     * Bepaalt de huidige speler en verandert de beurt.
     */
    public void bepaalHuidigeSpeler() {
        if (huidigeSpeler == null) {
            huidigeSpeler = spelers.get(0);
            huidigeSpeler.setMijnBeurt(true);
            return;
        }
        huidigeSpeler.setMijnBeurt(false);
        int index = spelers.indexOf(huidigeSpeler);
        if (index == spelers.size() - 1) {
            huidigeSpeler = spelers.get(0);
            rondeNummer++;
            bepaalWinnaar();
        } else {
            huidigeSpeler = spelers.get(index + 1);
        }
        huidigeSpeler.setMijnBeurt(true);
        bepaalWinnaar();
    }

    private void bepaalWinnaar() {
        Speler vorigeSpeler = null;
        for (int i = 0; i < spelers.size(); i++) {
            Speler speler = spelers.get(i);
            if (speler.getPrestigePunten() >= 15) {
                if (vorigeSpeler == null) {
                    vorigeSpeler = speler;
                    winnaars.add(vorigeSpeler);
                } else if (vorigeSpeler.getPrestigePunten() > speler.getPrestigePunten()) {
                    winnaars.remove(0);
                    winnaars.add(speler);
                    vorigeSpeler = speler;
                } else if (vorigeSpeler.getPrestigePunten() == speler.getPrestigePunten()) {
                    int bonussenVorigeSpeler = 0;
                    int bonussenSpeler = 0;
                    for (VoorraadKost bonus : vorigeSpeler.getEdelsteenBonussen()) {
                        bonussenVorigeSpeler += bonus.getAantal();
                    }
                    for (VoorraadKost bonus2 : speler.getEdelsteenBonussen()) {
                        bonussenSpeler += bonus2.getAantal();
                    }

                    if (bonussenSpeler > bonussenVorigeSpeler) {
                        winnaars.remove(0);
                        winnaars.add(speler);
                    } else if(bonussenSpeler < bonussenVorigeSpeler) {
                        winnaars.remove(0);
                        winnaars.add(vorigeSpeler);
                    } else {
                        winnaars.remove(0);
                        winnaars.add(speler);
                        winnaars.add(vorigeSpeler);
                    }
                }
            }

        }
    }

    /**
     * Toont de spelsituatie.
     *
     * @return String met de spelsituatie.
     */
    public String toonSpelSituatie() {
        String spelOverzicht = MessageHelper.getString("game_overview");
        String aantal = MessageHelper.getString("number_of");

        String Ontwikkeling = MessageHelper.getString("card_development");
        String Edelen = MessageHelper.getString("card_nobles");
        String Spelers = MessageHelper.getString("players");

        StringBuilder situatie = new StringBuilder("\t--- " + spelOverzicht + " ---\n");

        for (VoorraadKost edelsteen : edelstenen) {
            situatie.append("- ").append(aantal).append(" ").append(edelsteen.getType()).append(": ").append(edelsteen.getAantal()).append("\t");
        }

        situatie.append(Ontwikkeling).append("I: ").append(ontwikkelingI.size()).append("\n");
        // Voeg de eerste vier elementen van ontwikkelingI toe aan StringBuilder
        for (int i = 0; i < 4 && i < ontwikkelingI.size(); i++) {
            situatie.append(ontwikkelingI.get(i));
        }
        situatie.append("- ").append(aantal).append(" ").append(Ontwikkeling).append("II: ").append(ontwikkelingII.size()).append("\t");
        // Voeg de eerste vier elementen van ontwikkelingII toe aan StringBuilder
        for (int i = 0; i < 4 && i < ontwikkelingII.size(); i++) {
            situatie.append(ontwikkelingII.get(i));
        }
        situatie.append("- ").append(aantal).append(" ").append(Ontwikkeling).append("III: ").append(ontwikkelingIII.size()).append("\n");
        // Voeg de eerste vier elementen van ontwikkelingIII toe aan StringBuilder
        for (int i = 0; i < 4 && i < ontwikkelingIII.size(); i++) {
            situatie.append(ontwikkelingIII.get(i));
        }
        situatie.append("- ").append(aantal).append(" ").append(Edelen).append(": ").append(edelen.size());
        // Voeg de eerste vier elementen van edelen toe aan StringBuilder
        for (int i = 0; i < 4 && i < edelen.size(); i++) {
            situatie.append(edelen.get(i));
        }

        situatie.append("\n-> ").append(Spelers).append(":\n");

        for (Speler speler : spelers) {
            situatie.append(speler.spelerOverzicht());
        }
        return situatie.toString();
    }

    /**
     * Sorteert spelers op basis van geboortejaar en naam.
     *
     * @param spelers Spelers die worden gesorteerd.
     * @return gesorteerde spelers.
     */
    private Collection<Speler> sorteerSpelers(ArrayList<Speler> spelers) {
        spelers.sort((s1, s2) -> {
            if (s1.getGeboortejaar() != s2.getGeboortejaar()) {
                return s2.getGeboortejaar() - s1.getGeboortejaar();
            } else {
                return s2.getGebruikersnaam().length() - s1.getGebruikersnaam().length();
            }
        });
        return spelers;
    }

    /**
     * Pak twee edelstenen van hetzelfde type en voeg ze toe aan de huidige speler.
     *
     * @param edelsteen EdelsteenType van de tweede edelsteen die worden gepakt.
     */
    public void pakTweeEdelstenenDezelfdeKleur(EdelsteenType edelsteen) {
        this.edelstenen
                .stream()
                .filter(es -> es.getType() == edelsteen)
                .forEach(es -> {
                    if (es.getAantal() < 4)
                        throw new OnvoldoendeEdelstenenException(MessageHelper.getString("insufficient_gems"));
                    es.setAantal(es.getAantal() - 2);
                    huidigeSpeler.voegEdelstenenToe(es.getType(), 2);
                });
    }

    /**
     * Pak drie edelstenen van verschillende type en voeg ze toe aan de huidige speler.
     *
     * @param edelsteen edelsteenType van de drie edelstenen
     */
    public void pakDrieEdelstenenVerschillendeKleur(EdelsteenType edelsteen) {
        edelstenen
                .stream()
                .filter(es -> es.getType() == edelsteen)
                .forEach(es -> {
                    if (es.getAantal() == 0)
                        throw new OnvoldoendeEdelstenenException(MessageHelper.getString("insufficient_gems"));
                    es.setAantal(es.getAantal() - 1);
                    huidigeSpeler.voegEdelstenenToe(es.getType(), 1);
                });
    }

    /**
     * Voeg edelsteenType toe aan het spel.
     *
     * @param edelsteenType EdelsteenType die wordt toegevoegd.
     * @param aantal        hoeveelheid edelsteenType dat wordt toegevoegd.
     */
    public void voegEdelsteenToe(EdelsteenType edelsteenType, int aantal) {
        edelstenen
                .stream()
                .filter(es -> es.getType() == edelsteenType)
                .findFirst()
                .ifPresent(es -> es.setAantal(es.getAantal() + aantal));
    }

    /**
     * Geeft een ontwikkeling aan de hand van het id en het niveau terug.
     *
     * @param id     id van de ontwikkeling
     * @param niveau niveau van de ontwikkeling
     * @return Ontwikkeling volgens id en niveau.
     */
    public Ontwikkeling geefOntwikkeling(String id, String niveau) {
        return switch (niveau) {
            case "1" -> openOntwikelingI.stream()
                    .filter(ontw -> ontw.getId().equals(id))
                    .findFirst()
                    .orElse(null);
            case "2" -> openOntwikelingII.stream()
                    .filter(ontw -> ontw.getId().equals(id))
                    .findFirst()
                    .orElse(null);
            case "3" -> openOntwikelingIII.stream()
                    .filter(ontw -> ontw.getId().equals(id))
                    .findFirst()
                    .orElse(null);
            default -> null;
        };
    }

    /**
     * Geeft een edele aan de hand van het id.
     * @param id id van de edele
     * @return Edele volgens id.
     */
    public Edele geefEdele(String id) {
        return edelen.stream()
                .filter(edele -> edele.getId().equals(id))
                .findFirst()
                .orElse(null);
    }

    /**
     * Verwijder openOntwikkeling aan de hand van hetid en het niveau.
     *
     * @param id     id van de ontwikkeling
     * @param niveau niveau van de ontwikkeling
     * @throws Exception Exception
     */
    public void verwijderOpenOntwikkeling(String id, String niveau) throws Exception {
        switch (niveau) {
            case "1" -> {
                boolean verwijderd = openOntwikelingI.removeIf(ontw -> ontw.getId().equals(id));
                //throw new OntwikkelingNietGevondenException(MessageHelper.getString("card_development_not_found"));
                if (!verwijderd) throw new Exception("Ontwikkeling niet gevonden");
            }
            case "2" -> {
                boolean verwijderd = openOntwikelingII.removeIf(ontw -> ontw.getId().equals(id));
                if (!verwijderd) throw new Exception("Ontwikkeling niet gevonden");
            }
            case "3" -> {
                boolean verwijderd = openOntwikelingIII.removeIf(ontw -> ontw.getId().equals(id));
                if (!verwijderd) throw new Exception("Ontwikkeling niet gevonden");
            }
        }
    }

    /**
     * Voeg een ontwikkeling toe aan de hand het niveau in openOntwikeling.
     *
     * @param niveau niveau van ontwikkeling
     */
    public void voegEenOntwikkelingToe(String niveau) {
        switch (niveau) {
            case "1" -> {
                Ontwikkeling ontwKaart = ontwikkelingI.get(0);
                ontwikkelingI.remove(ontwKaart);
                openOntwikelingI.add(ontwKaart);
            }
            case "2" -> {
                Ontwikkeling ontwKaart = ontwikkelingII.get(0);
                ontwikkelingII.remove(ontwKaart);
                openOntwikelingII.add(ontwKaart);
            }
            case "3" -> {
                Ontwikkeling ontwKaart = ontwikkelingIII.get(0);
                ontwikkelingIII.remove(ontwKaart);
                openOntwikelingIII.add(ontwKaart);
            }
        }
    }

    /**
     * Kan huidige speler deze ontwikkeling kopen.
     *
     * @param id     id van ontwikkeling
     * @param niveau niveau van ontwikkeling
     * @return true als de speler deze ontwikkeling kopen kan, anders false
     */
    public boolean kanHuidigeSpelerOntwikkelingKopen(String id, String niveau) {
        Ontwikkeling ontwKaart = geefOntwikkeling(id, niveau);
        Map<EdelsteenType, Boolean> edelstenenStatus = new HashMap<>();

        for (VoorraadKost kostOntwikkeling : ontwKaart.getKosten()) {
            edelstenenStatus.put(kostOntwikkeling.getType(), false);
        }

        for (VoorraadKost kostOntwikkeling : ontwKaart.getKosten()) {
            for (VoorraadKost voorraadSpeler : huidigeSpeler.getEdelstenen()) {
                for (VoorraadKost voorraadBonusSpeler : huidigeSpeler.getEdelsteenBonussen()) {
                    if (kostOntwikkeling.getType().equals(voorraadSpeler.getType()) && kostOntwikkeling.getType().equals(voorraadBonusSpeler.getType()) && kostOntwikkeling.getAantal() <= (voorraadSpeler.getAantal() + voorraadBonusSpeler.getAantal())) {
                        edelstenenStatus.put(kostOntwikkeling.getType(), true);
                    }
                }
            }
        }

        return !edelstenenStatus.containsValue(false);
    }

    /**
     * Kan huidegi speler deze edele krijgen.
     *
     * @param id id van edele
     * @return true als de speler deze edele krijgen kan, anders false
     */
    public boolean kanHuidigeSpelerEdeleKrijgen(String id) {
        Edele edeleKaart = geefEdele(id);
        Map<EdelsteenType, Boolean> bonussenStatus = new HashMap<>();

        for (VoorraadKost bonusEdele : edeleKaart.getVereisteBonussen()) {
            bonussenStatus.put(bonusEdele.getType(), false);
        }

        for (VoorraadKost bonusEdele : edeleKaart.getVereisteBonussen()) {
            for (VoorraadKost bonusSpeler : huidigeSpeler.getEdelsteenBonussen()) {
                if (bonusEdele.getType().equals(bonusSpeler.getType()) && bonusEdele.getAantal() <= bonusSpeler.getAantal()) {
                    bonussenStatus.put(bonusEdele.getType(), true);
                }
            }
        }

        return !bonussenStatus.containsValue(false);
    }
}
