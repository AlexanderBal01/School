package persistentie;

public class Connectie {
    public static final String DB_USER = "ID351669_g118";
    private static final String DB_PASS = "splendorg118?!";
    public static final String JDBC_URL = "jdbc:mysql://ID351669_g118.db.webhosting.be?serverTimezone=UTC&useLegacyDatetimeCode=false&user=" + DB_USER + "&password=" + DB_PASS;
}
