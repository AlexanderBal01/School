package persistentie;

import domein.Speler;

import java.sql.*;

public class SpelerMapper {

    //region SQL Queries
    private static final String SELECT_SPELER = "SELECT * FROM " + Connectie.DB_USER
            + ".Speler WHERE gebruikersnaam =  + ?";
    //endregion


    /** Geeft de speler met de opgegeven gebruikersnaam terug uit de database.
     @param gebruikersnaam de gebruikersnaam van de speler die opgehaald moet worden
     @return de speler met de opgegeven gebruikersnaam, of null als deze niet gevonden is
     */
    public Speler geefSpelerDB(String gebruikersnaam) {
        Speler speler = null;

        try {
            Connection conn = DriverManager.getConnection(Connectie.JDBC_URL);
            PreparedStatement query = conn.prepareStatement(SELECT_SPELER);

            query.setString(1, gebruikersnaam);

            try (ResultSet rs = query.executeQuery()) {
                if (rs.next()) {
                    String gevondenGebruikersnaam = rs.getString("gebruikersnaam");
                    int gevondenGeboortejaar = rs.getInt("geboortejaar");

                    speler = new Speler(gevondenGebruikersnaam, gevondenGeboortejaar);
                }
            }
        } catch (SQLException ex) {
            throw new RuntimeException(ex);
        }

        return speler;
    }

    /**
     * Controleert of een speler
     * met de gegeven gebruikersnaam bestaat in de database.
     @param gebruikersnaam de gebruikersnaam van de speler
     @return true als de speler bestaat, anders false
     */
    public Boolean bestaatSpelerDB(String gebruikersnaam) {
        try (Connection conn = DriverManager.getConnection(Connectie.JDBC_URL);
             PreparedStatement query = conn.prepareStatement(SELECT_SPELER)) {

            query.setString(1, gebruikersnaam);
            try (ResultSet resultSet = query.executeQuery()) {
                return resultSet.next();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }
}
