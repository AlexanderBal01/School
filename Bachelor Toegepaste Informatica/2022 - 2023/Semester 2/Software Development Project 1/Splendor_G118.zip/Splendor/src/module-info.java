module splendor_module {
	exports persistentie;
	exports cui;
	exports utils;
	exports dto;
	exports main;
	exports domein;
	exports exceptions;

	requires java.sql;
	requires javafx.fxml;
	requires javafx.controls;
	requires javafx.graphics;

	
	opens main to javafx.fxml, javafx.graphics;
	opens gui to javafx.fxml, javafx.graphics;
	opens gui.controllers to javafx.fxml;
}

