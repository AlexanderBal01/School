package utils;

import javafx.animation.FadeTransition;
import javafx.animation.PathTransition;
import javafx.animation.ScaleTransition;
import javafx.scene.Node;
import javafx.scene.shape.Shape;
import javafx.util.Duration;

public class AnimationHelper {
    public static void fadeAnimation(Duration duration, Node node, double fromValue, double toValue) {
        FadeTransition ft = new FadeTransition(duration, node);
        ft.setFromValue(fromValue);
        ft.setToValue(toValue);
        ft.play();
    }

    public static void scaleAnimation(Duration duration, Node node, double fromValueX, double fromValueY, double toValueX, double toValueY) {
        ScaleTransition st = new ScaleTransition(duration, node);
        st.setFromX(fromValueX);
        st.setFromY(fromValueY);
        st.setToX(toValueX);
        st.setToY(toValueY);
        st.play();
    }

    public static void pathAnimation(Duration duration, Shape shape, Node node, double fromValue, double toValue) {
        PathTransition pt = new PathTransition(duration, shape, node);
    }
}
