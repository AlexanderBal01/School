package utils;

public class TextHelper {
    /**
     * Maakt de eerste letter van een string hoofdletter
     * en de rest van de letters klein.
     * @param str de string om te capitaliseren
     * @return de gecapitaliseerde string, of de invoerstring als deze null of leeg is
     */
    public static String Capitalize(String str) {
        if (str == null || str.isEmpty())
            return str;
        return str.substring(0, 1).toUpperCase() + str.substring(1).toLowerCase();
    }
}
