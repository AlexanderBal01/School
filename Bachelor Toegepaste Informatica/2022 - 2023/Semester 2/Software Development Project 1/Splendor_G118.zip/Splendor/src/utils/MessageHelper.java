package utils;

import java.util.Locale;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

public class MessageHelper {
    private static Locale appLocale;
    private static final String MESSAGES = "resources/languages/messages";

    /**
     * Initialiseert de taalinstelling van de applicatie.
     * @param language de taalinstelling
     */
    public static void setLanguage(String language) {
        appLocale = new Locale(language);
    }
    /**
     * Haalt een string op uit het resourcebundel op basis van de opgegeven sleutel en taalinstelling.
     * @param key de sleutel voor de te halen string
     * @return de string uit het resourcebundel die overeenkomt met de opgegeven sleutel
     * @throws MissingResourceException als de opgegeven sleutel niet wordt gevonden in het resourcebundel
     */
    public static String getString(String key) {
        ResourceBundle bundle = ResourceBundle.getBundle(MESSAGES, appLocale);
        return bundle.getString(key);
    }
    /**
     * Haalt een string op uit het resourcebundel op basis van de opgegeven sleutel en taalinstelling.
     * @param key de sleutel voor de te halen string
     * @param language de taalinstelling voor het resourcebundel
     * @return de string uit het resourcebundel die overeenkomt met de opgegeven sleutel
     * @throws MissingResourceException als de opgegeven sleutel niet wordt gevonden in het resourcebundel
     */
    public static String getStringLanguage(String key,String language) {
        ResourceBundle bundle = ResourceBundle.getBundle(MESSAGES, appLocale = new Locale(language));
        return bundle.getString(key);
    }
    /**
     * Geeft de taalcode in hoofdletters terug van de huidige applicatietaalinstelling.
     * @return de taalcode van de huidige applicatietaalinstelling in hoofdletters
     */
    public static String getLanguage() {
        return appLocale.getLanguage().toUpperCase();
    }
}
