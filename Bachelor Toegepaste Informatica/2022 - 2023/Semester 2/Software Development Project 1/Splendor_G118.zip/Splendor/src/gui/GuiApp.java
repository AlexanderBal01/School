package gui;

import domein.DomeinController;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.util.Duration;
import utils.AnimationHelper;

import java.io.IOException;

public class GuiApp extends Application {

    @Override
    public void start(Stage stage) throws IOException {
        DomeinController controller = new DomeinController();
        Scene scene = new Scene(new HoofdPaneel(controller), 900, 700);
        stage.setScene(scene);
        stage.setResizable(false);
        stage.setTitle("Splendor");
        AnimationHelper.fadeAnimation(Duration.seconds(1.5),scene.getRoot(),0.6,1);
        stage.show();
    }

    public static void main(String... args) {
        Application.launch(GuiApp.class, args);
    }

}
