package gui.controllers;

import gui.HoofdPaneel;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

import java.net.URL;
import java.util.ResourceBundle;

public class AlertController implements Initializable {

    private HoofdPaneel hoofdPaneel;
    private final boolean isInfo;
    private final String lblTitelInhoud;
    private final String lblTekstInhoud;

    // region FXML
    @FXML
    private Label lblTitel;
    @FXML
    private Button btnBevestigen;
    @FXML
    private Label lblTekst;
    @FXML
    private ImageView imgAlert;
    @FXML
    private ImageView imgInfo;
    // endregion

    /**
     * Constructor voor AlertController
     *
     * @param hoofdPaneel     HoofdPaneel
     * @param lblTitleContent lblTitleContent
     * @param lblTextContent  lblTextContent
     */
    public AlertController(HoofdPaneel hoofdPaneel, boolean isInfo, String lblTitleContent, String lblTextContent) {
        this.isInfo = isInfo;
        this.hoofdPaneel = hoofdPaneel;
        this.lblTitelInhoud = lblTitleContent;
        this.lblTekstInhoud = lblTextContent;
    }

    public AlertController(boolean isInfo, String lblTitleContent, String lblTextContent) {
        this.isInfo = isInfo;
        this.lblTitelInhoud = lblTitleContent;
        this.lblTekstInhoud = lblTextContent;
    }

    /**
     * Initialiseer de labels en buttons met de correcte tekst
     *
     * @param url            URL
     * @param resourceBundle ResourceBundle
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        if (isInfo) imgAlert.setOpacity(0);
        else imgInfo.setOpacity(0);
        lblTitel.setText(lblTitelInhoud);
        lblTekst.setText(lblTekstInhoud);
    }

    /**
     * Sluit de alert
     */
    public void handleAlert() {
        Stage stageModal = (Stage) btnBevestigen.getScene().getWindow();
        stageModal.close();
    }
}
