package gui.controllers;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class OntwKaartController implements Initializable {
    private final String prestige;
    private final String robijn;
    private final String diamant;
    private final String saffier;
    private final String smaragd;
    private final String onyx;
    private final String imgEdelsteen;
    private final String imgAchtergrond;
    @FXML
    private ImageView imgEdelsteentype;
    @FXML
    private ImageView imgAchtergrondOntw;
    @FXML
    private Label lblPrestigeOntw;
    @FXML
    private Label lblDiamantOntw;
    @FXML
    private Label lblRobijnOntw;
    @FXML
    private Label lblSaffierOntw;
    @FXML
    private Label lblSmaragdOntw;
    @FXML
    private Label lblOnyxOntw;


    public OntwKaartController(String lblPrestige, String lblRobijn, String lblDiamant, String lblSaffier, String lblSmaragd, String lblOnyx, String imgEdelsteen, String imgAchtergrond) throws IOException {
        this.prestige = lblPrestige;
        this.robijn = lblRobijn;
        this.diamant = lblDiamant;
        this.saffier = lblSaffier;
        this.smaragd = lblSmaragd;
        this.onyx = lblOnyx;
        this.imgEdelsteen = imgEdelsteen;
        this.imgAchtergrond = imgAchtergrond;
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        this.imgAchtergrondOntw.setImage(laadAfbeelding(imgAchtergrond));
        this.imgEdelsteentype.setImage(laadAfbeelding(imgEdelsteen));
        this.lblPrestigeOntw.setText(prestige);
        this.lblRobijnOntw.setText(robijn);
        this.lblDiamantOntw.setText(diamant);
        this.lblSaffierOntw.setText(saffier);
        this.lblSmaragdOntw.setText(smaragd);
        this.lblOnyxOntw.setText(onyx);
    }

    private Image laadAfbeelding(String imageFile) {
        File bestand = new File(imageFile);
        return new Image(bestand.toURI().toString());
    }

}
