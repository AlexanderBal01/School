package gui.controllers;

import dto.SpelerDTO;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import utils.MessageHelper;
import utils.TextHelper;

import java.net.URL;
import java.util.Map;
import java.util.ResourceBundle;

public class SpelerInfoController implements Initializable {

    private SpelerDTO speler;
    // region FXML
    @FXML
    private Label lblSpeler;
    @FXML
    private Label lblGebruikersnaam;
    @FXML
    private Label lblSmagard;
    @FXML
    private Label lblDiamant;
    @FXML
    private Label lblOnyx;
    @FXML
    private Label lblSaffier;
    @FXML
    private Label lblRobijn;
    @FXML
    private Label lblBonusSmagard;
    @FXML
    private Label lblBonusDiamant;
    @FXML
    private Label lblBonusOnyx;
    @FXML
    private Label lblBonusSaffier;
    @FXML
    private Label lblBonusRobijn;
    @FXML
    private Label lblPrestigePunten;
    //  endregion

    public SpelerInfoController(SpelerDTO speler) {
        this.speler = speler;
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        lblSpeler.setText(TextHelper.Capitalize(MessageHelper.getString("player") + ": "));
        lblGebruikersnaam.setText(String.format("%s, %d", speler.gebruikersnaam(), speler.geboortejaar()));
        vernieuwEdelstenen();
    }

    /**
     * Vernieuwen van edelstenen via een dictionary van edelstenen en labels.
     */
    public void vernieuwEdelstenen() {
        Map<String, Label> labelMap = Map.of(
                "DIAMANT", lblDiamant,
                "SAFFIER", lblSaffier,
                "SMARAGD", lblSmagard,
                "ROBIJN", lblRobijn,
                "ONYX", lblOnyx
        );
        speler.edelstenen().forEach(edelsteen -> {
            Label label = labelMap.get(edelsteen.edelsteenTypeDTO().type());
            int aantal = edelsteen.aantal();
            label.setText(Integer.toString(aantal));
        });

        Map<String, Label> labelBonusMap = Map.of(
                "DIAMANT", lblBonusDiamant,
                "SAFFIER", lblBonusSaffier,
                "SMARAGD", lblBonusSmagard,
                "ROBIJN", lblBonusRobijn,
                "ONYX", lblBonusOnyx
        );
        speler.bonussen().forEach(bonus -> {
            Label label = labelBonusMap.get(bonus.edelsteenTypeDTO().type());
            int aantal = bonus.aantal();
            label.setText(Integer.toString(aantal));
        });

        lblPrestigePunten.setText(Integer.toString(speler.prestigePunten()));
    }
}
