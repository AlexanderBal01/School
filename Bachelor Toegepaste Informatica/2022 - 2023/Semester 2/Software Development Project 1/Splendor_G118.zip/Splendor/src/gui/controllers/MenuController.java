package gui.controllers;

import domein.DomeinController;
import gui.HoofdPaneel;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.util.Duration;
import utils.AnimationHelper;
import utils.MessageHelper;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class MenuController implements Initializable {
    //! FXML kan rood onderlijnen onder onAction, maar normaal werkt het.
    private final DomeinController domeinController;
    private final HoofdPaneel hoofdPaneel;

    // region FXML
    @FXML Label lblHoofdScherm;
    @FXML Button btnOpstellingSpel;
    @FXML Button btnVeranderTaal;
    @FXML Button btnSluitSpel;
    // endregion

    /**
     * Constructor voor MenuController
     * @param controller domeincontroller
     * @param hoofdPaneel hoofdPaneel
     */
    public MenuController(DomeinController controller, HoofdPaneel hoofdPaneel) {
        this.domeinController = controller;
        this.hoofdPaneel = hoofdPaneel;
    }

    /**
     * Methode om hoofdPaneel toonSpelMaken() te laten werken
     */
    @FXML
    public void gaNaarOpstelling() {
        try {
            hoofdPaneel.toonSpelMaken();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Methode om hoofdPaneel toonTaalVeranderen() te laten werken
     * @throws IOException krijgt een foutmelding
     */
    public void gaNaarTaal() throws IOException {
        hoofdPaneel.toonTaalVeranderen();
    }

    /**
     * Methode om de applicatie te stoppen
     */
    @FXML
    public void sluitApplicatie() {
        Platform.exit();
    }

    /**
     * Initialiseer de labels en buttons met de correcte tekst
     * @param url URL
     * @param resourceBundle resourceBundle
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        AnimationHelper.fadeAnimation(Duration.seconds(3),btnOpstellingSpel,0.5,1);
        AnimationHelper.fadeAnimation(Duration.seconds(3),btnVeranderTaal,0.5,1);
        AnimationHelper.fadeAnimation(Duration.seconds(3),btnSluitSpel,0.5,1);
        AnimationHelper.scaleAnimation(Duration.seconds(2),lblHoofdScherm,0.5,0.5,1,1);
        lblHoofdScherm.setText(MessageHelper.getString("menu_main_menu"));
        btnOpstellingSpel.setText(MessageHelper.getString("menu_option_1"));
        btnVeranderTaal.setText(MessageHelper.getString("menu_option_2"));
        btnSluitSpel.setText(MessageHelper.getString("menu_option_3"));
    }
}
