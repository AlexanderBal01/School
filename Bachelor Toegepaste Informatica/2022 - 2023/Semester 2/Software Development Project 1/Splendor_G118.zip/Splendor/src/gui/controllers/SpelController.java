package gui.controllers;

import domein.DomeinController;
import domein.EdelsteenType;
import dto.*;
import gui.HoofdPaneel;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import utils.MessageHelper;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.*;
import java.util.stream.Collectors;

public class SpelController implements Initializable {
    private final DomeinController domeinController;
    private final HoofdPaneel hoofdPaneel;

    // region FXML
    @FXML
    private VBox stpEdelstenen;
    @FXML
    private StackPane stkpDiamant;
    @FXML
    private Label lblAantalDiamant;
    @FXML
    private StackPane stkpSaffier;
    @FXML
    private Label lblAantalSaffier;
    @FXML
    private StackPane stkpAantalSmaragd;
    @FXML
    private Label lblAantalSmaragd;
    @FXML
    private StackPane stkpRobijn;
    @FXML
    private Label lblAantalRobijn;
    @FXML
    private StackPane stkpOnyx;
    @FXML
    private Label lblAantalOnyx;
    @FXML
    private GridPane spelGrid;
    @FXML
    private GridPane gridEdele;
    @FXML
    private VBox spelers;
    @FXML
    private Label lblHuidigeSpeler;
    @FXML
    private Label lblSpelerNaam;
    @FXML
    private Label lblOntwStack_1;
    @FXML
    private Label lblOntwStack_2;
    @FXML
    private Label lblOntwStack_3;
    @FXML
    private Button btnPasBeurt;
    @FXML
    private Button btnPakTweeEdelstenen;
    @FXML
    private Button btnPakDrieEdelstenen;
    @FXML
    private Button btnKoopOntwikkeling;
    //  endregion

    public SpelController(DomeinController domeinController, HoofdPaneel hoofdPaneel) {
        this.domeinController = domeinController;
        this.hoofdPaneel = hoofdPaneel;
    }




    // region Initialeer methodes
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        initialiseerEdelstenen();
        initialiseerSpelerButtons();
        initialiseerEdelen();
        initialiseerTekst();
        initialiseerOntwikkelingI();
        initialiseerOntwikkelingII();
        initialiseerOntwikkelingIII();
    }

    /**
     * Initialiseert de knoppen voor elke speler in het spel.
     */
    private void initialiseerSpelerButtons() {
        Collection<Node> spelerBtns = spelers.getChildren();
        for (int i = 0; i < domeinController.geefSpelersDTO().size(); i++) {
            Button spelerBtn = (Button) spelerBtns.toArray()[i];
            SpelerDTO spelerDTO = domeinController.geefSpelerDTO(i);
            spelerBtn.setDisable(false);
            spelerBtn.setText(spelerDTO.gebruikersnaam());
            spelerBtn.setOnMousePressed(event -> toonSpelerInfo(spelerDTO));
        }
    }

    /**
     * Initialiseert de tekst.
     */
    private void initialiseerTekst() {
        lblHuidigeSpeler.setText(MessageHelper.getString("menu_game_player") + ": ");
        lblSpelerNaam.setText(domeinController.geefHuidigeSpelerDTO().gebruikersnaam());
        btnPakTweeEdelstenen.setText(MessageHelper.getString("take_two_gems"));
        btnPakDrieEdelstenen.setText(MessageHelper.getString("take_three_gems"));
        btnKoopOntwikkeling.setText(MessageHelper.getString("buy_one_development"));
        btnPasBeurt.setText(MessageHelper.getString("pass_turn"));
    }

    /**
     * Initialiseert de edelen.
     */
    private void initialiseerEdelen() {
        Collection<EdeleDTO> edeleDTOS = domeinController.geefEdelenDTO();
        for (int i = 0; i < edeleDTOS.size(); i++) {
            try {
                EdeleDTO edelDTO = (EdeleDTO) edeleDTOS.toArray()[i];
                String imgEdel = String.format("src/gui/images/nobles_%d.png", (i + 1));
                String prestigePunten = String.valueOf(edelDTO.prestigePunten());
                String vereisteDiamanten = geefVereistEdelstenenEdel(edelDTO, "white");
                String vereisteRobijnen = geefVereistEdelstenenEdel(edelDTO, "red");
                String vereisteSaffier = geefVereistEdelstenenEdel(edelDTO, "blue");
                String vereisteSmaragd = geefVereistEdelstenenEdel(edelDTO, "green");
                String vereisteOnyx = geefVereistEdelstenenEdel(edelDTO, "black");
                String id = edelDTO.id();

                Node edelKaart = hoofdPaneel.laadEdeleKaartScherm(imgEdel, prestigePunten, vereisteRobijnen, vereisteDiamanten, vereisteSaffier, vereisteSmaragd, vereisteOnyx);
                edelKaart.setId(id);
                edelKaart.setOnMouseClicked(this::opKlikBtnKiesEdele);
                GridPane.setConstraints(edelKaart, i, 0);
                gridEdele.getChildren().add(edelKaart);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }

    }

    /**
     * Initialiseert de nieuwe ontwikkeling.
     *
     * @param niveau      Welke niveau is het?
     * @param rijWaarde   Welke rij
     * @param kolomWaarde Welke kolom
     */
    private void initialiseerNieuweOntwikkeling(String niveau, int rijWaarde, int kolomWaarde) throws IOException {
        switch (niveau) {
            case "1" -> {
                OntwikkelingDTO ontwikkelingIDTO = (OntwikkelingDTO) domeinController.geefOpenOntwikkelingIDTO().toArray()[3];
                String id = ontwikkelingIDTO.id();
                String imgAchtergrond = id.substring(0, id.length() - 2);
                String imgAchtergrondPath = String.format("src/gui/images/%s.png", imgAchtergrond);
                String imgEdelsteen = String.format("src/gui/images/%s.png", ontwikkelingIDTO.type().type());
                String prestigePunten = String.valueOf(ontwikkelingIDTO.prestigePunten());
                String vereisteDiamanten = geefVereistEdelstenenOntwk(ontwikkelingIDTO, "white");
                String vereisteRobijnen = geefVereistEdelstenenOntwk(ontwikkelingIDTO, "red");
                String vereisteSaffier = geefVereistEdelstenenOntwk(ontwikkelingIDTO, "blue");
                String vereisteSmaragd = geefVereistEdelstenenOntwk(ontwikkelingIDTO, "green");
                String vereisteOnyx = geefVereistEdelstenenOntwk(ontwikkelingIDTO, "black");

                Node ontwikkelingKaart = hoofdPaneel.laadOntwKaartScherm(prestigePunten, vereisteRobijnen, vereisteDiamanten, vereisteSaffier, vereisteSmaragd, vereisteOnyx, imgEdelsteen, imgAchtergrondPath);
                ontwikkelingKaart.setId(id);
                ontwikkelingKaart.setOnMouseClicked(this::opKlikBtnOntwikkelingsKaart);
                spelGrid.add(ontwikkelingKaart, kolomWaarde, rijWaarde);

            }
            case "2" -> {
                OntwikkelingDTO ontwikkelingIDTO = (OntwikkelingDTO) domeinController.geefOpenOntwikkelingIIDTO().toArray()[3];
                String id = ontwikkelingIDTO.id();
                String imgAchtergrond = id.substring(0, id.length() - 2);
                String imgAchtergrondPath = String.format("src/gui/images/%s.png", imgAchtergrond);
                String imgEdelsteen = String.format("src/gui/images/%s.png", ontwikkelingIDTO.type().type());
                String prestigePunten = String.valueOf(ontwikkelingIDTO.prestigePunten());
                String vereisteDiamanten = geefVereistEdelstenenOntwk(ontwikkelingIDTO, "white");
                String vereisteRobijnen = geefVereistEdelstenenOntwk(ontwikkelingIDTO, "red");
                String vereisteSaffier = geefVereistEdelstenenOntwk(ontwikkelingIDTO, "blue");
                String vereisteSmaragd = geefVereistEdelstenenOntwk(ontwikkelingIDTO, "green");
                String vereisteOnyx = geefVereistEdelstenenOntwk(ontwikkelingIDTO, "black");

                Node ontwikkelingKaart = hoofdPaneel.laadOntwKaartScherm(prestigePunten, vereisteRobijnen, vereisteDiamanten, vereisteSaffier, vereisteSmaragd, vereisteOnyx, imgEdelsteen, imgAchtergrondPath);
                ontwikkelingKaart.setId(id);
                ontwikkelingKaart.setOnMouseClicked(this::opKlikBtnOntwikkelingsKaart);
                spelGrid.add(ontwikkelingKaart, kolomWaarde, rijWaarde);

            }
            case "3" -> {
                OntwikkelingDTO ontwikkelingIDTO = (OntwikkelingDTO) domeinController.geefOpenOntwikkelingIIIDTO().toArray()[3];
                String id = ontwikkelingIDTO.id();
                String imgAchtergrond = id.substring(0, id.length() - 2);
                String imgAchtergrondPath = String.format("src/gui/images/%s.png", imgAchtergrond);
                String imgEdelsteen = String.format("src/gui/images/%s.png", ontwikkelingIDTO.type().type());
                String prestigePunten = String.valueOf(ontwikkelingIDTO.prestigePunten());
                String vereisteDiamanten = geefVereistEdelstenenOntwk(ontwikkelingIDTO, "white");
                String vereisteRobijnen = geefVereistEdelstenenOntwk(ontwikkelingIDTO, "red");
                String vereisteSaffier = geefVereistEdelstenenOntwk(ontwikkelingIDTO, "blue");
                String vereisteSmaragd = geefVereistEdelstenenOntwk(ontwikkelingIDTO, "green");
                String vereisteOnyx = geefVereistEdelstenenOntwk(ontwikkelingIDTO, "black");

                Node ontwikkelingKaart = hoofdPaneel.laadOntwKaartScherm(prestigePunten, vereisteRobijnen, vereisteDiamanten, vereisteSaffier, vereisteSmaragd, vereisteOnyx, imgEdelsteen, imgAchtergrondPath);
                ontwikkelingKaart.setId(id);
                ontwikkelingKaart.setOnMouseClicked(this::opKlikBtnOntwikkelingsKaart);
                spelGrid.add(ontwikkelingKaart, kolomWaarde, rijWaarde);
            }
        }
    }

    /**
     * Initialiseert de 4 ontwikkelingen I op het scherm.
     */
    private void initialiseerOntwikkelingI() {
        Collection<OntwikkelingDTO> ontwikkelingIDTOS = domeinController.geefSpelDTO().ontwikkelingI();
        for (int i = 0; i < 4; i++) {
            try {
                OntwikkelingDTO ontwikkelingIDTO = (OntwikkelingDTO) ontwikkelingIDTOS.toArray()[i];
                String id = ontwikkelingIDTO.id();
                String imgAchtergrond = id.substring(0, id.length() - 2);
                String imgAchtergrondPath = String.format("src/gui/images/%s.png", imgAchtergrond);
                String imgEdelsteen = String.format("src/gui/images/%s.png", ontwikkelingIDTO.type().type());
                String prestigePunten = String.valueOf(ontwikkelingIDTO.prestigePunten());
                String vereisteDiamanten = geefVereistEdelstenenOntwk(ontwikkelingIDTO, MessageHelper.getString("color_diamond"));
                String vereisteRobijnen = geefVereistEdelstenenOntwk(ontwikkelingIDTO, MessageHelper.getString("color_ruby"));
                String vereisteSaffier = geefVereistEdelstenenOntwk(ontwikkelingIDTO, MessageHelper.getString("color_sapphire"));
                String vereisteSmaragd = geefVereistEdelstenenOntwk(ontwikkelingIDTO, MessageHelper.getString("color_emerald"));
                String vereisteOnyx = geefVereistEdelstenenOntwk(ontwikkelingIDTO, MessageHelper.getString("color_onyx"));

                Node ontwikkelingKaart = hoofdPaneel.laadOntwKaartScherm(prestigePunten, vereisteRobijnen, vereisteDiamanten, vereisteSaffier, vereisteSmaragd, vereisteOnyx, imgEdelsteen, imgAchtergrondPath);
                ontwikkelingKaart.setId(id);
                ontwikkelingKaart.setOnMouseClicked(this::opKlikBtnOntwikkelingsKaart);
                GridPane.setConstraints(ontwikkelingKaart, i, 0);
                spelGrid.getChildren().add(ontwikkelingKaart);
                domeinController.voegOntwikkelingIToeAanOpenOntwikkelingI(id);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
        lblOntwStack_1.setText(String.valueOf(domeinController.geefSpelDTO().ontwikkelingI().size()));
    }

    /**
     * Initialiseert de 4 ontwikkelingen II op het scherm.
     */
    private void initialiseerOntwikkelingII() {
        Collection<OntwikkelingDTO> ontwikkelingIIDTOS = domeinController.geefSpelDTO().ontwikkelingII();
        for (int i = 0; i < 4; i++) {
            try {
                OntwikkelingDTO ontwikkelingIIDTO = (OntwikkelingDTO) ontwikkelingIIDTOS.toArray()[i];
                String id = ontwikkelingIIDTO.id();
                String[] idSplit = id.split("_");
                String imgAchtergrond = idSplit[0] + "_" + idSplit[1];
                String imgAchtergrondPath = String.format("src/gui/images/%s.png", imgAchtergrond);
                String imgEdelsteen = String.format("src/gui/images/%s.png", ontwikkelingIIDTO.type().type());
                String prestigePunten = String.valueOf(ontwikkelingIIDTO.prestigePunten());
                String vereisteDiamanten = geefVereistEdelstenenOntwk(ontwikkelingIIDTO, MessageHelper.getString("color_diamond"));
                String vereisteRobijnen = geefVereistEdelstenenOntwk(ontwikkelingIIDTO, MessageHelper.getString("color_ruby"));
                String vereisteSaffier = geefVereistEdelstenenOntwk(ontwikkelingIIDTO, MessageHelper.getString("color_sapphire"));
                String vereisteSmaragd = geefVereistEdelstenenOntwk(ontwikkelingIIDTO, MessageHelper.getString("color_emerald"));
                String vereisteOnyx = geefVereistEdelstenenOntwk(ontwikkelingIIDTO, MessageHelper.getString("color_onyx"));

                Node ontwikkelingKaart = hoofdPaneel.laadOntwKaartScherm(prestigePunten, vereisteRobijnen, vereisteDiamanten, vereisteSaffier, vereisteSmaragd, vereisteOnyx, imgEdelsteen, imgAchtergrondPath);
                ontwikkelingKaart.setId(id);
                ontwikkelingKaart.setOnMouseClicked(this::opKlikBtnOntwikkelingsKaart);
                GridPane.setConstraints(ontwikkelingKaart, i, 1);
                spelGrid.getChildren().add(ontwikkelingKaart);
                domeinController.voegOntwikkelingIIToeAanOpenOntwikkelingII(id);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
        lblOntwStack_2.setText(String.valueOf(domeinController.geefSpelDTO().ontwikkelingII().size()));
    }

    /**
     * Initialiseert de 4 ontwikkelingen III op het scherm.
     */
    private void initialiseerOntwikkelingIII() {
        Collection<OntwikkelingDTO> ontwikkelingIIIDTOS = domeinController.geefSpelDTO().ontwikkelingIII();
        for (int i = 0; i < 4; i++) {
            try {
                OntwikkelingDTO ontwikkelingIIIDTO = (OntwikkelingDTO) ontwikkelingIIIDTOS.toArray()[i];
                String id = ontwikkelingIIIDTO.id();
                String[] idSplit = id.split("_");
                String imgAchtergrond = idSplit[0] + "_" + idSplit[1];
                String imgAchtergrondPath = String.format("src/gui/images/%s.png", imgAchtergrond);
                String imgEdelsteen = String.format("src/gui/images/%s.png", ontwikkelingIIIDTO.type().type());
                String prestigePunten = String.valueOf(ontwikkelingIIIDTO.prestigePunten());
                String vereisteDiamanten = geefVereistEdelstenenOntwk(ontwikkelingIIIDTO, MessageHelper.getString("color_diamond"));
                String vereisteRobijnen = geefVereistEdelstenenOntwk(ontwikkelingIIIDTO, MessageHelper.getString("color_ruby"));
                String vereisteSaffier = geefVereistEdelstenenOntwk(ontwikkelingIIIDTO, MessageHelper.getString("color_sapphire"));
                String vereisteSmaragd = geefVereistEdelstenenOntwk(ontwikkelingIIIDTO, MessageHelper.getString("color_emerald"));
                String vereisteOnyx = geefVereistEdelstenenOntwk(ontwikkelingIIIDTO, MessageHelper.getString("color_onyx"));

                Node ontwikkelingKaart = hoofdPaneel.laadOntwKaartScherm(prestigePunten, vereisteRobijnen, vereisteDiamanten, vereisteSaffier, vereisteSmaragd, vereisteOnyx, imgEdelsteen, imgAchtergrondPath);
                ontwikkelingKaart.setId(id);
                ontwikkelingKaart.setOnMouseClicked(this::opKlikBtnOntwikkelingsKaart);
                GridPane.setConstraints(ontwikkelingKaart, i, 2);
                spelGrid.getChildren().add(ontwikkelingKaart);
                domeinController.voegOntwikkelingIIIToeAanOpenOntwikkelingIII(id);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
        lblOntwStack_3.setText(String.valueOf(domeinController.geefSpelDTO().ontwikkelingIII().size()));
    }

    /**
     * Laadt alle edelstenen in GUI
     */
    public void initialiseerEdelstenen() {
        Map<String, Label> typeNaarLabel = new HashMap<>() {{
            put(EdelsteenType.DIAMANT.name(), lblAantalDiamant);
            put(EdelsteenType.SAFFIER.name(), lblAantalSaffier);
            put(EdelsteenType.SMARAGD.name(), lblAantalSmaragd);
            put(EdelsteenType.ROBIJN.name(), lblAantalRobijn);
            put(EdelsteenType.ONYX.name(), lblAantalOnyx);
        }};
        Collection<VoorraadKostDTO> edelstenenDTO = domeinController.geefEdelstenenDTO();
        for (VoorraadKostDTO edelsteenDTO : edelstenenDTO) {
            String edelsteenType = edelsteenDTO.edelsteenTypeDTO().type();
            Label label = typeNaarLabel.get(edelsteenType);
            label.setText(Integer.toString(edelsteenDTO.aantal()));
        }
    }
    //  endregion


    // region Opklik methodes
    @FXML
    public void opKlikBtnPasBeurt() {
        domeinController.getSpel().bepaalHuidigeSpeler();
        lblSpelerNaam.setText(domeinController.geefHuidigeSpelerDTO().gebruikersnaam());
    }

    /**
     * Op klik btn ontwikkelingskaart, wordt een ontwikkeling toegevoegd aan de speler en een nieuwe ontwikkeling geinitialiseerd.
     *
     * @param e mouseEvent
     */
    public void opKlikBtnOntwikkelingsKaart(MouseEvent e) {
        StackPane stackPane = (StackPane) e.getSource();
        int rijWaarde = GridPane.getRowIndex(stackPane);
        int kolomWaarde = GridPane.getColumnIndex(stackPane);

        String id = stackPane.getId();
        String niveau = id.split("")[5];

        try {
            boolean kanKopen = domeinController.kanHuidigeSpelerOntwikkelingKopen(id, niveau);
            if (kanKopen) {
                domeinController.voegOntwikkelingToeAanSpeler(id, niveau);
                spelGrid.getChildren().remove(stackPane);
                initialiseerNieuweOntwikkeling(niveau, rijWaarde, kolomWaarde);
                schakelSpelGrid(true);
                toonAlert(MessageHelper.getString("buy_development_title"), MessageHelper.getString("buy_development_message"));
                initialiseerEdelstenen();

                int aantalEdele = 0;

                for (Node edeleKaart : gridEdele.getChildren()) {
                    String edeleKaartId = edeleKaart.getId();

                    boolean kanEdeleKrijgen = domeinController.kanHuidigeSpelerEdeleKrijgen(edeleKaartId);
                    if (kanEdeleKrijgen)
                        aantalEdele++;
                }

                if (aantalEdele > 1) {
                    btnPasBeurt.setDisable(true);
                    btnKoopOntwikkeling.setDisable(true);
                    btnPakTweeEdelstenen.setDisable(true);
                    btnPakDrieEdelstenen.setDisable(true);

                    schakelGridEdelen(false);

                } else if (aantalEdele == 1){
                    for (Node edeleKaart : gridEdele.getChildren()) {
                        String edeleKaartId = edeleKaart.getId();

                        boolean kanEdeleKrijgen = domeinController.kanHuidigeSpelerEdeleKrijgen(edeleKaartId);
                        if (kanEdeleKrijgen) {
                            domeinController.voegEdeleToeAanSpeler(edeleKaartId);
                            gridEdele.getChildren().remove(edeleKaart);
                        }

                    }
                }

                domeinController.bepaalHuidigeSpelerInSpel();

                lblSpelerNaam.setText(domeinController.geefHuidigeSpelerDTO().gebruikersnaam());
            } else {
                toonAlert(MessageHelper.getString("cant_buy_development_title"), MessageHelper.getString("cant_buy_development_message"));
                schakelSpelGrid(true);
            }
        } catch (Exception error) {
            System.err.println("Ontwikkeling bestaat niet");
        }
        try {
            if (!domeinController.getSpel().getWinnaars().isEmpty()) {
                hoofdPaneel.toonWinnaarScherm();
            }
        } catch (Exception error) {
            System.err.println("Winaarscherm kapot");
        }
    }

    public void opKlikBtnKiesEdele(MouseEvent e) {
        StackPane stackPane = (StackPane) e.getSource();

        String id = stackPane.getId();

        try {
            boolean kanKopen = domeinController.kanHuidigeSpelerEdeleKrijgen(id);
            if (kanKopen) {
                domeinController.voegEdeleToeAanSpeler(id);
                gridEdele.getChildren().remove(stackPane);
                schakelGridEdelen(true);

                btnPasBeurt.setDisable(false);
                btnKoopOntwikkeling.setDisable(false);
                btnPakTweeEdelstenen.setDisable(false);
                btnPakDrieEdelstenen.setDisable(false);
            } else {
                toonAlert(MessageHelper.getString("cant_get_noble_title"), MessageHelper.getString("cant_get_noble_message"));
            }
        } catch (Exception error) {
            System.err.println("Edele bestaat niet");
        }
    }

    /**
     * Zet alle edelen uit de GUI op actief of inactief
     *
     * @param actief Boolean voor actief of inactief
     */
    private void schakelGridEdelen(boolean actief) {
        gridEdele.setDisable(actief);
    }

    /**
     * Op klik methode voor 2 edelstenen zelfde kleur.
     */
    public void opKlikBtnPakTweeEdelstenen() {
        schakelEdelstenen(false);
        stpEdelstenen.getChildren().forEach(e -> {
            EdelsteenTypeDTO edelsteenType = converteerIdNaarEdelsteenType(e.getId());
            e.setOnMousePressed(null);
            e.setOnMousePressed(event -> {
                String resultaat = domeinController.pakTweeEdelstenenDezelfdeKleur(edelsteenType);
                initialiseerEdelstenen();
                toonAlert(MessageHelper.getString("take_two_gems"), resultaat);
                domeinController.bepaalHuidigeSpelerInSpel();
                lblSpelerNaam.setText(domeinController.geefHuidigeSpelerDTO().gebruikersnaam());
                schakelEdelstenen(true);
            });
        });
    }

    /**
     * Op klik methode voor 3 edelstenen verschillende kleur.
     */
    public void opKlikBtnDrieEdelstenen() {
        schakelEdelstenen(false);
        HashSet<EdelsteenTypeDTO> edelstenen = new HashSet<>();

        for (Node gem : stpEdelstenen.getChildren()) {
            EdelsteenTypeDTO edelsteenType = converteerIdNaarEdelsteenType(gem.getId());
            gem.setOnMousePressed(null);

            gem.setOnMouseClicked(event -> {
                edelstenen.add(edelsteenType);

                gem.setStyle("-fx-background-color: #F3C506; -fx-background-radius: 5; -fx-alignment: center");
                if (edelstenen.size() >= 3) {
                    schakelEdelstenen(true);
                    String resultaat = domeinController.pakDrieEdelstenenVeschillendeKleur(edelstenen);
                    initialiseerEdelstenen();
                    toonAlert(MessageHelper.getString("take_three_gems"), resultaat);
                    domeinController.bepaalHuidigeSpelerInSpel();
                    lblSpelerNaam.setText(domeinController.geefHuidigeSpelerDTO().gebruikersnaam());

                    for (Node resetGem : stpEdelstenen.getChildren()) {
                        resetGem.setStyle("-fx-background-color: transparent;");
                    }
                }
            });
        }
    }

    public void opKlikBtnKoopOntwikkeling() {
        schakelSpelGrid(false);
    }

    // endregion


    // region GeefVereisteEdelstenen methodden

    /**
     * Geeft aantal vereiste edelstenen terug voor een edelsteen met een bepaalde kleur.
     *
     * @param edelDTO EdelsteenDTO
     * @param kleur   String van kleur
     * @return String van aantal vereiste edelstenen voor een edelsteen met de kleur.
     */
    private String geefVereistEdelstenenEdel(EdeleDTO edelDTO, String kleur) {
        return String.valueOf(edelDTO.vereisteBonussen().stream()
                .filter(b -> b.edelsteenTypeDTO().kleur().equals(kleur))
                .findFirst()
                .map(b -> b.aantal())
                .orElse(0));
    }

    /**
     * Geeft aantal vereiste edelstenen terug voor een edelsteen met een bepaalde kleur.
     *
     * @param ontwikkelingDTO OntwikkelingDTO
     * @param kleur           String van kleur
     * @return String van aantal vereiste edelstenen voor een edelsteen met de kleur.
     */
    private String geefVereistEdelstenenOntwk(OntwikkelingDTO ontwikkelingDTO, String kleur) {
        return String.valueOf(ontwikkelingDTO.kosten().stream()
                .filter(b -> b.edelsteenTypeDTO().kleur().equals(kleur))
                .findFirst()
                .map(b -> b.aantal())
                .orElse(0));
    }
    // endregion


    // region Toon methodes

    /**
     * Toont een modal voor de spelerinfo
     *
     * @param spelerDTO SpelerDTO met alle gegevens
     */
    private void toonSpelerInfo(SpelerDTO spelerDTO) {
        spelerDTO = domeinController.geefSpelerDTO(spelerDTO.gebruikersnaam());
        File spelerInfoFile = new File("src/gui/fxml/SpelerInfoScherm.fxml");
        Stage stageModal = new Stage();
        Scene scene = null;
        try {
            FXMLLoader infoScreen = new FXMLLoader(spelerInfoFile.toURI().toURL());
            infoScreen.setController(new SpelerInfoController(spelerDTO));

            scene = new Scene(infoScreen.load());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        stageModal.setTitle("Speler info");
        stageModal.initModality(Modality.APPLICATION_MODAL);
        stageModal.setResizable(false);
        stageModal.setScene(scene);
        stageModal.showAndWait();
    }

    /**
     * Toont een alert met de gegeven titel en tekst.
     *
     * @param title Titel van de alert
     * @param text  Tekst van de alert
     */
    public void toonAlert(String title, String text) {
        File spelerInfoFile = new File("src/gui/fxml/AlertScherm.fxml");
        Stage stageModal = new Stage();
        Scene scene = null;
        try {
            FXMLLoader infoScreen = new FXMLLoader(spelerInfoFile.toURI().toURL());
            infoScreen.setController(new AlertController(true, title, text));

            scene = new Scene(infoScreen.load());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        stageModal.setTitle(title);

        stageModal.initModality(Modality.APPLICATION_MODAL);
        stageModal.setResizable(false);
        stageModal.setScene(scene);
        stageModal.showAndWait();
    }
    // endregion


    // region Utils

    /**
     * Converteert een ID naar een edelsteentype.
     *
     * @param stpkId String van Node ID
     * @return EdelsteenTypeDTO
     */
    private EdelsteenTypeDTO converteerIdNaarEdelsteenType(String stpkId) {
        return switch (stpkId) {
            case "stkpDiamant" ->
                    new EdelsteenTypeDTO(MessageHelper.getStringLanguage("gems_diamond", "nl"), MessageHelper.getString("color_diamond"));
            case "stkpSaffier" ->
                    new EdelsteenTypeDTO(MessageHelper.getStringLanguage("gems_sapphire", "nl"), MessageHelper.getString("color_sapphire"));
            case "stkpSmaragd" ->
                    new EdelsteenTypeDTO(MessageHelper.getStringLanguage("gems_emerald", "nl"), MessageHelper.getString("color_emerald"));
            case "stkpRobijn" ->
                    new EdelsteenTypeDTO(MessageHelper.getStringLanguage("gems_ruby", "nl"), MessageHelper.getString("color_ruby"));
            case "stkpOnyx" ->
                    new EdelsteenTypeDTO(MessageHelper.getStringLanguage("gems_onyx", "nl"), MessageHelper.getString("color_onyx"));
            default -> null;
        };
    }

    /**
     * Zet alle edelstenen uit de GUI op actief of inactief.
     *
     * @param actief Boolean voor actief of inactief
     */
    private void schakelEdelstenen(boolean actief) {
        stpEdelstenen.getChildren().forEach(e -> {
            e.setDisable(actief);
        });
    }

    private void schakelSpelGrid(boolean actief) {
        spelGrid.setDisable(actief);
    }
    // endregion

}

