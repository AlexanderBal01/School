package gui;

import domein.DomeinController;
import gui.controllers.*;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class HoofdPaneel extends BorderPane implements Initializable {

    private final DomeinController domeinController;

    FXMLLoader menuScherm;
    MenuController menuController;

    FXMLLoader opstellingScherm;
    OpstellingController opstellingController;

    FXMLLoader spelScherm;
    SpelController spelController;

    FXMLLoader winnaarScherm;
    WinnaarController winnaarController;

    /**
     * Constructor voor HoofdPaneel
     *
     * @param controller DomeinController
     * @throws IOException Fouten bij het laden van het scherm
     */
    public HoofdPaneel(DomeinController controller) throws IOException {
        domeinController = controller;

        menuScherm = new FXMLLoader(getClass().getResource("fxml/MenuScherm.fxml"));
        menuController = new MenuController(domeinController, this);
        menuScherm.setController(menuController);

        opstellingScherm = new FXMLLoader(getClass().getResource("fxml/OpstellingScherm.fxml"));
        opstellingController = new OpstellingController(domeinController, this);
        opstellingScherm.setController(opstellingController);

        spelScherm = new FXMLLoader(getClass().getResource("fxml/SpelScherm.fxml"));
        spelController = new SpelController(domeinController, this);
        spelScherm.setController(spelController);

        voegComponentenToe();
    }


    /**
     * Voegt alle componenten toe aan het scherm
     *
     * @throws IOException Fouten bij het laden van het scherm
     */
    private void voegComponentenToe() throws IOException {
        setCenter(menuScherm.load());
    }

    /**
     * Toont het taal veranderen scherm
     *
     * @throws IOException Fouten bij het laden van het scherm
     */
    public void toonTaalVeranderen() throws IOException {
        FXMLLoader languageScreen = new FXMLLoader(getClass().getResource("fxml/TaalScherm.fxml"));
        languageScreen.setController(new TaalController(this));
        setCenter(languageScreen.load());
    }

    /**
     * Toont het hoofd menu scherm
     *
     * @throws IOException Fouten bij het laden van het scherm
     */
    public void toonHoofdMenu() throws IOException {
        menuScherm = new FXMLLoader(getClass().getResource("fxml/MenuScherm.fxml"));
        menuController = new MenuController(domeinController, this);
        menuScherm.setController(menuController);
        setCenter(menuScherm.load());
    }


    /**
     * Toont het spel maken scherm met een CreateController
     *
     * @throws IOException Fouten bij het laden van het scherm
     */
    public void toonSpelMaken() throws IOException {
        opstellingScherm = new FXMLLoader(getClass().getResource("fxml/OpstellingScherm.fxml"));
        opstellingController = new OpstellingController(domeinController, this);
        opstellingScherm.setController(opstellingController);
        setCenter(opstellingScherm.load());
    }

    public void toonWinnaarScherm() throws IOException {
        winnaarScherm = new FXMLLoader(getClass().getResource("fxml/WinnaarScherm.fxml"));
        winnaarController = new WinnaarController(domeinController, this);
        winnaarScherm.setController(winnaarController);
        setCenter(winnaarScherm.load());
    }

    /**
     * Toont het spel scherm met een SpelController
     *
     * @throws IOException Fouten bij het laden van het scherm
     */
    public void toonSpelScherm() throws IOException {
        spelScherm = new FXMLLoader(getClass().getResource("fxml/SpelScherm.fxml"));
        spelController = new SpelController(domeinController, this);
        spelScherm.setController(spelController);
        setCenter(spelScherm.load());
    }


    /**
     * Toont een alert scherm
     *
     * @param isInfo      boolean of een info alert of een error alert
     * @param title       String titel van het scherm
     * @param headerText  String header van het scherm
     * @param contentText String content van het scherm
     * @throws IOException Fouten bij het laden van het scherm
     */
    public void toonAlertScherm(boolean isInfo, String title, String headerText, String contentText) throws IOException {
        FXMLLoader alertScreen = new FXMLLoader(getClass().getResource("fxml/AlertScherm.fxml"));
        alertScreen.setController(new AlertController(this, isInfo, headerText, contentText));
        Stage stageModal = new Stage();
        stageModal.setTitle(title);
        Scene scene = new Scene(alertScreen.load());
        stageModal.initModality(Modality.APPLICATION_MODAL);
        stageModal.setResizable(false);
        stageModal.setScene(scene);
        stageModal.showAndWait();
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }

    public Node laadEdeleKaartScherm(String imgEdel, String lblPrestige, String lblRabijn, String lblDiamant, String lblSaffier, String lblSmaragd, String lblOnyx) throws IOException {
        FXMLLoader edeleKaart = new FXMLLoader(getClass().getResource("fxml/EdeleKaart.fxml"));
        EdelekaartController edeleKaartController = new EdelekaartController(imgEdel, lblPrestige, lblRabijn, lblDiamant, lblSaffier, lblSmaragd, lblOnyx);
        edeleKaart.setController(edeleKaartController);
        return edeleKaart.load();
    }
    public Node laadOntwKaartScherm(String lblPrestige, String lblRobijn, String lblDiamant, String lblSaffier, String lblSmaragd, String lblOnyx, String imgEdelsteen, String imgAchtergrond) throws IOException {
        FXMLLoader ontwKaart = new FXMLLoader(getClass().getResource("fxml/OntwKaart.fxml"));
        OntwKaartController ontwKaartController = new OntwKaartController(lblPrestige, lblRobijn, lblDiamant, lblSaffier, lblSmaragd, lblOnyx, imgEdelsteen, imgAchtergrond);
        ontwKaart.setController(ontwKaartController);
        return ontwKaart.load();
    }
}
