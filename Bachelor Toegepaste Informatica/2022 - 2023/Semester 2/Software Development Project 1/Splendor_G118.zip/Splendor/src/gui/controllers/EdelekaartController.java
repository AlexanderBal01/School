package gui.controllers;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.Set;

public class EdelekaartController implements Initializable {

    private final String afbeelding;
    private final String prestige;
    private final String rabijn;
    private final String diamant;
    private final String saffier;
    private final String smaragd;
    private final String onyx;

    // region FXML
    @FXML
    private ImageView imgEdel;
    @FXML
    private Label lblPrestige;
    @FXML
    private Label lblRabijn;
    @FXML
    private Label lblDiamant;
    @FXML
    private Label lblSaffier;
    @FXML
    private Label lblSmaragd;
    @FXML
    private Label lblOnyx;
    // endregion

    public EdelekaartController(String imgEdel, String lblPrestige, String lblRabijn, String lblDiamant, String lblSaffier, String lblSmaragd, String lblOnyx) throws IOException {
        this.afbeelding = imgEdel;
        this.prestige = lblPrestige;
        this.rabijn = lblRabijn;
        this.diamant = lblDiamant;
        this.saffier = lblSaffier;
        this.smaragd = lblSmaragd;
        this.onyx = lblOnyx;
    }

    // region Setter
    private void setImgEdel(ImageView imgEdel) {
        this.imgEdel = imgEdel;
    }

    private void setLblPrestige(Label lblPrestige) {
        this.lblPrestige = lblPrestige;
    }

    private void setLblRabijn(Label lblRabijn) {
        this.lblRabijn = lblRabijn;
    }

    private void setLblDiamant(Label lblDiamant) {
        this.lblDiamant = lblDiamant;
    }

    private void setLblSaffier(Label lblSaffier) {
        this.lblSaffier = lblSaffier;
    }

    private void setLblSmaragd(Label lblSmaragd) {
        this.lblSmaragd = lblSmaragd;
    }

    private void setLblOnyx(Label lblOnyx) {
        this.lblOnyx = lblOnyx;
    }
    // endregion

    // region Getter
    public Label getLblPrestige() {
        return lblPrestige;
    }

    public Label getLblRabijn() {
        return lblRabijn;
    }

    public Label getLblDiamant() {
        return lblDiamant;
    }

    public Label getLblSaffier() {
        return lblSaffier;
    }

    public Label getLblSmaragd() {
        return lblSmaragd;
    }

    public Label getLblOnyx() {
        return lblOnyx;
    }

    // endregion

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        this.imgEdel.setImage(laadAfbeelding(afbeelding));
        this.lblPrestige.setText(prestige);
        this.lblRabijn.setText(rabijn);
        this.lblDiamant.setText(diamant);
        this.lblSaffier.setText(saffier);
        this.lblSmaragd.setText(smaragd);
        this.lblOnyx.setText(onyx);
    }

    /**
     * Stelt de afbeelding in vanaf een bestand
     *
     * @param imageFile het pad naar het afbeeldingsbestand
     * @return de afbeelding
     */
    private Image laadAfbeelding(String imageFile) {
        File bestand = new File(imageFile);
        return new Image(bestand.toURI().toString());
    }

}
