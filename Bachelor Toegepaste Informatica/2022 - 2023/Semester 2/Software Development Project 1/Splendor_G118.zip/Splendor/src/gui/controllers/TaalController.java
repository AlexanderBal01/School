package gui.controllers;

import gui.HoofdPaneel;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import utils.MessageHelper;

import java.io.IOException;
import java.net.URL;
import java.util.Objects;
import java.util.ResourceBundle;

public class TaalController implements Initializable {

    private HoofdPaneel hoofdPaneel;

    // region FXML
    @FXML private RadioButton rdoEngels;
    @FXML private RadioButton rdoNederlands;
    @FXML private Label lblKiesTaal;
    @FXML private Button  btnSelecteer;
    // endregion

    /**
     * Constructor voor LanguageController
     * @param hoofdPaneel HoofdPaneel object
     */
    public TaalController(HoofdPaneel hoofdPaneel) {
        this.hoofdPaneel = hoofdPaneel;
    }

    /**
     * Initialiseer de controller met de juiste labels en buttons.
     * De radiobuttons worden gecontroleerd door de ToggleGroup.
     * @param url URL
     * @param resourceBundle ResourceBundle
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        ToggleGroup toggleGroup = new ToggleGroup();
        rdoEngels.setToggleGroup(toggleGroup);
        rdoNederlands.setToggleGroup(toggleGroup);

        lblKiesTaal.setText(MessageHelper.getString("language_choose"));
        rdoEngels.setText(MessageHelper.getString("language_english"));
        rdoNederlands.setText(MessageHelper.getString("language_dutch"));

        btnSelecteer.setText(MessageHelper.getString("menu_select"));

        if (MessageHelper.getLanguage().equals("NL")) {
            rdoNederlands.setSelected(true);
        } else {
            rdoEngels.setSelected(true);
        }
    }

    /**
     * Controleer of er een radiobutton gekozen is.
     * @param event ActionEvent
     */
    @FXML
    private void handleGekozenTaal(ActionEvent event) {
        RadioButton radioButton = (RadioButton) event.getSource();
        if (radioButton.isSelected()) {
            String gekozenTaal = radioButton.getText();
            stelTaalIn(gekozenTaal);
        }
    }

    /**
     * Verander de taal van het spel via messagehelper en toon de hoofdmenu.
     * @throws IOException krijgt bij fouten.
     */
    @FXML
    private void gaNaarHoofdMenu() throws IOException {
        hoofdPaneel.toonHoofdMenu();
    }

    /**
     * Stelt de taal in op basis van de gekozen taal.
     */
    private void stelTaalIn(String taal) {
        if (Objects.equals(taal, "Dutch") || Objects.equals(taal, "Nederlands"))
            MessageHelper.setLanguage("nl");
        else
            MessageHelper.setLanguage("en");
    }
}
