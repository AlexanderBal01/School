package gui.controllers;

import domein.DomeinController;
import dto.SpelerDTO;
import gui.HoofdPaneel;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import utils.MessageHelper;

import java.net.URL;
import java.util.Collection;
import java.util.ResourceBundle;
import java.util.stream.Collectors;

public class WinnaarController implements Initializable {

    private final HoofdPaneel hoofdPaneel;
    private final DomeinController domeinController;

    // region FXML
    @FXML
    private Label lblWinnaarsTitel;
    @FXML
    private Label lblIsWinnaarTitel;
    @FXML
    private Label lblEerstePlaatsTekst;
    @FXML
    private Button btnExit;
    // endregion

    /**
     * Constructor voor WinnaarController
     *
     * @param hoofdPaneel HoofdPaneel object
     */
    public WinnaarController(DomeinController domeinController, HoofdPaneel hoofdPaneel) {
        this.hoofdPaneel = hoofdPaneel;
        this.domeinController = domeinController;
    }

    /**
     * Initialiseer de controller met de juiste labels.
     *
     * @param url            URL
     * @param resourceBundle ResourceBundle
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        lblWinnaarsTitel.setText(MessageHelper.getString("winner_title"));
        lblIsWinnaarTitel.setText(MessageHelper.getString("is_winner_title"));
        Collection<SpelerDTO> winaars = domeinController.geefWinnaarDTO();
        lblEerstePlaatsTekst.setText(winaars.stream().map(spelerDTO -> spelerDTO.gebruikersnaam()).collect(Collectors.joining(",")));
    }

    @FXML
    public void opKlikBtnExit() {
        Platform.exit();
    }
}