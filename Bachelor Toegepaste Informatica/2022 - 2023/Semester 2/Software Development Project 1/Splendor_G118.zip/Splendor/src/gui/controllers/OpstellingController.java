package gui.controllers;

import domein.DomeinController;
import dto.SpelerDTO;
import gui.HoofdPaneel;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import utils.MessageHelper;
import utils.TextHelper;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class OpstellingController implements Initializable {

    DomeinController domeinController;
    HoofdPaneel hoofdPaneel;

    // region FXML
    @FXML private ListView<String> lstSpelers;
    @FXML private Label lblSelectPlayer;
    @FXML private Label lblUsername;
    @FXML private TextField txtUsername;
    @FXML private Button btnMaakSpel;
    @FXML private Button btnVoegSpeler;
    @FXML private Button btnVerwijderSpeler;
    // endregion


    /**
     * Lijst van spelers in het spel
     */
    private final ObservableList<String> spelers = FXCollections.observableArrayList();

    /**
     * Constructor voor CreateController
     *
     * @param domeinController DomeinController
     * @param hoofdPaneel      HoofdPaneel
     */
    public OpstellingController(DomeinController domeinController, HoofdPaneel hoofdPaneel)  {
        this.domeinController = domeinController;
        this.hoofdPaneel = hoofdPaneel;
    }

    /**
     * Initialiseer de labels en buttons met de correcte tekst
     *
     * @param url            URL
     * @param resourceBundle ResourceBundle
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        lblSelectPlayer.setText(MessageHelper.getString("players_select"));
        lblUsername.setText(TextHelper.Capitalize(MessageHelper.getString("player_username")));
        lstSpelers.setItems(spelers);
        btnMaakSpel.setText(MessageHelper.getString("menu_game_start"));
    }

    /**
     * Voegt een speler toe aan de lijst van spelers
     */
    @FXML
    public void handleVoegSpelerToe() throws IOException {
        try {
            if (txtUsername.getText().isEmpty()) throw new Exception(MessageHelper.getString("player_username_empty"));
            SpelerDTO gevondenSpelerDTO = domeinController.selecteerSpelerDtoUitDatabank(txtUsername.getText());
            String messageGevondenSpeler = String.format(MessageHelper.getString("player_add_format"), gevondenSpelerDTO.gebruikersnaam(), gevondenSpelerDTO.geboortejaar());
            hoofdPaneel.toonAlertScherm(true, MessageHelper.getString("player_added"), MessageHelper.getString("message_everthing_right"), messageGevondenSpeler);
            spelers.add(txtUsername.getText());
            txtUsername.clear();
        } catch (Exception e) {
            hoofdPaneel.toonAlertScherm(false, MessageHelper.getString("player_added"), MessageHelper.getString("message_something_wrong"), e.getMessage());
        } finally {
            if (spelers.size() > 0) btnVerwijderSpeler.disableProperty().setValue(false);
            if (spelers.size() >= 2) btnMaakSpel.disableProperty().setValue(false);
            if (spelers.size() > 3) btnVoegSpeler.disableProperty().setValue(true);
        }
    }

    @FXML
    public void handleVerwijderSpeler() {
        String selectedPlayer = lstSpelers.getSelectionModel().getSelectedItem();
        domeinController.verwijderSpelerInSpel(selectedPlayer);
        lstSpelers.getItems().remove(selectedPlayer);
        if (spelers.size() < 1) btnVerwijderSpeler.disableProperty().setValue(true);
        if (spelers.size() < 2) btnMaakSpel.disableProperty().setValue(true);
        if (spelers.size() > 3) btnVoegSpeler.disableProperty().setValue(true);
    }

    /**
     * Maakt spel met opgegeven spelers
     */
    @FXML
    public void handleMaakSpel() throws IOException {
        domeinController.maakNieuwSpel();
        hoofdPaneel.toonSpelScherm();
    }
}
