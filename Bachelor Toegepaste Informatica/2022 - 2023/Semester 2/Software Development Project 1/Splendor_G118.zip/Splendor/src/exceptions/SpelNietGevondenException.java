package exceptions;

public class SpelNietGevondenException extends RuntimeException {
    public SpelNietGevondenException() {
    }

    public SpelNietGevondenException(String message) {
        super(message);
    }

    public SpelNietGevondenException(String message, Throwable cause) {
        super(message, cause);
    }

    public SpelNietGevondenException(Throwable cause) {
        super(cause);
    }

    public SpelNietGevondenException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
