package exceptions;

public class MaximumAantalSpelerException extends RuntimeException {
    public MaximumAantalSpelerException() {
    }

    public MaximumAantalSpelerException(String message) {
        super(message);
    }

    public MaximumAantalSpelerException(String message, Throwable cause) {
        super(message, cause);
    }

    public MaximumAantalSpelerException(Throwable cause) {
        super(cause);
    }

    public MaximumAantalSpelerException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
