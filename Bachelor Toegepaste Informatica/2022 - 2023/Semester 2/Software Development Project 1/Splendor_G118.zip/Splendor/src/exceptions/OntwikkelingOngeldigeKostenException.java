package exceptions;

public class OntwikkelingOngeldigeKostenException extends RuntimeException {
    public OntwikkelingOngeldigeKostenException() {
    }

    public OntwikkelingOngeldigeKostenException(String message) {
        super(message);
    }

    public OntwikkelingOngeldigeKostenException(String message, Throwable cause) {
        super(message, cause);
    }

    public OntwikkelingOngeldigeKostenException(Throwable cause) {
        super(cause);
    }

    public OntwikkelingOngeldigeKostenException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
