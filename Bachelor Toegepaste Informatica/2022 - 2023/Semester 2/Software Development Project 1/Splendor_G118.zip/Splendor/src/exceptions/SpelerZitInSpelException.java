package exceptions;

public class SpelerZitInSpelException extends RuntimeException {
    public SpelerZitInSpelException() {
    }

    public SpelerZitInSpelException(String message) {
        super(message);
    }

    public SpelerZitInSpelException(String message, Throwable cause) {
        super(message, cause);
    }

    public SpelerZitInSpelException(Throwable cause) {
        super(cause);
    }

    public SpelerZitInSpelException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
