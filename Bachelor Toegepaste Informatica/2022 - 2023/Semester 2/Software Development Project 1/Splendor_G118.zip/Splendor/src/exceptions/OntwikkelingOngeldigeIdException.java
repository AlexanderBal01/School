package exceptions;

public class OntwikkelingOngeldigeIdException extends RuntimeException {
    public OntwikkelingOngeldigeIdException() {
    }

    public OntwikkelingOngeldigeIdException(String message) {
        super(message);
    }

    public OntwikkelingOngeldigeIdException(String message, Throwable cause) {
        super(message, cause);
    }

    public OntwikkelingOngeldigeIdException(Throwable cause) {
        super(cause);
    }

    public OntwikkelingOngeldigeIdException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
