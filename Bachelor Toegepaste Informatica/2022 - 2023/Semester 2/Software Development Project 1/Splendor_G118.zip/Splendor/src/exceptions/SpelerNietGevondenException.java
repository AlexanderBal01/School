package exceptions;

public class SpelerNietGevondenException extends RuntimeException {
    public SpelerNietGevondenException() {
    }

    public SpelerNietGevondenException(String message) {
        super(message);
    }

    public SpelerNietGevondenException(String message, Throwable cause) {
        super(message, cause);
    }

    public SpelerNietGevondenException(Throwable cause) {
        super(cause);
    }

    public SpelerNietGevondenException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
