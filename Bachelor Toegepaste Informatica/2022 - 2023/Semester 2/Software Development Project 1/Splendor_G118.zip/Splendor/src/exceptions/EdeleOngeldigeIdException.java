package exceptions;

public class EdeleOngeldigeIdException extends RuntimeException {
    public EdeleOngeldigeIdException() {
    }

    public EdeleOngeldigeIdException(String message) {
        super(message);
    }

    public EdeleOngeldigeIdException(String message, Throwable cause) {
        super(message, cause);
    }

    public EdeleOngeldigeIdException(Throwable cause) {
        super(cause);
    }

    public EdeleOngeldigeIdException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
