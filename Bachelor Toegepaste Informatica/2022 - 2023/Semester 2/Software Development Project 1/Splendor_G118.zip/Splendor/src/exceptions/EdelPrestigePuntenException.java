package exceptions;

public class EdelPrestigePuntenException extends RuntimeException {
    public EdelPrestigePuntenException() {
    }

    public EdelPrestigePuntenException(String message) {
        super(message);
    }

    public EdelPrestigePuntenException(String message, Throwable cause) {
        super(message, cause);
    }

    public EdelPrestigePuntenException(Throwable cause) {
        super(cause);
    }

    public EdelPrestigePuntenException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
