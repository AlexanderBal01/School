package exceptions;

public class EdelVereisteBonussenException extends RuntimeException {
    public EdelVereisteBonussenException() {
    }

    public EdelVereisteBonussenException(String message) {
        super(message);
    }

    public EdelVereisteBonussenException(String message, Throwable cause) {
        super(message, cause);
    }

    public EdelVereisteBonussenException(Throwable cause) {
        super(cause);
    }

    public EdelVereisteBonussenException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
