package exceptions;

public class GeboortejaarException extends RuntimeException {
    public GeboortejaarException() {
    }

    public GeboortejaarException(String message) {
        super(message);
    }

    public GeboortejaarException(String message, Throwable cause) {
        super(message, cause);
    }

    public GeboortejaarException(Throwable cause) {
        super(cause);
    }

    public GeboortejaarException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
