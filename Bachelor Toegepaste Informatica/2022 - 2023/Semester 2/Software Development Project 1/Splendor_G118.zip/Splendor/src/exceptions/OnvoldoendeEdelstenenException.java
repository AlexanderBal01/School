package exceptions;

public class OnvoldoendeEdelstenenException extends RuntimeException {
    public OnvoldoendeEdelstenenException() {
    }

    public OnvoldoendeEdelstenenException(String message) {
        super(message);
    }

    public OnvoldoendeEdelstenenException(String message, Throwable cause) {
        super(message, cause);
    }

    public OnvoldoendeEdelstenenException(Throwable cause) {
        super(cause);
    }

    public OnvoldoendeEdelstenenException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
