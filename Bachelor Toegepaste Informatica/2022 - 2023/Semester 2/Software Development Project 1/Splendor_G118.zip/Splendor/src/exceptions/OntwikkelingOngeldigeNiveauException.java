package exceptions;

public class OntwikkelingOngeldigeNiveauException extends RuntimeException {
    public OntwikkelingOngeldigeNiveauException() {
    }

    public OntwikkelingOngeldigeNiveauException(String message) {
        super(message);
    }

    public OntwikkelingOngeldigeNiveauException(String message, Throwable cause) {
        super(message, cause);
    }

    public OntwikkelingOngeldigeNiveauException(Throwable cause) {
        super(cause);
    }

    public OntwikkelingOngeldigeNiveauException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
