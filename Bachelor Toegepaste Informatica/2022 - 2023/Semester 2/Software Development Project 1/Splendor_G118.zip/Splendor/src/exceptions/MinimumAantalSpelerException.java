package exceptions;

public class MinimumAantalSpelerException extends RuntimeException {
    public MinimumAantalSpelerException() {
    }

    public MinimumAantalSpelerException(String message) {
        super(message);
    }

    public MinimumAantalSpelerException(String message, Throwable cause) {
        super(message, cause);
    }

    public MinimumAantalSpelerException(Throwable cause) {
        super(cause);
    }

    public MinimumAantalSpelerException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
