package dto;

import domein.EdelsteenType;
import domein.Ontwikkeling;
import domein.VoorraadKost;

import java.util.Collection;

public record OntwikkelingDTO(String id, int prestigePunten, EdelsteenTypeDTO type, int niveau,
        Collection<VoorraadKostDTO> kosten) {

    public OntwikkelingDTO(Ontwikkeling ontwikkeling) {
        this(ontwikkeling.getId(), ontwikkeling.getPrestigePunten(), edelsteenTypeNaarDTO(ontwikkeling.getBonusType()), ontwikkeling.getNiveau(),
                kostenNaarDTO(ontwikkeling.getKosten()));
    }

    /**
     * Hier wordt edelsteenType omgezet naar EdeleDTO
     * De kleur wordt gebruikt om een EdelsteenTypeDTO te maken.
     * 
     * @param edelsteenType EdelsteenType van een Ontwikkeling die omgezet moet
     *                      worden
     * @return EdelsteenTypeDTO
     */
    private static EdelsteenTypeDTO edelsteenTypeNaarDTO(EdelsteenType edelsteenType) {
        return new EdelsteenTypeDTO(edelsteenType.name(),edelsteenType.getKleur());
    }

    /**
     * Hier wordt <u>VoorraadKost</u> lijst omgezet naar <u>VoorraadKostDTO</u>
     * lijst via een stream.
     * 
     * @param kosten Voorraad kosten van een Ontwikkeling die omgezet moet worden
     * @return VoorraadKostDTO lijst
     */
    private static Collection<VoorraadKostDTO> kostenNaarDTO(Collection<VoorraadKost> kosten) {
        return kosten
                .stream()
                .map(kost -> new VoorraadKostDTO(kost))
                .toList();
    }
}
