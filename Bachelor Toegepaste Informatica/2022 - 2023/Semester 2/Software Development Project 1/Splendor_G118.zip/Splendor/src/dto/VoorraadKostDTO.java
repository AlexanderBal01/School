package dto;

import domein.VoorraadKost;

public record VoorraadKostDTO(EdelsteenTypeDTO edelsteenTypeDTO, int aantal) {

    public VoorraadKostDTO(VoorraadKost voorraadKost) {
        this(new EdelsteenTypeDTO(voorraadKost.getType().name(), voorraadKost.getType().getKleur()), voorraadKost.getAantal());
    }
}
