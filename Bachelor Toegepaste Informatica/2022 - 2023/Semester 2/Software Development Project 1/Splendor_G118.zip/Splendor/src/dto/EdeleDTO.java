package dto;

import domein.Edele;
import domein.VoorraadKost;

import java.util.Collection;
import java.util.stream.Collectors;

public record EdeleDTO(int prestigePunten, Collection<VoorraadKostDTO> vereisteBonussen, String id) {

    public EdeleDTO(Edele edele) {
        this(edele.getPrestigePunten(), voorraadKostenNaarDTO(edele.getVereisteBonussen()), edele.getId());
    }

    /**
     * Hier wordt voorraadKosten lijst omgezet naar voorraadKostenDTO lijst via een
     * stream.
     * 
     * @param vereisteBonussen voorraadKosten lijst die omgezet moet worden in
     *                         VoorraadKostDTO's
     * @return VoorraadKostDTO lijst
     */
    private static Collection<VoorraadKostDTO> voorraadKostenNaarDTO(Collection<VoorraadKost> vereisteBonussen) {
        return vereisteBonussen
                .stream()
                .map(bonussen -> new VoorraadKostDTO(bonussen))
                .collect(Collectors.toList());
    }

    /**
     * Getter voor PrestigePunten
     * 
     * @return PrestigePunten
     */
    public int geefPrestigePuntenEdele() {
        return prestigePunten;
    }
}
