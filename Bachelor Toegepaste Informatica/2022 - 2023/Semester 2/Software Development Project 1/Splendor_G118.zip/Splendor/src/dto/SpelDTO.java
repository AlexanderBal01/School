package dto;

import domein.*;

import java.util.Collection;
import java.util.Set;
import java.util.stream.Collectors;

public record SpelDTO(
        Collection<SpelerDTO> spelers,
        Collection<OntwikkelingDTO> ontwikkelingI,
        Collection<OntwikkelingDTO> ontwikkelingII,
        Collection<OntwikkelingDTO> ontwikkelingIII,
        Set<VoorraadKostDTO> edelstenen,
        Collection<EdeleDTO> edelen,
        Collection<SpelerDTO> winnaar,
        boolean isEinde,
        SpelerDTO huidgeSpeler) {
    public SpelDTO(Spel spel) {
        this(
                spelersSpelNaarDTO(spel.getSpelers()),
                ontwikkelingenNaarDTO(spel.getOntwikkelingI()),
                ontwikkelingenNaarDTO(spel.getOntwikkelingII()),
                ontwikkelingenNaarDTO(spel.getOntwikkelingIII()),
                edelstenenNaarDTO(spel.getEdelstenen()),
                edelenNaarDTO(spel.getEdelen()),
                spelersSpelNaarDTO(spel.getWinnaars()),
                spel.getIsEinde(),
                spelerNaarDTO(spel.getHuidgeSpeler())
        );
    }

    private static SpelerDTO spelerNaarDTO(Speler speler) {
        if (speler == null)
            return null;
        return new SpelerDTO(speler);
    }

    /**
     * Hier wordt Speler lijst omgezet naar SpelerDTO lijst via een stream.
     *
     * @param spelers Speler lijst die omgezet moet worden in SpelerDTO lijst
     * @return SpelerDTO lijst
     */
    private static Collection<SpelerDTO> spelersSpelNaarDTO(Collection<Speler> spelers) {
        if (spelers == null) return null;
        return spelers
                .stream()
                .map(speler -> new SpelerDTO(speler))
                .collect(Collectors.toList());
    }

    /**
     * Hier wordt Ontwikkeling lijst omgezet naar OntwikkelingDTO lijst via een
     * stream.
     *
     * @param ontwikkelingen Ontwikkeling lijst die omgezet moet worden in
     *                       OntwikkelingDTO lijst
     * @return OntwikkelingDTO lijst
     */
    private static Collection<OntwikkelingDTO> ontwikkelingenNaarDTO(Collection<Ontwikkeling> ontwikkelingen) {
        return ontwikkelingen
                .stream()
                .map(ontwikkeling -> new OntwikkelingDTO(ontwikkeling))
                .collect(Collectors.toList());
    }

    /**
     * Hier wordt Edele lijst omgezet naar EdeleDTO lijst via een stream.
     *
     * @param edelen Edele lijst die omgezet moet worden in EdeleDTO lijst
     * @return EdeleDTO lijst
     */
    private static Collection<EdeleDTO> edelenNaarDTO(Collection<Edele> edelen) {
        return edelen.stream()
                .map(edele -> new EdeleDTO(edele))
                .collect(Collectors.toList());
    }

    private static Set<VoorraadKostDTO> edelstenenNaarDTO(Set<VoorraadKost> edelenstenen) {
        return edelenstenen
                .stream()
                .map(edelsteen -> new VoorraadKostDTO(edelsteen))
                .collect(Collectors.toSet());
    }
}
