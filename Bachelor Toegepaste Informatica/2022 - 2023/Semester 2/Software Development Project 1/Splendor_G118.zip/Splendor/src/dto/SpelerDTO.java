package dto;

import domein.*;
import java.util.Collection;
import java.util.Set;
import java.util.stream.Collectors;

public record SpelerDTO(String gebruikersnaam, int geboortejaar, boolean isStartSpeler, boolean isMijnBeurt,
        Collection<VoorraadKostDTO> edelstenen, Collection<EdeleDTO> edelen,
        Collection<OntwikkelingDTO> ontwikkelingen, Collection<VoorraadKostDTO> bonussen, int prestigePunten) {

    public SpelerDTO(Speler speler) {

        this(speler.getGebruikersnaam(), speler.getGeboortejaar(), speler.isStartSpeler(), speler.isMijnBeurt(),
                edelstenenNaarDTO(speler.getEdelstenen()), edelenNaarDTO(speler.getEdelen()),
                ontwikkelingenNaarDTO(speler.getOntwikkelingen()), edelstenenNaarDTO(speler.getEdelsteenBonussen()), speler.getPrestigePunten());
    }

    /**
     * Hier wordt edelstenen lijst omgezet naar VoorraadKostDTO lijst via een
     * stream.
     * 
     * @param edelenstenen Edelstenen lijst die omgezet moet worden in
     *                     VoorraadKostDTO's
     * @return een Set met VoorraadKostDTO's
     */
    private static Collection<VoorraadKostDTO> edelstenenNaarDTO(Set<VoorraadKost> edelenstenen) {
        return edelenstenen
                .stream()
                .map(voorraadKost -> new VoorraadKostDTO(voorraadKost))
                .collect(Collectors.toList());
    }

    /**
     * Hier wordt edelen lijst omgezet naar EdeleDTO lijst via een stream.
     *
     * @param edelen Edelen lijst die omgezet moet worden in EdeleDTO's
     * @return een ArrayList met EdeleDTO's
     */
    private static Collection<EdeleDTO> edelenNaarDTO(Collection<Edele> edelen) {
        return edelen
                .stream()
                .map(edele -> new EdeleDTO(edele))
                .collect(Collectors.toList());
    }

    /**
     * Hier wordt ontwikkelingen lijst omgezet naar OntwikkelingDTO lijst via een
     * stream.
     *
     * @param ontwikkelingen ontwikkeligen lijst die omgezet moet worden in
     *                       OntwikkelingDTO's
     * @return een ArrayList met OntwikkelingenDTO's
     */
    private static Collection<OntwikkelingDTO> ontwikkelingenNaarDTO(Collection<Ontwikkeling> ontwikkelingen) {
        return ontwikkelingen
                .stream()
                .map(ontwikkeling -> new OntwikkelingDTO(ontwikkeling))
                .collect(Collectors.toList());
    }

    public int geefPrestigePuntenEdelen() {
        return edelen.stream().mapToInt(edele -> edele.prestigePunten()).sum();
    }

}
