package dto;

public record EdelsteenTypeDTO(String type, String kleur) {}
