package cui;

import domein.DomeinController;
import dto.EdelsteenTypeDTO;
import dto.SpelerDTO;
import exceptions.OnvoldoendeEdelstenenException;
import utils.MessageHelper;

import java.util.HashSet;
import java.util.InputMismatchException;
import java.util.Objects;
import java.util.Scanner;


public class ConsoleApp {

    private final DomeinController controller;
    private final Scanner scan;

    public ConsoleApp() {
        scan = new Scanner(System.in);
        controller = new DomeinController();
        printLine("Welcome to the game Splendor!");
        selecteerOptie();
    }

    private void selecteerOptie() {
        int input = 0;
        printLine(MessageHelper.getString("language") + " " + MessageHelper.getLanguage() + "\n");
        printLine(MessageHelper.getString("menu_choose"));
        do {
            try {
                printLine("1) " + MessageHelper.getString("menu_option_1"));
                printLine("2) " + MessageHelper.getString("menu_option_2"));
                printLine("3) " + MessageHelper.getString("menu_option_3"));

                input = scan.nextInt();
            } catch (Exception e) {
                System.err.println("selecteerOptie: " + "Kies een optie uit de lijst!");
                scan.nextLine(); // consume invalid input
            }
        } while (input != 1 && input != 2 && input != 3);

        switch (input) {
            case 1 -> selecteerSpelers();
            case 2 -> selecteerTaal();
            case 3 -> System.exit(1);
        }
    }

    private void selecteerTaal() {
        int input = 0;
        printLine(MessageHelper.getString("language_choose"));
        do {
            try {
                printLine("1) " + MessageHelper.getString("language_dutch") + " " + "2) " + MessageHelper.getString("language_english"));
                input = scan.nextInt();
            } catch (Exception e) {
                System.err.println("selecteerTaal: " + "Kies een taal uit de lijst!");
                scan.nextLine(); // consume invalid input
            }
        } while (input != 1 && input != 2);

        switch (input) {
            case 1 -> MessageHelper.setLanguage("nl");
            case 2 -> MessageHelper.setLanguage("en");
        }
        printLine(MessageHelper.getString("language_chosen"));
        selecteerOptie();
    }

    private void selecteerSpelers() {
        printLine(MessageHelper.getString("players_select"));
        String userInput = null;
        int aantalSpeler = 0;
        scan.nextLine();
        do {
            try {
                printLine(MessageHelper.getString("player_search") + "\t");
                userInput = scan.nextLine();
                if (!Objects.equals(userInput, "x") && !Objects.equals(userInput, "")) {
                    SpelerDTO spelerDTO = controller.selecteerSpelerDtoUitDatabank(userInput);
                    System.out.printf((MessageHelper.getString("player_add_format")) + "%n", spelerDTO.gebruikersnaam(), spelerDTO.geboortejaar());
                    aantalSpeler++;
                    System.out.println();
                }
            } catch (Exception e) {
                System.err.println("selecteerSpelers: " + e.getMessage());
            }
        } while (!Objects.equals(userInput, "x") || (aantalSpeler < 2 || aantalSpeler > 4));
        maakSpel();
    }

    private void maakSpel() {
        try {
            controller.maakNieuwSpel();
            System.out.println("Nieuw spel aangemaakt met spelers: ");

            for (SpelerDTO spelerDTO : controller.geefSpelersDTO()) {
                System.out.println("\t- " + spelerDTO.gebruikersnaam() + ", " + spelerDTO.geboortejaar());
            }
            System.out.println(controller.getSpelOverzicht());
        } catch (Exception e) {
            printLine("maakSpel: " + e.getMessage());
        }
        selecteerStartSpel();
    }

    private void selecteerStartSpel() {
        int input = 0;
        printLine(MessageHelper.getString("menu_choose"));
        do {
            try {
                printLine("1) " + MessageHelper.getString("menu_game_start"));
                input = scan.nextInt();
            } catch (Exception e) {
                System.err.println("selecteerOptie: " + "Kies een optie uit de lijst!");
                scan.nextLine(); // consume invalid input
            }
        } while (input != 1);
        startSpel();
    }

    private void startSpel() {
        speelRondes();
    }

    private void speelRondes() {
        while (!controller.isEindeSpel()) {
            controller.bepaalHuidigeSpelerInSpel();
            speelBeurt();
        }
    }

    private void speelBeurt() {
        int input = 0;
        do {
            printLine(MessageHelper.getString("menu_game_player") + ":\t" + controller.geefHuidigeSpelerDTO());
            printLine(MessageHelper.getString("menu_choose"));
            try {
                printLine("1) " + MessageHelper.getString("menu_game_option1"));
                printLine("2) " + MessageHelper.getString("menu_game_option2"));
                printLine("3) " + MessageHelper.getString("menu_game_option3"));
                printLine("4) " + MessageHelper.getString("menu_game_option4"));
                input = scan.nextInt();
            } catch (Exception e) {
                System.err.println("selecteerOptie: " + "Kies een optie uit de lijst!");
                scan.nextLine(); // consume invalid input
            }
        } while (input != 1 && input != 2 && input != 3 && input != 4);
        switch (input) {
            case 1 -> selecteerMenuOptie1();
            case 2 -> selecteerMenuOptie2();
            case 3 -> System.err.println("Work in progress");
            case 4 -> System.err.println("Work in progress!");
        }
    }

    private void selecteerMenuOptie1() {
        int input;
        HashSet<String> gemChoose = new HashSet<>();
        do {
            try {
                printLine(MessageHelper.getString("menu_game_option1_choose"));
                printLine("1) " + MessageHelper.getString("gems_diamond"));
                printLine("2) " + MessageHelper.getString("gems_sapphire"));
                printLine("3) " + MessageHelper.getString("gems_emerald"));
                printLine("4) " + MessageHelper.getString("gems_ruby"));
                printLine("5) " + MessageHelper.getString("gems_onxy"));
                if (scan.hasNextInt()) {
                    input = scan.nextInt();
                    EdelsteenTypeDTO gekozenEdelsteen = converteerIntNaarEdelsteen(input);
                    if (gemChoose.contains(gekozenEdelsteen.type())) {
                        System.err.println("Deze edelsteen is al gekozen, kies een andere!");
                    } else {
                        gemChoose.add(gekozenEdelsteen.type());
                    }
                } else {
                    throw new InputMismatchException();
                }
            } catch (Exception e) {
                System.err.println("Kies een optie uit de lijst!");
                scan.nextLine(); // consume invalid input
            }
        } while (gemChoose.size() < 3);


        System.out.println("Je hebt de volgende edelstenen gekozen: " + gemChoose);
    }

    private void selecteerMenuOptie2() {
        int input = 0;
        boolean beurtBezig = true;
        do {
            try {
                printLine(MessageHelper.getString("menu_game_option2_choose"));
                printLine("1) " + MessageHelper.getString("gems_diamond"));
                printLine("2) " + MessageHelper.getString("gems_sapphire"));
                printLine("3) " + MessageHelper.getString("gems_emerald"));
                printLine("4) " + MessageHelper.getString("gems_ruby"));
                printLine("5) " + MessageHelper.getString("gems_onyx"));

                input = scan.nextInt();
                EdelsteenTypeDTO edelsteenTypeDTO = converteerIntNaarEdelsteen(input);
                System.out.println(controller.pakTweeEdelstenenDezelfdeKleur(edelsteenTypeDTO));
                beurtBezig = false;
            } catch (OnvoldoendeEdelstenenException e) {
                System.err.println("selecteerMenuOptie2: " + e.getMessage());
                scan.nextLine(); // consume invalid input
            } catch (Exception e) {
                System.err.println("selecteerMenuOptie2: " + "Kies een optie uit de lijst!");
                scan.nextLine(); // consume invalid input
            }
        } while (beurtBezig || (input != 1 && input != 2 && input != 3 && input != 4 && input != 5));
    }

    // region Utils
    private void printLine(String txt) {
        System.out.println(txt);
    }

    private EdelsteenTypeDTO converteerIntNaarEdelsteen(int edelsteenNummer) {
        if (edelsteenNummer == 1) {
            return new EdelsteenTypeDTO(MessageHelper.getStringLanguage("gems_diamond","nl"), MessageHelper.getString("color_diamond"));
        } else if (edelsteenNummer == 2) {
            return new EdelsteenTypeDTO(MessageHelper.getStringLanguage("gems_sapphire","nl"), MessageHelper.getString("color_sapphire"));
        } else if (edelsteenNummer == 3) {
            return new EdelsteenTypeDTO(MessageHelper.getStringLanguage("gems_emerald","nl"), MessageHelper.getString("color_emerald"));
        } else if (edelsteenNummer == 4) {
            return new EdelsteenTypeDTO(MessageHelper.getStringLanguage("gems_ruby","nl"), MessageHelper.getString("color_ruby"));
        } else {
            return new EdelsteenTypeDTO(MessageHelper.getStringLanguage("gems_onxy","nl"), MessageHelper.getString("color_onyx"));
        }
    }
    // endregion
}
