<a href="https://github.com/HoGentTIProjecten1/splendor-g118/blob/main/docs/README.md" style="display: inline-block; background-color: #4CAF50; color: white; padding: 0.5rem 1rem; border-radius: 0.25rem; text-decoration: none; font-weight: bold; font-size: 1rem; box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1); transition: all 0.2s ease-in-out;">Go Back</a>


| Contract:        | Start een nieuw spel                         |
|------------------|----------------------------------------------|
| Operation:       | startNieuwSpel()                             |
| Cross References | Maak nieuw spel                              |
| Preconditions:   | -                                            |
| Postconditions:  | Het systeem heeft een nieuw spel aangemaakt  |

| Contract:        | Selecteer speler                              |
|------------------|-----------------------------------------------|
| Operation:       | selecteerSpeler(gebruikersnaam, geboortejaar) |
| Cross References | Maak nieuw spel                               |
| Preconditions:   | -                                             |
| Postconditions:  | - Speler wordt gezocht in database            |
|                  | - Instantie van Speler werd aangemaakt        |
|                  | - Speler wordt toegevoegd aan spel            |
