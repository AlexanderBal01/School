import domein.EdelsteenType;
import domein.Spel;
import domein.Speler;
import exceptions.MaximumAantalSpelerException;
import exceptions.MinimumAantalSpelerException;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import utils.MessageHelper;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class SpelTest {
    @BeforeAll
    public static void init() {
        MessageHelper.setLanguage("nl");
    }

    @Test
    @DisplayName("Test: Maak een spel met _ spelers -> werptMinimumAantalSpelerException")
    void maakSpel_MetNullSpeler_WerptException() {
        MinimumAantalSpelerException thrown = assertThrows(
                MinimumAantalSpelerException.class,
                () -> new Spel(null)
        );
        assertTrue(thrown.getMessage().contains(MessageHelper.getString("exception_min_players")));
    }

    @Test
    @DisplayName("Test: Maak een spel met 1 spelers -> werptMinimumAantalSpelerException")
    void maakSpel_Met1Speler_WerptException() {
        ArrayList<Speler> spelers = new ArrayList<>(List.of(
                new Speler("Burak", 1999)
        ));

        MinimumAantalSpelerException thrown = assertThrows(
                MinimumAantalSpelerException.class,
                () -> new Spel(spelers)
        );
        assertTrue(thrown.getMessage().contains(MessageHelper.getString("exception_min_players")));
    }

    @Test
    @DisplayName("Test: Maak een spel met 2 spelers -> creeertSpel")
    void maakSpel_Met2Spelers_CreeertSpel() {
        ArrayList<Speler> spelers = new ArrayList<>(Arrays.asList(
                new Speler("Alexander", 2001),
                new Speler("Burak", 1999)
        ));

        Spel nieuwSpel = new Spel(spelers);

        assertEquals(2, nieuwSpel.getSpelers().size());
        assertNull(nieuwSpel.getWinnaars());
        assertEquals(2, nieuwSpel.getMIN_AANTAL_SPELERS());
        assertEquals(4, nieuwSpel.getMAX_AANTAL_SPELERS());
        // Edelstenen
        nieuwSpel.getEdelstenen().forEach(edelsteen -> {
            assertEquals(4, edelsteen.getAantal());
        });
        // Ontwikkelingen
        assertEquals(40, nieuwSpel.getOntwikkelingI().size());
        assertEquals(30, nieuwSpel.getOntwikkelingII().size());
        assertEquals(20, nieuwSpel.getOntwikkelingIII().size());
        // Edel
        assertEquals(3, nieuwSpel.getEdelen().size());
        assertEquals(0, nieuwSpel.getRondeNummer());
        // Spel
        assertFalse(nieuwSpel.getIsEinde());
        assertEquals(new Speler("Alexander", 2001), nieuwSpel.getHuidgeSpeler());
    }

    @Test
    @DisplayName("Test: Maak een spel met 3 spelers -> creeertSpel")
    void maakSpel_Met3Spelers_CreeertSpel() {
        ArrayList<Speler> spelers = new ArrayList<>(Arrays.asList(
                new Speler("Alexander", 2001),
                new Speler("Simon", 2001),
                new Speler("Burak", 1999)
        ));

        Spel nieuwSpel = new Spel(spelers);

        assertEquals(3, nieuwSpel.getSpelers().size());
        assertNull(nieuwSpel.getWinnaars());
        assertEquals(2, nieuwSpel.getMIN_AANTAL_SPELERS());
        assertEquals(4, nieuwSpel.getMAX_AANTAL_SPELERS());
        // Edelstenen
        nieuwSpel.getEdelstenen().forEach(edelsteen -> {
            assertEquals(5, edelsteen.getAantal());
        });
        // Ontwikkelingen
        assertEquals(40, nieuwSpel.getOntwikkelingI().size());
        assertEquals(30, nieuwSpel.getOntwikkelingII().size());
        assertEquals(20, nieuwSpel.getOntwikkelingIII().size());
        // Edel
        assertEquals(4, nieuwSpel.getEdelen().size());
        assertEquals(0, nieuwSpel.getRondeNummer());
        // Spel
        assertFalse(nieuwSpel.getIsEinde());
        assertEquals(new Speler("Alexander", 2001), nieuwSpel.getHuidgeSpeler());
    }

    @Test
    @DisplayName("Test: Maak een spel met 4 spelers -> creeertSpel")
    void maakSpel_Met4Spelers_CreeertSpel() {
        ArrayList<Speler> spelers = new ArrayList<>(Arrays.asList(
                new Speler("Burak", 1999),
                new Speler("Alexander", 2001),
                new Speler("Simon", 2001),
                new Speler("Jonas", 2001)
        ));
        Spel nieuwSpel = new Spel(spelers);

        assertEquals(4, nieuwSpel.getSpelers().size());
        assertNull(nieuwSpel.getWinnaars());
        assertEquals(2, nieuwSpel.getMIN_AANTAL_SPELERS());
        assertEquals(4, nieuwSpel.getMAX_AANTAL_SPELERS());
        // Edelstenen
        nieuwSpel.getEdelstenen().forEach(edelsteen -> {
            assertEquals(7, edelsteen.getAantal());
        });
        // Ontwikkelingen
        assertEquals(40, nieuwSpel.getOntwikkelingI().size());
        assertEquals(30, nieuwSpel.getOntwikkelingII().size());
        assertEquals(20, nieuwSpel.getOntwikkelingIII().size());
        // Edel
        assertEquals(5, nieuwSpel.getEdelen().size());
        assertEquals(0, nieuwSpel.getRondeNummer());
        assertFalse(nieuwSpel.getIsEinde());
        assertEquals(new Speler("Alexander", 2001), nieuwSpel.getHuidgeSpeler());
    }

    @Test
    @DisplayName("Test: Maak een spel met 5 spelers -> werptMaximumAantalSpelerException")
    void maakSpel_Met5Speler_WerptException() {
        ArrayList<Speler> spelers = new ArrayList<>(List.of(
                new Speler("Burak", 1999),
                new Speler("Alexander", 2001),
                new Speler("Simon", 2001),
                new Speler("Jonas", 2001),
                new Speler("David", 1990)
        ));

        MaximumAantalSpelerException thrown = assertThrows(
                MaximumAantalSpelerException.class,
                () -> new Spel(spelers)
        );
        assertTrue(thrown.getMessage().contains(MessageHelper.getString("exception_max_players")));
    }

    @Test
    @DisplayName("Test: De speler kiest voor 2 edelstenen van dezelfde kleur -> VultAantalMet2")
    void kiesTweeEdelstenen_VultAantalMet2() {
        ArrayList<Speler> spelers = new ArrayList<>(Arrays.asList(
                new Speler("Alexander", 2001),
                new Speler("Burak", 1999)
        ));

        Spel nieuwSpel = new Spel(spelers);
        nieuwSpel.bepaalHuidigeSpeler();
        nieuwSpel.pakTweeEdelstenenDezelfdeKleur(EdelsteenType.ONYX);

        assertEquals(2, nieuwSpel
                .getHuidgeSpeler()
                .getEdelstenen()
                .stream()
                .filter(gem -> gem.getType() == EdelsteenType.ONYX).findFirst()
                .orElseThrow(() -> new AssertionError("Expected at least two gems of type ONYX, but found none."))
                .getAantal()
        );
    }

}
