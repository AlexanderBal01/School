
import domein.Edele;
import domein.EdelsteenType;
import domein.VoorraadKost;
import exceptions.EdelPrestigePuntenException;
import exceptions.EdelVereisteBonussenException;
import exceptions.EdeleOngeldigeIdException;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EmptySource;
import org.junit.jupiter.params.provider.NullSource;
import org.junit.jupiter.params.provider.ValueSource;
import utils.MessageHelper;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

public class EdeleTest {
    @BeforeAll
    static void init() {
        MessageHelper.setLanguage("nl");
    }

    @Test
    @DisplayName("Test: Maak een edel met geldige punten, geldige vereiste bonussen en geldige id -> creeertEdel")
    void maakEdel_MetGeldigePunten_MetVereisteBonussen_CreeertEdel() {
        int punten = 3;
        String id = "edele_01";
        ArrayList<VoorraadKost> vereisteBonussen = new ArrayList<>() {{
            add(new VoorraadKost(EdelsteenType.ONYX, 7));
        }};

        Edele nieuweEdele = new Edele(punten, vereisteBonussen, id);

        assertEquals(punten, nieuweEdele.getPrestigePunten());
        assertEquals(vereisteBonussen, nieuweEdele.getVereisteBonussen());

    }

    @ParameterizedTest
    @NullSource
    @DisplayName("Test: Maak een edel met geldige punten, ongeldige vereiste bonussen en geldige id -> werptEdelVereisteBonussenException")
    void maakEdel_MetOngeldigeVereisteBonussen_WerptException(ArrayList<VoorraadKost> vereisteBonussen) {
        int punten = 3;
        String id = "edele_01";
        EdelVereisteBonussenException thrown = assertThrows(
                EdelVereisteBonussenException.class,
                () -> new Edele(punten, vereisteBonussen, id)
        );
        assertTrue(thrown.getMessage().contains(MessageHelper.getString("exception_noblebonus_invalid")));
    }

    @ParameterizedTest
    @ValueSource(ints = {-1, 0, 4})
    @DisplayName("Test: Maak een edel met ongeldige punten, geldige vereiste bonussen en geldige id -> werptEdelPrestigePuntenException")
    void maakEdel_MetOngeldigePunten_WerptException(int punten) {
        String id = "edele_01";
        ArrayList<VoorraadKost> vereisteBonussen = new ArrayList<>() {{
            add(new VoorraadKost(EdelsteenType.ONYX, 7));
        }};
        EdelPrestigePuntenException thrown = assertThrows(
                EdelPrestigePuntenException.class,
                () -> new Edele(punten, vereisteBonussen, id)
        );
        assertTrue(thrown.getMessage().contains(MessageHelper.getString("exception_noblepoints_invalid")));
    }

    @ParameterizedTest
    @EmptySource
    @DisplayName("Test: Maak een edel met geldige punten, geldige vereiste bonussen en ongeldige id -> OntwikkelingOngeldigeIdException")
    void maakOntwikkeling_MetOngeldigeId_WerptException(String id) {
        int punten = 3;
        ArrayList<VoorraadKost> vereisteBonussen = new ArrayList<>() {{
            add(new VoorraadKost(EdelsteenType.ONYX, 7));
        }};

        EdeleOngeldigeIdException thrown = assertThrows(
                EdeleOngeldigeIdException.class,
                () -> new Edele(punten, vereisteBonussen, id)
        );
        assertTrue(thrown.getMessage().contains(MessageHelper.getString("exception_nobleid_invalid")));
    }
}