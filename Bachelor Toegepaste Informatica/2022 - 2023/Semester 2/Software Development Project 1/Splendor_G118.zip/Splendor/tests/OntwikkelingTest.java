
import domein.EdelsteenType;
import domein.Ontwikkeling;
import domein.VoorraadKost;
import exceptions.OntwikkelingOngeldigeIdException;
import exceptions.OntwikkelingOngeldigeKostenException;
import exceptions.OntwikkelingOngeldigeNiveauException;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EmptySource;
import org.junit.jupiter.params.provider.NullSource;
import org.junit.jupiter.params.provider.ValueSource;
import utils.MessageHelper;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

public class OntwikkelingTest {
    @BeforeAll
    static void init() {
        MessageHelper.setLanguage("nl");
    }

    @Test
    @DisplayName("Test: Maak een ontwikkeling met geldige id, geldige punten, geldige type, geldige kost en geldige niveau -> creeertOntwikkeling")
    void maakOntwikkeling_MetGeldigeId_MetPunten_MetType_MetNiveau_MetKosten_MetNiveau_CreeertOntwikkeling() {
        int punten = 3;
        EdelsteenType type = EdelsteenType.DIAMANT;
        int niveau = 1;
        String id = "dia_n1_0";
        ArrayList<VoorraadKost> kosten = new ArrayList<>() {{
            add(new VoorraadKost(EdelsteenType.ONYX, 3));
            add(new VoorraadKost(EdelsteenType.SMARAGD, 2));
        }};

        Ontwikkeling nieuweOntwikkeling = new Ontwikkeling(id, punten, type, niveau, kosten);

        assertEquals(punten, nieuweOntwikkeling.getPrestigePunten());
        assertEquals(type, nieuweOntwikkeling.getBonusType());
        assertEquals(niveau, nieuweOntwikkeling.getNiveau());
        assertEquals(kosten, nieuweOntwikkeling.getKosten());
    }

    @ParameterizedTest
    @EmptySource
    @DisplayName("Test: Maak een ontwikkeling met ongeldige id, geldige punten, geldige type, geldige kost en geldige niveau -> OntwikkelingOngeldigeIdException")
    void maakOntwikkeling_MetOngeldigeId_WerptException(String id) {
        int punten = 3;
        EdelsteenType type = EdelsteenType.DIAMANT;
        int niveau = 1;
        ArrayList<VoorraadKost> kosten = new ArrayList<>() {{
            add(new VoorraadKost(EdelsteenType.ONYX, 3));
            add(new VoorraadKost(EdelsteenType.SMARAGD, 2));
        }};

        OntwikkelingOngeldigeIdException thrown = assertThrows(
                OntwikkelingOngeldigeIdException.class,
                () -> new Ontwikkeling(id, punten, type, niveau, kosten)
        );
        assertTrue(thrown.getMessage().contains(MessageHelper.getString("exception_developmentid_invalid")));
    }

    @ParameterizedTest
    @ValueSource(ints = {-1, 0, 4})
    @DisplayName("Test: Maak een ontwikkeling met ongeldige niveau, geldige punten, geldige type, geldige kost en geldige id -> OntwikkelingOngeldigeNiveauException")
    void maakOntwikkeling_MetOngeldigeNiveau_WerptException(int niveau) {
        int punten = 3;
        EdelsteenType type = EdelsteenType.DIAMANT;
        String id = "dia_n1_0";
        ArrayList<VoorraadKost> kosten = new ArrayList<>() {{
            add(new VoorraadKost(EdelsteenType.ONYX, 3));
            add(new VoorraadKost(EdelsteenType.SMARAGD, 2));
        }};

        OntwikkelingOngeldigeNiveauException thrown = assertThrows(
                OntwikkelingOngeldigeNiveauException.class,
                () -> new Ontwikkeling(id, punten, type, niveau, kosten)
        );
        assertTrue(thrown.getMessage().contains(MessageHelper.getString("exception_developmentlevel_invalid")));
    }

    @ParameterizedTest
    @NullSource
    @DisplayName("Test: Maak een ontwikkeling met ongeldige kost, geldige punten, geldige type, geldige niveau en geldige id -> OntwikkelingOngeldigeKostenException")
    void maakOntwikkeling_metOngeldigeKost_werptException(ArrayList<VoorraadKost> kosten) {
        int punten = 3;
        EdelsteenType type = EdelsteenType.DIAMANT;
        int niveau = 1;
        String id = "dia_n1_0";

        OntwikkelingOngeldigeKostenException thrown = assertThrows(
                OntwikkelingOngeldigeKostenException.class,
                () -> new Ontwikkeling(id, punten, type, niveau, kosten)
        );
        assertTrue(thrown.getMessage().contains(MessageHelper.getString("exception_developmentcosts_invalid")));
    }
}