
import domein.Speler;
import exceptions.GeboortejaarException;
import exceptions.GebruikersnaamException;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import utils.MessageHelper;

import static org.junit.jupiter.api.Assertions.*;

public class SpelerTest {

    @BeforeAll
    public static void init() {
        MessageHelper.setLanguage("nl");
    }

    @Test
    @DisplayName("Test: Maak een speler met geldige gebruikersnaam en geboortejaar -> creeertSpeler")
    void maakSpeler_MetGeldigeGebruikersnaam_MetGeldigeGeboortejaar_CreeertSpeler() {
        String gebruikersnaam = "Bob";
        int geboortejaar = 2000;

        Speler nieuweSpeler = new Speler(gebruikersnaam, geboortejaar);

        assertEquals(gebruikersnaam, nieuweSpeler.getGebruikersnaam());
        assertEquals(geboortejaar, nieuweSpeler.getGeboortejaar());
    }

    @ParameterizedTest
    @ValueSource(strings = {"_Bob", "1Bob", "_bob", "1bob"})
    @DisplayName("Test: Maak een speler met ongeldige gebruikersnaam en geldige geboortejaar -> werptGebruikersnaamException")
    void maakSpeler_MetOngeldigeGebruikersnaam_WerptException(String gebruikersnaam) {
        int geboortejaar = 2000;
        GebruikersnaamException thrown = assertThrows(
                GebruikersnaamException.class,
                () -> new Speler(gebruikersnaam, geboortejaar)
        );
        assertTrue(thrown.getMessage().contains(MessageHelper.getString("exception_set_username")));
    }

    @ParameterizedTest
    @ValueSource(ints = {2024, 2023, 2022, 2021, 2020, 2019, 2018})
    @DisplayName("Test: Maak een speler met geldige gebruikersnaam en ongeldige geboortejaar -> werptGeboortejaarException")
    void maakSpeler_MetOngeldigeGeboortejaar_WerptException(int geboortejaar) {
        String gebruikersnaam = "Bob";
        GeboortejaarException thrown = assertThrows(
                GeboortejaarException.class,
                () -> new Speler(gebruikersnaam, geboortejaar)
        );
        assertTrue(thrown.getMessage().contains(MessageHelper.getString("exception_set_birthyear")));
    }
}
