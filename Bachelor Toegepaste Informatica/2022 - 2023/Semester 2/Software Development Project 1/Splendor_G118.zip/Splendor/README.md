# Splendor - Software Development Project I (2022-2023) 🌟

<p align="center"><a href="https://github.com/HoGentTIProjecten1/splendor-g118/blob/main/docs/README.md">Operation Contracts</a></p>

## :memo: Logboek

   <div>
      <a target="_blank" rel="noopener" href="https://hogent-my.sharepoint.com/:f:/g/personal/liesbeth_lewyllie_hogent_be/Eqk0GblQmCdAlcrJllP1W7YBGoN3nrjV6hHlJ96pWUvaYw">
         <img style="width: 10%; height: auto;" src="https://user-images.githubusercontent.com/60544395/221661298-f45a1de8-aeda-4cce-b1da-a4d84c1cf5ef.png"
            alt="Logboek"/>
         <p>G118</p>
      </a>
   </div>
   
   
## :label: VP online

   <div>
      <a target="_blank" rel="noopener" href="https://online.visual-paradigm.com/admin.jsp#projects">
         <img style="width: 10%; height: auto;" src="https://images.g2crowd.com/uploads/product/image/large_detail/large_detail_116f10f6a6cf357ca498acf6fd3b618e/visual-paradigm-online-diagrams.png"
            alt="VPONLINE"/>
         <p>Visual Paradigm online</p>
      </a>
   </div>


## :baby: Leden

| **Naam**       | **GitHub**                          |
|----------------|-------------------------------------|
| Burak Balci    | <https://github.com/Bataklik>       |
| Alexander Bal  | <https://github.com/AlexanderBal01> |
| Simon Erdmann  | <https://github.com/SimonErdmann>   |
| Jonas Janssens | <https://github.com/JonasJanssens1> |

## :floppy_disk: Databank gebruikers
* spider_man
* Alex01
* Buraq_01
* Jonas
* Simon_E
