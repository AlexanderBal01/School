const express = require('express');
const path = require('path');
const cookieParser = require('cookie-parser');
const logger = require('morgan');
const router = express.Router(); 

const indexRouter = require('./routes/index');

const app = express();
app.use(express.json());

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
//app.use(express.static(path.join(__dirname, 'public')));

// functies
const middlewareFunc1 = router.get('*', (req, res, next) =>{
    console.log("Time: ", Date.now());
    console.log("IP: ", req.ip);
    next();
})

app.use('/', middlewareFunc1);
app.use('/', indexRouter.homeGet);
app.use('/', indexRouter.testGet);
app.use('/', indexRouter.testCijfersGet);
app.use('/', indexRouter.searchQueryGet);
app.use('/', indexRouter.testPost);
app.use('/', indexRouter.fallbackRoute);





module.exports = app;
