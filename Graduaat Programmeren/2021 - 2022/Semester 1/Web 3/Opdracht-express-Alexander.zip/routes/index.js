const express = require('express');
const router = express.Router(); 

/* GET home page. */
const routers = {
  homeGet: router.get('/', (req, res) => {
    res.send(`<p>home page</p>`)
  }),

  testGet: router.get('/test', (req, res) => {
    res.send(`<p>test page</p>`)
  }),

  testCijfersGet: router.get(`/test/:id([0-9]{3})`, (req, res) => {
    res.send(`<p>ID: ${req.params.id}`);
  }),

  searchQueryGet: router.get('/search', (req, res) => {
    res.send(`<p>SEARCHED: ${req.query.q}`)
  }),

  testPost: router.post('/test', (req, res) => {
    req.body.server = true;
    res.json(req.body);
 }),

 fallbackRoute: router.get('*', (req, res) => {
  res.status(404).send('<p>NIET GEVONDEN</p>');
 })
}


module.exports = routers;