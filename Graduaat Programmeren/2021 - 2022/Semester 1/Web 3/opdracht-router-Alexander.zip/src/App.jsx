import "./App.css";
import { BrowserRouter, Routes, Route, NavLink } from "react-router-dom";
import React, { useEffect, useState}from 'react';
import Axios from 'axios';
import Home from "./components/Home";
import Apis from "./components/Apis";
import ApisDetail from "./components/ApisDetail";

function App() {
    const [refresh, setRefresh] = useState(false);
    const [isLoading, setIsLoading] = useState(false);
    const [api, setAPIS] = useState([]);



    const styleForActive = ({ isActive }) => {
        return {
          color: isActive ? "#CDD7D6" : "#F87060",
        };
      };

    useEffect(() => {
        setIsLoading(true);
        Axios({
            method: 'GET',
            url:"https://api.publicapis.org/entries?category=development",
        }).then((response) => {
            setAPIS(response.data.entries);
            setIsLoading(false);
        }).catch((err) => console.log(err))
        .finally(() => setIsLoading(false));
    }, [refresh])

    if(isLoading) {
        return (<p>Loading...</p>)
    }

  return (
    <React.StrictMode>
      <BrowserRouter>
      <nav style={{ display: "flex", justifyContent: "space-around", padding: "10px" }}>
        <NavLink style={styleForActive} to="/">Home</NavLink>
        <NavLink style={styleForActive} to="/apis">Apis</NavLink>
      </nav>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/apis">
          <Route index element={<Apis api={api}/>} />
          <Route path=":id" element={<ApisDetail api={api}/>} />
        </Route>
      </Routes>
    </BrowserRouter>
    </React.StrictMode>
  );
}

export default App;
