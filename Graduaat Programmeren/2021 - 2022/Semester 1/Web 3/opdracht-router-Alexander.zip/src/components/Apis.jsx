import React from 'react'
import { NavLink } from 'react-router-dom';
import styles from './Main.module.css'

const Apis = (props) => {

    const styleForActive = ({ isActive }) => {
        return {
          color: isActive ? "#CDD7D6" : "#F87060",
        };
    };

    const {api} = props;
    return (
        <div>
            <h1 className={styles.titel}>Welcome to the API'S page of APIS by Alexander Bal</h1>
            <ul>
            {api.map((repo, idx) => 
                    <li key={idx} className={styles.apitext}>
                        <NavLink style={styleForActive} to={`/apis/${idx}`}>{repo.API}</NavLink>
                    </li>
            )}
            </ul>
        </div>
    );
}

export default Apis
