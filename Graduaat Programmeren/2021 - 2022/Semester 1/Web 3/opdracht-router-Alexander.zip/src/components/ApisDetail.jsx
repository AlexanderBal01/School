import React from 'react';
import styles from './Main.module.css';
import { Apis } from './Apis';
import { useNavigate, useParams } from 'react-router';

const ApisDetail = (props) => {

    const styleForActive = ({ isActive }) => {
        return {
          color: isActive ? "#CDD7D6" : "#F87060",
        };
    };
    
    const { api } = props;

    const params = useParams().id;
    const navigate = useNavigate();

    console.log(api);

    return (
        <div>
            <h1 className={styles.titel}>API Details</h1>
            <p className={styles.apitext}>Index: {params}</p>

            <p className={styles.apitext}>Title {api[params].API}</p>
            <p className={styles.apitext}>{api[params].Description}</p>
            <p className={styles.apitext}>Link: <a className={styles.apiLink} href={api[params].Link}>{api[params].API}</a></p>
            <button onClick={() => navigate(-1)}>Keer terug</button>
        </div>
    )
}

export default ApisDetail
