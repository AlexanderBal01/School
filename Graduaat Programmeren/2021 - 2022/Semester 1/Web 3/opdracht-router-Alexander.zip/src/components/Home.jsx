import React from 'react';
import styles from './Main.module.css'

const Home = () => {
    return (
        <div>
            <h1 className={styles.titel}>Welcome to the Home page of APIS by Alexander Bal</h1>
        </div>
    )
}

export default Home
