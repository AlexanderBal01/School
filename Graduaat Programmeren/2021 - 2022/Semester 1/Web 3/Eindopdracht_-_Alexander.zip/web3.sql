CREATE DATABASE  IF NOT EXISTS `web3` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `web3`;
-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: localhost    Database: web3
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bestelling`
--

DROP TABLE IF EXISTS `bestelling`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bestelling` (
  `id` int NOT NULL,
  `created` varchar(50) NOT NULL,
  `voornaam` varchar(255) NOT NULL,
  `achternaam` varchar(255) NOT NULL,
  `straat` varchar(1000) NOT NULL,
  `huisnummer` varchar(25) NOT NULL,
  `postcode` int NOT NULL,
  `stad` varchar(255) NOT NULL,
  `telefoon` varchar(255) NOT NULL,
  `email` varchar(1000) NOT NULL,
  `totaalPrijs` float NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bestelling`
--

LOCK TABLES `bestelling` WRITE;
/*!40000 ALTER TABLE `bestelling` DISABLE KEYS */;
/*!40000 ALTER TABLE `bestelling` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orderline`
--

DROP TABLE IF EXISTS `orderline`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orderline` (
  `bestellingId` int NOT NULL,
  `productId` int NOT NULL,
  `aantal` int NOT NULL,
  `prijs` float NOT NULL,
  KEY `bestellingId` (`bestellingId`),
  KEY `productId` (`productId`),
  CONSTRAINT `orderline_ibfk_1` FOREIGN KEY (`bestellingId`) REFERENCES `bestelling` (`id`),
  CONSTRAINT `orderline_ibfk_2` FOREIGN KEY (`productId`) REFERENCES `product` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orderline`
--

LOCK TABLES `orderline` WRITE;
/*!40000 ALTER TABLE `orderline` DISABLE KEYS */;
/*!40000 ALTER TABLE `orderline` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product` (
  `id` int NOT NULL AUTO_INCREMENT,
  `productnaam` varchar(255) NOT NULL,
  `prijs` double NOT NULL,
  `beschrijving` varchar(10000) NOT NULL,
  `afbeelding` varchar(10000) DEFAULT NULL,
  `aanbevolen` varchar(255) NOT NULL,
  `categorie` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` VALUES (1,'RIPNDIP NOT TODAY 8.25 DECK',84.99,'Het perfecte deck om te beginnen skaten!','https://test-web3.alexanderbal.be/Afbeeldingen/decks/deck1.jpg','true','decks'),(2,'DIAMOND X ACDC HIGHWAY TO HELL 8.25 DECK (BLACK)',84.99,'Het perfect deck voor gevorderde skaters!','https://test-web3.alexanderbal.be/Afbeeldingen/decks/deck2.jpg','false','decks'),(3,'SANTA CRUZ CLASSIC DOT 8.25 DECK (BLACK)',69.99,'Het perfect deck voor rustige skaters!','https://test-web3.alexanderbal.be/Afbeeldingen/decks/deck3.jpg','false','decks'),(5,'VENTURE V-LIGHTS ALL POLISHED HIGH 5.6 TRUCK (SILVER) 8.25',79.98,'De perfecte truck om te beginnen skaten','https://test-web3.alexanderbal.be/Afbeeldingen/trucks/truck1.jpg','true','trucks'),(6,'INDEPENDENT 144 STAGE 11 STANDARD HOLLOW TRUCK (SILVER) 8.25',79.98,'De perfecte trucks voor gevorderde skaters!','https://test-web3.alexanderbal.be/Afbeeldingen/trucks/truck2.jpg','false','trucks'),(7,'THUNDER 148 HIGH TEAM HOLLOWS OG GRENADE TRUCK (SILVER OLIVE) 8.25',79.98,'De perfecte trucks voor rustige skaters!','https://test-web3.alexanderbal.be/Afbeeldingen/trucks/truck3.jpg','false','trucks'),(8,'GRIZZLY DONT BE SNOTTY 9 GRIPTAPE (MULTI)',15.99,'De perfecte griptape voor rustige skaters!','https://test-web3.alexanderbal.be/Afbeeldingen/griptape/grip1.jpg','true','griptape'),(9,'GRIZZLY CLOWNIN 9 GRIPTAPE (BLACK)',14.99,'Hang niet zo de clown uit','https://test-web3.alexanderbal.be/Afbeeldingen/griptape/grip2.jpg','flase','griptape'),(10,'GRIZZLY ANTIQUE POSTCARD #5 9 GRIPTAPE (MULTI)',14.99,'Dit lijkt wel op een grote postkaart','https://test-web3.alexanderbal.be/Afbeeldingen/griptape/grip3.jpg','flase','griptape'),(11,'ANDALE ABEC 7 BEARINGS',24.99,'Hoor ik daar abec 7, kopen!!!','https://test-web3.alexanderbal.be/Afbeeldingen/bearings/bearing1.jpg','flase','bearings'),(12,'ANDALE PUIG PRO BEARINGS',31.99,'Dit zijn de pro bearings waar Lucas Puig ook mee rijd.','https://test-web3.alexanderbal.be/Afbeeldingen/bearings/bearing2.jpg','true','bearings'),(13,'ANDALE X DIAMOND RIBEIRO PRO BEARINGS (MULTI)',59.99,'Dit zijn de snelste bearings op de markt','https://test-web3.alexanderbal.be/Afbeeldingen/bearings/bearing3.jpg','false','bearings'),(14,'SPITFIRE FORMULA FOUR OG CLASSICS WHEELS (NATURAL) 53MM 99A 4 PACK',59.99,'Spitfire, presoonlijk mijn favoriet','https://test-web3.alexanderbal.be/Afbeeldingen/wielen/wiel1.jpg','false','wielen'),(15,'BONES STF HERITAGE BONELESS V1 WHEELS (WHITE) 52MM 103A 4 PACK',54.99,'Met deze wielen shred je zo de straten','https://test-web3.alexanderbal.be/Afbeeldingen/wielen/wiel2.jpg','true','wielen'),(16,'BONES STF RETROS V5 WHEELS (WHITE RED) 53MM 103A 4 PACK',54.99,'Met deze wielen shred je zo de skateparken','https://test-web3.alexanderbal.be/Afbeeldingen/wielen/wiel3.jpg','flase','wielen');
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-01-09 22:39:58
