import react, { createContext } from "react";

export const NeutralContext = createContext(0);