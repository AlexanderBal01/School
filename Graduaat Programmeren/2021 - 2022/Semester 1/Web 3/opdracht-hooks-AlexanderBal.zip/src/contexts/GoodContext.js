import react, { createContext } from "react";

export const GoodContext = createContext(0);