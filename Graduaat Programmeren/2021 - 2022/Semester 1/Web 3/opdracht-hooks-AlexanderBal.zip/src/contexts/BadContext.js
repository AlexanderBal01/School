import react, { createContext } from "react";

export const BadContext = createContext(0);