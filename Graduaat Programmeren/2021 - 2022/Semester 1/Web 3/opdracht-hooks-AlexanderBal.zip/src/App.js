import "./App.css";
import ContextComponent from "./components/ContextComponent";

function App() {
  return (
    <div className="App">
      <ContextComponent />
    </div>
  );
}

export default App;