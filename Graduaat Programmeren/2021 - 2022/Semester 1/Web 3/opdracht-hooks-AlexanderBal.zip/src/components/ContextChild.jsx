import React from 'react';
import SecondContextChild from './SecondContextChild';

const ContextChild = () => {
    return (
        <div>
            <h1>give feedback</h1>

            <SecondContextChild />
        </div>
    )
}

export default ContextChild
