import React, { useContext } from 'react';
import { GoodContext } from '../contexts/GoodContext';
import { NeutralContext } from '../contexts/NeutralContext';
import { BadContext } from '../contexts/BadContext';

const ThirdContextChild = () => {
    const counterGood = useContext(GoodContext);
    const counterNeutral = useContext(NeutralContext);
    const counterBad = useContext(BadContext);

    return (
        <div>
            <h1>Statistics</h1>
            <p>good {counterGood}</p>
            <p>Neutral {counterNeutral}</p>
            <p>Bad {counterBad}</p>
        </div>
    )
}

export default ThirdContextChild
