import React, { useState } from 'react';
import { GoodContext } from '../contexts/GoodContext';
import { NeutralContext } from '../contexts/NeutralContext';
import { BadContext } from '../contexts/BadContext';
import ContextChild from './ContextChild';
import styles from './Buttons.module.css';

const ContextComponent = () => {

    const [counterGood, setCounterGood] = useState(0);
    const [counterNeutral, setCounterNeutral] = useState(0);
    const [counterBad, setCounterBad] = useState(0);

    return (
        <div>
            <GoodContext.Provider value={counterGood}>
                <NeutralContext.Provider value={counterNeutral}>
                    <BadContext.Provider value={counterBad}>
                        <ContextChild />
                    </BadContext.Provider>
                </NeutralContext.Provider>
            </GoodContext.Provider>

            <a className={styles.goodButton} onClick={() => setCounterGood(counterGood+1)}>Good</a>
            <a className={styles.neutralButton} onClick={() => setCounterNeutral(counterNeutral+1)}>Neutral</a>
            <a className={styles.badButton} onClick={() => setCounterBad(counterBad+1)}>Bad</a>
        </div>
    )
}

export default ContextComponent
