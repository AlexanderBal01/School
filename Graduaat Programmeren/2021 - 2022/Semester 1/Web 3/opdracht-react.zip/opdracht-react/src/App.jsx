import logo from './logo.svg';
import './App.css';
import Header from './components/Header';
import Part from './components/Part';
import List from './components/List';
import Footer from './components/Footer';

function App() {

  const course = "Web 3";

  const part1 = "Introduction";
  const excercices1 = 15;

  const part2 = "ES syntax";
  const excercices2 = 14;

  const technologies = [ {id: 1, name: "Node.js"}, {id: 12, name: "JavaScript"}, {id: 3, name: "Express"}, {id: 4, name: "react"}, ]

  return (
    <div>
      <Header course = { course } />
      <Part part1 = { part1 } excercices1 = { excercices1 } part2 = { part2 } excercices2 = { excercices2 } />
      <List technologies = { technologies } />
      <Footer excercices1 = { excercices1 } excercices2 = { excercices2 } />
    </div>
  );
}

export default App;