import React from 'react'

const Footer = (props) => {
    return (
        <p>Number of excercices { props.excercices1 + props.excercices2 }</p>
    )
}

export default Footer
