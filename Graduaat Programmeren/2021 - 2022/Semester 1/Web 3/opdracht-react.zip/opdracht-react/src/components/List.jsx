import React from 'react';

const List = (props) => {
    return (
        <ul>
            {props.technologies.map(t => <li key={t.id}>{t.name}</li>)}
        </ul>
    );
}

export default List;
