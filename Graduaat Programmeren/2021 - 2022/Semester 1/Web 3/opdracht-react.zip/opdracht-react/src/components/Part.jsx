import React from 'react';

const Part = (props) => {

    return (
        <>
            <p>
                { props.part1 } { props.excercices1 }
            </p> 
            <p>
                { props.part2 } { props.excercices2 }
            </p>
        </>
    )
}

export default Part;
