const express = require('express');
const router = express.Router();
const db = require('../config/db');
const { check, validationResult } = require('express-validator');
const bcrypt = require('bcrypt');
const saltRounds = 10;

/* GET home page. */
const routers = {
  homeGet: router.get('/', (req, res) => {
    res.send(`<p>Home</p>`)
  }),

  usersGet: router.get('/users', (req, res) => {
    db.query("SELECT * FROM users", (err, results, fields) => {
      if(err){
        res.send(err);
      };
      
      res.json(results);
    })
  }),

  usersIdGet: router.get('/users/:id([0-9])', (req, res) => {
    db.query(`SELECT * FROM users WHERE ID=${req.params.id}`, (err, results, fields) => {
      if(err){
        res.send(err);
      };
      
      res.json(results);
    })
  }),

  usersPost: router.post('/users', [check('email').isEmail().normalizeEmail(), check('wachtwoord').isLength({ min: 6 }).trim().escape(), check('voornaam').not().isEmpty(), check('achternaam').not().isEmpty()], (req, res) =>{
    const errors = validationResult(req);
    console.log(errors);

    if (!errors.isEmpty()){
      res.status(400).json(errors);
    }

    bcrypt.hash(req.body.wachtwoord, saltRounds).then((hash) => {
      db.query(`INSERT INTO users (voornaam, achternaam, wachtwoord, email )VALUES ('${req.body.voornaam}', '${req.body.achternaam}', '${hash}', '${req.body.email}')`, (err, results, fields) => {
        if(err){
          console.log('An error occurred while executing the query');
          res.send(err);
          throw err;
        };
        res.json(results);
      })
    }).catch(err => res.send(err));
  }),

  usersLoginPost: router.post('/users/login', [check('email').isEmail().normalizeEmail(), check('wachtwoord').isLength({ min: 6 }).trim().escape()], (req, res, next) => {
    db.query(`SELECT * FROM users WHERE email = '${req.body.email}'`, (err, result) => {
      // user does not exists
      if (err) {
        console.log('An error occurred while executing the query');
        res.send(err);
        throw err;
      };
      if (!result.length) {
        return res.status(401).send({
          msg: 'Email or password is incorrect!'
        });
      }

      // check password
      bcrypt.hash(req.body.wachtwoord, saltRounds).then((hash) => {
        bcrypt.compare(req.body.wachtwoord, hash).then((result) => {
          if(result){
            res.status(200).send({
              msg: 'Logged in!',
              user: result[0]
            });
          } else {
            console.log('An error occurred while executing the query');
            res.send(err);
          }
        })
      });      
    })
  })
}


module.exports = routers;
