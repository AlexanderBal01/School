const obj = {voornaam : "Alexander", achternaam : "Bal", leeftijd : 19, woonplaats : "Dendermonde"};
const filesystem = require('./file.js');
const http = require('http');
const server = http.createServer((req, res) => {

    if(req.url == '/'){
        res.writeHead(200, { 'Content-Type': 'text/html'});
        res.write('<html><body><p>Home Page.</p></body></html>')
        res.end()
    }
    else if(req.url == '/profile'){
        res.writeHead(200, { 'Content-Type': 'text/html'});
        res.write('<html><body><p>Profile Page.</p></body></html>')
        res.end()
    }
    else if (req.url == '/data') {
        res.writeHead(200, { 'Content-Type': 'application/json'});
        res.write(JSON.stringify(obj));
        res.end();
    }

});

server.listen(5000)
console.log('Node.js web server at port 5000 is running..');

filesystem.write;
filesystem.read;