const fs = require('fs');

const filesystem = {
    write: fs.writeFile('test.txt', 'Alexander Bal', (err) => {
        if (err){
            console.log(err);
        } else{
            console.log('Write operation complete.')
        }
    }),

    read : fs.readFile('./test.txt', (err,data) => {
        if (err){
            throw err;
        }
        console.log(data);
    })
}

module.exports = filesystem;