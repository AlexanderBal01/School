import logo from "./logo.svg";
import "./App.css";
import HookComponent from "./components/HookComponent";
import Child from "./components/Child";
import Repos from "./components/Repos";

function App() {
  return (
    <div className="App">
      <HookComponent />
      <Child />
      <Repos />
    </div>
  );
}

export default App;
