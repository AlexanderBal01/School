import React from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { addAlexander } from '../store/Alexander/slice';
import { addOne } from '../store/test/slice';

const Child = () => {

    const counterState = useSelector(state => state.counter);
    const testState = useSelector(state => state.test);
    const alexanderState = useSelector(state => state.alexander);

    const dispatch = useDispatch();

    return (
        <div style={{ border: "solid 2px black", marginTop: 20}}>
            <h2>Child component</h2>
            <p>Counter state: {counterState.value}</p>
            <p>Test state:</p>
            <ul>
                {testState.map((value, idx) => <li key={idx}>{value}</li>)}
            </ul>
            <button onClick={() => dispatch(addOne("One"))}>Add one</button>
            <ul>
                {alexanderState.map((value, idx) => <li key={idx}>{value}</li>)}
            </ul>
            <button onClick={() => dispatch(addAlexander("Alexander"))}>Add alexander</button>
        </div>
    )
}

export default Child
