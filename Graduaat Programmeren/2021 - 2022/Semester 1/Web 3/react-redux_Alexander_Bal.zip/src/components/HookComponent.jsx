import React from 'react'
import { useDispatch, useSelector } from 'react-redux';
// Nieuwe Manier
import { increment, decrement, incrementByValue, decrementByValue } from '../store/counter/slice';
// OUDE MANIER
// import { decrement, increment, incrementByValue } from '../store/old_counter/actions';

const HookComponent = () => {

    // Dit is de hook om de volledige state terug te krijgen van de store
    const state = useSelector(state => state);
    // Counter state waarmee we de counter value laten tonen in de component
    const counterState = useSelector(state => state.counter);

    // Dit is de hook om een action te dispatchen naar de store
    const dispatch = useDispatch();

    return (
        <div style={{ border: "solid 2px black"}}>
           <h1>Counter state: {counterState.value}</h1> 
           <button onClick={() => dispatch(increment())}>Increment</button>
           <button onClick={() => dispatch(decrement())}>Decrement</button>
           <button onClick={() => dispatch(incrementByValue(5))}>Increment by 5</button>
           {/* TODO: Toevoegen van knop decrementByValue - 5 */}
           <button onClick={() => dispatch(decrementByValue(5))}>Decrement by 5</button>
        </div>
    )
}

export default HookComponent
