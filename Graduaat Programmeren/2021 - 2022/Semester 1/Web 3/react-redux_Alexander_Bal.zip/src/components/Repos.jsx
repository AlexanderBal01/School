import React, { useEffect } from 'react'
import { useSelector, useDispatch } from 'react-redux';
import { fetchGithubRepos } from '../store/repos/slice';

const Repos = () => {

    const dispatch = useDispatch();
    const reposState = useSelector(state => state.repos);

    useEffect(() => {
        dispatch(fetchGithubRepos())
    }, [])

    return (
        <div style={{ margin: 20, border: "solid 2px black"}}>
            <h2>Repos component</h2>
            {reposState.data.map((repo) => <p key={repo.id}>{repo.name}</p>)}
        </div>
    )
}

export default Repos
