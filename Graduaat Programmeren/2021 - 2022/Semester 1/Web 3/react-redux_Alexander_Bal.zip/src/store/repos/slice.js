import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import Axios from "axios";

// Asynchrone code die uitgevoerd moet worden kan niet in gewone reducers -> speciaal type van reducers
// createAsyncThunk waarbij we een naam maken voor de action type ('githubRepos/fetch')
// daarna asynchrone code meegeven
// Maakt gebruik van async en await

export const fetchGithubRepos = createAsyncThunk(
  "githubRepos/fetch",
  async () => {
    const response = await Axios({
      url: "https://api.github.com/users/DavidBr89/repos",
      method: "GET",
    });
    return response;
  }
);

const reposSlice = createSlice({
  name: "repos",
  initialState: {
    status: "idle",
    data: [],
    error: null,
  },
  // Extra reducers voor asyncThunk drie toestanden (PROMISE)
  // PENDING
  // FULFILLED
  // REJECTED
  extraReducers: {
    [fetchGithubRepos.pending]: (state, action) => {
      return { ...state, status: "pending", data: [], error: null };
    },
    [fetchGithubRepos.fulfilled]: (state, action) => {
      return {
        ...state,
        status: "success",
        data: action.payload.data,
        error: null,
      };
    },
    [fetchGithubRepos.rejected]: (state, action) => {
      return { ...state, status: "error", data: [], error: action.payload };
    },
  },
});

export const { reducer } = reposSlice;
