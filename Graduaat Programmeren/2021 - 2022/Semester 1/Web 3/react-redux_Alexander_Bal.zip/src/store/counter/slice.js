// Nieuwe manier -> Manier dat wij gaan gebruiken

import { createSlice } from "@reduxjs/toolkit";

// Slices genereren automatisch action types, action creators en reducers
const counterSlice = createSlice({
  // NAAM van onze reducer -> VERPLICHT, prefix voor de action types
  // bvb. counter/increment is een action type
  name: "counter",
  // Initiële state van de reducer
  initialState: {
    value: 0,
  },
  // Reducers definiëren -> state gaan wijzigen
  // Ik denk door een wijziging in de nieuwe versie dat je ook terug immutable moet werken
  reducers: {
    increment: (state, action) => {
      return { ...state, value: state.value + 1 };
    },
    incrementByValue: (state, action) => {
      const { payload } = action;
      return { ...state, value: state.value + payload };
    },
    decrement: (state, action) => {
      return { ...state, value: state.value - 1 };
    },
    // TODO: Ontbrekende reducer gaan schrijven -> mutable manier
    decrementByValue: (state, action) => {
      const { payload } = action;
      state.value = state.value - payload;
      return state;
    }
  },
});

export const { actions, reducer } = counterSlice;
// TODO: exporteren van uw action creator
export const { increment, decrement, incrementByValue, decrementByValue } = actions;
