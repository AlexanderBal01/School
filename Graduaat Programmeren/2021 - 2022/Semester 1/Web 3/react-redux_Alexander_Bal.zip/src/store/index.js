import { configureStore, combineReducers } from "@reduxjs/toolkit";
// OUDE MANIER
// import { counterReducer } from "./old_counter/reducers";
// NIEUWE MANIER
import { reducer as counterReducer } from "./counter/slice";
import { reducer as testReducer } from "./test/slice";
import { reducer as reposReducer } from "./repos/slice";
import { reducer as alexanderReducer } from "./Alexander/slice";
import { loadState, saveState } from "./localStorage";
import { throttle } from "lodash";

// Counter reducer
// Test reducer
const rootReducer = combineReducers({
  counter: counterReducer,
  test: testReducer,
  repos: reposReducer,
  // TODO: NIEUWE SLICE AANMAKEN -> OBJECT, ARRAY, VALUE
  alexander: alexanderReducer,
});

// Het ophalen van de state uit de localStorage
const loadedStateFromLocalStorage = loadState();

// Dit gaat onze store configureren met verschillende properties
// Elke APPLICATIE heeft maar 1 STORE
// reducer -> rootReducer meegeven
// preLoadedState -> State uit onze localStorage halen
export const store = configureStore({
  // De root reducer die we gaan meegeven in onze store,
  // Meerdere reducers meegeven gaat dan via een methode combineReducers
  reducer: rootReducer,
  preloadedState: loadedStateFromLocalStorage,
});

// De throttle methode vanuit het lodash package, gaat ervoor zorgen dat we nu telkens 1 second wachten vooraleer we de state gaan wegschrijven in de localstorage
store.subscribe(
  throttle(() => {
    saveState(store.getState());
  }, 1000)
);

// Enkel de counter state opslaan in de localstorage
// store.subscribe(
//   throttle(() => {
//     saveState({ counter: store.getState().counter });
//   }, 1000)
// );
