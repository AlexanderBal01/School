const { createSlice } = require("@reduxjs/toolkit");

const testSlice = createSlice({
  name: "test",
  initialState: [],
  reducers: {
    addOne: (state, action) => {
      const { payload } = action;
      return [...state, payload];
    },
  },
});

export const { actions, reducer } = testSlice;
export const { addOne } = actions;
