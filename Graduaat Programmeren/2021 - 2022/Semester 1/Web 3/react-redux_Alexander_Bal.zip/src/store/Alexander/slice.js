const { createSlice } = require("@reduxjs/toolkit");

const sliceAlexander = createSlice({
  name: "alexander",
  initialState: [],
  reducers: {
    addAlexander: (state, action) => {
      const { payload } = action;
      return [...state, payload];
    },
  },
});

export const { actions, reducer } = sliceAlexander;
export const { addAlexander } = actions;