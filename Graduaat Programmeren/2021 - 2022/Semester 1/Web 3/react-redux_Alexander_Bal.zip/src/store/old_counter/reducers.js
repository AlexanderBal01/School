// OUDE METHODE

import { DECREMENT, INCREMENT, INCREMENT_BY_VALUE, DECREMENT_BY_VALUE } from "./actions";

// REDUCER Aangemaakt
// Counter reducer

// OBJECT, ARRAY, VALUE
const initialState = {
  value: 0,
};

// Dit is de reducer - die zal zorgen dat de actions opgevangen worden en de state zal wijzigen
// aan de hand van de action en de data die meegegeven is met die action (payload)

// Twee argumenten -> HUIDIGE STATE en een ACTION
// De reducer die geeft een nieuwe state terug
// OPGELET: De state moet steeds op een immutable manier aangepast worden (OBJECTEN & ARRAYS)

export const counterReducer = (state = initialState, action) => {
  // Met het switch statement gaan we checken welke action opegeroepen is geweest
  switch (action.type) {
    // ACTION TYPE === INCREMENT
    // De state verhogen met 1
    case INCREMENT:
      // IMMUTABLE MANIER
      return { ...state, value: state.value + 1 };
    // ACTION TYPE === INCREMENT_BY_VALUE
    // De state verhogen met meegegeven value
    case INCREMENT_BY_VALUE:
      return { ...state, value: state.value + action.payload };
    // ACTION TYPE === DECREMENT
    // De state verminderen met 1
    case DECREMENT:
      return { ...state, value: state.value - 1 };
    // ACTION TYPE === DECREMENT_BY_VALUE
    // De state verminderen met meegeven waarde

    // TODO: Schrijf hier de ontbrekende reducer (Niet vergeten te importeren)
    case DECREMENT_BY_VALUE:
      return { ...state, value: state.value - action.payload };
    // DEFAULT VALUE
    // State is niet gewijzigd dus huidige state returnen
    default:
      return state;
  }
};
