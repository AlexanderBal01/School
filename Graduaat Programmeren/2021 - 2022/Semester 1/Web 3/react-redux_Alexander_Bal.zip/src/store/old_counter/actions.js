// OUDE METHODE

// ACTIONS
// Elke action heeft een type -> String

// ACTION TYPE definiëren:
// - Het verhogen van de state met 1
// - Het verhogen van de state met een bepaalde waarde
// - Het verminderen van de state met 1
// - Het verminderen van de state met een bepaalde waarde
export const INCREMENT = "INCREMENT";
export const INCREMENT_BY_VALUE = "INCREMENT_BY_VALUE";
export const DECREMENT = "DECREMENT";

// TODO: Ontbrekende action type schrijven -> 4 de action type verminderen met een waarde
export const DECREMENT_BY_VALUE = "DECREMENT_BY_VALUE";

// ACTION CREATORS
// Functies zodanig dat we de actions kunnen dispatchen naar onze store
// 1ste Action creator -> Zorgt voor de increment van onze state (ACTION)
export const increment = () => {
  // Action gaan returnen
  return { type: INCREMENT };
};

// 2de action creator -> Zorgt voor de increment van onze state maar met een meegegeven waarde
export const incrementByValue = (value) => {
  // Action gaan returnen
  return { type: INCREMENT_BY_VALUE, payload: value };
};

// 3de action creator -> Zorgt voor de decrement van onze state
export const decrement = () => {
  // Action gaan returnen
  return { type: DECREMENT };
};

// 4de Action creator -> Zorgt voor de decrement van onze state met een meegegeven waarde

// TODO: Action creator aanmaken
export const decrementByValue = (value) => {
  return { type: DECREMENT_BY_VALUE, payload: value };
}