﻿using Business_Layer.Exceptions.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business_Layer.Model {
    public class Rivier {
        #region Properties
        public int ID { get; private set; }
        public string Naam { get; private set; }
        public double Lengte { get; private set; }
        #endregion

        #region Ctor
        public Rivier(string naam, double lengte) {
            ZetNaam(naam);
            ZetLengte(lengte);
        }

        public Rivier(int id, string naam, double lengte) : this(naam, lengte) {
            ZetId(id);
        }
        #endregion

        #region Methods
        public void ZetId(int id) {
            if (id > 0) {
                ID = id;
            } else {
                throw new RivierException("Rivier - Id moet groter zijn dan 0");
            }
        }

        public void ZetNaam(string naam) {
            if(!string.IsNullOrWhiteSpace(naam)) {
                Naam = naam;
            } else {
                throw new RivierException("Rivier - Naam moet ingevuld zijn");
            }
        }

        public void ZetLengte(double lengte) {
            if (lengte > 0) {
                Lengte = lengte;
            } else {
                throw new RivierException("Rivier - Lengte moet groter zijn dan 0");
            }
        }
        #endregion
    }
}
