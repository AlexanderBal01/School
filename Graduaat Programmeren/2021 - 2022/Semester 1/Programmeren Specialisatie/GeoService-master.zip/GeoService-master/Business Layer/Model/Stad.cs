﻿using Business_Layer.Exceptions.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business_Layer.Model {
    public class Stad {
        #region Properties
        public int ID { get; private set; }
        public string Naam { get; private set; }
        public int BevolkingsAantal { get; private set; }
        #endregion

        #region Ctor
        public Stad(string naam, int bevolkingsAantal) {
            ZetNaam(naam);
            ZetBevolkingsAantal(bevolkingsAantal);
        }

        public Stad(int id, string naam, int bevolkingsAantal) : this(naam, bevolkingsAantal) {
            ZetId(id);
        }
        #endregion

        #region Methods
        public void ZetId(int id) {
            if (id > 0) {
                ID = id;
            } else {
                throw new StadException("Stad - Id moet groter zijn dan 0");
            }
        }

        public void ZetNaam(string naam) {
            if (!string.IsNullOrWhiteSpace(naam)) {
                Naam = naam;
            } else {
                throw new StadException("Stad - Naam moet ingevuld zijn");
            }
        }

        public void ZetBevolkingsAantal(int bevolkingsAantal) {
            if (bevolkingsAantal > 0) {
                BevolkingsAantal = bevolkingsAantal;
            } else {
                throw new StadException("Stad - BevolkingsAantal moet groter zijn dan 0");
            }
        }
        #endregion
    }
}
