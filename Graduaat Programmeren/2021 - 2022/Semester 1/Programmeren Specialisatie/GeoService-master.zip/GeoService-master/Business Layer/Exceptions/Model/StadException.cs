﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business_Layer.Exceptions.Model {
    public class StadException : Exception {
        #region Ctor
        public StadException(string message) : base(message) {
        }

        public StadException(string message, Exception innerException) : base(message, innerException) {
        }
        #endregion
    }
}
