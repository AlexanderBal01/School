﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business_Layer.Exceptions.Model {
    public class RivierException : Exception {
        #region Ctor
        public RivierException(string message) : base(message) {
        }

        public RivierException(string message, Exception innerException) : base(message, innerException) {
        }
        #endregion
    }
}
