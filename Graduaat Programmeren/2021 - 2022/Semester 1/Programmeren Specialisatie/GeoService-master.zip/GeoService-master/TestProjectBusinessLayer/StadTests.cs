﻿using Business_Layer.Exceptions.Model;
using Business_Layer.Model;
using System;
using Xunit;

namespace TestProjectBusinessLayer {
    public class StadTests {
        #region Tests Ctor
        [Fact]
        public void Test_Ctor_Valid() {
            Stad stad = new Stad("Dendermonde", 45849);

            Assert.Equal("Dendermonde", stad.Naam);
            Assert.Equal(45849, stad.BevolkingsAantal);
        }

        [Fact]
        public void Test_Ctor_WithId_Valid() {
            Stad stad = new Stad(1, "Dendermonde", 45849);

            Assert.Equal(1, stad.ID);
            Assert.Equal("Dendermonde", stad.Naam);
            Assert.Equal(45849, stad.BevolkingsAantal);
        }
        #endregion

        #region Tests Methods
        [Fact]
        public void Test_ZetId_Valid() {
            Stad stad = new Stad("Dendermonde", 45849);
            stad.ZetId(1);

            Assert.Equal(1, stad.ID);
        }

        [Theory]
        [InlineData(0)]
        [InlineData(-1)]
        public void Test_ZetId_Invalid(int id) {
            Stad stad = new Stad("Dendermonde", 45849);

            Assert.Throws<StadException>(() => stad.ZetId(id));
        }

        [Fact]
        public void Test_ZetNaam_Valid() {
            Stad stad = new Stad("Dendermonde", 45849);
            stad.ZetNaam("Hamme");

            Assert.Equal("Hamme", stad.Naam);
        }

        [Theory]
        [InlineData("")]
        [InlineData(" ")]
        public void Test_ZetNaam_Invalid(string naam) {
            Stad stad = new Stad("Dendermonde", 45849);

            Assert.Throws<StadException>(() => stad.ZetNaam(naam));
        }

        [Fact]
        public void Test_ZetBevolkingsAantal_Valid() {
            Stad stad = new Stad("Dendermonde", 45849);
            stad.ZetBevolkingsAantal(263703);

            Assert.Equal(263703, stad.BevolkingsAantal);
        }

        [Theory]
        [InlineData(0)]
        [InlineData(-1)]
        public void Test_ZetBevolkingsAantal_Invalid(int bevolkingsAantal) {
            Stad stad = new Stad("Dendermonde", 45849);

            Assert.Throws<StadException>(() => stad.ZetBevolkingsAantal(bevolkingsAantal));
        }
        #endregion
    }
}
