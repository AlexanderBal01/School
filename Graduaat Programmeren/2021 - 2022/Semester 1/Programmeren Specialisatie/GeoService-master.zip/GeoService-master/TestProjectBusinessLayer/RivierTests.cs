using Business_Layer.Exceptions.Model;
using Business_Layer.Model;
using System;
using Xunit;

namespace TestProjectBusinessLayer {
    public class RivierTests {
        #region Tests Ctor
        [Fact]
        public void Test_Ctor_Valid() {
            Rivier rivier = new Rivier("Schelde", 360);

            Assert.Equal("Schelde", rivier.Naam);
            Assert.Equal(360, rivier.Lengte);
        }

        [Fact]
        public void Test_Ctor_WithId_Valid() {
            Rivier rivier = new Rivier(1, "Schelde", 360);

            Assert.Equal(1, rivier.ID);
            Assert.Equal("Schelde", rivier.Naam);
            Assert.Equal(360, rivier.Lengte);
        }
        #endregion

        #region Tests Methods
        [Fact]
        public void Test_ZetId_Valid() {
            Rivier rivier = new Rivier("Schelde", 360);
            rivier.ZetId(1);

            Assert.Equal(1, rivier.ID);
        }

        [Theory]
        [InlineData(0)]
        [InlineData(-1)]
        public void Test_ZetId_Invalid(int id) {
            Rivier rivier = new Rivier("Schelde", 360);

            Assert.Throws<RivierException>(() => rivier.ZetId(id));
        }

        [Fact]
        public void Test_ZetNaam_Valid() {
            Rivier rivier = new Rivier("Schelde", 360);
            rivier.ZetNaam("Dender");

            Assert.Equal("Dender", rivier.Naam);
        }

        [Theory]
        [InlineData("")]
        [InlineData(" ")]
        public void Test_ZetNaam_Invalid(string naam) {
            Rivier rivier = new Rivier("Schelde", 360);
            
            Assert.Throws<RivierException>(() => rivier.ZetNaam(naam));
        }

        [Fact]
        public void Test_ZetLengte_Valid() {
            Rivier rivier = new Rivier("Schelde", 360);
            rivier.ZetLengte(360.01);

            Assert.Equal(360.01, rivier.Lengte);
        }

        [Theory]
        [InlineData(0)]
        [InlineData(-1)]
        [InlineData(-0.01)]
        public void Test_ZetLengte_Invalid(double lengte) {
            Rivier rivier = new Rivier("Schelde", 360);

            Assert.Throws<RivierException>(() => rivier.ZetLengte(lengte));
        }
        #endregion
    }
}
