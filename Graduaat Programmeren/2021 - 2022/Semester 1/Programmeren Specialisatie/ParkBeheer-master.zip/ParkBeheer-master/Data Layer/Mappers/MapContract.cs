﻿using Business_Layer.Model;
using Data_Layer.Exceptions;
using Data_Layer.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Layer.Mappers {
    public static class MapContract {
        public static Huurcontract MapToDomain(HuurContractEF huurContractEF, ParkBeheerContext context) {
            try {
                HuurderEF huurderEF = context.Huurders.Find(huurContractEF.HuurderID);
                HuisEF huisEF = context.Huizen.Find(huurContractEF.HuisID);

                Huurperiode huurperiode = new Huurperiode(huurContractEF.StartDatum, huurContractEF.AantalVerhuurDagen);
                Huurcontract huurcontract = new Huurcontract(huurContractEF.ID, huurperiode,
                    MapHuurder.MapToDomain(huurContractEF.Huurder),
                    MapHuis.MapToDomain(huurContractEF.Huis));

                return huurcontract;
            } catch (Exception ex) {
                throw new MapperException("MapContract - MapToDomain niet gelukt", ex);
            }
        }

        public static HuurContractEF MapToDB(Huurcontract huurcontract, ParkBeheerContext context) {
            try {
                HuurderEF huurderEF = context.Huurders.Where(h => h.ID == huurcontract.Huurder.Id).FirstOrDefault();
                if (huurderEF == null) {
                    huurderEF = MapHuurder.MapToDB(huurcontract.Huurder);
                }

                HuisEF huisEF = context.Huizen.Where(h => h.Nummer == huurcontract.Huis.Nr && h.Park.ID == huurcontract.Huis.Park.Id).FirstOrDefault();
                if (huisEF == null) {
                    huisEF = MapHuis.MapToDB(huurcontract.Huis, context);
                }

                ParkEF parkEF = context.Parken.Where(p => p.Naam == huurcontract.Huis.Park.Naam).FirstOrDefault();
                if (parkEF == null) {
                    parkEF = MapPark.MapToDB(huurcontract.Huis.Park);
                }

                huisEF.Park = parkEF;

                HuurContractEF huurContractEF = new HuurContractEF(huurcontract.Id, huurcontract.Huurperiode.StartDatum,
                    huurcontract.Huurperiode.EindDatum, huurcontract.Huurperiode.Aantaldagen, huisEF.ID, huisEF, huurderEF.ID, huurderEF);

                return huurContractEF;
            } catch (Exception ex) {
                throw new MapperException("MapContract - MapToDB niet gelukt", ex);
            }
        }
    }
}
