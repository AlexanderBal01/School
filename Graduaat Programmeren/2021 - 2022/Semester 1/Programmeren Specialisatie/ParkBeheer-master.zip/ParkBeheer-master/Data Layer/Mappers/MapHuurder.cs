﻿using Business_Layer.Model;
using Data_Layer.Exceptions;
using Data_Layer.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Layer.Mappers {
    public static class MapHuurder {
        public static Huurder MapToDomain(HuurderEF huurder) {
            try {
                return new Huurder(huurder.ID, huurder.Naam,
                    new Contactgegevens(huurder.Email, huurder.Telefoon, huurder.Adres));
            } catch (Exception ex) {
                throw new MapperException("MapHuurder - MapToDomain niet gelukt", ex);
            }
        }

        public static HuurderEF MapToDB(Huurder huurder) {
            try {
                return new HuurderEF(huurder.Id, huurder.Naam, huurder.Contactgegevens.Tel,
                    huurder.Contactgegevens.Email, huurder.Contactgegevens.Adres);
            } catch (Exception ex) {
                throw new MapperException("MapHuurder - MapToDB niet gelukt", ex);
            }
        }
    }
}
