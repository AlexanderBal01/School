﻿using Business_Layer.Model;
using Data_Layer.Exceptions;
using Data_Layer.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Layer.Mappers {
    public static class MapHuis {
        public static Huis MapToDomain(HuisEF huis) {
            try {
                Dictionary<Huurder, List<Huurcontract>> dicContracten = new Dictionary<Huurder, List<Huurcontract>>();

                foreach (HuurContractEF huurContractEF in huis.HuurContracten) {
                    Huurder huurder = new Huurder(huurContractEF.HuurderID, huurContractEF.Huurder.Naam,
                        new Contactgegevens(huurContractEF.Huurder.Email, huurContractEF.Huurder.Telefoon,
                        huurContractEF.Huurder.Adres));
                    Huurcontract hc = new Huurcontract(huurContractEF.ID, new Huurperiode(
                        huurContractEF.StartDatum, huurContractEF.AantalVerhuurDagen), huurder, new Huis(
                            huurContractEF.Huis.ID, huurContractEF.Huis.Straat, huurContractEF.Huis.Nummer, huurContractEF.Huis.Actief, new Park(
                                huurContractEF.Huis.Park.ID, huurContractEF.Huis.Park.Naam, huurContractEF.Huis.Park.Locatie)));

                    if (!dicContracten.ContainsKey(huurder)) {
                        dicContracten.Add(huurder, new List<Huurcontract>() { hc });
                    } else {
                        dicContracten[huurder].Add(hc);
                    }
                }

                return new Huis(huis.ID, huis.Straat, huis.Nummer, huis.Actief, MapPark.MapToDomain(huis.Park), dicContracten);
            } catch (Exception ex) {
                throw new MapperException("MapHuis - MapToDomain niet gelukt", ex);
            }
        }

        public static HuisEF MapToDB(Huis huis, ParkBeheerContext context) {
            try {
                ParkEF p = context.Parken.Where(x => x.Naam == huis.Park.Naam).FirstOrDefault();
                if (p == null) {
                    MapPark.MapToDB(huis.Park);
                }

                return new HuisEF(huis.Id, huis.Straat, huis.Nr, huis.Actief, p);
            } catch (Exception ex) {
                throw new MapperException("MapHuis - MapToDB niet gelukt", ex);
            }
        }
    }
}
