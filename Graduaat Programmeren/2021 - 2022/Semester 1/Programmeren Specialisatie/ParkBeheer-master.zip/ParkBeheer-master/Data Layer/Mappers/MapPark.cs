﻿using Business_Layer.Model;
using Data_Layer.Exceptions;
using Data_Layer.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Layer.Mappers {
    public static class MapPark {
        public static Park MapToDomain(ParkEF parkEF) {
            try {
                Park park = new Park(parkEF.ID, parkEF.Naam, parkEF.Locatie);
                if (parkEF.Huizen.Count > 0) {
                    foreach (HuisEF huisEF in parkEF.Huizen) {
                        park.VoegHuisToe(HuisEFToHuis(huisEF, park));
                    }
                }
                return park;
            } catch (Exception ex) {
                throw new MapperException("MapPark - MapToDomain niet gelukt", ex);
            }
        }

        private static Huis HuisEFToHuis(HuisEF huisEF, Park park) {
            return new Huis(huisEF.Straat, huisEF.Nummer, park);
        }

        public static ParkEF MapToDB(Park park) {
            try {
                return new ParkEF(park.Id, park.Naam, park.Locatie);
            } catch (Exception ex) {
                throw new MapperException("MapPark - MapToDB niet gelukt", ex);
            }
        }

    }
}
