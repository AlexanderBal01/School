﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Layer.Model {
    public class HuurContractEF {
        #region Properties
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        [Column(TypeName = "nvarchar(25)")]
        public string ID { get; set; }

        [Required]
        public DateTime StartDatum { get; set; }

        [Required]
        public DateTime EindDatum { get; set; }

        public int AantalVerhuurDagen { get; set; }

        [Required]
        public int HuisID { get; set; }

        public HuisEF Huis { get; set; }

        [Required]
        public int HuurderID { get; set; }

        public HuurderEF Huurder { get; set; }
        #endregion

        #region Ctor
        public HuurContractEF() {

        }

        public HuurContractEF(string id, DateTime startDatum, DateTime eindDatum, int aantalVerhuurDagen, int huisID, HuisEF huis, int huurderID, HuurderEF huurder) {
            ID = id;
            StartDatum = startDatum;
            EindDatum = eindDatum;
            AantalVerhuurDagen = aantalVerhuurDagen;
            HuisID = huisID;
            Huis = huis;
            HuurderID = huurderID;
            Huurder = huurder;
        }
        #endregion
    }
}
