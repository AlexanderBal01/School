﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Layer.Model {
    public class HuisEF {
        #region Properties
        [Key]
        public int ID { get; set; }

        [MaxLength(250)]
        public string Straat { get; set; }

        [Required]
        public int Nummer { get; set; }

        [Required]
        public bool Actief { get; set; }

        [Required]
        public string ParkId { get; set; }

        public ParkEF Park { get; set; }

        public List<HuurContractEF> HuurContracten { get; set; } = new List<HuurContractEF>();
        #endregion

        #region Ctor
        public HuisEF() {
        }

        public HuisEF(int id, string straat, int nummer, bool actief, ParkEF park) {
            ID = id;
            Straat = straat;
            Nummer = nummer;
            Actief = actief;
            Park = park;
        }

        public HuisEF(int id, string straat, int nummer, bool actief,
            ParkEF park, List<HuurContractEF> huurContracten) : this(id, straat, nummer, actief, park) {
            HuurContracten = huurContracten;
        }
        #endregion
    }
}
