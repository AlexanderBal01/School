﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Layer.Model {
    public class ParkEF {
        #region Properties
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        [Column(TypeName = "nvarchar(20)")]
        public string ID { get; set; }

        [Required]
        [MaxLength(250)]
        public string Naam { get; set; }

        [MaxLength(500)]
        public string Locatie { get; set; }

        public List<HuisEF> Huizen { get; set; } = new List<HuisEF>();
        #endregion

        #region Ctor
        public ParkEF() {

        }

        public ParkEF(string id, string naam, string locatie) {
            ID = id;
            Naam = naam;
            Locatie = locatie;
        }
        #endregion
    }
}
