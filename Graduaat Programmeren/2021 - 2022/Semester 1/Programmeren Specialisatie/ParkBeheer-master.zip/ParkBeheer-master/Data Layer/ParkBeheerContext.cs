﻿using Data_Layer.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Layer {
    public class ParkBeheerContext : DbContext {
        #region Properties
        private string ConnectionString;
        #endregion

        #region DBSet
        public DbSet<HuisEF> Huizen { get; set; }
        public DbSet<HuurContractEF> HuurContracten { get; set; }
        public DbSet<HuurderEF> Huurders { get; set; }
        public DbSet<ParkEF> Parken { get; set; }
        #endregion

        #region Ctor
        public ParkBeheerContext(string connectionString) {
            ConnectionString = connectionString;
        }
        #endregion

        #region Methods
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder) {
            optionsBuilder.UseSqlServer(ConnectionString);
        }
        #endregion
    }
}
