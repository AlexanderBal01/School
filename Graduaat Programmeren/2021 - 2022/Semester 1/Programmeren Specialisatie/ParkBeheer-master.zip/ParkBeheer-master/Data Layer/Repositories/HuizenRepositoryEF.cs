﻿using Business_Layer.Interfaces;
using Business_Layer.Model;
using Data_Layer.Exceptions;
using Data_Layer.Mappers;
using Data_Layer.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;

namespace Data_Layer.Repositories {
    public class HuizenRepositoryEF : IHuizenRepository {
        #region Properties
        private ParkBeheerContext Context;
        #endregion

        #region Ctor
        public HuizenRepositoryEF(string connectionString) {
            Context = new ParkBeheerContext(connectionString);
        }
        #endregion

        #region Methods
        public Huis GeefHuis(int id) {
            try {
                HuisEF huisEF = Context.Huizen.Where(x => x.ID == id)
                    .Include(x => x.Park)
                    .Include(x => x.HuurContracten).ThenInclude(x => x.Huurder)
                    .AsNoTracking().FirstOrDefault();
                Huis huis = MapHuis.MapToDomain(huisEF);
                return huis;
            } catch (Exception ex) {
                throw new RepositoryException("GeefHuis niet gelukt", ex);
            }
        }

        public bool HeeftHuis(string straat, int nummer, Park park) {
            try {
                if (Context.Huizen.Where(x => x.Straat == straat && x.Nummer == nummer && x.Park == MapPark.MapToDB(park)).AsNoTracking().FirstOrDefault() != null) {
                    return true;
                } else {
                    return false;
                }
            } catch (Exception ex) {
                throw new RepositoryException("HeeftHuis niet gelukt", ex);
            }
        }

        public bool HeeftHuis(int id) {
            try {
                return Context.Huizen.Any(x => x.ID == id);
            } catch (Exception ex) {
                throw new RepositoryException("HeeftHuis niet gelukt", ex);
            }
        }

        public void UpdateHuis(Huis huis) {
            try {
                Context.Huizen.Update(MapHuis.MapToDB(huis, Context));
                Context.SaveChanges();
                Context.ChangeTracker.Clear();
            } catch (Exception ex) {
                throw new RepositoryException("UpdateHuis niet gelukt", ex);
            }
        }

        public Huis VoegHuisToe(Huis h) {
            try {
                Context.Huizen.Add(MapHuis.MapToDB(h, Context));
                Context.SaveChanges();
                Context.ChangeTracker.Clear();
                return h;
            } catch (Exception ex) {
                throw new RepositoryException("VoegHuisToe niet gelukt", ex);
            }
        }
        #endregion
    }
}
