﻿using Business_Layer.Interfaces;
using Business_Layer.Model;
using Data_Layer.Exceptions;
using Data_Layer.Mappers;
using Data_Layer.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Layer.Repositories {
    public class ParkRepository : IParkRepository {
        private ParkBeheerContext Context;

        public ParkRepository(string connection) {
            Context = new ParkBeheerContext(connection);
        }


        public Park GeefPark(string id) {
            try {
                return MapPark.MapToDomain(Context.Parken.Where(x => x.ID == id).AsNoTracking().FirstOrDefault());
            } catch (Exception ex) {
                throw new RepositoryException("GeefPark", ex);
            }
        }

        public List<Park> GeefParken(string locatie) {
            return Context.Parken.Where(p => p.Locatie == locatie).Select(x => MapPark.MapToDomain(x)).ToList();
        }

        public void UpdatePark(Park p) {
            try {
                Context.Parken.Update(MapPark.MapToDB(p));
                Context.SaveChanges();
                Context.ChangeTracker.Clear();
            } catch (Exception ex) {
                throw new RepositoryException("UpdatePark", ex);
            }
        }

        public void VoegParkToe(Park p) {
            try {
                ParkEF park = MapPark.MapToDB(p);
                Context.Parken.Add(park);
                Context.SaveChanges();
                Context.ChangeTracker.Clear();
            } catch (Exception ex) {
                throw new RepositoryException("VoegParkToe", ex);
            }
        }
    }
}
