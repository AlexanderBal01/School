﻿using Business_Layer.Interfaces;
using Business_Layer.Model;
using Data_Layer.Exceptions;
using Data_Layer.Mappers;
using Data_Layer.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Data_Layer.Repositories {
    public class ContractenRepositoryEF : IContractenRepository {
        #region Properties
        private ParkBeheerContext Context;
        #endregion

        #region Ctor
        public ContractenRepositoryEF(string connectionString) {
            Context = new ParkBeheerContext(connectionString);
        }
        #endregion

        #region Methods
        public void AnnuleerContract(Huurcontract contract) {
            try {
                Context.HuurContracten.Remove(new HuurContractEF() { ID = contract.Id });
                Context.SaveChanges();
                Context.ChangeTracker.Clear();
            } catch (Exception ex) {
                throw new RepositoryException("AnnuleerContract niet gelukt", ex);
            }
        }

        public Huurcontract GeefContract(string id) {
            try {
                HuurContractEF huurContractEF = Context.HuurContracten.Where(x => x.ID == id)
                    .Include(x => x.Huis).ThenInclude(x => x.Park)
                    .Include(x => x.Huurder)
                    .AsNoTracking().FirstOrDefault();
                Huurcontract huurcontract = MapContract.MapToDomain(huurContractEF, Context);
                return huurcontract;
            } catch (Exception ex) {
                throw new RepositoryException("GeefContract niet gelukt", ex);
            }
        }

        public List<Huurcontract> GeefContracten(DateTime dtBegin, DateTime? dtEinde) {
            try {
                List<Huurcontract> huurContracten = Context.HuurContracten.Select(x => MapContract.MapToDomain(x, Context))
                    .Where(x => x.Huurperiode.StartDatum >= dtBegin && x.Huurperiode.EindDatum <= dtEinde)
                    .Include(x => x.Huis).ThenInclude(x => x.Park)
                    .Include(x => x.Huurder).AsNoTracking().ToList();
                return huurContracten;
            } catch (Exception ex) {
                throw new RepositoryException("GeefContracten niet gelukt", ex);
            }
        }

        public bool HeeftContract(DateTime startDatum, int huurderid, int huisid) {
            try {
                return Context.HuurContracten.Any(x => x.StartDatum == startDatum && x.HuurderID == huurderid && x.HuisID == huisid);
            } catch (Exception ex) {
                throw new RepositoryException("HeeftContract mislukt", ex);
            }
        }

        public bool HeeftContract(string id) {
            try {
                return Context.HuurContracten.Any(x => x.ID == id);
            } catch (Exception ex) {
                throw new RepositoryException("HeeftContract niet gelukt", ex);
            }
        }

        public void UpdateContract(Huurcontract contract) {
            try {
                Context.HuurContracten.Update(MapContract.MapToDB(contract, Context));
                Context.SaveChanges();
                Context.ChangeTracker.Clear();
            } catch (Exception ex) {
                throw new RepositoryException("UpdateContract niet gelukt", ex);
            }
        }

        public void VoegContractToe(Huurcontract contract) {
            try {
                Context.HuurContracten.Add(MapContract.MapToDB(contract, Context));
                Context.SaveChanges();
                Context.ChangeTracker.Clear();
            } catch (Exception ex) {
                throw new RepositoryException("VoegContractToe niet gelukt", ex);
            }
        }
        #endregion
    }
}
