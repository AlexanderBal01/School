﻿using Business_Layer.Interfaces;
using Business_Layer.Model;
using Data_Layer.Exceptions;
using Data_Layer.Mappers;
using Data_Layer.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Data_Layer.Repositories {
    public class HuurderRepositoryEF : IHuurderRepository {
        #region Properties
        private ParkBeheerContext Context;
        #endregion

        #region Ctor
        public HuurderRepositoryEF(string connectionString) {
            Context = new ParkBeheerContext(connectionString);
        }
        #endregion

        #region Methods
        public Huurder GeefHuurder(int id) {
            try {
                HuurderEF huurderEF = Context.Huurders.Where(x => x.ID == id).AsNoTracking().FirstOrDefault();
                Huurder huurder = MapHuurder.MapToDomain(huurderEF);
                return huurder;
            } catch (Exception ex) {
                throw new RepositoryException("GeefHuurder niet gelukt", ex);
            }
        }

        public List<Huurder> GeefHuurders(string naam) {
            try {
                List<HuurderEF> huurdersEF = Context.Huurders.Where(x => x.Naam == naam).AsNoTracking().ToList();
                List<Huurder> huurders = new List<Huurder>();
                foreach (HuurderEF huurderEF in huurdersEF) {
                    Huurder huurder = MapHuurder.MapToDomain(huurderEF);
                    huurders.Add(huurder);
                }
                return huurders;
            } catch (Exception ex) {
                throw new RepositoryException("GeefHuurders niet gelukt", ex);
            }
        }

        public bool HeeftHuurder(string naam, Contactgegevens contact) {
            try {
                return Context.Huurders.Any(x => x.Naam == naam
                && x.Telefoon == contact.Tel
                && x.Email == contact.Email
                && x.Adres == contact.Adres);
            } catch (Exception ex) {
                throw new RepositoryException("HeeftHuurder niet gelukt", ex);
            }
        }

        public bool HeeftHuurder(int id) {
            try {
                return Context.Huurders.Any(x => x.ID == id);
            } catch (Exception ex) {
                throw new RepositoryException("HeeftHuurder niet gelukt", ex);
            }
        }

        public void UpdateHuurder(Huurder huurder) {
            try {
                Context.Huurders.Update(MapHuurder.MapToDB(huurder));
                Context.SaveChanges();
                Context.ChangeTracker.Clear();
            } catch (Exception ex) {
                throw new RepositoryException("UpdateHuurder niet gelukt", ex);
            }
        }

        public Huurder VoegHuurderToe(Huurder h) {
            try {
                Context.Huurders.Add(MapHuurder.MapToDB(h));
                Context.SaveChanges();
                Context.ChangeTracker.Clear();
                return h;
            } catch (Exception ex) {
                throw new RepositoryException("VoegHuurderToe niet gelukt", ex);
            }
        }
        #endregion
    }
}
