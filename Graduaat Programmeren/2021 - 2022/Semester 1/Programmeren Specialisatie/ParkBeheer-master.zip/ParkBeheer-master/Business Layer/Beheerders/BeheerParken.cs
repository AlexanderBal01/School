﻿using Business_Layer.Exceptions;
using Business_Layer.Interfaces;
using Business_Layer.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business_Layer.Beheerders {
    public class BeheerParken {
        private IParkRepository repo;

        public BeheerParken(IParkRepository p) {
            this.repo = p;
        }


        public Park GeefPark(string id) {
            try {
                return repo.GeefPark(id);
            } catch (Exception ex) {
                throw new BeheerderException("GeefPark", ex);
            }
        }

        public List<Park> GeefParken(string locatie) {
            try {
                return repo.GeefParken(locatie);
            } catch (Exception ex) {
                throw new BeheerderException("GeefParken", ex);
            }
        }

        public void UpdatePark(Park p) {
            try {
                repo.UpdatePark(p);
            } catch (Exception ex) {
                throw new BeheerderException("UpdatePark", ex);
            }
        }

        public void VoegParkToe(Park p) {
            try {
                repo.VoegParkToe(p);
            } catch (Exception ex) {
                throw new BeheerderException("VoegParkToe", ex);
            }
        }
    }
}
