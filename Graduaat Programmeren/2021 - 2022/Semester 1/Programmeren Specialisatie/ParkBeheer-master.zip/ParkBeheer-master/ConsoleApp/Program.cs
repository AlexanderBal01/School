﻿using Business_Layer.Beheerders;
using Business_Layer.Interfaces;
using Business_Layer.Model;
using Data_Layer.Repositories;
using System;
using System.Configuration;

namespace ConsoleApp {
    internal class Program {
        static void Main(string[] args) {
            string ConnectionStringEF = ConfigurationManager.ConnectionStrings["connectionstringEF"].ConnectionString.ToString();
            //ParkBeheerContext context = new ParkBeheerContext(ConnectionStringEF);
            //context.Database.EnsureDeleted();
            //context.Database.EnsureCreated();

            #region Parken
            IParkRepository parkRepo = new ParkRepository(ConnectionStringEF);
            BeheerParken bp = new BeheerParken(parkRepo);
            Park p = new Park("1", "VIPPARK", "Dendermonde");
            bp.VoegParkToe(p);
            Park park = bp.GeefPark("1");
            Console.WriteLine(park);
            bp.GeefParken("Dendermonde");
            #endregion


            #region Huizen
            IHuizenRepository huisRepo = new HuizenRepositoryEF(ConnectionStringEF);
            BeheerHuizen bhz = new BeheerHuizen(huisRepo);
            bhz.VoegNieuwHuisToe("Martelarenlaan", 1, park);
            Huis h1 = bhz.GeefHuis(1);
            #endregion

            #region Huurders
            IHuurderRepository huurderRepo = new HuurderRepositoryEF(ConnectionStringEF);
            BeheerHuurders bhr = new BeheerHuurders(huurderRepo);
            bhr.VoegNieuweHuurderToe("Alexander Bal", new Contactgegevens("balalexander73@gmail.com", "0496385483", "Martelarenlaan-38-9200-Dendermonde"));
            Huurder hr1 = bhr.GeefHuurder(1);
            #endregion

            #region Huurcontracten
            IContractenRepository contractRepo = new ContractenRepositoryEF(ConnectionStringEF);
            BeheerContracten bc = new BeheerContracten(contractRepo);

            bc.MaakContract("1", new Huurperiode(DateTime.Today, 180), hr1, h1);
            #endregion

        }
    }
}
