﻿using BusinessLayer.Exceptions.Model;
using BusinessLayer.Model;
using BusinessLayer.Enums;
using System;
using Xunit;

namespace TestProjectBusinessLayerVoetbaltruitjes {
    public class UnitTestTruitje {
        #region Tests Ctor
        [Fact]
        public void Test_Ctor_Valid() {
            Club c = new Club("Real Madrid", "LaLiga");
            ClubSet cs = new ClubSet(true, 2);
            Truitje truitje = new Truitje(Maat.S, "2021-2022", 9.95, c, cs);

            Assert.Equal(Maat.S, truitje.Maat);
            Assert.Equal("2021-2022", truitje.Seizoen);
            Assert.Equal(9.95, truitje.Prijs);
            Assert.Equal(c, truitje.Club);
            Assert.Equal(cs, truitje.ClubSet);
        }

        [Fact]
        public void Test_Ctor_WithId_Valid() {
            Club c = new Club("Real Madrid", "LaLiga");
            ClubSet cs = new ClubSet(true, 2);
            Truitje truitje = new Truitje(1, Maat.S, "2021-2022", 9.95, c, cs);

            Assert.Equal(1, truitje.Id);
            Assert.Equal(Maat.S, truitje.Maat);
            Assert.Equal("2021-2022", truitje.Seizoen);
            Assert.Equal(9.95, truitje.Prijs);
            Assert.Equal(c, truitje.Club);
            Assert.Equal(cs, truitje.ClubSet);
        }
        #endregion

        #region Tests Methods
        [Fact]
        public void Test_ZetId_Valid() {
            Club c = new Club("Real Madrid", "LaLiga");
            ClubSet cs = new ClubSet(true, 2);
            Truitje truitje = new Truitje(1, Maat.S, "2021-2022", 9.95, c, cs);

            truitje.ZetId(2);

            Assert.Equal(2, truitje.Id);

        }

        [Theory]
        [InlineData(0)]
        [InlineData(-1)]
        public void Test_ZetId_Invalid(int id) {
            Club c = new Club("Real Madrid", "LaLiga");
            ClubSet cs = new ClubSet(true, 2);
            Truitje truitje = new Truitje(1, Maat.S, "2021-2022", 9.95, c, cs);

            Assert.Throws<TruitjeException>(() => truitje.ZetId(id));
        }

        [Fact]
        public void Test_ZetSeizoen_Valid() {
            Club c = new Club("Real Madrid", "LaLiga");
            ClubSet cs = new ClubSet(true, 2);
            Truitje truitje = new Truitje(1, Maat.S, "2021-2022", 9.95, c, cs);

            truitje.ZetSeizoen("2022-2023");

            Assert.Equal("2022-2023", truitje.Seizoen);
        }

        [Theory]
        [InlineData("")]
        [InlineData(" ")]
        public void Test_ZetSeizoen_Invalid(string seizoen) {
            Club c = new Club("Real Madrid", "LaLiga");
            ClubSet cs = new ClubSet(true, 2);
            Truitje truitje = new Truitje(1, Maat.S, "2021-2022", 9.95, c, cs);

            Assert.Throws<TruitjeException>(() => truitje.ZetSeizoen(seizoen));
        }

        [Fact]
        public void Test_ZetPrijs_Valid() {
            Club c = new Club("Real Madrid", "LaLiga");
            ClubSet cs = new ClubSet(true, 2);
            Truitje truitje = new Truitje(1, Maat.S, "2021-2022", 9.95, c, cs);

            truitje.ZetPrijs(9.95);

            Assert.Equal(9.95, truitje.Prijs);
        }

        [Theory]
        [InlineData(0.00)]
        [InlineData(-0.01)]
        [InlineData(-1.00)]
        public void Test_ZetPrijs_Invalid(double prijs) {
            Club c = new Club("Real Madrid", "LaLiga");
            ClubSet cs = new ClubSet(true, 2);
            Truitje truitje = new Truitje(1, Maat.S, "2021-2022", 9.95, c, cs);

            Assert.Throws<TruitjeException>(() => truitje.ZetPrijs(prijs));
        }

        [Fact]
        public void Test_ZetClub_Valid() {
            Club c = new Club("Real Madrid", "LaLiga");
            ClubSet cs = new ClubSet(true, 2);
            Truitje truitje = new Truitje(1, Maat.S, "2021-2022", 9.95, c, cs);

            Club c2 = new Club("FC Barcelona", "LaLiga");
            truitje.ZetClub(c2);

            Assert.Equal(c2, truitje.Club);
        }

        [Theory]
        [InlineData(null)]
        public void Test_ZetClub_Invalid(Club club) {
            Club c = new Club("Real Madrid", "LaLiga");
            ClubSet cs = new ClubSet(true, 2);
            Truitje truitje = new Truitje(1, Maat.S, "2021-2022", 9.95, c, cs);

            Assert.Throws<TruitjeException>(() => truitje.ZetClub(club));
        }

        [Fact]
        public void Test_ZetClubSet_Valid() {
            Club c = new Club("Real Madrid", "LaLiga");
            ClubSet cs = new ClubSet(true, 2);
            Truitje truitje = new Truitje(1, Maat.S, "2021-2022", 9.95, c, cs);

            ClubSet cs2 = new ClubSet(false, 1);
            truitje.ZetClubSet(cs2);

            Assert.Equal(cs2, truitje.ClubSet);
        }

        [Theory]
        [InlineData(null)]
        public void Test_ZetClubSet_Invalid(ClubSet clubSet) {
            Club c = new Club("Real Madrid", "LaLiga");
            ClubSet cs = new ClubSet(true, 2);
            Truitje truitje = new Truitje(1, Maat.S, "2021-2022", 9.95, c, cs);

            Assert.Throws<TruitjeException>(() => truitje.ZetClubSet(clubSet));
        }
        #endregion
    }
}
