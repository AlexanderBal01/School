using BusinessLayer.Exceptions.Model;
using BusinessLayer.Model;
using System;
using Xunit;

namespace TestProjectBusinessLayerVoetbaltruitjes {
    public class UnitTestClub {
        #region Tests Ctor
        [Fact]
        public void Test_Ctor_Valid() {
            Club club = new Club("Real Madrid", "LaLiga");

            Assert.Equal("Real Madrid", club.Ploegnaam);
            Assert.Equal("LaLiga", club.Competitie);
        }

        [Fact]
        public void Test_Ctor_WithId_Valid() {
            Club club = new Club(1, "Real Madrid", "LaLiga");

            Assert.Equal(1, club.Id);
            Assert.Equal("Real Madrid", club.Ploegnaam);
            Assert.Equal("LaLiga", club.Competitie);
        }
        #endregion

        #region Tests Methods
        [Fact]
        public void Test_ZetId_Valid() {
            Club club = new Club("Real Madrid", "LaLiga");

            club.ZetId(1);

            Assert.Equal(1, club.Id);
        }

        [Theory]
        [InlineData(0)]
        [InlineData(-1)]
        public void Test_ZetId_Invalid(int id) {
            Club club = new Club("Real Madrid", "LaLiga");

            Assert.Throws<ClubException>(() => club.ZetId(id));
        }

        [Fact]
        public void Test_ZetCompetitie_Valid() {
            Club club = new Club("Real Madrid", "LaLiga");

            club.ZetCompetitie("Premier League");

            Assert.Equal("Premier League", club.Competitie);
        }

        [Theory]
        [InlineData("")]
        [InlineData(" ")]
        public void Test_ZetCompetitie_Invalid(string competitie) {
            Club club = new Club("Real Madrid", "LaLiga");

            Assert.Throws<ClubException>(() => club.ZetCompetitie(competitie));
        }

        [Fact]
        public void Test_ZetPloegNaam_Valid() {
            Club club = new Club("Real Madrid", "LaLiga");

            club.ZetPloegnaam("Chelsea");

            Assert.Equal("Chelsea", club.Ploegnaam);
        }

        [Theory]
        [InlineData("")]
        [InlineData(" ")]
        public void Test_ZetPloegNaam_Invalid(string ploegnaam) {
            Club club = new Club("Real Madrid", "LaLiga");

            Assert.Throws<ClubException>(() => club.ZetPloegnaam(ploegnaam));
        }
        #endregion
    }
}
