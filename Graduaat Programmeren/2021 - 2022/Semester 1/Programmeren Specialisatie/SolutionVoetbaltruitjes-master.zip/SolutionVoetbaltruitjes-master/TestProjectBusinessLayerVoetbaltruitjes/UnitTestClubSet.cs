﻿using BusinessLayer.Exceptions.Model;
using BusinessLayer.Model;
using System;
using Xunit;

namespace TestProjectBusinessLayerVoetbaltruitjes {
    public class UnitTestClubSet {
        #region Tests Ctor
        [Fact]
        public void Test_Ctor_Valid() {
            ClubSet clubSet = new ClubSet(true, 2);

            Assert.True(clubSet.IsThuis);
            Assert.Equal(2, clubSet.Versie);
        }

        [Fact]
        public void Test_Ctor_WithId_Valid() {
            ClubSet clubSet = new ClubSet(2, true, 1);

            Assert.Equal(2, clubSet.Id);
            Assert.True(clubSet.IsThuis);
            Assert.Equal(1, clubSet.Versie);
        }
        #endregion

        #region Tests Methods
        [Fact]
        public void Test_ZetId_Valid() {
            ClubSet clubSet = new ClubSet(true, 2);

            clubSet.ZetId(1);

            Assert.Equal(1, clubSet.Id);
        }

        [Theory]
        [InlineData(0)]
        [InlineData(-1)]
        public void Test_ZetId_Invalid(int id) {
            ClubSet clubSet = new ClubSet(true, 2);

            Assert.Throws<ClubSetException>(() => clubSet.ZetId(id));
        }

        [Fact]
        public void Test_ZetVersie_Valid() {
            ClubSet clubSet = new ClubSet(true, 2);

            clubSet.ZetVersie(1);

            Assert.Equal(1, clubSet.Versie);
        }

        [Theory]
        [InlineData(0)]
        [InlineData(-1)]
        public void Test_ZetVersie_Invalid(int versie) {
            ClubSet clubSet = new ClubSet(true, 2);

            Assert.Throws<ClubSetException>(() => clubSet.ZetVersie(versie));
        }
        #endregion
    }
}
