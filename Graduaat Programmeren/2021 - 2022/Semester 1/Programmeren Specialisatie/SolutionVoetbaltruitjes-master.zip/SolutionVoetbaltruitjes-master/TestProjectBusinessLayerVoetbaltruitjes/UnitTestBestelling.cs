﻿using BusinessLayer.Enums;
using BusinessLayer.Exceptions.Model;
using BusinessLayer.Model;
using System;
using System.Collections.Generic;
using Xunit;

namespace TestProjectBusinessLayerVoetbaltruitjes {
    public class UnitTestBestelling {
        #region Tests Ctor
        [Fact]
        public void Test_Ctor_Valid() {
            Bestelling bestelling = new Bestelling(new DateTime(2021, 12, 13));

            Assert.Equal(new DateTime(2021, 12, 13), bestelling.Datum);
        }

        [Fact]
        public void Test_Ctor_WithKlant_Valid() {
            Klant k = new Klant("alexander", "martelarenlaan 38, 9200 Dendermonde");
            Bestelling bestelling = new Bestelling(k, new DateTime(2021, 12, 13));

            Assert.Equal(k, bestelling.Klant);
            Assert.Equal(new DateTime(2021, 12, 13), bestelling.Datum);
        }

        [Fact]
        public void Test_Ctor_WithProducten_Valid() {
            Club c = new Club("Real Madrid", "LaLiga");
            ClubSet cs = new ClubSet(true, 2);
            Truitje t = new Truitje(Maat.S, "2021-2022", 9.95, c, cs);
            Klant k = new Klant("alexander", "martelarenlaan 38, 9200 Dendermonde");
            Bestelling bestelling = new Bestelling(k, new DateTime(2021, 12, 13), t, 5);

            Dictionary<Truitje, int> d = new Dictionary<Truitje, int>();
            d.Add(t, 5);

            Assert.Equal(k, bestelling.Klant);
            Assert.Equal(new DateTime(2021, 12, 13), bestelling.Datum);
            Assert.Equal(d, bestelling.Producten);
        }

        [Fact]
        public void Test_Ctor_WithPrijs_Valid() {
            Club c = new Club("Real Madrid", "LaLiga");
            ClubSet cs = new ClubSet(true, 2);
            Truitje t = new Truitje(Maat.S, "2021-2022", 9.95, c, cs);
            Klant k = new Klant("alexander", "martelarenlaan 38, 9200 Dendermonde");
            Bestelling bestelling = new Bestelling(1, k, new DateTime(2021, 12, 13), (10.95*5), true, t, 5);

            Dictionary<Truitje, int> d = new Dictionary<Truitje, int>();
            d.Add(t, 5);

            Assert.Equal(1, bestelling.Id);
            Assert.Equal(k, bestelling.Klant);
            Assert.Equal(new DateTime(2021, 12, 13), bestelling.Datum);
            Assert.Equal(d, bestelling.Producten);
            Assert.Equal((10.95 * 5), bestelling.Prijs);
            Assert.True(bestelling.Betaald);
        }
        #endregion

        #region Tests Methods
        [Fact]
        public void Test_ZetDatum_Valid() {
            Bestelling bestelling = new Bestelling(new DateTime(2021, 12, 14));

            bestelling.ZetDatum(new DateTime(2021, 12, 13));

            Assert.Equal(new DateTime(2021, 12, 13), bestelling.Datum);
        }

        [Theory]
        [InlineData(null)]
        public void Test_ZetDatum_Invalid(DateTime? dateTime) {
            Bestelling bestelling = new Bestelling(new DateTime(2021, 12, 13));

            Assert.Throws<BestellingException>(() => bestelling.ZetDatum(dateTime));
        }

        [Fact]
        public void Test_ZetId_Valid() {
            Bestelling bestelling = new Bestelling(new DateTime(2021, 12, 13));

            bestelling.ZetId(2);

            Assert.Equal(2, bestelling.Id);
        }

        [Theory]
        [InlineData(0)]
        [InlineData(-1)]
        public void Test_ZetId_Invalid(int id) {
            Bestelling bestelling = new Bestelling(new DateTime(2021, 12, 13));

            Assert.Throws<BestellingException>(() => bestelling.ZetId(id));
        }

        [Fact]
        public void Test_ZetKlant_Valid() {
            Klant k = new Klant("alexander", "martelarenlaan 38, 9200 Dendermonde");
            Bestelling bestelling = new Bestelling(new DateTime(2021, 12, 13));

            bestelling.ZetKlant(k);

            Assert.Equal(k, bestelling.Klant);
        }

        [Theory]
        [InlineData(null)]
        public void Test_ZetKlant_Invalid(Klant klant) {
            Bestelling bestelling = new Bestelling(new DateTime(2021, 12, 13));

            Assert.Throws<BestellingException>(() => bestelling.ZetKlant(klant));
        }

        [Fact]
        public void Test_ZetProducten_Valid() {
            Dictionary<Truitje, int> d = new Dictionary<Truitje, int>();
            Club c = new Club("Real Madrid", "LaLiga");
            ClubSet cs = new ClubSet(true, 2);
            Truitje t = new Truitje(Maat.S, "2021-2022", 9.95, c, cs);
            d.Add(t, 5);

            Bestelling bestelling = new Bestelling(new DateTime(2021, 12, 13));
            bestelling.ZetProducten(t, 5);

            Assert.Equal(d, bestelling.Producten);
        }

        [Theory]
        [InlineData(null)]
        public void Test_ZetProducten_InvalidTruitje(Truitje truitje) {
            Bestelling bestelling = new Bestelling(new DateTime(2021, 12, 13));

            Assert.Throws<BestellingException>(() => bestelling.ZetProducten(truitje, 5));
        }

        [Theory]
        [InlineData(0)]
        [InlineData(-1)]
        public void Test_ZetProducten_InvalidAantalTruitje(int aantalTruitje) {
            Bestelling bestelling = new Bestelling(new DateTime(2021,12, 13)); 
            
            Club c = new Club("Real Madrid", "LaLiga");
            ClubSet cs = new ClubSet(true, 2);
            Truitje t = new Truitje(Maat.S, "2021-2022", 9.95, c, cs);

            Assert.Throws<BestellingException>(() => bestelling.ZetProducten(t, aantalTruitje));
        }
        #endregion
    }
}
