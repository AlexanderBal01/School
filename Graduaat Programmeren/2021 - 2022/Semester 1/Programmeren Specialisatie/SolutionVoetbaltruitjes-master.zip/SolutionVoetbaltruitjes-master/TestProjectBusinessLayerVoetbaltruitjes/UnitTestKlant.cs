﻿using BusinessLayer.Exceptions.Model;
using BusinessLayer.Model;
using BusinessLayer.Enums;
using System;
using Xunit;
using System.Collections.Generic;

namespace TestProjectBusinessLayerVoetbaltruitjes {
    public class UnitTestKlant {
        #region Tests Ctor
        [Fact]
        public void Test_Ctor_Valid() {
            Klant klant = new Klant("Alexander Bal", "Martelarenlaan 38, 9200 Dendermonde");

            Assert.Equal("Alexander Bal", klant.Naam);
            Assert.Equal("Martelarenlaan 38, 9200 Dendermonde", klant.Adres);
        }

        [Fact]
        public void Test_Ctor_WithId_Valid() {
            Klant klant = new Klant(1, "Alexander Bal", "Martelarenlaan 38, 9200 Dendermonde");

            Assert.Equal(1, klant.Id);
            Assert.Equal("Alexander Bal", klant.Naam);
            Assert.Equal("Martelarenlaan 38, 9200 Dendermonde", klant.Adres);
        }

        [Fact]
        public void Test_Ctor_WithBestelling_Valid() {
            Bestelling b = new Bestelling(new DateTime(2021, 12, 13));
            Klant klant = new Klant(1, "Alexander Bal", "Martelarenlaan 38, 9200 Dendermonde", b);

            List<Bestelling> l = new List<Bestelling>();
            l.Add(b);

            Assert.Equal(1, klant.Id);
            Assert.Equal("Alexander Bal", klant.Naam);
            Assert.Equal("Martelarenlaan 38, 9200 Dendermonde", klant.Adres);
            Assert.Equal(l, klant.Bestellingen);
        }
        #endregion

        #region Tests Methods
        [Fact]
        public void Test_ZetNaam_Valid() {
            Klant klant = new Klant("Alexander Bal", "Martelarenlaan 38, 9200 Dendermonde");

            klant.ZetNaam("Geert Bal");

            Assert.Equal("Geert Bal", klant.Naam);
        }

        [Theory]
        [InlineData("")]
        [InlineData(" ")]
        public void Test_ZetNaam_Invalid(string naam) {
            Klant klant = new Klant("Alexander Bal", "Martelarenlaan 38, 9200 Dendermonde");

            Assert.Throws<KlantException>(() => klant.ZetNaam(naam));
        }

        [Fact]
        public void Test_ZetAdres_Valid() {
            Klant klant = new Klant("Alexander Bal", "Martelarenlaan 38, 9200 Dendermonde");

            klant.ZetAdres("Martelarenlaan 38");

            Assert.Equal("Martelarenlaan 38", klant.Adres);
        }

        [Theory]
        [InlineData("")]
        [InlineData(" ")]
        [InlineData("abcd")]
        public void Test_ZetAdres_Invalid(string adres) {
            Klant klant = new Klant("Alexander Bal", "Martelarenlaan 38, 9200 Dendermonde");

            Assert.Throws<KlantException>(() => klant.ZetAdres(adres));
        }

        [Fact]
        public void Test_ZetId_Valid() {
            Klant klant = new Klant("Alexander Bal", "Martelarenlaan 38, 9200 Dendermonde");

            klant.ZetId(1);

            Assert.Equal(1, klant.Id);
        }

        [Theory]
        [InlineData(0)]
        [InlineData(-1)]
        public void Test_ZetId_Invalid(int id) {
            Klant klant = new Klant("Alexander Bal", "Martelarenlaan 38, 9200 Dendermonde");

            Assert.Throws<KlantException>(() => klant.ZetId(id)); ;
        }

        [Fact]
        public void Test_ZetBestelling_Valid() {
            Klant klant = new Klant("Alexander Bal", "Martelarenlaan 38, 9200 Dendermonde");

            Bestelling b = new Bestelling(new DateTime(2021, 12, 13));
            klant.ZetBestelling(b);

            List<Bestelling> l = new List<Bestelling>();
            l.Add(b);

            Assert.Equal(l, klant.Bestellingen);
        }

        [Theory]
        [InlineData(null)]
        public void Test_ZetBestelling_Invalid(Bestelling bestelling) {
            Klant klant = new Klant("Alexander Bal", "Martelarenlaan 38, 9200 Dendermonde");

            Assert.Throws<KlantException>(() => klant.ZetBestelling(bestelling));
        }
        #endregion
    }
}
