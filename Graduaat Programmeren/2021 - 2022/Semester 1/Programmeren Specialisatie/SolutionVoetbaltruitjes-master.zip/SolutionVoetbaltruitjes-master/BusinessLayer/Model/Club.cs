﻿using BusinessLayer.Exceptions.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.Model {
    public class Club {
        #region Properties
        public string Ploegnaam { get; private set; }
        public string Competitie { get; private set; }
        public int Id { get; private set; }
        #endregion

        #region Ctor
        public Club(string ploegnaam, string competitie) {
            ZetPloegnaam(ploegnaam);
            ZetCompetitie(competitie);
        }

        public Club(int id, string ploegnaam, string competitie) : this(ploegnaam, competitie) {
            ZetId(id);
        }
        #endregion

        #region Methods
        public void ZetId(int id) {
            if (id >= 1) {
                Id = id;
            } else {
                throw new ClubException("Club - Id moet groeter zijn dan 0");
            }
        }

        public void ZetCompetitie(string competitie) {
            if (!string.IsNullOrWhiteSpace(competitie)) {
                Competitie = competitie;
            } else {
                throw new ClubException("Club - Competitie mag niet leeg zijn.");
            }
        }

        public void ZetPloegnaam(string ploegnaam) {
            if (!string.IsNullOrWhiteSpace(ploegnaam)) {
                Ploegnaam = ploegnaam;
            } else {
                throw new ClubException("Club - Ploegnaam mag niet leeg zijn.");
            }
        }

        public override bool Equals(object obj) {
            return obj is Club club &&
                   Ploegnaam == club.Ploegnaam &&
                   Competitie == club.Competitie &&
                   Id == club.Id;
        }

        public override int GetHashCode() {
            return HashCode.Combine(Ploegnaam, Competitie, Id);
        }

        public override string ToString() {
            return $"Club: {Id}, {Ploegnaam}, {Competitie}";
        }

        #endregion
    }
}
