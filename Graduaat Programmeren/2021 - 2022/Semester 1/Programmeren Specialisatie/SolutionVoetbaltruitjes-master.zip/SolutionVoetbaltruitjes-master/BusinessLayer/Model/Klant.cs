﻿using BusinessLayer.Exceptions.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.Model {
    public class Klant {
        #region Properties
        public int Id { get; private set; }
        public string Naam { get; private set; }
        public string Adres { get; private set; }
        public List<Bestelling> Bestellingen = new List<Bestelling>();
        #endregion

        #region Ctor
        public Klant(string naam, string adres) {
            ZetNaam(naam);
            ZetAdres(adres);
        }

        public Klant(int id, string naam, string adres) : this (naam, adres) {
            ZetId(id);
        }

        public Klant(int id, string naam, string adres, Bestelling bestelling) : this (id ,naam, adres) {
            ZetBestelling(bestelling);
        }
        #endregion

        #region Methods
        public void ZetNaam(string naam) {
            if (!string.IsNullOrWhiteSpace(naam)) {
                Naam = naam;
            } else {
                throw new KlantException("Klant - Naam moet ingevuld zijn.");
            }
        }

        public void ZetAdres(string adres) {
            if (!string.IsNullOrWhiteSpace(adres)) {
                if (adres.Trim().Length >= 5) {
                    Adres = adres;
                } else {
                    throw new KlantException("Klant - Adres moet minstens 5 karakters lang zijn.");
                }
            } else {
                throw new KlantException("Klant - Adres moet ingevuld zijn");
            }
        }

        public void ZetId(int id) {
            if (id > 0) {
                Id = id;
            } else {
                throw new KlantException("Klantnummer moet groter zijn dan 0.");
            }
        }

        public void ZetBestelling(Bestelling bestelling) {
            if (bestelling == null) {
                throw new KlantException("Klant - Bestelling is null");
            } else {
                Bestellingen.Add(bestelling);
                bestelling.ZetKlant(this);
            }
        }

        public bool HeeftBestelling(Bestelling bestelling) {
            if (Bestellingen.Contains(bestelling)) {
                return true;
            } else {
                return false;
            }
        }

        public void VerwijderBestelling(Bestelling bestelling) {
            if (bestelling == null) {
                throw new KlantException("Klant - kan bestelling niet verwijderen");
            } else if (Bestellingen.Contains(bestelling)) {
                Bestellingen.Remove(bestelling);
            }
        }

        public override bool Equals(object obj) {
            return obj is Klant klant &&
                   Id == klant.Id &&
                   Naam == klant.Naam &&
                   Adres == klant.Adres &&
                   EqualityComparer<List<Bestelling>>.Default.Equals(Bestellingen, klant.Bestellingen);
        }

        public override int GetHashCode() {
            return HashCode.Combine(Id, Naam, Adres, Bestellingen);
        }

        public override string ToString() {
            return $"Klant {Id}, {Naam}, {Adres}";
        }


        #endregion
    }
}
