﻿using BusinessLayer.Exceptions.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.Model {
    public class ClubSet {
        #region Properties
        public int Id { get; private set; }
        public bool IsThuis { get; private set; }
        public int Versie { get; private set; }
        #endregion

        #region Ctor
        public ClubSet(bool isThuis, int versie) {
            IsThuis = isThuis;
            ZetVersie(versie);
        }

        public ClubSet(int id, bool isThuis, int versie) : this(isThuis, versie) {
            ZetId(id);
        }
        #endregion

        #region Methods
        public void ZetId(int id) {
            if (id >= 1) {
                Id = id;
            } else {
                throw new ClubSetException("Clubset - id moet groter of gelijk zijn aan 1.");
            }
        }

        public void ZetVersie(int versie) {
            if (versie >= 1) {
                Versie = versie;
            } else {
                throw new ClubSetException("Clubset - Versie moet groter of gelijk zijn aan 1.");
            }
        }

        public override bool Equals(object obj) {
            return obj is ClubSet set &&
                   Id == set.Id &&
                   IsThuis == set.IsThuis &&
                   Versie == set.Versie;
        }

        public override int GetHashCode() {
            return HashCode.Combine(Id, IsThuis, Versie);
        }

        public override string ToString() {
            return $"Isthuis: {IsThuis} versie: {Versie}";
        }
        #endregion
    }
}
