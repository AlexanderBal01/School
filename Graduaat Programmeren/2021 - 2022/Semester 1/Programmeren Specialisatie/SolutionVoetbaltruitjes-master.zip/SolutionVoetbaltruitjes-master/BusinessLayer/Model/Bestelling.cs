﻿using BusinessLayer.Exceptions.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.Model {
    public class Bestelling {
        #region Properties
        public Dictionary<Truitje, int> Producten = new Dictionary<Truitje, int>();

        public int Id { get; private set; }
        public DateTime Datum { get; set; }
        public double Prijs { get; private set; }
        public bool Betaald { get; private set; }
        public Klant Klant { get; private set; }
        private double Korting;
        #endregion

        #region Ctor
        public Bestelling(DateTime datum) {
            ZetDatum(datum);
        }

        public Bestelling(Klant klant, DateTime datum) : this(datum) {
            ZetKlant(klant);
        }

        public Bestelling(Klant klant, DateTime datum, Truitje truitje, int aantalTruitje) : this(klant, datum) {
            ZetProducten(truitje, aantalTruitje);
        }

        public Bestelling(Klant klant, DateTime datum, Truitje truitje, int aantalTruitje, bool betaald, double prijs) : this(klant, datum, truitje, aantalTruitje) {
            Betaald = betaald;
            ZetPrijs(prijs);
        }

        public Bestelling(int id, Klant klant, DateTime datum, double prijs, bool betaald, Truitje truitje, int aantalTruitje) : this(klant, datum, truitje, aantalTruitje) {
            ZetPrijs(prijs);
            Betaald = betaald;
            ZetId(id);
        }
        #endregion

        #region Methods
        public void ZetDatum(DateTime datum) {
            if (!string.IsNullOrEmpty(datum.ToLongDateString())) {
                Datum = datum;
            } else {
                throw new BestellingException("Bestelling - Datum moet ingevuld zijn.");
            }
        }

        public void ZetId(int id) {
            if (id > 0) {
                Id = id;
            } else {
                throw new BestellingException("Bestelling - Id Moet groter zijn dan 0");
            }
        }

        public void ZetKlant(Klant klant) {
            if (klant == null) {
                throw new BestellingException("Bestelling - invalid klant");
            }

            if (klant == Klant && klant != null) {
                throw new BestellingException("Bestelling - invalid klant");
            }

            if (klant == null && Klant != null) {
                throw new BestellingException("Klant is hetzelfde");
            }

            if (Klant != null) {
                if (Klant.HeeftBestelling(this)) {
                    Klant.VerwijderBestelling(this);
                }
            }
            if (!klant.HeeftBestelling(this)) {
                klant.ZetBestelling(this);
            }
            Klant = klant;
        }

        public void ZetProducten(Truitje truitje, int aantalTruitje) {
            if (aantalTruitje <= 0) {
                throw new BestellingException("Bestelling - aantal truitjes kleiner dan 0");
            }

            if (truitje is null) {
                throw new BestellingException("Bestelling - truitje is null");
            } else {
                Producten.Add(truitje, aantalTruitje);
                if (HeeftRechtOpKorting()) {
                    Prijs = (aantalTruitje * truitje.Prijs) - ((aantalTruitje * truitje.Prijs) / Korting);
                } else {
                    Prijs = aantalTruitje * truitje.Prijs;
                }
                
            }

        }

        public void ZetPrijs(double prijs) {
            if (prijs > 0) {
                if (HeeftRechtOpKorting()) {
                    Prijs = prijs - (prijs / Korting);
                } else {
                    Prijs = prijs;
                }
            } else {
                throw new BestellingException("Bestelling - Prijs moet groter zijn dan 0");
            }
        }

        public bool HeeftRechtOpKorting() {
            if (Klant.Bestellingen.Count == 0) {
                if (Klant.Bestellingen.Count > 5 && Klant.Bestellingen.Count <= 10) {
                    Korting = 0.10;
                    return true;
                } else if (Klant.Bestellingen.Count > 10) {
                    Korting = 0.20;
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        }

        public override bool Equals(object obj) {
            return obj is Bestelling bestelling &&
                   EqualityComparer<Dictionary<Truitje, int>>.Default.Equals(Producten, bestelling.Producten) &&
                   Id == bestelling.Id &&
                   Datum == bestelling.Datum &&
                   Prijs == bestelling.Prijs &&
                   Betaald == bestelling.Betaald &&
                   EqualityComparer<Klant>.Default.Equals(Klant, bestelling.Klant) &&
                   Korting == bestelling.Korting;
        }

        public override int GetHashCode() {
            return HashCode.Combine(Producten, Id, Datum, Prijs, Betaald, Klant, Korting);
        }

        public override string ToString() {
            return $"Bestelling {Id}, {Datum}, {Prijs}\n" +
                $"{Klant}";
        }
        #endregion
    }
}
