﻿using BusinessLayer.Enums;
using BusinessLayer.Exceptions.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.Model {
    public class Truitje {
        #region Properties
        public int Id { get; private set; }
        public Maat Maat { get; private set; }
        public string Seizoen { get; private set; }
        public double Prijs { get; private set; }
        public Club Club { get; private set; }
        public ClubSet ClubSet { get; private set; }
        #endregion

        #region Ctor
        public Truitje(Maat maat, string seizoen, double prijs, Club club, ClubSet clubSet) {
            Maat = maat;
            ZetSeizoen(seizoen);
            ZetPrijs(prijs);
            ZetClub(club);
            ZetClubSet(clubSet);
        }

        public Truitje(int id, Maat maat, string seizoen, double prijs, Club club, ClubSet clubSet) : this(maat, seizoen, prijs, club, clubSet) {
            ZetId(id);
        }
        #endregion

        #region Methods
        public void ZetId(int id) {
            if (id >= 1) {
                Id = id;
            } else {
                throw new TruitjeException("id moet groter zijn dan 0.");
            }
        }

        public void ZetSeizoen(string seizoen) {
            if (!string.IsNullOrWhiteSpace(seizoen)) {
                Seizoen = seizoen;
            } else {
                throw new TruitjeException("Truitje - Seizoen mag niet leeg zijn.");
            }
        }

        public void ZetPrijs(double prijs) {
            if (prijs > 0) {
                Prijs = prijs;
            } else {
                throw new TruitjeException("Truitje - Prijs moet groter zijn dan 0.");
            }
        }

        public void ZetClub(Club club) {
            if (club == null) {
                throw new TruitjeException("Truitje - club is null.");
            } else {
                Club = club;
            }
        }

        public void ZetClubSet(ClubSet clubSet) {
            if (clubSet == null) {
                throw new TruitjeException("Truitje - ClubSet is null");
            } else {
                ClubSet = clubSet;
            }
        }

        public override bool Equals(object obj) {
            return obj is Truitje truitje &&
                   Id == truitje.Id &&
                   Maat == truitje.Maat &&
                   Seizoen == truitje.Seizoen &&
                   Prijs == truitje.Prijs &&
                   EqualityComparer<Club>.Default.Equals(Club, truitje.Club) &&
                   EqualityComparer<ClubSet>.Default.Equals(ClubSet, truitje.ClubSet);
        }

        public override int GetHashCode() {
            return HashCode.Combine(Id, Maat, Seizoen, Prijs, Club, ClubSet);
        }

        public override string ToString() {
            return $"Truitje {Id}, {Maat}, {Seizoen}, {Prijs}\n" +
                $"{Club}\n" +
                $"{ClubSet}";
        }
        #endregion
    }
}
