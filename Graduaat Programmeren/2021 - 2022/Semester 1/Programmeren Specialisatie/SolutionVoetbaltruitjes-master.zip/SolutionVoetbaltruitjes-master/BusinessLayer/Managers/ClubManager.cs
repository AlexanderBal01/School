﻿using BusinessLayer.Exceptions.Mangers;
using BusinessLayer.Interfaces;
using BusinessLayer.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.Managers {
    public class ClubManager {
        #region Properties
        private IClubRepository Repo;
        #endregion

        #region Ctor
        public ClubManager(IClubRepository repo) {
            Repo = repo;
        }
        #endregion

        #region Methods
        public List<Club> GeefClubs(string tekst) {
            try {
                return Repo.GeefClubs(tekst);
            } catch (Exception ex) {
                throw new ClubManagerException("GeefClubs", ex);
            }
        }

        public Club MaakClubAan(Club club) {
            try {
                if (club == null) {
                    throw new ClubManagerException("MaakClubAan - Club is null");
                }
                if (Repo.BestaatClubId(club.Id)) {
                    throw new ClubManagerException("MaakClubAan - Club bestaat reeds");
                }
                return Repo.MaakClubAan(club);
            } catch (Exception ex) {
                throw new ClubManagerException("MaakClubAan", ex);
            }
        }

        public bool UpdateClub(Club club) {
            try {
                if (club == null) {
                    throw new ClubManagerException("UpdateClub - Club is null");
                }
                if (!Repo.BestaatClubId(club.Id)) {
                    throw new ClubManagerException("UpdateClub - Club bestaat reeds");
                }
                List<Club> clubDB = Repo.GeefClubs(club.Id.ToString());
                if (clubDB.Contains(club)) {
                    throw new ClubManagerException("UpdateClub - Club heeft geen verschillen");
                }
                Repo.UpdateClub(club);
                return true;
            } catch (Exception ex) {
                throw new ClubManagerException("UpdateClub", ex);
            }
        }

        public void VerwijderClub(int id) {
            try {
                if (!Repo.BestaatClubId(id)) {
                    throw new ClubManagerException("VerwijderClub - Cluib bestaat nog niet");
                }
                Repo.VerwijderClub(id);
            } catch (Exception ex) {
                throw new ClubManagerException("VerwijderClub", ex);
            }
        }

        public bool BestaatClubId(int id) {
            try {
                return Repo.BestaatClubId(id);
            } catch (Exception ex) {
                throw new ClubManagerException("BestaatClubId", ex);
            }
        }
        #endregion
    }
}
