﻿using BusinessLayer.Exceptions.Mangers;
using BusinessLayer.Interfaces;
using BusinessLayer.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.Managers {
    public class ClubSetManager {
        #region Properties
        private IClubSetRepository Repo;
        #endregion

        #region Ctor
        public ClubSetManager(IClubSetRepository repo) {
            Repo = repo;
        }
        #endregion

        #region Methods
        public List<ClubSet> GeefClubSets(string tekst) {
            try {
                return Repo.GeefClubSets(tekst);
            } catch (Exception ex) {
                throw new ClubSetManagerException("GeefClubSets", ex);
            }
        }

        public ClubSet MaakClubSetAan(ClubSet clubSet) {
            try {
                if (clubSet == null) {
                    throw new ClubSetManagerException("MaakClubSetAan - clubset is null");
                }
                if (Repo.BestaatClubSetId(clubSet.Id)) {
                    throw new ClubSetManagerException("MaakClubSetAan - clubset bestaat reeds");
                }
                return Repo.MaakClubSetAan(clubSet);
            } catch (Exception ex) {
                throw new ClubSetManagerException("MaakClubSetAan", ex);
            }
        }

        public bool UpdateClubSet(ClubSet clubSet) {
            try {
                if (clubSet == null) {
                    throw new ClubSetManagerException("UpdateClubSet - clubset is null");
                }
                if (!Repo.BestaatClubSetId(clubSet.Id)) {
                    throw new ClubSetManagerException("UpdateClubSet - clubset bestaat niet");
                }
                List<ClubSet> clubSetDB = Repo.GeefClubSets(clubSet.Id.ToString());
                if (clubSetDB.Contains(clubSet)) {
                    throw new ClubSetManagerException("UpdateClubSet - clubset heeft geen verschillen");
                }
                Repo.UpdateClubSet(clubSet);
                return true;
            } catch (Exception ex) { 
                throw new ClubSetManagerException("UpdateClubSet", ex);
            }
        }

        public void VerwijderClubSet(int id) {
            try {
                if (!Repo.BestaatClubSetId(id)) {
                    throw new ClubSetManagerException("VerwijderClubSet - Clubset bestaat nog niet");
                }
                Repo.VerwijderClubSet(id);
            } catch (Exception ex) {
                throw new ClubSetManagerException("VerwijderClubSet", ex);
            }
        }

        public bool BestaatClubSetId(int id) {
            try {
                return Repo.BestaatClubSetId(id);
            } catch (Exception ex) {
                throw new ClubSetManagerException("BestaatClubSetId", ex);
            }
        }
        #endregion
    }
}
