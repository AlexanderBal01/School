﻿using BusinessLayer.Exceptions.Mangers;
using BusinessLayer.Interfaces;
using BusinessLayer.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.Managers {
    public class BestellingManager {
        #region Properties
        private IBestellingRepository Repo;
        #endregion

        #region Ctor
        public BestellingManager(IBestellingRepository repo) {
            Repo = repo;
        }
        #endregion

        #region Methods
        public List<Bestelling> GeefBestellingen(string tekst) {
            try {
                return Repo.GeefBestellingen(tekst);
            } catch (Exception ex) {
                throw new BestellingManagerException("GeefBestellingen", ex);
            }
        }

        public Bestelling MaakBestellingAan(Bestelling bestelling) {
            try {
                if (bestelling == null) {
                    throw new BestellingManagerException("MaakBestellingAan - bestelling is null");
                }
                if (Repo.BestaatBestellingId(bestelling.Id)) {
                    throw new BestellingManagerException("MaakBestellingAan - bestelling bestaat reeds");
                }
                return Repo.MaakBestellingAan(bestelling);
            } catch (Exception ex) {
                throw new BestellingManagerException("MaakBestellingAan", ex);
            }
        }

        public bool UpdateBestelling(Bestelling bestelling) {
            try {
                if (bestelling == null) {
                    throw new BestellingManagerException("UpdateBestelling - bestelling is null");
                }
                if (!Repo.BestaatBestellingId(bestelling.Id)) {
                    throw new BestellingManagerException("UpdateBestelling - bestelling bestaat niet");
                }
                List<Bestelling> bestellingDB = Repo.GeefBestellingen(bestelling.Id.ToString());
                if (bestellingDB.Contains(bestelling)) {
                    throw new BestellingManagerException("UpdateBestelling - bestelling heeft geen verschillen");
                }
                Repo.UpdateBestelling(bestelling);
                return true;
            } catch (Exception ex) {
                throw new BestellingManagerException("UpdateBestelling", ex);
            }
        }

        public void VerwijderBestelling(int id) {
            try {
                if (!Repo.BestaatBestellingId(id)) {
                    throw new BestellingManagerException("VerwijderBestelling - bestelling bestaat niet");
                }
                Repo.VerwijderBestelling(id);
            } catch (Exception ex) {
                throw new BestellingManagerException("VerwijderBestelling", ex);
            }
        }

        public bool BestaatBestellingId(int id) {
            try {
                return Repo.BestaatBestellingId(id);
            } catch (Exception ex) {
                throw new BestellingManagerException("BestaatBestellingId", ex);
            }
        }
        #endregion
    }
}
