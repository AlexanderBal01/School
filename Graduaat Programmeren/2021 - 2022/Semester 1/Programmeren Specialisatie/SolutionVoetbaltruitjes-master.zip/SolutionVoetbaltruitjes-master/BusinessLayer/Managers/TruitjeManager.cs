﻿using BusinessLayer.Enums;
using BusinessLayer.Exceptions.Mangers;
using BusinessLayer.Interfaces;
using BusinessLayer.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.Managers {
    public class TruitjeManager {
        #region Properties
        private ITruitjeRepository Repo;
        #endregion

        #region Ctor
        public TruitjeManager(ITruitjeRepository repo) {
            Repo = repo;
        }
        #endregion

        #region Methods
        public List<Truitje> GeefTruitjes(string tekst) {
            try {
                return Repo.GeefTruitjes(tekst);
            } catch (Exception ex) {
                throw new TruitjeManagerException("GeefTruitjes", ex);
            }
        }

        public Truitje MaakTruitjeAan(Truitje truitje) {
            try {
                if (truitje == null) {
                    throw new TruitjeManagerException("MaakTruitjeAan - truitje is null");
                }
                if (Repo.BestaatTruitjeId(truitje.Id)) {
                    throw new TruitjeManagerException("MaakTruitjeAan - truitje bestaat reeds");
                }
                return Repo.MaakTruitjeAan(truitje);
            } catch (Exception ex) {
                throw new TruitjeManagerException("MaakTruitjeAan", ex);
            }
        }

        public bool UpdateTruitje(Truitje truitje) {
            try {
                if (truitje == null) {
                    throw new TruitjeManagerException("UpdateTruitje - truitje is null");
                }
                if (!Repo.BestaatTruitjeId(truitje.Id)) {
                    throw new TruitjeManagerException("UpdateTruitje - truitje bestaat niet");
                }
                List<Truitje> truitjeDB = Repo.GeefTruitjes(truitje.Id.ToString());
                if (truitjeDB.Contains(truitje)) {
                    throw new TruitjeManagerException("UpdateTruitje - truitje heeft geen verschillen");
                }
                Repo.UpdateTruitje(truitje);
                return true;
            } catch (Exception ex) {
                throw new TruitjeManagerException("UpdateTruitje", ex);
            }
        }

        public bool BestaatTruitjeId(int id) {
            try {
                return Repo.BestaatTruitjeId(id);
            } catch (Exception ex) {
                throw new TruitjeManagerException("BestaatTruitjeId", ex);
            }
        }

        public void VerwijderTruitje(int id) {
            try {
                if (!Repo.BestaatTruitjeId(id)) {
                    throw new TruitjeManagerException("VerwijderTruitje - Truitje bestaat nog niet");
                }
                Repo.VerwijderTruitje(id);
            } catch (Exception ex) {
                throw new TruitjeManagerException("VerwijderTruitje", ex);
            }
        }
        #endregion
    }
}
