﻿using BusinessLayer.Exceptions.Mangers;
using BusinessLayer.Interfaces;
using BusinessLayer.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.Managers {
    public class KlantManager {
        #region Properties
        private IKlantRepository Repo;
        #endregion

        #region Ctor
        public KlantManager(IKlantRepository repo) {
            Repo = repo;
        }
        #endregion

        #region Methods
        public List<Klant> GeefKlanten(string tekst) {
            try {
                
                return Repo.GeefKlanten(tekst);
            } catch (Exception ex) {
                throw new KlantManagerException("GeefKlanten", ex);
            }
        }

        public Klant MaakKlantAan(Klant klant) {
            try {
                if (klant == null) {
                    throw new KlantManagerException("MaakKlantAan - klant is null");
                }
                if (Repo.BestaatKlantId(klant.Id)) {
                    throw new KlantManagerException("MaakKlantAan - klant bestaat reeds");
                }
                return Repo.MaakKlantAan(klant);
            } catch (Exception ex) {
                throw new KlantManagerException("MaakKlantAan", ex);
            }
        }

        public bool UpdateKlant(Klant klant) {
            try {
                if (klant == null) {
                    throw new KlantManagerException("UpdateKlant - klant is null");
                }
                if (!Repo.BestaatKlantId(klant.Id)) {
                    throw new KlantManagerException("UpdateKlant - klant bestaat niet");
                }
                List<Klant> klantDB = Repo.GeefKlanten(klant.Id.ToString());
                if (klantDB.Contains(klant)) {
                    throw new KlantManagerException("UpdateKlant - klant heeft geen verschillen");
                }
                Repo.UpdateKlant(klant);
                return true;
            } catch (Exception ex) {
                throw new KlantManagerException("UpdateKlant", ex);
            }
        }

        public bool BestaatKlantId(int id) {
            try {
                return Repo.BestaatKlantId(id);
            } catch (Exception ex) {
                throw new KlantManagerException("BestaatKlantId", ex);
            }
        }

        public void VerwijderKlant (int id) {
            try {
                if (!Repo.BestaatKlantId(id)) {
                    throw new KlantManagerException("VerwijderKlant - Klant Bestaat nog niet");
                }
                Repo.VerwijderKlant(id);
            } catch (Exception ex) {
                throw new KlantManagerException("VerwijderKlant", ex);
            }
        }
        #endregion
    }
}
