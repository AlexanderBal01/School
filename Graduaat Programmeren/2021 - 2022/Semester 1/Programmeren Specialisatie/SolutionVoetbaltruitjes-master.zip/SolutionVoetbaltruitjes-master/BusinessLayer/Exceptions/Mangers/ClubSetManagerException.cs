﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.Exceptions.Mangers {
    public class ClubSetManagerException : Exception {
        #region Ctor
        public ClubSetManagerException(string message) : base(message) {
        }

        public ClubSetManagerException(string message, Exception innerException) : base(message, innerException) {
        }
        #endregion
    }
}
