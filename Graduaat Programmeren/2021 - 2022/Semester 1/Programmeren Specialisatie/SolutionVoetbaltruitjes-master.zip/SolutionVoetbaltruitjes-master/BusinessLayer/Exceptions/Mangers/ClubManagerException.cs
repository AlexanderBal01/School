﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.Exceptions.Mangers {
    public class ClubManagerException : Exception {
        #region Ctor
        public ClubManagerException(string message) : base(message) {
        }

        public ClubManagerException(string message, Exception innerException) : base(message, innerException) {
        }
        #endregion
    }
}
