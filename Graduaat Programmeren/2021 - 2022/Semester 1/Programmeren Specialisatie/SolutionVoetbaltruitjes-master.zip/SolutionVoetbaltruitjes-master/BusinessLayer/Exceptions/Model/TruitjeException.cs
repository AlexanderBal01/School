﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.Exceptions.Model {
    public class TruitjeException : Exception {
        #region Ctor
        public TruitjeException(string message) : base(message) {
        }

        public TruitjeException(string message, Exception innerException) : base(message, innerException) {
        }
        #endregion
    }
}
