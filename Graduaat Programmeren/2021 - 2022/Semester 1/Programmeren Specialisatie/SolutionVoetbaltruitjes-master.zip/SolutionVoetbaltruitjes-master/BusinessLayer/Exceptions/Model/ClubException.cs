﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.Exceptions.Model {
    public class ClubException : Exception {
        #region Ctor
        public ClubException(string message) : base(message) {
        }

        public ClubException(string message, Exception innerException) : base(message, innerException) {
        }
        #endregion
    }
}
