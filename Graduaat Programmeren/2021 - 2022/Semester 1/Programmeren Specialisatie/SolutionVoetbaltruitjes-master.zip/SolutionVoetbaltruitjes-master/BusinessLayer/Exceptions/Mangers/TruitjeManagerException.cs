﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.Exceptions.Mangers {
    public class TruitjeManagerException : Exception {
        #region Ctor
        public TruitjeManagerException(string message) : base(message) {
        }

        public TruitjeManagerException(string message, Exception innerException) : base(message, innerException) {
        }
        #endregion
    }
}
