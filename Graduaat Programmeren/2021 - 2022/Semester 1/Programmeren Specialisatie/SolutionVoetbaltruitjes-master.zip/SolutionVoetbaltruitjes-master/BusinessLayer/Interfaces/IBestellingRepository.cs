﻿using BusinessLayer.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.Interfaces {
    public interface IBestellingRepository {
        bool BestaatBestellingId(int id);

        List<Bestelling> GeefBestellingen(string tekst);

        Bestelling MaakBestellingAan(Bestelling bestelling);
        void UpdateBestelling(Bestelling bestelling);
        void VerwijderBestelling(int id);
    }
}
