﻿using BusinessLayer.Enums;
using BusinessLayer.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.Interfaces {
    public interface ITruitjeRepository {
        List<Truitje> GeefTruitjes(string tekst);

        bool BestaatTruitjeId(int id);

        Truitje MaakTruitjeAan(Truitje truitje);
        void UpdateTruitje(Truitje truitje);
        void VerwijderTruitje(int id);
    }
}
