﻿using BusinessLayer.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.Interfaces {
    public interface IKlantRepository {
        List<Klant> GeefKlanten(string tekst);

        bool BestaatKlantId(int id);

        Klant MaakKlantAan(Klant klant);
        void UpdateKlant(Klant klant);
        void VerwijderKlant(int id);
    }
}
