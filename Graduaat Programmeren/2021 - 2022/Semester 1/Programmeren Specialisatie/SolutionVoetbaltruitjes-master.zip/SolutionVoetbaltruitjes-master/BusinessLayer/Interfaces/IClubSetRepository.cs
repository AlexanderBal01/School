﻿using BusinessLayer.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.Interfaces {
    public interface IClubSetRepository {
        List<ClubSet> GeefClubSets(string tekst);

        bool BestaatClubSetId(int id);

        ClubSet MaakClubSetAan(ClubSet clubSet);
        void UpdateClubSet(ClubSet clubSet);
        void VerwijderClubSet(int id);
    }
}
