﻿using BusinessLayer.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.Interfaces {
    public interface IClubRepository {
        List<Club> GeefClubs(string tekst);

        bool BestaatClubId(int id);
        
        Club MaakClubAan(Club club);
        void UpdateClub(Club club);
        void VerwijderClub(int id);
    }
}
