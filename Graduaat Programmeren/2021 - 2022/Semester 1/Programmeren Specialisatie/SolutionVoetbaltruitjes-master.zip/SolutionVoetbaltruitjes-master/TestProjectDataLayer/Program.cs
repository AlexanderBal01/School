﻿using BusinessLayer.Enums;
using BusinessLayer.Managers;
using BusinessLayer.Model;
using DataLayerADO.Repositories;
using System;
using System.Configuration;

namespace TestProjectDataLayer {
    internal class Program {
        static void Main(string[] args) {
            string connectionString = ConfigurationManager.ConnectionStrings["connectionString"].ConnectionString;

            #region Club
            ClubRepository CR = new ClubRepository(connectionString);
            ClubManager CM = new ClubManager(CR);
            Club c = new Club("Real Madrid CF", "LaLiga");

            //CM.MaakClubAan(c);
            //CM.UpdateClub(new Club(1, "FC Barcelona", "LaLiga"));
            //Console.WriteLine(CM.GeefClubOpId(1));
            //CM.VerwijderClub(1);
            //Console.WriteLine(CM.BestaatClubCompetitie("LaLiga"));
            //Console.WriteLine(CM.BestaatClubId(2));
            //Console.WriteLine(CM.BestaatClubPloegnaam("Real Madrid CF"));
            //Console.WriteLine(CM.GeefClubOpPloegnaam("Real Madrid CF"));
            //foreach (var item in CM.GeefClubsOpCompetitie("LaLiga")) {
            //    Console.WriteLine(item);
            //}
            #endregion

            #region ClubSet
            ClubSetRepository CSR = new ClubSetRepository(connectionString);
            ClubSetManager CSM = new ClubSetManager(CSR);
            ClubSet cs = new ClubSet(true, 1);

            //CSM.MaakClubSetAan(cs);
            //Console.WriteLine(CSM.BestaatVersieTruitje(1));
            //Console.WriteLine(CSM.BestaatClubSetId(1));
            //Console.WriteLine(CSM.GeefClubSetOpId(1));
            //CSM.UpdateClubSet(new ClubSet(1, false, 2));
            //CSM.VerwijderClubSet(1);
            #endregion

            #region Klant
            KlantRepository KR = new KlantRepository(connectionString);
            KlantManager KM = new KlantManager(KR);
            Klant k = new Klant("Sébastiaan Bal", "Martelarenlaan 38, 9200 Dendermonde");

            //KM.MaakKlantAan(k);
            //Console.WriteLine(KM.BestaatKlantId(1));
            //Console.WriteLine(KM.BestaatKlantAdres("Martelarenlaan 38, 9200 Dendermonde"));
            //Console.WriteLine(KM.BestaatKlantNaam("Alexander Bal"));
            //foreach (var item in KM.GeefAlleKlanten()) {
            //    Console.WriteLine(item);
            //}
            //foreach (var item in KM.GeefKlantOpAdres("Martelarenlaan 38, 9200 Dendermonde")) {
            //    Console.WriteLine(item);
            //}
            //Console.WriteLine(KM.GeefKlantOpId(1));
            //foreach (var item in KM.GeefKlantOpNaam("Alexander Bal")) {
            //    Console.WriteLine(item);
            //}
            //KM.UpdateKlant(new Klant(2, "Sébastiaan Bal", "Martelarenlaan 36, 9200 Dendermonde"));
            //KM.VerwijderKlant(2);
            #endregion

            #region Truitje
            TruitjeRepository TR = new TruitjeRepository(connectionString);
            TruitjeManager TM = new TruitjeManager(TR);
            Club cT = new Club(2, "Real Madrid CF", "LaLiga");
            ClubSet csT = new ClubSet(2, true, 1);
            Truitje t = new Truitje(Maat.M, "2021-2022", 9.95, cT, csT);

            //TM.MaakTruitjeAan(t);
            //Console.WriteLine(TM.GeefTruitjeOpId(1));
            //TM.UpdateTruitje(new Truitje(1, Maat.M, "2022-2023", 10.10, cT, csT));
            //TM.VerwijderTruitje(1);
            //foreach (var item in TM.GeefTruitjesOpSeizoen("2021-2022")) {
            //    Console.WriteLine(item);
            //}
            //foreach (var item in TM.GeefTruitjesOpMaat(Maat.M)) {
            //    Console.WriteLine(item);
            //}
            //foreach (var item in TM.GeefAlleTruitjes()) {
            //    Console.WriteLine(item);
            //}
            //foreach (var item in TM.GeefTruitjesPrijs(9.95)) {
            //    Console.WriteLine(item);
            //}
            //foreach (var item in TM.GeefTruitjesClubId(2)) {
            //    Console.WriteLine(item);
            //}

            //foreach (var item in CM.GeefTruitjesOpCompetitie("LaLiga")) {
            //    Console.WriteLine(item);
            //}
            //foreach (var item in CM.GeefTruitjesOpPloegnaam("Real Madrid CF")) {
            //    Console.WriteLine(item);
            //}

            //foreach (var item in CSM.GeefTruitjesOpIsThuis(true)) {
            //    Console.WriteLine(item);
            //}
            //foreach (var item in CSM.GeefTruitjesOpVersie(1)) {
            //    Console.WriteLine(item);
            //}
            #endregion

            #region Bestelling
            BestellingRepository BR = new BestellingRepository(connectionString);
            BestellingManager BM = new BestellingManager(BR);
            Klant kB = KM.GeefKlantOpId(1);
            Truitje tB = TM.GeefTruitjeOpId(2);
            Bestelling b = new Bestelling(kB, new DateTime(2021, 12, 26), tB, 4, true);

            //BM.MaakBestellingAan(b);
            //BM.VerwijderBestelling(14);
            //Console.WriteLine(BM.BestaatBestellingId(15));
            //Console.WriteLine(BM.BestaatKlant(1));
            //Console.WriteLine(BM.GeefBestellingOpId(15));
            //Bestelling bUpdate = BM.GeefBestellingOpId(15);
            //bUpdate.ZetKlant(KM.GeefKlantOpId(3));
            //BM.UpdateBestelling(bUpdate);
            //foreach (var item in BM.GeefAlleBestellingen()) {
            //    Console.WriteLine(item);
            //}
            //foreach (var item in BM.GeefBestellingenDatum(new DateTime(2021,12,26))) {
            //    Console.WriteLine(item);
            //}
            //foreach (var item in BM.GeefBestellingenKlant(KM.GeefKlantOpId(3))) {
            //    Console.WriteLine(item);
            //}
            #endregion
        }
    }
}
