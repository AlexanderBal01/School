﻿using BusinessLayer.Managers;
using BusinessLayer.Model;
using DataLayerADO.Repositories;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using User_Interface.Aanpassen;

namespace User_Interface.Beheren {
    /// <summary>
    /// Interaction logic for BeherenMainWindow.xaml
    /// </summary>
    public partial class BeherenMainWindow : Window {
        public BeherenMainWindow() {
            InitializeComponent();

            ZoekenTXT.GotFocus += RemoveText;
            ZoekenTXT.LostFocus += AddText;
        }

        ClubManager CM = new ClubManager(new ClubRepository(ConfigurationManager.ConnectionStrings["connectionString"].ToString()));
        ClubSetManager CSM = new ClubSetManager(new ClubSetRepository(ConfigurationManager.ConnectionStrings["connectionString"].ToString()));
        KlantManager KM = new KlantManager(new KlantRepository(ConfigurationManager.ConnectionStrings["connectionString"].ToString()));
        TruitjeManager TM = new TruitjeManager(new TruitjeRepository(ConfigurationManager.ConnectionStrings["connectionString"].ToString()));
        BestellingManager BM = new BestellingManager(new BestellingRepository(ConfigurationManager.ConnectionStrings["connectionString"].ToString()));

        private string VorigeText = "";

        private List<Club> GevondenClubs = null;
        private List<ClubSet> GevondenClubSets = null;
        private List<Klant> GevondenKlanten = null;
        private List<Truitje> GevondenTruitjes = null;
        private List<Bestelling> GevondenBestellingen = null;

        private void RemoveText(object sender, EventArgs e) {
            var txtbox = (TextBox)sender;
            if (ZoekenTXT.Text == "Zoek club op id, clubnaam of competitie") {
                VorigeText = ZoekenTXT.Text;
                txtbox.Text = "";
            } else if (ZoekenTXT.Text == "Zoek clubset op id, versie of Isthuis") {
                VorigeText = ZoekenTXT.Text;
                txtbox.Text = "";
            } else if (ZoekenTXT.Text == "Zoek klant op id, naam of adres") {
                VorigeText = ZoekenTXT.Text;
                txtbox.Text = "";
            } else if (ZoekenTXT.Text == "Zoek truitje op id, maat, seizoen, prijs, clubnaam of competitie") {
                VorigeText = ZoekenTXT.Text;
                txtbox.Text = "";
            } else if (ZoekenTXT.Text == "Zoek bestelling op id, klant naam of adres") {
                VorigeText = ZoekenTXT.Text;
                txtbox.Text = "";
            }
        }

        private void AddText(object sender, EventArgs e) {
            var txtbox = (TextBox)sender;
            if (string.IsNullOrWhiteSpace(ZoekenTXT.Text)) {
                txtbox.Text = VorigeText;
            }
        }

        private void BtnTerug_Click(object sender, RoutedEventArgs e) {
            MessageBoxResult messageBoxResult = MessageBox.Show("Ben je zeker?", "Confirmation", MessageBoxButton.YesNo);
            if (messageBoxResult == MessageBoxResult.Yes) {
                MainWindow mainWindow = new MainWindow();
                mainWindow.Show();
                this.Close();
            }
        }

        private void BtnAanpassen_Click(object sender, RoutedEventArgs e) {
            try {
                if (ListBoxZoekenResult.SelectedItem != null) {
                    var selectedValue = ListBoxZoekenResult.SelectedItem;
                    string zoekType = comboBoxTypeZoeken.SelectedValue.ToString();
                    if (zoekType.Contains("Klant")) {
                        try {
                            Klant klant = (Klant)selectedValue;
                            KlantAanpassenWindow klantAanpassen = new KlantAanpassenWindow("klant", klant);
                            if (klantAanpassen.ShowDialog() == true) {
                                if (klantAanpassen.IsClosed == true) {
                                    KM.UpdateKlant(klantAanpassen.AanTePassenKlant);
                                }
                            }
                            if (klantAanpassen.IsVisible == false) {
                                ListBoxZoekenResult.Items.Clear();
                                ListBoxZoekenResult.Items.Add("-- Geen Resultaten Gevonden --");
                                ListBoxZoekenResult.IsEnabled = false;
                            }
                        } catch (Exception ex) {
                            MessageBox.Show("Klant Updaten Mislukt : \n" + ex.Message, "Fout", MessageBoxButton.OK, MessageBoxImage.Warning);
                        }
                    } else if (zoekType.Contains("Bestelling")) {
                        try {
                            Bestelling bestelling = (Bestelling)selectedValue;
                            BestellingAanpassenWindow bestellingAanpassen = new BestellingAanpassenWindow("bestelling", bestelling);
                            if (bestellingAanpassen.ShowDialog() == true) {
                                if (bestellingAanpassen.IsClosed == true) {
                                    BM.UpdateBestelling(bestellingAanpassen.AanTePassenBestelling);
                                }
                            }
                            if (bestellingAanpassen.IsVisible == false) {
                                ListBoxZoekenResult.Items.Clear();
                                ListBoxZoekenResult.Items.Add("-- Geen Resultaten Gevonden --");
                                ListBoxZoekenResult.IsEnabled = false;
                            }
                        } catch (Exception ex) {
                            MessageBox.Show("Bestelling Updaten Mislukt : \n" + ex.Message, "Fout", MessageBoxButton.OK, MessageBoxImage.Warning);
                        }
                    } else if (zoekType.Contains("Truitje")) {
                        try {
                            Truitje truitje = (Truitje)selectedValue;
                            TruitjeAanpassenWindow truitjeAanpassen = new TruitjeAanpassenWindow("truitje", truitje);
                            if (truitjeAanpassen.ShowDialog() == true) {
                                if (truitjeAanpassen.IsClosed == true) {
                                    TM.UpdateTruitje(truitjeAanpassen.AanTePassenTruitje);
                                }
                                if (truitjeAanpassen.IsVisible == false) {
                                    ListBoxZoekenResult.Items.Clear();
                                    ListBoxZoekenResult.Items.Add("-- Geen Resultaten Gevonden --");
                                    ListBoxZoekenResult.IsEnabled = false;
                                }
                            }
                        } catch (Exception ex) {
                            MessageBox.Show("Truitje Updaten Mislukt : \n" + ex.Message, "Fout", MessageBoxButton.OK, MessageBoxImage.Warning);
                        }
                    } else if (zoekType.Contains("Club")) {
                        try {
                            Club club = (Club)selectedValue;
                            ClubAanpassenWindow clubAanpassen = new ClubAanpassenWindow("club", club);
                            if (clubAanpassen.ShowDialog() == true) {
                                if (clubAanpassen.IsClosed == true) {
                                    CM.UpdateClub(clubAanpassen.AanTePassenClub);
                                }
                            }
                            if (clubAanpassen.IsVisible == false) {
                                ListBoxZoekenResult.Items.Clear();
                                ListBoxZoekenResult.Items.Add("-- Geen Resultaten Gevonden --");
                                ListBoxZoekenResult.IsEnabled = false;
                            }
                        } catch (Exception ex) {
                            MessageBox.Show("Club Updaten Mislukt : \n" + ex.Message, "Fout", MessageBoxButton.OK, MessageBoxImage.Warning);
                        }
                    } else if (zoekType.Contains("ClubSet")) {
                        try {
                            ClubSet clubSet = (ClubSet)selectedValue;
                            ClubSetAanpassenWindow clubSetAanpassen = new ClubSetAanpassenWindow("clubset", clubSet);
                            if (clubSetAanpassen.ShowDialog() == true) {
                                if (clubSetAanpassen.IsClosed == true) {
                                    CSM.UpdateClubSet(clubSet);
                                }
                            }
                            if (clubSetAanpassen.IsVisible == false) {
                                ListBoxZoekenResult.Items.Clear();
                                ListBoxZoekenResult.Items.Add("-- Geen Resultaten Gevonden --");
                                ListBoxZoekenResult.IsEnabled = false;
                            }
                        } catch (Exception ex) {
                            MessageBox.Show("ClubSet Updaten Mislukt : \n" + ex.Message, "Fout", MessageBoxButton.OK, MessageBoxImage.Warning);
                        }
                    }
                } else {
                    throw new Exception("Niets Geselecteerd");
                }
            } catch (Exception ex) {
                MessageBox.Show(ex.Message, "Fout", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void BtnVerwijderen_Click(object sender, RoutedEventArgs e) {
            try {
                if (ListBoxZoekenResult.SelectedItem != null) {
                    var selectedValue = ListBoxZoekenResult.SelectedItem;
                    if (comboBoxTypeZoeken.SelectedItem.ToString().Contains("Klant")) {
                        try {
                            Klant klant = (Klant)selectedValue;
                            MessageBoxResult messageBoxResult = MessageBox.Show("Ben je zeker?", "Confirmation", MessageBoxButton.YesNo);
                            if (messageBoxResult == MessageBoxResult.Yes) {
                                KM.VerwijderKlant(klant.Id);
                            }
                        } catch (Exception ex) {
                            MessageBox.Show("Klant Verwijderen Mislukt \n" + ex.Message, "Fout", MessageBoxButton.OK, MessageBoxImage.Warning);
                        }
                    } else if (comboBoxTypeZoeken.SelectedItem.ToString().Contains("Bestelling")) {
                        try {
                            Bestelling bestelling = (Bestelling)selectedValue;
                            MessageBoxResult messageBoxResult = MessageBox.Show("Ben je zeker?", "Confirmation", MessageBoxButton.YesNo);
                            if (messageBoxResult == MessageBoxResult.Yes) {
                                BM.VerwijderBestelling(bestelling.Id);
                            }
                        } catch (Exception ex) {
                            MessageBox.Show("Bestelling Verwijderen Mislukt \n" + ex.Message, "Fout", MessageBoxButton.OK, MessageBoxImage.Warning);
                        }
                    } else if (comboBoxTypeZoeken.SelectedItem.ToString().Contains("Truitje")) {
                        try {
                            Truitje truitje = (Truitje)selectedValue;
                            MessageBoxResult messageBoxResult = MessageBox.Show("Ben je zeker?", "Confirmation", MessageBoxButton.YesNo);
                            if (messageBoxResult == MessageBoxResult.Yes) {
                                TM.VerwijderTruitje(truitje.Id);
                            }
                        } catch (Exception ex) {
                            MessageBox.Show("Truitje Verwijderen Mislukt \n" + ex.Message, "Fout", MessageBoxButton.OK, MessageBoxImage.Warning);
                        }
                    } else if (comboBoxTypeZoeken.SelectedItem.ToString().Contains("Club")) {
                        try {
                            Club club = (Club)selectedValue;
                            MessageBoxResult messageBoxResult = MessageBox.Show("Ben je zeker?", "Confirmation", MessageBoxButton.YesNo);
                            if (messageBoxResult == MessageBoxResult.Yes) {
                                CM.VerwijderClub(club.Id);
                            }
                        } catch (Exception ex) {
                            MessageBox.Show("Club Verwijderen Mislukt \n" + ex.Message, "Fout", MessageBoxButton.OK, MessageBoxImage.Warning);
                        }
                    } else if (comboBoxTypeZoeken.SelectedItem.ToString().Contains("ClubSet")) {
                        try {
                            ClubSet clubSet = (ClubSet)selectedValue;
                            MessageBoxResult messageBoxResult = MessageBox.Show("Ben je zeker?", "Confirmation", MessageBoxButton.YesNo);
                            if (messageBoxResult == MessageBoxResult.Yes) {
                                CSM.VerwijderClubSet(clubSet.Id);
                            }
                        } catch (Exception ex) {
                            MessageBox.Show("ClubSet Verwijderen Mislukt \n" + ex.Message, "Fout", MessageBoxButton.OK, MessageBoxImage.Warning);
                        }
                    }
                }
            } catch (Exception ex) {
                MessageBox.Show(ex.Message, "Fout", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void BtnZoeken_Click(object sender, RoutedEventArgs e) {
            try {
                ListBoxZoekenResult.IsEnabled = true;
                ListBoxZoekenResult.Items.Clear();

                if (comboBoxTypeZoeken.Text == "Klant") {
                    string tekst = ZoekenTXT.Text;
                    List<Klant> klanten = KM.GeefKlanten(tekst);
                    foreach (var k in klanten) {
                        ListBoxZoekenResult.Items.Add(k);
                    }
                    GevondenKlanten = klanten;
                } else if (comboBoxTypeZoeken.Text == "Bestelling") {
                    string tekst = ZoekenTXT.Text;
                    List<Bestelling> bestellingen = BM.GeefBestellingen(tekst);
                    foreach (var b in bestellingen) {
                        ListBoxZoekenResult.Items.Add(b);
                    }
                    GevondenBestellingen = bestellingen;
                } else if (comboBoxTypeZoeken.Text == "Truitje") {
                    string tekst = ZoekenTXT.Text;
                    List<Truitje> truitjes = TM.GeefTruitjes(tekst);
                    foreach (var t in truitjes) {
                        ListBoxZoekenResult.Items.Add(t);
                    }
                    GevondenTruitjes = truitjes;
                } else if (comboBoxTypeZoeken.Text == "Club") {
                    string tekst = ZoekenTXT.Text;
                    List<Club> clubs = CM.GeefClubs(tekst);
                    foreach (var c in clubs) {
                        ListBoxZoekenResult.Items.Add(c);
                    }
                    GevondenClubs = clubs;
                } else if (comboBoxTypeZoeken.Text == "ClubSet") {
                    string tekst = ZoekenTXT.Text;
                    List<ClubSet> clubSets = CSM.GeefClubSets(tekst);
                    foreach (var cs in clubSets) {
                        ListBoxZoekenResult.Items.Add(cs);
                    }
                    GevondenClubSets = clubSets;
                }

                if (ListBoxZoekenResult.Items.Count == 0) {
                    ListBoxZoekenResult.Items.Add("-- Geen Resultaten Gevonden --");
                    ListBoxZoekenResult.IsEnabled = false;
                }
            } catch (Exception ex) {
                MessageBox.Show(ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void comboBoxTypeZoeken_SelectionChanged(object sender, SelectionChangedEventArgs e) {
            if (comboBoxTypeZoeken.SelectedItem.ToString().Contains("Klant")) {
                ZoekenTXT.Text = "Zoek klant op id, naam of adres";
            } else if (comboBoxTypeZoeken.SelectedItem.ToString().Contains("Bestelling")) {
                ZoekenTXT.Text = "Zoek bestelling op id, klant naam of adres";
            } else if (comboBoxTypeZoeken.SelectedItem.ToString().Contains("Truitje")) {
                ZoekenTXT.Text = "Zoek truitje op id, maat, seizoen, prijs, clubnaam of competitie";
            } else if (comboBoxTypeZoeken.SelectedItem.ToString().Contains("Club")) {
                ZoekenTXT.Text = "Zoek club op id, clubnaam of competitie";
            } else if (comboBoxTypeZoeken.SelectedItem.ToString().Contains("ClubSet")) {
                ZoekenTXT.Text = "Zoek clubset op id, versie of isthuis";
            }
        }
    }
}
