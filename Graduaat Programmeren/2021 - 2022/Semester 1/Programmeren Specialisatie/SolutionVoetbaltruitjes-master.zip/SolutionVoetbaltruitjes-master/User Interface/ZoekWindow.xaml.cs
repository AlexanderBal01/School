﻿using BusinessLayer.Managers;
using BusinessLayer.Model;
using DataLayerADO.Repositories;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace User_Interface {
    /// <summary>
    /// Interaction logic for ZoekWindow.xaml
    /// </summary>
    public partial class ZoekWindow : Window {
        public ZoekWindow(string zoekOnderwerp) {
            InitializeComponent();

            if (zoekOnderwerp.ToLower() == "club") {
                LblTitel.Content = "Voetbaltruitjes - Club Selecteren";
                ZoekenTXT.Text = "Zoek club op id, clubnaam of competitie";
                ZoekOnderwerp = zoekOnderwerp;
            } else if (zoekOnderwerp.ToLower() == "clubset") {
                LblTitel.Content = "Voetbaltruitjes - ClubSet Selecteren";
                ZoekenTXT.Text = "Zoek clubset op id, versie of isthuis";
                ZoekOnderwerp = zoekOnderwerp;
            } else if (zoekOnderwerp.ToLower() == "klant") {
                LblTitel.Content = "Voetbaltruitjes - Klant Selecteren";
                ZoekenTXT.Text = "Zoek klant op id, naam of adres";
                ZoekOnderwerp = zoekOnderwerp;
            } else if (zoekOnderwerp.ToLower() == "truitje") {
                LblTitel.Content = "Voetbaltruitjes - Truitje Selecteren";
                ZoekenTXT.Text = "Zoek truitje op id, maat, seizoen, prijs, clubnaam of competitie";
                ZoekOnderwerp = zoekOnderwerp;
            }

            ZoekenTXT.GotFocus += RemoveText;
            ZoekenTXT.LostFocus += AddText;
        }

        ClubManager CM = new ClubManager(new ClubRepository(ConfigurationManager.ConnectionStrings["connectionString"].ToString()));
        ClubSetManager CSM = new ClubSetManager(new ClubSetRepository(ConfigurationManager.ConnectionStrings["connectionString"].ToString()));
        KlantManager KM = new KlantManager(new KlantRepository(ConfigurationManager.ConnectionStrings["connectionString"].ToString()));
        TruitjeManager TM = new TruitjeManager(new TruitjeRepository(ConfigurationManager.ConnectionStrings["connectionString"].ToString()));

        string ZoekOnderwerp = "";
        string VorigeText = "";

        public Club club = null;
        public ClubSet clubSet = null;
        public Klant klant = null;
        public Truitje truitje = null;

        private List<Club> GevondenClubs = null;
        private List<ClubSet> GevondenClubSets = null;
        private List<Klant> GevondenKlanten = null;
        private List<Truitje> GevondenTruitjes = null;

        public void Search() {
            ListBoxZoekenResult.IsEnabled = true;
            ListBoxZoekenResult.Items.Clear();

            try {
                if (ZoekOnderwerp.ToLower() == "club") {
                    string tekst = ZoekenTXT.Text;
                    GevondenClubs = CM.GeefClubs(tekst);
                    foreach (var c in GevondenClubs) {
                        ListBoxZoekenResult.Items.Add(c);
                    }
                } else if (ZoekOnderwerp.ToLower() == "clubset") {
                    string tekst = ZoekenTXT.Text;
                    GevondenClubSets = CSM.GeefClubSets(tekst);
                    foreach (var cs in GevondenClubSets) {
                        ListBoxZoekenResult.Items.Add(cs);
                    }
                } else if (ZoekOnderwerp.ToLower() == "klant") {
                    string tekst = ZoekenTXT.Text;
                    GevondenKlanten = KM.GeefKlanten(tekst);
                    foreach (var k in GevondenKlanten) {
                        ListBoxZoekenResult.Items.Add(k);
                    }
                } else if (ZoekOnderwerp.ToLower() == "truitje") {
                    string tekst = ZoekenTXT.Text;
                    GevondenTruitjes = TM.GeefTruitjes(tekst);
                    foreach (var t in GevondenTruitjes) {
                        ListBoxZoekenResult.Items.Add(t);
                    }
                }

                if (ListBoxZoekenResult.Items.Count == 0) {
                    ListBoxZoekenResult.Items.Add("-- Geen Resultaten Gevonden --");
                    ListBoxZoekenResult.IsEnabled = false;
                }
            } catch (Exception ex) {
                ListBoxZoekenResult.Items.Add(ex);
            }
        }

        private void BtnAnnuleer_Click(object sender, RoutedEventArgs e) {
            MessageBoxResult messageBoxResult = MessageBox.Show("Ben je zeker?", "Confirmation", MessageBoxButton.YesNo);
            if (messageBoxResult == MessageBoxResult.Yes) {
                Close();
            }
        }

        private void BtnZoeken_Click(object sender, RoutedEventArgs e) {
            Search();
        }

        private void BtnSelecteer_Click(object sender, RoutedEventArgs e) {
            if (ListBoxZoekenResult.SelectedItem == null) {
                MessageBoxResult messageBoxResult = MessageBox.Show("Niets geselecteerd", "Confirmation", MessageBoxButton.OK);
            } else if (ZoekOnderwerp.ToLower() == "club") {
                try {
                    var tussenItem = ListBoxZoekenResult.SelectedIndex;
                    var tussenClub = GevondenClubs[tussenItem];
                    club = tussenClub;
                } catch (Exception) {
                    throw;
                }
                DialogResult = true;
                Close();
            } else if (ZoekOnderwerp.ToLower() == "clubset") {
                try {
                    var tussenItem = ListBoxZoekenResult.SelectedIndex;
                    var tussenClubSet = GevondenClubSets[tussenItem];
                    clubSet = tussenClubSet;
                } catch (Exception) {
                    throw;
                }
                DialogResult = true;
                Close();
            } else if (ZoekOnderwerp.ToLower() == "klant") {
                try {
                    var tussenItem = ListBoxZoekenResult.SelectedIndex;
                    var tussenKlant = GevondenKlanten[tussenItem];
                    klant = tussenKlant;
                } catch (Exception) {
                    throw;
                }
                DialogResult = true;
                Close();
            } else if (ZoekOnderwerp.ToLower() == "truitje") {
                try {
                    var tussenItem = ListBoxZoekenResult.SelectedIndex;
                    var tussenTruitje = GevondenTruitjes[tussenItem];
                    truitje = tussenTruitje;
                } catch (Exception) {
                    throw;
                }
                DialogResult = true;
                Close();
            }
        }

        private void RemoveText(object sender, EventArgs e) {
            var txtbox = (TextBox)sender;
            if (ZoekenTXT.Text == "Zoek club op id, clubnaam of competitie") {
                VorigeText = ZoekenTXT.Text;
                txtbox.Text = "";
            } else if (ZoekenTXT.Text == "Zoek clubset op id, versie of Isthuis") {
                VorigeText = ZoekenTXT.Text;
                txtbox.Text = "";
            } else if (ZoekenTXT.Text == "Zoek klant op id, naam of adres") {
                VorigeText = ZoekenTXT.Text;
                txtbox.Text = "";
            } else if (ZoekenTXT.Text == "Zoek truitje op id, maat, seizoen, prijs, clubid, clubsetid, clubnaam of competitie") {
                VorigeText = ZoekenTXT.Text;
                txtbox.Text = "";
            }
        }

        private void AddText(object sender, EventArgs e) {
            var txtbox = (TextBox)sender;
            if (string.IsNullOrWhiteSpace(ZoekenTXT.Text)) {
                txtbox.Text = VorigeText;
            }
        }
    }
}
