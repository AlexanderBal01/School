﻿using BusinessLayer.Managers;
using BusinessLayer.Model;
using DataLayerADO.Repositories;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace User_Interface.Aanpassen {
    /// <summary>
    /// Interaction logic for ClubAanpassenWindow.xaml
    /// </summary>
    public partial class ClubAanpassenWindow : Window {
        public ClubAanpassenWindow(string aanTePassen, Club club) {
            InitializeComponent();

            AanTePassenClub = club;
            AanTePassen = aanTePassen;

            SetValues(club);
        }

        ClubManager CM = new ClubManager(new ClubRepository(ConfigurationManager.ConnectionStrings["connectionString"].ToString()));

        public Club AanTePassenClub { get; set; }
        private string AanTePassen { get; set; }
        string VorigeTekst = "";
        public bool IsClosed = false;

        private void SetValues(Club club) {
            lblClubId.Content += club.Id.ToString();
            PloegNaamTXT.Text = club.Ploegnaam;
            CompetitieTXT.Text = club.Competitie;
        }

        private void AddTekst(object sender, EventArgs e) {
            var txtbox = (TextBox)sender;
            if (string.IsNullOrWhiteSpace(txtbox.Text))
                txtbox.Text = VorigeTekst;
        }

        private void RemoveTekst(object sender, RoutedEventArgs e) {
            var txtbox = (TextBox)sender;
            if (!string.IsNullOrWhiteSpace(txtbox.Text)) {
                VorigeTekst = txtbox.Text;
                txtbox.Text = "";
            }
        }

        private void BtnTerug_Click(object sender, RoutedEventArgs e) {
            MessageBoxResult messageBoxResult = MessageBox.Show("Ben je zeker?", "Confirmation", MessageBoxButton.YesNo);
            if (messageBoxResult == MessageBoxResult.Yes) {
                Close();
            }
        }

        private void BtnAanpassen_Click(object sender, RoutedEventArgs e) {
            try {
                if (!IsClosed) {
                    AanTePassenClub = new Club(int.Parse(lblClubId.Content.ToString().Remove(0, 8)), PloegNaamTXT.Text, CompetitieTXT.Text);
                    IsClosed = true;
                }

                if (IsClosed) {
                    bool isGelukt = CM.UpdateClub(AanTePassenClub);
                    if (isGelukt) {
                        MessageBoxResult messageBoxResult = MessageBox.Show("Klant Geüpdatet", "Klant Update", MessageBoxButton.OK, MessageBoxImage.Information);
                        if (messageBoxResult == MessageBoxResult.OK) {
                            Close();
                        }
                    }
                }
            } catch (Exception ex) {
                MessageBox.Show(ex.Message, "Club updaten mislukt", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }
    }
}
