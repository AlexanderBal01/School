﻿using BusinessLayer.Managers;
using BusinessLayer.Model;
using DataLayerADO.Repositories;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace User_Interface.Aanpassen {
    /// <summary>
    /// Interaction logic for ClubSetAanpassen.xaml
    /// </summary>
    public partial class ClubSetAanpassenWindow : Window {
        public ClubSetAanpassenWindow(string aanTePassen, ClubSet clubSet) {
            InitializeComponent();

            AanTePassenClubSet = clubSet;
            AanTePassen = aanTePassen;

            SetValues(clubSet);
        }

        ClubSetManager CSM = new ClubSetManager(new ClubSetRepository(ConfigurationManager.ConnectionStrings["connectionString"].ToString()));

        public ClubSet AanTePassenClubSet { get; set; }
        private string AanTePassen { get; set; }
        string VorigeTekst = "";
        public bool IsClosed = false;

        private void AddTekst(object sender, EventArgs e) {
            var txtbox = (TextBox)sender;
            if (string.IsNullOrWhiteSpace(txtbox.Text))
                txtbox.Text = VorigeTekst;
        }

        private void RemoveTekst(object sender, RoutedEventArgs e) {
            var txtbox = (TextBox)sender;
            if (!string.IsNullOrWhiteSpace(txtbox.Text)) {
                VorigeTekst = txtbox.Text;
                txtbox.Text = "";
            }
        }

        private void SetValues(ClubSet clubSet) {
            lblClubSetId.Content += clubSet.Id.ToString();
            VersieTXT.Text = clubSet.Versie.ToString();
            if (clubSet.IsThuis == true) {
                RadioBtnJa.IsChecked = true;
            }
            if (clubSet.IsThuis == false) {
                RadioBtnNee.IsChecked = true;
            }
        }

        private void BtnTerug_Click(object sender, RoutedEventArgs e) {
            MessageBoxResult messageBoxResult = MessageBox.Show("Ben je zeker?", "Confirmation", MessageBoxButton.YesNo);
            if (messageBoxResult == MessageBoxResult.Yes) {
                Close();
            }
        }

        private void BtnAanpassen_Click(object sender, RoutedEventArgs e) {
            try {
                if (!IsClosed) {
                    if (RadioBtnJa.IsChecked == true) {
                        AanTePassenClubSet = new ClubSet(int.Parse(lblClubSetId.Content.ToString().Remove(0, 11)), true, int.Parse(VersieTXT.Text));
                    } else if (RadioBtnNee.IsChecked == true) {
                        AanTePassenClubSet = new ClubSet(int.Parse(lblClubSetId.Content.ToString().Remove(0, 11)), false, int.Parse(VersieTXT.Text));
                    }
                    IsClosed = true;
                }

                if (IsClosed) {
                    bool isGelukt = CSM.UpdateClubSet(AanTePassenClubSet);
                    if (isGelukt) {
                        MessageBoxResult messageBoxResult = MessageBox.Show("Klant Geüpdatet", "Klant Update", MessageBoxButton.OK, MessageBoxImage.Information);
                        if (messageBoxResult == MessageBoxResult.OK) {
                            Close();
                        }
                    }
                }
            } catch (Exception ex) {
                MessageBox.Show(ex.Message, "ClubSet updaten mislukt", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }
    }
}
