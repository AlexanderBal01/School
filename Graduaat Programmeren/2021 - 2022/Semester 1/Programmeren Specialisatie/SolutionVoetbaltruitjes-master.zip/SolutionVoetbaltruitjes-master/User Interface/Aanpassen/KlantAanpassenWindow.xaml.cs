﻿using BusinessLayer.Managers;
using BusinessLayer.Model;
using DataLayerADO.Repositories;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace User_Interface.Aanpassen {
    /// <summary>
    /// Interaction logic for KlantAanpassenWindow.xaml
    /// </summary>
    public partial class KlantAanpassenWindow : Window {
        public KlantAanpassenWindow(string aanTePassen, Klant klant) {
            InitializeComponent();
            AanTePassenKlant = klant;
            AanTePassen = aanTePassen;

            SetValues(klant);
        }

        KlantManager KM = new KlantManager(new KlantRepository(ConfigurationManager.ConnectionStrings["connectionString"].ToString()));

        private string AanTePassen { get; set; }
        public Klant AanTePassenKlant { get; set; }

        string VorigeTekst = "";
        public bool IsClosed = false;

        public void SetValues(Klant klant) {
            lblKlantId.Content += klant.Id.ToString();
            KlantNaamTXT.Text = klant.Naam;
            KlantAdresTXT.Text = klant.Adres;
        }

        private void AddTekst(object sender, EventArgs e) {
            var txtbox = (TextBox)sender;
            if (string.IsNullOrWhiteSpace(txtbox.Text))
                txtbox.Text = VorigeTekst;
        }

        private void RemoveTekst(object sender, RoutedEventArgs e) {
            var txtbox = (TextBox)sender;
            if (!string.IsNullOrWhiteSpace(txtbox.Text)) {
                VorigeTekst = txtbox.Text;
                txtbox.Text = "";
            }
        }

        private void BtnAanpassen_Click(object sender, RoutedEventArgs e) {
            try {
                if (!IsClosed) {
                    AanTePassenKlant = new Klant(int.Parse(lblKlantId.Content.ToString().Remove(0, 10)), KlantNaamTXT.Text, KlantAdresTXT.Text);
                    IsClosed = true;
                }

                if (IsClosed) {
                    bool isGelukt = KM.UpdateKlant(AanTePassenKlant);
                    if (isGelukt) {
                        MessageBoxResult messageBoxResult = MessageBox.Show("Klant Geüpdatet", "Klant Update", MessageBoxButton.OK, MessageBoxImage.Information);
                        if (messageBoxResult == MessageBoxResult.OK) {
                            Close();
                        }
                    }
                }
            } catch (Exception ex) {
                MessageBox.Show(ex.Message, "Klant updaten mislukt", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e) {
            MessageBoxResult messageBoxResult = MessageBox.Show("Ben je zeker?", "Confirmation", MessageBoxButton.YesNo);
            if (messageBoxResult == MessageBoxResult.Yes) {
                Close();
            }
        }
    }
}
