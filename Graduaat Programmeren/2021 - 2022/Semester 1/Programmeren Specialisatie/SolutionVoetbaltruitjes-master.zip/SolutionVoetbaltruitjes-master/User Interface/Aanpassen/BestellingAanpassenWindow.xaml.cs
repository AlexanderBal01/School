﻿using BusinessLayer.Managers;
using BusinessLayer.Model;
using DataLayerADO.Repositories;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace User_Interface.Aanpassen {
    /// <summary>
    /// Interaction logic for BestellingAanpassenWIndow.xaml
    /// </summary>
    public partial class BestellingAanpassenWindow : Window {
        public BestellingAanpassenWindow(string aanTePassen, Bestelling bestelling) {
            InitializeComponent();
            AanTePassenBestelling = bestelling;
            BestaandeKlant = bestelling.Klant;
            BestaandTruitje = bestelling.Producten.Keys.First();
            AanTePassen = aanTePassen;

            SetValues(bestelling);
        }

        BestellingManager BM = new BestellingManager(new BestellingRepository(ConfigurationManager.ConnectionStrings["connectionString"].ToString()));

        public Bestelling AanTePassenBestelling { get; set; }
        public Klant BestaandeKlant { get; set; }
        public Truitje BestaandTruitje { get; set; }
        private string AanTePassen { get; set; }
        string VorigeTekst = "";
        public bool IsClosed = false;

        public void SetValues(Bestelling bestelling) {
            lblBestellingId.Content += bestelling.Id.ToString();
            DatePicker.SelectedDate = bestelling.Datum;
            PrijsTXT.Text = bestelling.Prijs.ToString();
            if (bestelling.Betaald == true) {
                RadioBtnJa.IsChecked = true;
            }
            if (bestelling.Betaald == false) {
                RadioBtnNee.IsChecked = true;
            }
            LblBestaandeKlant.Content += bestelling.Klant.Naam;
            LblBestaandTruitje.Content += bestelling.Producten.Keys.First().Club.Ploegnaam;
            AantalTXT.Text = bestelling.Producten.Values.First().ToString();
        }

        private void BtnBestuurderBestaandeKlant_Click(object sender, RoutedEventArgs e) {
            ZoekWindow zoek = new ZoekWindow("klant");
            if (zoek.ShowDialog() == true) {
                BestaandeKlant = zoek.klant;
                LblBestaandeKlant.Content = $"Geselecteerde Klant: " + BestaandeKlant.Naam;
                AanTePassenBestelling.ZetKlant(BestaandeKlant);
            }
        }

        private void BtnBestuurderBestaandTruitje_Click(object sender, RoutedEventArgs e) {
            ZoekWindow zoek = new ZoekWindow("truitje");
            if (zoek.ShowDialog() == true) {
                BestaandTruitje = zoek.truitje;
                LblBestaandTruitje.Content = $"Geselecteerd Truitje: " + BestaandTruitje.Club.Ploegnaam;
                AanTePassenBestelling.Producten.Keys.First().ZetId(BestaandTruitje.Id);
                AanTePassenBestelling.Producten.Keys.First().ZetSeizoen(BestaandTruitje.Seizoen);
                AanTePassenBestelling.Producten.Keys.First().ZetClub(BestaandTruitje.Club);
                AanTePassenBestelling.Producten.Keys.First().ZetClubSet(BestaandTruitje.ClubSet);
                AanTePassenBestelling.Producten.Keys.First().ZetPrijs(BestaandTruitje.Prijs);
            }
        }

        private void BtnTerug_Click(object sender, RoutedEventArgs e) {
            MessageBoxResult messageBoxResult = MessageBox.Show("Ben je zeker?", "Confirmation", MessageBoxButton.YesNo);
            if (messageBoxResult == MessageBoxResult.Yes) {
                Close();
            }
        }

        private void BtnAanpassen_Click(object sender, RoutedEventArgs e) {
            try {
                if (!IsClosed) {
                    if (LblBestaandeKlant.Content.ToString() != "Geselecteerde Klant: " && LblBestaandTruitje.Content.ToString() != "Geselecteerd Truitje: ") {
                        if (RadioBtnJa.IsChecked == true) {
                            AanTePassenBestelling = new Bestelling(int.Parse(lblBestellingId.Content.ToString().Remove(0, 14)), BestaandeKlant, (DateTime)DatePicker.SelectedDate, double.Parse(PrijsTXT.Text), true, BestaandTruitje, int.Parse(AantalTXT.Text));
                        } else if (RadioBtnNee.IsChecked == true) {
                            AanTePassenBestelling = new Bestelling(int.Parse(lblBestellingId.Content.ToString().Remove(0, 14)), BestaandeKlant, (DateTime)DatePicker.SelectedDate, double.Parse(PrijsTXT.Text), false, BestaandTruitje, int.Parse(AantalTXT.Text));
                        }
                        IsClosed = true;
                    }

                    bool isGelukt = BM.UpdateBestelling(AanTePassenBestelling);
                    if (isGelukt) {
                        MessageBoxResult messageBoxResult = MessageBox.Show("Bestelling Geüpdatet", "Bestelling Update", MessageBoxButton.OK, MessageBoxImage.Information);
                        if (messageBoxResult == MessageBoxResult.OK) {
                            Close();
                        }
                    }
                } else {
                    MessageBox.Show("Bestelling Update gefaald", "Bestelling Update", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
                IsClosed = false;
            } catch (Exception ex) {
                MessageBox.Show(ex.Message, "Bestelling updaten mislukt", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void AddTekst(object sender, EventArgs e) {
            var txtbox = (TextBox)sender;
            if (string.IsNullOrWhiteSpace(txtbox.Text))
                txtbox.Text = VorigeTekst;
        }

        private void RemoveTekst(object sender, RoutedEventArgs e) {
            var txtbox = (TextBox)sender;
            if (!string.IsNullOrWhiteSpace(txtbox.Text)) {
                VorigeTekst = txtbox.Text;
                txtbox.Text = "";
            }
        }
    }
}
