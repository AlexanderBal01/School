﻿using BusinessLayer.Enums;
using BusinessLayer.Managers;
using BusinessLayer.Model;
using DataLayerADO.Repositories;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace User_Interface.Aanpassen {
    /// <summary>
    /// Interaction logic for TruitjeAanpassenWindow.xaml
    /// </summary>
    public partial class TruitjeAanpassenWindow : Window {
        public TruitjeAanpassenWindow(string aanTePassen, Truitje truitje) {
            InitializeComponent();
            AanTePassenTruitje = truitje;
            BestaandeClub = truitje.Club;
            BestaandeClubSet = truitje.ClubSet;
            AanTePassen = aanTePassen;

            SetValues(truitje);
        }

        TruitjeManager TM = new TruitjeManager(new TruitjeRepository(ConfigurationManager.ConnectionStrings["connectionString"].ToString()));

        public Truitje AanTePassenTruitje { get; set; }
        public Club BestaandeClub { get; set; }
        public ClubSet BestaandeClubSet { get; set; }
        private string AanTePassen { get; set; }
        string VorigeTekst = "";
        public bool IsClosed = false;

        private void SetValues(Truitje truitje) {
            lblTruitjeId.Content += truitje.Id.ToString();
            comboBoxMaat.SelectedItem = truitje.Maat.ToString();
            SeizoenTXT.Text = truitje.Seizoen;
            PrijsTXT.Text = truitje.Prijs.ToString();
            LblBestaandeClub.Content += truitje.Club.Ploegnaam;
            LblBestaandClubSet.Content += truitje.ClubSet.Versie.ToString();
        }

        private void AddTekst(object sender, EventArgs e) {
            var txtbox = (TextBox)sender;
            if (string.IsNullOrWhiteSpace(txtbox.Text))
                txtbox.Text = VorigeTekst;
        }

        private void RemoveTekst(object sender, RoutedEventArgs e) {
            var txtbox = (TextBox)sender;
            if (!string.IsNullOrWhiteSpace(txtbox.Text)) {
                VorigeTekst = txtbox.Text;
                txtbox.Text = "";
            }
        }

        private void BtnBestuurderBestaandeClub_Click(object sender, RoutedEventArgs e) {
            ZoekWindow zoek = new ZoekWindow("club");
            if (zoek.ShowDialog() == true) {
                BestaandeClub = zoek.club;
                LblBestaandeClub.Content = $"Geselecteerde Club: " + BestaandeClub.Ploegnaam;
                AanTePassenTruitje.ZetClub(BestaandeClub);
            }
        }

        private void BtnBestuurderBestaandeClubSet_Click(object sender, RoutedEventArgs e) {
            ZoekWindow zoek = new ZoekWindow("clubset");
            if (zoek.ShowDialog() == true) {
                BestaandeClubSet = zoek.clubSet;
                LblBestaandClubSet.Content = $"Geselecteerde ClubSet versie: " + BestaandeClubSet.Versie;
                AanTePassenTruitje.ZetClubSet(BestaandeClubSet);
            }
        }

        private void BtnAanpassen_Click(object sender, RoutedEventArgs e) {
            try {
                if (!IsClosed) {
                    if (LblBestaandeClub.Content.ToString() != "Geselecteerde Club: " && LblBestaandClubSet.Content.ToString() != "Geselecteerd ClubSet versie: ") {
                        AanTePassenTruitje = new Truitje(int.Parse(lblTruitjeId.Content.ToString().Remove(0, 11)), Enum.Parse<Maat>(comboBoxMaat.SelectedValue.ToString()), SeizoenTXT.Text, double.Parse(PrijsTXT.Text), BestaandeClub, BestaandeClubSet);
                        IsClosed = true;
                    }

                    bool isGelukt = TM.UpdateTruitje(AanTePassenTruitje);
                    if (isGelukt) {
                        MessageBoxResult messageBoxResult = MessageBox.Show("Truitje Geüpdatet", "Truitje Update", MessageBoxButton.OK, MessageBoxImage.Information);
                        if (messageBoxResult == MessageBoxResult.OK) {
                            Close();
                        }
                    }
                } else {
                    MessageBox.Show("Truitje Update gefaald", "Truitje Update", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
                IsClosed = false;
            } catch (Exception ex) {
                MessageBox.Show(ex.Message, "Truitje updaten mislukt", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void BtnTerug_Click(object sender, RoutedEventArgs e) {
            MessageBoxResult messageBoxResult = MessageBox.Show("Ben je zeker?", "Confirmation", MessageBoxButton.YesNo);
            if (messageBoxResult == MessageBoxResult.Yes) {
                Close();
            }
        }
    }
}
