﻿using BusinessLayer.Enums;
using BusinessLayer.Managers;
using BusinessLayer.Model;
using DataLayerADO.Repositories;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace User_Interface.Toevoegen {
    /// <summary>
    /// Interaction logic for TruitjeToevoegen.xaml
    /// </summary>
    public partial class TruitjeToevoegenWindow : Window {
        public TruitjeToevoegenWindow() {
            InitializeComponent();

            SeizoenTXT.GotFocus += RemoveText;
            PrijsTXT.GotFocus += RemoveText;
            SeizoenTXT.LostFocus += AddText;
            PrijsTXT.LostFocus += AddText;
        }

        TruitjeManager TM = new TruitjeManager(new TruitjeRepository(ConfigurationManager.ConnectionStrings["connectionString"].ToString()));

        Club BestaandeClub = null;
        ClubSet BestaandeClubSet = null;

        private void RemoveText(object sender, EventArgs e) {
            var txtbox = (TextBox)sender;
            if (SeizoenTXT.Text == "Seizoen") {
                txtbox.Text = "";
            } else if (PrijsTXT.Text == "Prijs") {
                txtbox.Text = "";
            }
        }

        private void AddText(object sender, EventArgs e) {
            var txtbox = (TextBox)sender;
            if (string.IsNullOrWhiteSpace(SeizoenTXT.Text)) {
                txtbox.Text = "Seizoen";
            } else if (string.IsNullOrWhiteSpace(PrijsTXT.Text)) {
                txtbox.Text = "Prijs";
            }
        }

        private void BtnClubZoeken_Click(object sender, RoutedEventArgs e) {
            ZoekWindow zoek = new ZoekWindow("club");
            if (zoek.ShowDialog() == true) {
                BestaandeClub = zoek.club;
                ClubNaamTXT.Content = BestaandeClub.Ploegnaam;
            }
        }

        private void BtnClubSetZoeken_Click(object sender, RoutedEventArgs e) {
            ZoekWindow zoek = new ZoekWindow("clubset");
            if (zoek.ShowDialog() == true) {
                BestaandeClubSet = zoek.clubSet;
                ClubSetTXT.Content = BestaandeClubSet.Versie;
            }
        }

        private void BtnToevoegen_Click(object sender, RoutedEventArgs e) {
            if (SeizoenTXT.Text != "Seizoen" && PrijsTXT.Text != "Prijs" && BestaandeClub != null && BestaandeClubSet != null) {
                Truitje truitje = new Truitje(Enum.Parse<Maat>(comboBoxMaat.Text), SeizoenTXT.Text, double.Parse(PrijsTXT.Text), BestaandeClub, BestaandeClubSet);
                TM.MaakTruitjeAan(truitje);
                if (MessageBox.Show("Toevoegen gelukt", "toevoegen gelukt", MessageBoxButton.OK, MessageBoxImage.None) == MessageBoxResult.OK) {
                    MainWindow mainWindow = new MainWindow();
                    mainWindow.Show();
                    this.Close();
                } else {
                    MessageBox.Show("Toevoegen niet gelukt", "Toevoegen niet gelukt", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            } else {
                MessageBox.Show("Toevoegen niet gelukt", "Toevoegen niet gelukt", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void BtnAnnuleer_Click(object sender, RoutedEventArgs e) {
            MessageBoxResult messageBoxResult = MessageBox.Show("Ben je zeker?", "Confirmation", MessageBoxButton.YesNo);
            if (messageBoxResult == MessageBoxResult.Yes) {
                MainWindow mainWindow = new MainWindow();
                mainWindow.Show();
                this.Close();
            }
        }
    }
}
