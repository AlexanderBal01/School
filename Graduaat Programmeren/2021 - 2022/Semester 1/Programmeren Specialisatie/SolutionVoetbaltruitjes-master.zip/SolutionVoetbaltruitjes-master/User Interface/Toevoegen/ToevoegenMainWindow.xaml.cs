﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace User_Interface.Toevoegen {
    /// <summary>
    /// Interaction logic for ToevoegenMainWindow.xaml
    /// </summary>
    public partial class ToevoegenMainWindow : Window {
        public ToevoegenMainWindow() {
            InitializeComponent();
        }

        private void BtnTerug_Click(object sender, RoutedEventArgs e) {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        private void BtnClubToevoegen_Click(object sender, RoutedEventArgs e) {
            ClubToevoegenWindow clubToevoegen = new ClubToevoegenWindow();
            clubToevoegen.Show();
            this.Close();
        }

        private void BtnClubSetToevoegen_Click(object sender, RoutedEventArgs e) {
            ClubSetToevoegenWindow clubSetToevoegen = new ClubSetToevoegenWindow();
            clubSetToevoegen.Show();
            this.Close();
        }

        private void BtnTruitjeToevoegen_Click(object sender, RoutedEventArgs e) {
            TruitjeToevoegenWindow truitjeToevoegen = new TruitjeToevoegenWindow();
            truitjeToevoegen.Show();
            this.Close();
        }

        private void BtnKlantToevoegen_Click(object sender, RoutedEventArgs e) {
            KlantToevoegenWindow klantToevoegen = new KlantToevoegenWindow();
            klantToevoegen.Show();
            this.Close();
        }

        private void BtnBestellingToevoegen_Click(object sender, RoutedEventArgs e) {
            BestellingToevoegenWIndow bestellingToevoegen = new BestellingToevoegenWIndow();
            bestellingToevoegen.Show();
            this.Close();
        }
    }
}
