﻿using BusinessLayer.Managers;
using BusinessLayer.Model;
using DataLayerADO.Repositories;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace User_Interface.Toevoegen {
    /// <summary>
    /// Interaction logic for ClubSetToevoegen.xaml
    /// </summary>
    public partial class ClubSetToevoegenWindow : Window {
        public ClubSetToevoegenWindow() {
            InitializeComponent();

            VersieTXT.GotFocus += RemoveText;
            VersieTXT.LostFocus += AddText;
        }

        ClubSetManager CSM = new ClubSetManager(new ClubSetRepository(ConfigurationManager.ConnectionStrings["connectionString"].ToString()));

        private void RemoveText(object sender, EventArgs e) {
            var txtbox = (TextBox)sender;
            if (VersieTXT.Text == "Versie") {
                txtbox.Text = "";
            }
        }

        private void AddText(object sender, EventArgs e) {
            var txtbox = (TextBox)sender;
            if (string.IsNullOrWhiteSpace(VersieTXT.Text)) {
                txtbox.Text = "Versie";
            }
        }

        private void BtnAnnuleer_Click(object sender, RoutedEventArgs e) {
            MessageBoxResult messageBoxResult = MessageBox.Show("Ben je zeker?", "Confirmation", MessageBoxButton.YesNo);
            if (messageBoxResult == MessageBoxResult.Yes) {
                MainWindow mainWindow = new MainWindow();
                mainWindow.Show();
                this.Close();
            }
        }

        private void BtnToevoegen_Click(object sender, RoutedEventArgs e) {
            if (VersieTXT.Text != "Versie" && ((bool)RadioBtnJa.IsChecked || (bool)RadioBtnNee.IsChecked)) {
                if ((bool)RadioBtnJa.IsChecked) {
                    ClubSet clubSet = new ClubSet(true, int.Parse(VersieTXT.Text));
                    CSM.MaakClubSetAan(clubSet);
                    if (MessageBox.Show("Toevoegen gelukt", "toevoegen gelukt", MessageBoxButton.OK, MessageBoxImage.None) == MessageBoxResult.OK) {
                        MainWindow mainWindow = new MainWindow();
                        mainWindow.Show();
                        this.Close();
                    } else {
                        MessageBox.Show("Toevoegen niet gelukt", "Toevoegen niet gelukt", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                } else if ((bool)RadioBtnNee.IsChecked) {
                    ClubSet clubSet = new ClubSet(false, int.Parse(VersieTXT.Text));
                    CSM.MaakClubSetAan(clubSet);
                    if (MessageBox.Show("Toevoegen gelukt", "toevoegen gelukt", MessageBoxButton.OK, MessageBoxImage.None) == MessageBoxResult.OK) {
                        MainWindow mainWindow = new MainWindow();
                        mainWindow.Show();
                        this.Close();
                    } else {
                        MessageBox.Show("Toevoegen niet gelukt", "Toevoegen niet gelukt", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            } else {
                MessageBox.Show("Toevoegen niet gelukt", "Toevoegen niet gelukt", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
