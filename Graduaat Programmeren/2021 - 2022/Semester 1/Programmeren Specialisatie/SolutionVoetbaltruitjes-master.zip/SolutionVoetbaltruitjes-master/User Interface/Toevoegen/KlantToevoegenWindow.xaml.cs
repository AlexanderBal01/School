﻿using BusinessLayer.Managers;
using BusinessLayer.Model;
using DataLayerADO.Repositories;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace User_Interface.Toevoegen {
    /// <summary>
    /// Interaction logic for KlantToevoegenWindow.xaml
    /// </summary>
    public partial class KlantToevoegenWindow : Window {
        public KlantToevoegenWindow() {
            InitializeComponent();

            NaamTXT.GotFocus += RemoveText;
            AdresTXT.GotFocus += RemoveText;
            NaamTXT.LostFocus += AddText;
            AdresTXT.LostFocus += AddText;
        }
        
        KlantManager KM = new KlantManager(new KlantRepository(ConfigurationManager.ConnectionStrings["connectionString"].ToString()));

        private void RemoveText(object sender, EventArgs e) {
            var txtbox = (TextBox)sender;
            if (NaamTXT.Text == "Naam") {
                txtbox.Text = "";
            } else if (AdresTXT.Text == "Adres") {
                txtbox.Text = "";
            }
        }

        private void AddText(object sender, EventArgs e) {
            var txtbox = (TextBox)sender;
            if (string.IsNullOrWhiteSpace(NaamTXT.Text)) {
                txtbox.Text = "Naam";
            } else if (string.IsNullOrWhiteSpace(AdresTXT.Text)) {
                txtbox.Text = "Adres";
            }
        }

        private void BtnToevoegen_Click(object sender, RoutedEventArgs e) {
            if (NaamTXT.Text != "Naam" && AdresTXT.Text != "Adres") {
                Klant klant = new Klant(NaamTXT.Text, AdresTXT.Text);
                KM.MaakKlantAan(klant);
                if (MessageBox.Show("Toevoegen gelukt", "toevoegen gelukt", MessageBoxButton.OK, MessageBoxImage.None) == MessageBoxResult.OK) {
                    MainWindow mainWindow = new MainWindow();
                    mainWindow.Show();
                    this.Close();
                } else {
                    MessageBox.Show("Toevoegen niet gelukt", "Toevoegen niet gelukt", MessageBoxButton.OK, MessageBoxImage.Error);
                }

            } else {
                MessageBox.Show("Toevoegen niet gelukt", "Toevoegen niet gelukt", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void BtnAnnuleer_Click(object sender, RoutedEventArgs e) {
            MessageBoxResult messageBoxResult = MessageBox.Show("Ben je zeker?", "Confirmation", MessageBoxButton.YesNo);
            if (messageBoxResult == MessageBoxResult.Yes) {
                MainWindow mainWindow = new MainWindow();
                mainWindow.Show();
                this.Close();
            }
        }
    }
}
