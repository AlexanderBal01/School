﻿using BusinessLayer.Managers;
using BusinessLayer.Model;
using DataLayerADO.Repositories;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace User_Interface.Toevoegen {
    /// <summary>
    /// Interaction logic for BestellingToevoegenWIndow.xaml
    /// </summary>
    public partial class BestellingToevoegenWIndow : Window {
        public BestellingToevoegenWIndow() {
            InitializeComponent();

            AantalTXT.GotFocus += RemoveText;
            AantalTXT.LostFocus += AddText;
            AantalTXT.LostFocus += ZetPrijs;

            DateTimeFormatInfo dtinfo = new DateTimeFormatInfo();
            dtinfo.ShortDatePattern = "dd-Mon-yyyy";
            dtinfo.DateSeparator = "-";
        }
        BestellingManager BM = new BestellingManager(new BestellingRepository(ConfigurationManager.ConnectionStrings["connectionString"].ToString()));

        Klant BestaandeKlant = null;
        Truitje BestaandTruitje = null;

        private void RemoveText(object sender, EventArgs e) {
            var txtbox = (TextBox)sender;
            if (AantalTXT.Text == "Aantal") {
                txtbox.Text = "";
            }
        }

        private void AddText(object sender, EventArgs e) {
            var txtbox = (TextBox)sender;
            if (string.IsNullOrWhiteSpace(AantalTXT.Text)) {
                txtbox.Text = "Aantal";
            }
        }

        private void BtnKlantZoeken_Click(object sender, RoutedEventArgs e) {
            ZoekWindow zoek = new ZoekWindow("Klant");
            if (zoek.ShowDialog() == true) {
                BestaandeKlant = zoek.klant;
                KlantNaamTXT.Content = BestaandeKlant.Naam;
            }
        }

        private void BtnTruitjeZoeken_Click(object sender, RoutedEventArgs e) {
            ZoekWindow zoek = new ZoekWindow("Truitje");
            if (zoek.ShowDialog() == true) {
                BestaandTruitje = zoek.truitje; ;
                TruitjeTXT.Content = BestaandTruitje.Club.Ploegnaam;
            }
        }

        private void BtnAnnuleer_Click(object sender, RoutedEventArgs e) {
            MessageBoxResult messageBoxResult = MessageBox.Show("Ben je zeker?", "Confirmation", MessageBoxButton.YesNo);
            if (messageBoxResult == MessageBoxResult.Yes) {
                MainWindow mainWindow = new MainWindow();
                mainWindow.Show();
                this.Close();
            }
        }

        private void BtnToevoegen_Click(object sender, RoutedEventArgs e) {
            if (AantalTXT.Text != "Aantal" && ((bool)RadioBtnJa.IsChecked || (bool)RadioBtnNee.IsChecked) && BestaandTruitje != null && BestaandeKlant != null) {
                if ((bool)RadioBtnJa.IsChecked) {
                    Bestelling bestelling = new Bestelling(BestaandeKlant, (DateTime)DatePicker.SelectedDate, BestaandTruitje, int.Parse(AantalTXT.Text), true, double.Parse(PrijsTXT.Content.ToString()));
                    BM.MaakBestellingAan(bestelling);
                    if (MessageBox.Show("Toevoegen gelukt", "toevoegen gelukt", MessageBoxButton.OK, MessageBoxImage.None) == MessageBoxResult.OK) {
                        MainWindow mainWindow = new MainWindow();
                        mainWindow.Show();
                        this.Close();
                    } else {
                        MessageBox.Show("Toevoegen niet gelukt", "Toevoegen niet gelukt", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                } else if ((bool)RadioBtnNee.IsChecked) {
                    Bestelling bestelling = new Bestelling(BestaandeKlant, (DateTime)DatePicker.SelectedDate, BestaandTruitje, int.Parse(AantalTXT.Text), false, double.Parse(PrijsTXT.Content.ToString()));
                    BM.MaakBestellingAan(bestelling);
                    if (MessageBox.Show("Toevoegen gelukt", "toevoegen gelukt", MessageBoxButton.OK, MessageBoxImage.None) == MessageBoxResult.OK) {
                        MainWindow mainWindow = new MainWindow();
                        mainWindow.Show();
                        this.Close();
                    } else {
                        MessageBox.Show("Toevoegen niet gelukt", "Toevoegen niet gelukt", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            } else {
                MessageBox.Show("Toevoegen niet gelukt", "Toevoegen niet gelukt", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ZetPrijs(object sender, RoutedEventArgs e) {
            if (AantalTXT.Text != "Aantal") {
                Bestelling bestelling = new Bestelling(BestaandeKlant, (DateTime)DatePicker.SelectedDate);
                bestelling.ZetProducten(BestaandTruitje, int.Parse(AantalTXT.Text));
                PrijsTXT.Content = bestelling.Prijs.ToString();
            }
            
        }
    }
}
