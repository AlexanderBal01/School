CREATE TABLE Truitje (
	TruitjeID INT NOT NULL IDENTITY(1,1) PRIMARY KEY,
	Maat Nvarchar(255) NOT NULL,
	Seizoen Nvarchar(255) NOT NULL,
	Prijs float NOT NULL,
	ClubId INT,
	ClubSetId INT,
	CONSTRAINT FK_ClubTruitje FOREIGN KEY (ClubId) REFERENCES Club(ClubID),
	CONSTRAINT FK_ClubSetTruitje FOREIGN KEY (ClubSetId) REFERENCES ClubSet(ClubSetID),
);