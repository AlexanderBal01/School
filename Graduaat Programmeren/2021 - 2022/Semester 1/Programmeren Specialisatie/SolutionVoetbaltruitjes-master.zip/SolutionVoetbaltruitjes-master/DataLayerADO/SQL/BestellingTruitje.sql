CREATE TABLE BestellingTruitje(
	TruitjeId int,
	BestellingId int,
	Aantal int NOT NULL,
	CONSTRAINT FK_TruitjeBestellingTruitje FOREIGN KEY (TruitjeId) REFERENCES Truitje(TruitjeID),
	CONSTRAINT FK_BestellingBestellingTruitje FOREIGN KEY (BestellingId) REFERENCES Bestelling(BestellingID),
);