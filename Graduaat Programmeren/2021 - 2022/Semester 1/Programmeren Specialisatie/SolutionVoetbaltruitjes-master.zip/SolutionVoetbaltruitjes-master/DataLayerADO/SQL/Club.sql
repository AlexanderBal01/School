CREATE TABLE Club (
	ClubID INT NOT NULL IDENTITY(1,1) PRIMARY KEY,
	Ploegnaam NVarchar(255) NOT NULL,
	Competitie Nvarchar(255) NOT NULL
);