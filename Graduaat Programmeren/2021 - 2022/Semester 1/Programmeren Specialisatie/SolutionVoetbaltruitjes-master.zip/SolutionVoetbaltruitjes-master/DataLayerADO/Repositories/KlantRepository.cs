﻿using BusinessLayer.Interfaces;
using BusinessLayer.Model;
using DataLayerADO.Exceptions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayerADO.Repositories {
    public class KlantRepository : IKlantRepository {
        #region Properties
        private string ConnectionString;
        #endregion

        #region Ctor
        public KlantRepository(string connectionString) {
            ConnectionString = connectionString;
        }
        #endregion

        #region Methods
        private SqlConnection GetConnection() {
            SqlConnection connection = new SqlConnection(ConnectionString);
            return connection;
        }

        //Werkt
        public bool BestaatKlantId(int id) {
            string query = "SELECT COUNT(*) FROM Klant WHERE KlantID=@id";
            SqlConnection connection = GetConnection();
            using (SqlCommand command = new SqlCommand(query, connection)) {
                try {
                    connection.Open();
                    command.Parameters.Add(new SqlParameter("@id", SqlDbType.Int));
                    command.Parameters["@id"].Value = id;
                    int klantBestaat = (int)command.ExecuteScalar();
                    if (klantBestaat > 0) {
                        return true;
                    }
                    return false;
                } catch (Exception ex) {
                    KlantRepositoryException klantRepositoryEx = new KlantRepositoryException("BestaatKlantId niet gelukt", ex);
                    klantRepositoryEx.Data.Add("id", id);
                    throw klantRepositoryEx;
                } finally {
                    connection.Close();
                }
            }
        }

        //Werkt
        public Klant MaakKlantAan(Klant klant) {
            string query = "INSERT INTO Klant output INSERTED.KlantID VALUES(@naam, @adres)";
            SqlConnection connection = GetConnection();
            using (SqlCommand command = new SqlCommand(query, connection)) {
                try {
                    connection.Open();
                    command.Parameters.Add(new SqlParameter("@naam", SqlDbType.NVarChar));
                    command.Parameters.Add(new SqlParameter("@adres", SqlDbType.NVarChar));
                    command.Parameters["@naam"].Value = klant.Naam;
                    command.Parameters["@adres"].Value = klant.Adres;
                    int newId = (int)command.ExecuteScalar();
                    klant.ZetId(newId);
                    return klant;
                } catch (Exception ex) {
                    KlantRepositoryException klantRepositoryEx = new KlantRepositoryException("MaakKlantAan niet gelukt", ex);
                    klantRepositoryEx.Data.Add("klant", klant);
                    throw klantRepositoryEx;
                } finally {
                    connection.Close();
                }
            }
        }

        // Werkt
        public void UpdateKlant(Klant klant) {
            string query = "UPDATE Klant SET Naam=@naam, Adres=@adres WHERE KlantID=@id";
            SqlConnection connection = GetConnection();
            using (SqlCommand command = new SqlCommand(query, connection)) {
                try {
                    connection.Open();
                    command.Parameters.Add(new SqlParameter("@naam", SqlDbType.NVarChar));
                    command.Parameters.Add(new SqlParameter("@adres", SqlDbType.NVarChar));
                    command.Parameters.Add(new SqlParameter("@id", SqlDbType.Int));
                    command.Parameters["@naam"].Value = klant.Naam;
                    command.Parameters["@adres"].Value = klant.Adres;
                    command.Parameters["@id"].Value = klant.Id;
                    command.ExecuteNonQuery();
                } catch (Exception ex) {
                    KlantRepositoryException klantRepositoryEx = new KlantRepositoryException("UpdateKlant niet gelukt", ex);
                    klantRepositoryEx.Data.Add("klant", klant);
                    throw klantRepositoryEx;
                } finally {
                    connection.Close();
                }
            }
        }

        //Werkt
        public void VerwijderKlant(int id) {
            string query = "DELETE FROM Klant WHERE KlantID=@id";
            SqlConnection connection = GetConnection();
            using (SqlCommand command = new SqlCommand(query, connection)) {
                try {
                    connection.Open();
                    command.Parameters.Add(new SqlParameter("@id", SqlDbType.Int));
                    command.Parameters["@id"].Value = id;
                    command.ExecuteNonQuery();
                } catch (Exception ex) {
                    KlantRepositoryException klantRepositoryEx = new KlantRepositoryException("VerwijderKlant niet gelukt", ex);
                    klantRepositoryEx.Data.Add("id", id);
                    throw klantRepositoryEx;
                } finally {
                    connection.Close();
                }
            }
        }

        public List<Klant> GeefKlanten(string tekst) {
            string query = "SELECT * FROM KLANT WHERE ((convert(nvarchar(255), KlantID) LIKE '%'+ @klantid +'%') OR (Naam LIKE '%'+ @naam +'%') OR (Adres LIKE '%'+ @adres +'%'))";
            SqlConnection connection = GetConnection();
            using (SqlCommand command = new SqlCommand(query, connection)) {
                try {
                    List<Klant> klanten = new List<Klant>();

                    connection.Open();

                    command.Parameters.Add(new SqlParameter("@klantid", SqlDbType.NVarChar));
                    command.Parameters.Add(new SqlParameter("@naam", SqlDbType.NVarChar));
                    command.Parameters.Add(new SqlParameter("@adres", SqlDbType.NVarChar));

                    command.Parameters["@klantid"].Value = tekst;
                    command.Parameters["@naam"].Value = tekst;
                    command.Parameters["@adres"].Value = tekst;

                    SqlDataReader dataReader = command.ExecuteReader();
                    while (dataReader.Read()) {
                        Klant k = new Klant((int)dataReader["KlantID"], (string)dataReader["Naam"], (string)dataReader["Adres"]);
                        klanten.Add(k);
                    }
                    dataReader.Close();
                    return klanten;
                } catch (Exception ex) {
                    KlantRepositoryException klantRepositoryEx = new KlantRepositoryException("GeefKlanten niet gelukt", ex);
                    klantRepositoryEx.Data.Add("tekst", tekst);
                    throw klantRepositoryEx;
                } finally {
                    connection.Close();
                }
            }
        }
        #endregion
    }
}
