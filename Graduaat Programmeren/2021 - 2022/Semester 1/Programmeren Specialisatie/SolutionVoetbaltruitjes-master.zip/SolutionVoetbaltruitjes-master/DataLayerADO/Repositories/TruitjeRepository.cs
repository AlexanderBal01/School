﻿using BusinessLayer.Enums;
using BusinessLayer.Interfaces;
using BusinessLayer.Model;
using DataLayerADO.Exceptions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayerADO.Repositories {
    public class TruitjeRepository : ITruitjeRepository {
        #region Properties
        private string ConnectionString;
        #endregion

        #region Ctor
        public TruitjeRepository(string connectionString) {
            ConnectionString = connectionString;
        }

        #endregion

        #region Methods
        private SqlConnection GetConnection() {
            SqlConnection connection = new SqlConnection(ConnectionString);
            return connection;
        }

        public static string MaatNaarString(Maat maat) {
            string s = maat.ToString();
            return s;
        }

        public static Maat StringNaarMaat(string maat) {
            var item = Enum.Parse<Maat>(maat);
            return item;
        }

        //Werkt
        public Truitje MaakTruitjeAan(Truitje truitje) {
            string query = "INSERT INTO Truitje (Maat, Seizoen, Prijs, ClubId, ClubSetId) output INSERTED.TruitjeID VALUES(@Maat, @Seizoen, @Prijs, @ClubId, @ClubSetId)";
            SqlConnection connection = GetConnection();
            using (SqlCommand command = new SqlCommand(query, connection)) {
                try {
                    connection.Open();
                    command.Parameters.Add(new SqlParameter("@Maat", SqlDbType.NVarChar));
                    command.Parameters.Add(new SqlParameter("@Seizoen", SqlDbType.NVarChar));
                    command.Parameters.Add(new SqlParameter("@Prijs", SqlDbType.Float));
                    command.Parameters.Add(new SqlParameter("@ClubId", SqlDbType.Int));
                    command.Parameters.Add(new SqlParameter("@ClubSetId", SqlDbType.Int));

                    command.Parameters["@Maat"].Value = MaatNaarString(truitje.Maat);
                    command.Parameters["@Seizoen"].Value = truitje.Seizoen;
                    command.Parameters["@Prijs"].Value = truitje.Prijs;
                    if (truitje.Club == null) {
                        command.Parameters["@ClubId"].Value = SqlInt32.Null;
                    } else {
                        command.Parameters["@ClubId"].Value = truitje.Club.Id;
                    }
                    if (truitje.ClubSet == null) {
                        command.Parameters["@ClubSetId"].Value = SqlInt32.Null;
                    } else {
                        command.Parameters["@ClubSetId"].Value = truitje.ClubSet.Id;
                    }
                    int newId = (int)command.ExecuteScalar();
                    truitje.ZetId(newId);
                    return truitje;
                } catch (Exception ex) {
                    TruitjeRepositoryException truitjeRepositoryEx = new TruitjeRepositoryException("MaakTruitjeAan niet gelukt", ex);
                    truitjeRepositoryEx.Data.Add("truitje", truitje);
                    throw truitjeRepositoryEx;
                } finally {
                    connection.Close();
                }
            }
        }

        //Werkt
        public void UpdateTruitje(Truitje truitje) {
            string query = "UPDATE Truitje SET Maat=@Maat, Seizoen=@Seizoen, Prijs=@Prijs, ClubId=@ClubId, @ClubSetId=@ClubSetId WHERE TruitjeID=@id";
            SqlConnection connection = GetConnection();
            using (SqlCommand command = new SqlCommand(query, connection)) {
                try {
                    connection.Open();
                    command.Parameters.Add(new SqlParameter("@Maat", SqlDbType.NVarChar));
                    command.Parameters.Add(new SqlParameter("@Seizoen", SqlDbType.NVarChar));
                    command.Parameters.Add(new SqlParameter("@Prijs", SqlDbType.Float));
                    command.Parameters.Add(new SqlParameter("@ClubId", SqlDbType.Int));
                    command.Parameters.Add(new SqlParameter("@ClubSetId", SqlDbType.Int));
                    command.Parameters.Add(new SqlParameter("@id", SqlDbType.Int));

                    command.Parameters["@Maat"].Value = MaatNaarString(truitje.Maat);
                    command.Parameters["@Seizoen"].Value = truitje.Seizoen;
                    command.Parameters["@Prijs"].Value = truitje.Prijs;
                    if (truitje.Club == null) {
                        command.Parameters["@ClubId"].Value = SqlInt32.Null;
                    } else {
                        command.Parameters["@ClubId"].Value = truitje.Club.Id;
                    }
                    if (truitje.ClubSet == null) {
                        command.Parameters["@ClubSetId"].Value = SqlInt32.Null;
                    } else {
                        command.Parameters["@ClubSetId"].Value = truitje.ClubSet.Id;
                    }
                    command.Parameters["@id"].Value = truitje.Id;
                    command.ExecuteNonQuery();
                } catch (Exception ex) {
                    TruitjeRepositoryException truitjeRepositoryEx = new TruitjeRepositoryException("UpdateTruitje niet gelukt", ex);
                    truitjeRepositoryEx.Data.Add("truitje", truitje);
                    throw truitjeRepositoryEx;
                } finally {
                    connection.Close();
                }
            }
        }

        //Werkt
        public void VerwijderTruitje(int id) {
            string query = "DELETE FROM Truitje WHERE TruitjeID=@id";
            SqlConnection connection = GetConnection();
            using (SqlCommand command = new SqlCommand(query, connection)) {
                try {
                    connection.Open();
                    command.Parameters.Add(new SqlParameter("@id", SqlDbType.Int));
                    command.Parameters["@id"].Value = id;
                    command.ExecuteNonQuery();
                } catch (Exception ex) {
                    TruitjeRepositoryException truitjeRepositoryEx = new TruitjeRepositoryException("VerwijderTruitje niet gelulkt", ex);
                    truitjeRepositoryEx.Data.Add("id", id);
                    throw truitjeRepositoryEx;
                } finally {
                    connection.Close();
                }
            }
        }

        //Werkt
        public bool BestaatTruitjeId(int id) {
            string query = "SELECT COUNT(*) FROM Truitje WHERE TruitjeID=@id";
            SqlConnection connection = GetConnection();
            using (SqlCommand command = new SqlCommand(query, connection)) {
                try {
                    connection.Open();
                    command.Parameters.Add(new SqlParameter("@id", SqlDbType.Int));
                    command.Parameters["@id"].Value = id;
                    int truitjeBestaat = (int)command.ExecuteScalar();
                    if (truitjeBestaat > 0) {
                        return true;
                    }
                    return false;
                } catch (Exception ex) {
                    TruitjeRepositoryException truitjeRepositoryEx = new TruitjeRepositoryException("BestaatTruitjeId niet gelukt", ex);
                    truitjeRepositoryEx.Data.Add("id", id);
                    throw truitjeRepositoryEx;
                } finally {
                    connection.Close();
                }
            }
        }

        public List<Truitje> GeefTruitjes(string tekst) {
            string query = "SELECT Truitje.*, Club.*, ClubSet.* FROM Truitje " +
                "JOIN Club ON Truitje.ClubId=Club.ClubID " +
                "JOIN ClubSet ON Truitje.ClubSetId=ClubSet.ClubSetID " +
                "WHERE ((convert(nvarchar(255), Truitje.TruitjeID) LIKE '%'+ @truitjeid +'%') " +
                "OR (Truitje.Maat LIKE '%'+ @maat +'%') " +
                "OR (Truitje.Seizoen LIKE '%'+ @seizoen +'%') " +
                "OR (convert(nvarchar(255), Truitje.Prijs) LIKE '%'+ @prijs +'%') " +
                "OR (convert(nvarchar(255), Club.ClubID) LIKE '%'+ @clubid +'%') " +
                "OR (convert(nvarchar(255), ClubSet.ClubSetID) LIKE '%'+ @clubsetid +'%') " +
                "OR (Club.Ploegnaam LIKE '%'+ @ploegnaam +'%') " +
                "OR (Club.Competitie LIKE '%'+ @competitie +'%'))";
            SqlConnection connection = GetConnection();
            using (SqlCommand command = new SqlCommand(query, connection)) {
                try {
                    List<Truitje> truitjes = new List<Truitje>();

                    connection.Open();

                    command.Parameters.Add(new SqlParameter("@truitjeid", SqlDbType.NVarChar));
                    command.Parameters.Add(new SqlParameter("@maat", SqlDbType.NVarChar));
                    command.Parameters.Add(new SqlParameter("@seizoen", SqlDbType.NVarChar));
                    command.Parameters.Add(new SqlParameter("@prijs", SqlDbType.NVarChar));
                    command.Parameters.Add(new SqlParameter("@clubid", SqlDbType.NVarChar));
                    command.Parameters.Add(new SqlParameter("@clubsetid", SqlDbType.NVarChar));
                    command.Parameters.Add(new SqlParameter("@ploegnaam", SqlDbType.NVarChar));
                    command.Parameters.Add(new SqlParameter("@competitie", SqlDbType.NVarChar));

                    command.Parameters["@truitjeid"].Value = tekst;
                    command.Parameters["@maat"].Value = tekst;
                    command.Parameters["@seizoen"].Value = tekst;
                    command.Parameters["@prijs"].Value = tekst;
                    command.Parameters["@clubid"].Value = tekst;
                    command.Parameters["@clubsetid"].Value = tekst;
                    command.Parameters["@ploegnaam"].Value = tekst;
                    command.Parameters["@competitie"].Value = tekst;

                    SqlDataReader dataReader = command.ExecuteReader();
                    while (dataReader.Read()) {
                        Club c = new Club((int)dataReader["ClubID"], (string)dataReader["Ploegnaam"], (string)dataReader["Competitie"]);
                        ClubSet cs = new ClubSet((int)dataReader["ClubSetID"], bool.Parse((string)dataReader["IsThuis"]), (int)dataReader["Versie"]);
                        Truitje t = new Truitje((int)dataReader["TruitjeID"], StringNaarMaat((string)dataReader["Maat"]), (string)dataReader["Seizoen"], (double)dataReader["Prijs"], c, cs);
                        truitjes.Add(t);
                    }
                    dataReader.Close();
                    return truitjes;
                } catch (Exception ex) {
                    TruitjeRepositoryException truitjeRepositoryEx = new TruitjeRepositoryException("GeefTruitjes niet gelukt", ex);
                    truitjeRepositoryEx.Data.Add("tekst", tekst);
                    throw truitjeRepositoryEx;
                } finally {
                    connection.Close();
                }
            }
        }
        #endregion
    }
}
