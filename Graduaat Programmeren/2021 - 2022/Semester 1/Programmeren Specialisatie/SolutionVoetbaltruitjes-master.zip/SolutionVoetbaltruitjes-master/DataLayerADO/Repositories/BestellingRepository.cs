﻿using BusinessLayer.Enums;
using BusinessLayer.Interfaces;
using BusinessLayer.Model;
using DataLayerADO.Exceptions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayerADO.Repositories {
    public class BestellingRepository : IBestellingRepository {
        #region Properties
        private string ConnectionString;
        #endregion

        #region Ctor
        public BestellingRepository(string connectionString) {
            ConnectionString = connectionString;
        }
        #endregion

        #region Methods
        private SqlConnection GetConnection() {
            SqlConnection connection = new SqlConnection(ConnectionString);
            return connection;
        }

        public static Maat StringNaarMaat(string maat) {
            var item = Enum.Parse<Maat>(maat);
            return item;
        }

        //Werkt
        public bool BestaatBestellingId(int id) {
            string query = "SELECT COUNT(*) FROM Bestelling WHERE BestellingID=@id";
            SqlConnection connection = GetConnection();
            using (SqlCommand command = new SqlCommand(query, connection)) {
                try {
                    connection.Open();
                    command.Parameters.Add(new SqlParameter("@id", SqlDbType.Int));
                    command.Parameters["@id"].Value = id;
                    int bestellingBestaat = (int)command.ExecuteScalar();
                    if (bestellingBestaat > 0) {
                        return true;
                    }
                    return false;
                } catch (Exception ex) {
                    BestellingRepositoryException bestellingRepositoryEx = new BestellingRepositoryException("BestaatBestellingId niet gelukt", ex);
                    bestellingRepositoryEx.Data.Add("id", id);
                    throw bestellingRepositoryEx;
                } finally {
                    connection.Close();
                }
            }
        }

        //Werkt
        public Bestelling MaakBestellingAan(Bestelling bestelling) {
            string queryBestelling = "INSERT INTO Bestelling output INSERTED.BestellingID VALUES(@datum, @prijs, @betaald, @klant)";
            string queryBestellingTruitje = "INSERT INTO BestellingTruitje VALUES(@truitje, @bestelling, @aantal)";
            SqlConnection connection = GetConnection();
            using (SqlCommand command = connection.CreateCommand()) {
                connection.Open();
                try {
                    command.CommandText = queryBestelling;
                    command.Parameters.Add(new SqlParameter("@datum", SqlDbType.DateTime));
                    command.Parameters.Add(new SqlParameter("@prijs", SqlDbType.Float));
                    command.Parameters.Add(new SqlParameter("@betaald", SqlDbType.NVarChar));
                    command.Parameters.Add(new SqlParameter("@klant", SqlDbType.Int));
                    command.Parameters["@datum"].Value = bestelling.Datum;
                    command.Parameters["@prijs"].Value = bestelling.Prijs;
                    command.Parameters["@betaald"].Value = bestelling.Betaald.ToString();
                    command.Parameters["@klant"].Value = bestelling.Klant.Id;
                    int newId = (int)command.ExecuteScalar();
                    bestelling.ZetId(newId);
                } catch (Exception ex) {
                    BestellingRepositoryException bestellingRepositoryEx = new BestellingRepositoryException("MaakBestellingAan queryBestelling niet gelukt", ex);
                    bestellingRepositoryEx.Data.Add("bestelling", bestelling);
                    throw bestellingRepositoryEx;
                }

                try {
                    command.CommandText = queryBestellingTruitje;
                    command.Parameters.Add(new SqlParameter("@truitje", SqlDbType.Int));
                    command.Parameters.Add(new SqlParameter("@bestelling", SqlDbType.Int));
                    command.Parameters.Add(new SqlParameter("@aantal", SqlDbType.Int));
                    var truitje = bestelling.Producten.Keys.First();
                    command.Parameters["@truitje"].Value = truitje.Id;
                    command.Parameters["@bestelling"].Value = bestelling.Id;
                    var aantal = bestelling.Producten.Values.First();
                    command.Parameters["@aantal"].Value = aantal;
                    command.ExecuteNonQuery();
                    return bestelling;
                } catch (Exception ex) {
                    BestellingRepositoryException bestellingRepositoryEx = new BestellingRepositoryException("MaakBestellingAan queryBestellingTruitje niet gelukt", ex);
                    bestellingRepositoryEx.Data.Add("bestelling", bestelling);
                    throw bestellingRepositoryEx;
                } finally {
                    connection.Close();
                }
            }
        }

        //Werkt
        public void UpdateBestelling(Bestelling bestelling) {
            string queryBestelling = "UPDATE Bestelling SET Datum=@datum, Prijs=@prijs, Betaald=@betaald, KlantId=@klant WHERE BestellingID=@id";
            string queryBestellingTruitje = "UPDATE BestellingTruitje SET TruitjeId=@truitje, Aantal=@aantal WHERE Bestellingid=@Bestellingid";
            SqlConnection connection = GetConnection();
            using (SqlCommand command = connection.CreateCommand()) {
                connection.Open();
                try {
                    command.CommandText = queryBestelling;
                    command.Parameters.Add(new SqlParameter("@id", SqlDbType.Int));
                    command.Parameters.Add(new SqlParameter("@datum", SqlDbType.DateTime));
                    command.Parameters.Add(new SqlParameter("@prijs", SqlDbType.Float));
                    command.Parameters.Add(new SqlParameter("@betaald", SqlDbType.NVarChar));
                    command.Parameters.Add(new SqlParameter("@klant", SqlDbType.Int));
                    command.Parameters["@datum"].Value = bestelling.Datum;
                    command.Parameters["@prijs"].Value = bestelling.Prijs;
                    command.Parameters["@betaald"].Value = bestelling.Betaald.ToString();
                    command.Parameters["@klant"].Value = bestelling.Klant.Id;
                    command.Parameters["@id"].Value = bestelling.Id;
                    command.ExecuteNonQuery();
                } catch (Exception ex) {
                    BestellingRepositoryException bestellingRepositoryEx = new BestellingRepositoryException("UpdateBestelling queryBestelling niet gelukt", ex);
                    bestellingRepositoryEx.Data.Add("bestelling", bestelling);
                    throw bestellingRepositoryEx;
                }

                try {
                    command.CommandText = queryBestellingTruitje;
                    command.Parameters.Add(new SqlParameter("@truitje", SqlDbType.Int));
                    command.Parameters.Add(new SqlParameter("@Bestellingid", SqlDbType.Int));
                    command.Parameters.Add(new SqlParameter("@aantal", SqlDbType.Int));
                    var truitje = int.Parse(bestelling.Producten.First().Key.Id.ToString());
                    command.Parameters["@truitje"].Value = truitje;
                    command.Parameters["@Bestellingid"].Value = bestelling.Id;
                    var aantal = int.Parse(bestelling.Producten.First().Value.ToString());
                    command.Parameters["@aantal"].Value = aantal;
                    command.ExecuteNonQuery();
                } catch (Exception ex) {
                    BestellingRepositoryException bestellingRepositoryEx = new BestellingRepositoryException("UpdateBestelling queryBestellingTruitje niet gelukt", ex);
                    bestellingRepositoryEx.Data.Add("bestelling", bestelling);
                    throw bestellingRepositoryEx;
                } finally {
                    connection.Close();
                }
            }
        }

        //Werkt
        public void VerwijderBestelling(int id) {
            string queryBestellingTruitje = "DELETE FROM BestellingTruitje WHERE BestellingId=@id";
            string queryBestelling = "DELETE FROM Bestelling WHERE BestellingID=@idBestelling";
            SqlConnection connection = GetConnection();
            using (SqlCommand command = connection.CreateCommand()) {
                connection.Open();
                try {
                    command.CommandText = queryBestellingTruitje;
                    command.Parameters.Add(new SqlParameter("@id", SqlDbType.Int));
                    command.Parameters["@id"].Value = id;
                    command.ExecuteNonQuery();
                } catch (Exception ex) {
                    BestellingRepositoryException bestellingRepositoryEx = new BestellingRepositoryException("VerwijderBestelling queryBestellingTruitje niet gelukt", ex);
                    bestellingRepositoryEx.Data.Add("id", id);
                    throw bestellingRepositoryEx;
                }

                try {
                    command.CommandText = queryBestelling;
                    command.Parameters.Add(new SqlParameter("@idBestelling", SqlDbType.Int));
                    command.Parameters["@idBestelling"].Value = id;
                    command.ExecuteNonQuery();
                } catch (Exception ex) {
                    BestellingRepositoryException bestellingRepositoryEx = new BestellingRepositoryException("VerwijderBestelling queryBestelling niet gelukt", ex);
                    bestellingRepositoryEx.Data.Add("id", id);
                    throw bestellingRepositoryEx;
                } finally {
                    connection.Close();
                }
            }
        }

        public List<Bestelling> GeefBestellingen(string tekst) {
            string query = "SELECT BestellingTruitje.*, Bestelling.*, Truitje.*, Klant.*, Club.*, ClubSet.* FROM BestellingTruitje " +
               "JOIN Bestelling ON BestellingTruitje.BestellingId=Bestelling.BestellingID " +
               "JOIN Klant ON Bestelling.KlantId=Klant.KlantID " +
               "JOIN Truitje ON BestellingTruitje.TruitjeId=Truitje.TruitjeID " +
               "JOIN Club ON Truitje.ClubId=Club.ClubID " +
               "JOIN ClubSet ON Truitje.ClubSetId=ClubSet.ClubSetID WHERE ((convert(nvarchar(255), Bestelling.BestellingID) LIKE '%'+ @bestllingid +'%') " +
               "OR (convert(nvarchar(255), Klant.KlantID) LIKE '%'+ @klantid +'%') " +
               "OR (Klant.Naam LIKE '%'+ @naam +'%') " +
               "OR (Klant.Adres LIKE '%'+ @adres +'%'))";
            SqlConnection connection = GetConnection();
            using (SqlCommand command = new SqlCommand(query, connection)) {
                try {
                    List<Bestelling> bestellingen = new List<Bestelling>();

                    connection.Open();

                    command.Parameters.Add(new SqlParameter("@bestllingid", SqlDbType.NVarChar));
                    command.Parameters.Add(new SqlParameter("@datum", SqlDbType.NVarChar));
                    command.Parameters.Add(new SqlParameter("@klantid", SqlDbType.NVarChar));
                    command.Parameters.Add(new SqlParameter("@naam", SqlDbType.NVarChar));
                    command.Parameters.Add(new SqlParameter("@adres", SqlDbType.NVarChar));

                    command.Parameters["@bestllingid"].Value = tekst;
                    command.Parameters["@datum"].Value = tekst;
                    command.Parameters["@klantid"].Value = tekst;
                    command.Parameters["@naam"].Value = tekst;
                    command.Parameters["@adres"].Value = tekst;

                    SqlDataReader dataReader = command.ExecuteReader();
                    while (dataReader.Read()) {
                        Klant k = new Klant((int)dataReader["KlantID"], (string)dataReader["Naam"], (string)dataReader["Adres"]);
                        Club c = new Club((int)dataReader["ClubID"], (string)dataReader["Ploegnaam"], (string)dataReader["Competitie"]);
                        ClubSet cs = new ClubSet((int)dataReader["ClubSetID"], bool.Parse((string)dataReader["IsThuis"]), (int)dataReader["Versie"]);
                        Truitje t = new Truitje((int)dataReader["TruitjeID"], StringNaarMaat((string)dataReader["Maat"]), (string)dataReader["Seizoen"], (double)dataReader["Prijs"], c, cs);
                        Bestelling b = new Bestelling((int)dataReader["BestellingID"], k, (DateTime)dataReader["Datum"], (double)dataReader["Prijs"], bool.Parse((string)dataReader["Betaald"]), t, (int)dataReader["Aantal"]);
                        bestellingen.Add(b);
                    }
                    dataReader.Close();
                    return bestellingen;
                } catch (Exception ex) {
                    BestellingRepositoryException bestellingRepositoryEx = new BestellingRepositoryException("GeefBestellingen niet gelukt", ex);
                    bestellingRepositoryEx.Data.Add("tekst", tekst);
                    throw bestellingRepositoryEx;
                } finally {
                    connection.Close();
                }
            }
        }
        #endregion
    }
}
