﻿using BusinessLayer.Enums;
using BusinessLayer.Interfaces;
using BusinessLayer.Model;
using DataLayerADO.Exceptions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayerADO.Repositories {
    public class ClubRepository : IClubRepository {
        #region Properties
        private string ConnectionString;
        #endregion

        #region Ctor
        public ClubRepository(string connectionString) {
            ConnectionString = connectionString;
        }
        #endregion

        #region Methods
        private SqlConnection GetConnection() {
            SqlConnection connection = new SqlConnection(ConnectionString);
            return connection;
        }

        public static Maat StringNaarMaat(string maat) {
            var item = Enum.Parse<Maat>(maat);
            return item;
        }

        //Werkt
        public bool BestaatClubId(int id) {
            string query = "SELECT COUNT(*) FROM Club WHERE ClubID=@id";
            SqlConnection connection = GetConnection();
            using (SqlCommand command = new SqlCommand(query, connection)) {
                try {
                    connection.Open();
                    command.Parameters.Add(new SqlParameter("@id", SqlDbType.Int));
                    command.Parameters["@id"].Value = id;
                    int clubBestaat = (int)command.ExecuteScalar();
                    if (clubBestaat > 0) {
                        return true;
                    }
                    return false;
                } catch (Exception ex) {
                    ClubRepositoryException clubRepositoryEx = new ClubRepositoryException("BestaatClubId niet gelukt", ex);
                    clubRepositoryEx.Data.Add("id", id);
                    throw clubRepositoryEx;
                } finally {
                    connection.Close();
                }
            }
        }

        //Werkt
        public List<Club> GeefClubs(string tekst) {
            string query = "SELECT * FROM Club WHERE ((convert(nvarchar(255), ClubID) LIKE '%'+ @clubid +'%') OR (Ploegnaam LIKE '%'+ @ploegnaam +'%') OR (Competitie LIKE '%'+ @competitie +'%'))";
            SqlConnection connection = GetConnection();
            using (SqlCommand command = new SqlCommand(query, connection)) {
                try {
                    List<Club> clubs = new List<Club>();

                    connection.Open();

                    command.Parameters.Add(new SqlParameter("@clubid", SqlDbType.NVarChar));
                    command.Parameters.Add(new SqlParameter("@ploegnaam", SqlDbType.NVarChar));
                    command.Parameters.Add(new SqlParameter("@competitie", SqlDbType.NVarChar));

                    command.Parameters["@clubid"].Value = tekst;
                    command.Parameters["@ploegnaam"].Value = tekst;
                    command.Parameters["@competitie"].Value = tekst;

                    SqlDataReader dataReader = command.ExecuteReader();
                    while (dataReader.Read()) {
                        Club c = new Club((int)dataReader["ClubID"], (string)dataReader["Ploegnaam"], (string)dataReader["Competitie"]);
                        clubs.Add(c);
                    }
                    dataReader.Close();
                    return clubs;
                } catch (Exception ex) {
                    ClubRepositoryException clubRepositoryEx = new ClubRepositoryException("GeefClub niet gelukt", ex);
                    clubRepositoryEx.Data.Add("tekst", tekst);
                    throw clubRepositoryEx;
                } finally {
                    connection.Close();
                }
            }
        }

        //Werkt
        public Club MaakClubAan(Club club) {
            string query = "INSERT INTO Club (Ploegnaam, Competitie) output INSERTED.ClubID VALUES(@ploegnaam, @competitie)";
            SqlConnection connection = GetConnection();
            using (SqlCommand command = new SqlCommand(query, connection)) {
                try {
                    connection.Open();
                    command.Parameters.Add(new SqlParameter("@ploegnaam", SqlDbType.NVarChar));
                    command.Parameters.Add(new SqlParameter("@competitie", SqlDbType.NVarChar));
                    command.Parameters["@ploegnaam"].Value = club.Ploegnaam;
                    command.Parameters["@competitie"].Value = club.Competitie;
                    int newId = (int)command.ExecuteScalar();
                    club.ZetId(newId);
                    return club;
                } catch (Exception ex) {
                    ClubRepositoryException clubRepositoryEx = new ClubRepositoryException("MaakClubAan niet gelukt", ex);
                    clubRepositoryEx.Data.Add("club", club);
                    throw clubRepositoryEx;
                } finally {
                    connection.Close();
                }
            }
        }

        //Werkt
        public void UpdateClub(Club club) {
            string query = "UPDATE Club SET Ploegnaam=@ploegnaam, Competitie=@competitie WHERE ClubID=@id";
            SqlConnection connection = GetConnection();
            using (SqlCommand command = new SqlCommand(query, connection)) {
                try {
                    connection.Open();
                    command.Parameters.Add(new SqlParameter("@ploegnaam", SqlDbType.NVarChar));
                    command.Parameters.Add(new SqlParameter("@competitie", SqlDbType.NVarChar));
                    command.Parameters.Add(new SqlParameter("@id", SqlDbType.Int));
                    command.Parameters["@ploegnaam"].Value = club.Ploegnaam;
                    command.Parameters["@competitie"].Value = club.Competitie;
                    command.Parameters["@id"].Value = club.Id;
                    command.ExecuteNonQuery();
                } catch (Exception ex) {
                    ClubRepositoryException clubRepositoryEx = new ClubRepositoryException("UpdateClub niet gelukt", ex);
                    clubRepositoryEx.Data.Add("club", club);
                    throw clubRepositoryEx;
                } finally {
                    connection.Close();
                }
            }
        }

        //Werkt
        public void VerwijderClub(int id) {
            string query = "DELETE FROM Club WHERE ClubID=@id";
            SqlConnection connection = GetConnection();
            using (SqlCommand command = new SqlCommand(query, connection)) {
                try {
                    connection.Open();
                    command.Parameters.Add(new SqlParameter("@id", SqlDbType.Int));
                    command.Parameters["@id"].Value = id;
                    command.ExecuteNonQuery();
                } catch (Exception ex) {
                    ClubRepositoryException clubRepositoryEx = new ClubRepositoryException("VerwijderClub niet gelukt", ex);
                    clubRepositoryEx.Data.Add("id", id);
                    throw clubRepositoryEx;
                } finally {
                    connection.Close();
                }
            }
        }
        #endregion
    }
}
