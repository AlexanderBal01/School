﻿using BusinessLayer.Enums;
using BusinessLayer.Interfaces;
using BusinessLayer.Model;
using DataLayerADO.Exceptions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayerADO.Repositories {
    public class ClubSetRepository : IClubSetRepository {
        #region Properties
        private string ConnectionString;
        #endregion

        #region Ctor
        public ClubSetRepository(string connectionString) {
            ConnectionString = connectionString;
        }

        #endregion

        #region Methods
        private SqlConnection GetConnection() {
            SqlConnection connection = new SqlConnection(ConnectionString);
            return connection;
        }

        public static Maat StringNaarMaat(string maat) {
            var item = Enum.Parse<Maat>(maat);
            return item;
        }

        //Werkt
        public bool BestaatClubSetId(int id) {
            string query = "SELECT COUNT(*) FROM ClubSet WHERE ClubSetID=@id";
            SqlConnection connection = GetConnection();
            using (SqlCommand command = new SqlCommand(query, connection)) {
                try {
                    connection.Open();
                    command.Parameters.Add(new SqlParameter("@id", SqlDbType.Int));
                    command.Parameters["@id"].Value = id;
                    int clubSetBestaat = (int)command.ExecuteScalar();
                    if (clubSetBestaat > 0) {
                        return true;
                    }
                    return false;
                } catch (Exception ex) {
                    ClubSetRepositoryException clubSetRepositoryEx = new ClubSetRepositoryException("BestaatClubSetId niet gelukt", ex);
                    clubSetRepositoryEx.Data.Add("id", id);
                    throw clubSetRepositoryEx;
                } finally {
                    connection.Close();
                }
            }
        }

        //Werkt
        public List<ClubSet> GeefClubSets(string tekst) {
            string query = "SELECT * FROM ClubSet WHERE ((convert(nvarchar(255), ClubSetID) LIKE '%'+ @clubsetid +'%') OR (convert(nvarchar(255), Versie) LIKE '%'+ @versie +'%') OR (IsThuis LIKE '%'+ @isthuis +'%'))";
            SqlConnection connection = GetConnection();
            using (SqlCommand command = new SqlCommand(query, connection)) {
                try {
                    List<ClubSet> clubSets = new List<ClubSet>();

                    connection.Open();

                    command.Parameters.Add(new SqlParameter("@clubsetid", SqlDbType.NVarChar));
                    command.Parameters.Add(new SqlParameter("@versie", SqlDbType.NVarChar));
                    command.Parameters.Add(new SqlParameter("@isthuis", SqlDbType.NVarChar));

                    
                    command.Parameters["@clubsetid"].Value = tekst;
                    command.Parameters["@versie"].Value = tekst;
                    command.Parameters["@isthuis"].Value = tekst;

                    SqlDataReader dataReader = command.ExecuteReader();
                    while (dataReader.Read()) {
                        ClubSet cs = new ClubSet((int)dataReader["ClubSetID"], bool.Parse((string)dataReader["IsThuis"]), (int)dataReader["Versie"]);
                        clubSets.Add(cs);
                    }
                    dataReader.Close();
                    return clubSets;
                } catch (Exception ex) {
                    ClubSetRepositoryException clubSetRepositoryEx = new ClubSetRepositoryException("GeefClubSets niet gelukt", ex);
                    clubSetRepositoryEx.Data.Add("tekst", tekst);
                    throw clubSetRepositoryEx;
                } finally {
                    connection.Close();
                }
            }
        }

        //Werkt
        public ClubSet MaakClubSetAan(ClubSet clubSet) {
            string query = "INSERT INTO ClubSet (Versie, IsThuis) output INSERTED.ClubSetID VALUES(@versie, @isThuis)";
            SqlConnection connection = GetConnection();
            using (SqlCommand command = new SqlCommand(query, connection)) {
                try {
                    connection.Open();
                    command.Parameters.Add(new SqlParameter("@versie", SqlDbType.Int));
                    command.Parameters.Add(new SqlParameter("@isThuis", SqlDbType.NVarChar));
                    command.Parameters["@versie"].Value = clubSet.Versie;
                    command.Parameters["@isThuis"].Value = clubSet.IsThuis.ToString();
                    int newId = (int)command.ExecuteScalar();
                    clubSet.ZetId(newId);
                    return clubSet;
                } catch (Exception ex) {
                    ClubSetRepositoryException clubSetRepositoryEx = new ClubSetRepositoryException("MaakClubSetAan niet gelukt", ex);
                    clubSetRepositoryEx.Data.Add("clubSet", clubSet);
                    throw clubSetRepositoryEx;
                } finally {
                    connection.Close();
                }
            }
        }

        //Werkt
        public void UpdateClubSet(ClubSet clubSet) {
            string query = "UPDATE ClubSet SET Versie=@versie, IsThuis=@isThuis WHERE ClubSetID=@id";
            SqlConnection connection = GetConnection();
            using (SqlCommand command = new SqlCommand(query, connection)) {
                try {
                    connection.Open();
                    command.Parameters.Add(new SqlParameter("@versie", SqlDbType.Int));
                    command.Parameters.Add(new SqlParameter("@isThuis", SqlDbType.Bit));
                    command.Parameters.Add(new SqlParameter("@id", SqlDbType.Int));
                    command.Parameters["@versie"].Value = clubSet.Versie;
                    command.Parameters["@isThuis"].Value = clubSet.IsThuis;
                    command.Parameters["@id"].Value = clubSet.Id;
                    command.ExecuteNonQuery();
                } catch (Exception ex) {
                    ClubSetRepositoryException clubSetRepositoryEx = new ClubSetRepositoryException("UpdateClubSet niet gelukt", ex);
                    clubSetRepositoryEx.Data.Add("clubSet", clubSet);
                    throw clubSetRepositoryEx;
                } finally {
                    connection.Close();
                }
            }
        }

        //Werkt
        public void VerwijderClubSet(int id) {
            string query = "DELETE FROM ClubSet WHERE ClubSetID=@id";
            SqlConnection connection = GetConnection();
            using (SqlCommand command = new SqlCommand(query, connection)) {
                try {
                    connection.Open();
                    command.Parameters.Add(new SqlParameter("@id", SqlDbType.Int));
                    command.Parameters["@id"].Value = id;
                    command.ExecuteNonQuery();
                } catch (Exception ex) {
                    ClubSetRepositoryException clubSetRepositoryEx = new ClubSetRepositoryException("VerwijderClubSet niet gelukt", ex);
                    clubSetRepositoryEx.Data.Add("id", id);
                    throw clubSetRepositoryEx;
                } finally {
                    connection.Close();
                }
            }
        }
        #endregion
    }
}
