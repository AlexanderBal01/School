﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayerADO.Exceptions {
    class TruitjeRepositoryException : Exception {
        #region Ctor
        public TruitjeRepositoryException(string message) : base(message) {
        }

        public TruitjeRepositoryException(string message, Exception innerException) : base(message, innerException) {
        }
        #endregion
    }
}
