﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayerADO.Exceptions {
    public class BestellingRepositoryException : Exception {
        #region Ctor
        public BestellingRepositoryException(string message) : base(message) {
        }

        public BestellingRepositoryException(string message, Exception innerException) : base(message, innerException) {
        }
        #endregion
    }
}
