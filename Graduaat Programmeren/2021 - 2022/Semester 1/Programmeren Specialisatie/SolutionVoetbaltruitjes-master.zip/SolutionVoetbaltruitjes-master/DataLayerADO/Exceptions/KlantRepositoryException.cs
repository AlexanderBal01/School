﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayerADO.Exceptions {
    public class KlantRepositoryException : Exception {
        #region Ctor
        public KlantRepositoryException(string message) : base(message) {
        }

        public KlantRepositoryException(string message, Exception innerException) : base(message, innerException) {
        }
        #endregion
    }
}
