﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayerADO.Exceptions {
    public class ClubSetRepositoryException : Exception {
        #region Ctor
        public ClubSetRepositoryException(string message) : base(message) {
        }

        public ClubSetRepositoryException(string message, Exception innerException) : base(message, innerException) {
        }
        #endregion
    }
}
