﻿using Data_Layer.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Layer {
    public class EscapeFromTheWoodsContext : DbContext {
        private string ConnectionString;

        public DbSet<ActieLogEF> ActieLogs { get; set; }

        public DbSet<BoomLogEF> BoomLogs { get; set; }

        public DbSet<AapLogEF> AapLogs { get; set; }

        public EscapeFromTheWoodsContext(string connectionString) {
            ConnectionString = connectionString;
        }

        protected override void OnConfiguring(DbContextOptionsBuilder builder) {
            builder.UseSqlServer(ConnectionString);
        }
    }
}
