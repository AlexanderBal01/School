﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Layer.Model {
    public class AapLogEF {
        public int Id { get; set; }

        public int AapId { get; set; }

        public string AapNaam { get; set; }

        public int BosId { get; set; }

        public int SequenceNumber { get; set; }

        public int BoomId { get; set; }

        public int X { get; set; }

        public int Y { get; set; }
    }
}
