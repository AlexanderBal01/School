﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Layer.Model {
    public class ActieLogEF {
        public int Id { get; set; }

        public int BosId { get; set; }

        public int AapId { get; set; }

        public string Bericht { get; set; }

    }
}
