﻿using Data_Layer.Model;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Layer {
    public class DBController {
        private string ConnectionString;

        public DBController(string connectionString) {
            ConnectionString = connectionString;
        }

        public void AddActieLog(ActieLogEF actieLogEF) {
            using (var context = new EscapeFromTheWoodsContext(ConnectionString)) {
                context.ActieLogs.Add(actieLogEF);
                context.SaveChanges();
            }
        }

        public void AddBoomLog(BoomLogEF boomLogEF) {
            using (var context = new EscapeFromTheWoodsContext(ConnectionString)) {
                context.BoomLogs.Add(boomLogEF);
                context.SaveChanges();
            }
        }

        public void AddAapLog(AapLogEF aapLogEF) {
            using (var context = new EscapeFromTheWoodsContext(ConnectionString)) {
                context.AapLogs.Add(aapLogEF);
                context.SaveChanges();
            }
        }

        public int GeefLaatsteBosId() {
            int id = 0;
            using (var ctx = new EscapeFromTheWoodsContext(ConnectionString)) {
                int log = ctx.ActieLogs.Count();
                if (log > 0) {
                    id = ctx.ActieLogs.ToList().Last().BosId;
                }
                return id;
            }
        }

        public int GeefLaatsteAapId() {
            int id = 0;
            using (var context = new EscapeFromTheWoodsContext(ConnectionString)) {
                int log = context.ActieLogs.Count();
                if (log > 0) {
                    id = context.ActieLogs.Select(x => x.AapId).ToList().Max();
                }
                return id;
            }
        }

    }
}
