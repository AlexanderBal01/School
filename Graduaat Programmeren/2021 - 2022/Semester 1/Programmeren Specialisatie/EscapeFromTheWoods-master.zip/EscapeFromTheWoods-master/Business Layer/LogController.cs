﻿using Data_Layer;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business_Layer {
    public static class LogController {
        public static Log Log = new Log();
        public static DBController DB = new DBController(ConfigurationManager.ConnectionStrings["connectionstringEF"].ConnectionString.ToString());
    }
}
