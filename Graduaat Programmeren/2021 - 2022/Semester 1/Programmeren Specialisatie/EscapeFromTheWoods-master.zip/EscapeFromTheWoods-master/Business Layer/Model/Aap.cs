﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business_Layer.Model {
    public class Aap {
        public int Id { get; set; }
        public string Naam { get; set; }
        public int Sprongen { get; set; }
        public SortedList<int, Boom> GepasseerdeBomen { get; set; } = new SortedList<int, Boom>();
        public SortedList<int, Boom> CalculatedPath { get; set; } = new SortedList<int, Boom>();
        
        public Aap(int id, string naam) {
            Id = id;
            Naam = naam;
        }

        public bool Spring(Bos bos) {
            do {
                Boom tree = bos.GetClosestTree(GepasseerdeBomen.Last().Value, this);
                double distanceToBorder = bos.GetDistanceToBorder(GepasseerdeBomen.Last().Value);
                double distanceToClosestTree = bos.GetDistance(GepasseerdeBomen.Last().Value, tree);
                if (distanceToBorder < distanceToClosestTree) {
                    CalculatedPath.Add(++Sprongen, new Boom(9696));

                    Console.WriteLine($"{Id}: Aap: {Naam} jumped out the forest!");
                    LogController.Log.TakenList.Add(Task.Run(() => LogController.Log.ActionLog(bos.Id, this.Id, $"{bos.Id}: Monkey: {Naam} jumped out of the forest")));
                    bos.Logs.Add($"{bos.Id}: Aap: {Naam} jumped out of the forest");
                } else {
                    Boom boom1 = GepasseerdeBomen[Sprongen];
                    CalculatedPath.Add(++Sprongen, tree);
                    GepasseerdeBomen.Add(Sprongen, tree);

                    Console.WriteLine($"{bos.Id}: Aap: {Naam} jumps from {boom1.Id} to {tree.Id} at {tree.X}, {tree.Y}");
                    LogController.Log.TakenList.Add(Task.Run(() => LogController.Log.ActionLog(bos.Id, this.Id, $"{bos.Id}: Monkey: {Naam} jumps from {boom1.Id} to {tree.Id} at {tree.X}, {tree.Y}")));
                    LogController.Log.TakenList.Add(Task.Run(() => LogController.Log.WriteAapLog(bos, this, tree)));
                    bos.Logs.Add($"{bos.Id}:  Aap: {Naam} jumps from {boom1.Id} to {tree.Id} at {tree.X}, {tree.Y}");
                    LogController.Log.LaatAapSlingerenInHetBos(bos, boom1, tree);
                }
            } while (CalculatedPath.Last().Value.Id != 9696);
            return true;
        }
    }
}
