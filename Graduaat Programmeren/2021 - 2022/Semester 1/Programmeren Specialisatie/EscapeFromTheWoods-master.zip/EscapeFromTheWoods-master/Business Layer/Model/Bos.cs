﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace Business_Layer.Model {
    public class Bos {
        public int Id { get; set; }

        public int XMaxValue { get; set; }

        public int YMaxValue { get; set; }

        public int ApenCounter { get; set; }

        public List<Boom> Bomen { get; set; } = new List<Boom>();

        public List<Aap> Apen { get; set; } = new List<Aap>();

        public List<string> Logs { get; set; } = new List<string>();

        public Image BitMap { get; set; }

        public Bos(int id, int bomen, int apen) {
            Id = id;
            XMaxValue = (int)(bomen * 10);
            YMaxValue = XMaxValue;
            ApenCounter = LogController.DB.GeefLaatsteAapId();
            GenerateTrees(bomen);
            GenerateMonkeyCharacters(apen);
        }

        private List<string> NaamList = new List<string>
        {
            "Alexander",
            "Jan",
            "Pieter",
            "Henri",
            "Jeroen",
            "Milan",
            "Yorge",
            "Petra",
            "Rufus",
            "Jens",
            "Maarten",
            "Guani",
            "Bryan",
            "Aaron",
            "Jeffe",
            "Frietsel",
            "Okan",
            "Patrick",
            "Ozgun",
            "Maxine",
            "Yahya",
            "Carti",
            "Jhonson",
            "Moderna",
            "Astrazeneca"
        };

        private void GenerateTrees(int bomen) {
            int counter = 0;
            Random r = new Random();
            for (int i = 0; i < bomen; i++) {
                int r1 = r.Next(1, XMaxValue - 20);
                int r2 = r.Next(1, YMaxValue - 20);
                Boom boom = new Boom { Id = counter++, X = r1, Y = r2 };

                if (!Bomen.Contains(boom)) {
                    LogController.Log.TakenList.Add(Task.Run(() => LogController.Log.TreeLog(this, boom)));
                    Console.WriteLine($"{Id}: creating a tree at {boom.X},{boom.Y} with Id: {boom.Id}");
                    Bomen.Add(boom);
                } else
                    i--;
            }
            Console.WriteLine($"{Id}: Generated forest with {Bomen.Count} amount of trees with Id: {Id}");
            LogController.Log.CreateBitMap(this);
        }


        private void GenerateMonkeyCharacters(int apen) {
            Random rnd = new Random();
            if (Id % 2 == 0)
                NaamList.Reverse();
            for (int i = 1; i < apen + 1; i++) {
                int random = rnd.Next(Bomen.Count - 1);
                Aap aap1 = new Aap(ApenCounter++, NaamList[i]);
                if (Bomen[random].Aap != null) {
                    i--;
                } else {
                    aap1.GepasseerdeBomen.Add(aap1.Sprongen, Bomen[random]);
                    Bomen[random].Aap = aap1;
                    Apen.Add(aap1);
                    Console.WriteLine($"{Id}: Placing my new monkey: {aap1.Naam} with ID {aap1.Id} in tree: {Bomen[random].Id}");
                    LogController.Log.TekenAapOpImage(this, Bomen[random]);
                }
            }
        }


        public Boom GetClosestTree(Boom boom, Aap aap) {
            double n = XMaxValue;
            Boom b = null;

            for (int i = 0; i < Bomen.Count; i++) {
                if (Bomen[i] != boom && !aap.GepasseerdeBomen.ContainsValue(Bomen[i])) {
                    if (GetDistance(boom, Bomen[i]) < n) {
                        n = GetDistance(boom, Bomen[i]);
                        b = Bomen[i];
                    }
                }
            }
            return b;
        }

        public double GetDistance(Boom boom1, Boom boom2) {
            return Math.Sqrt(Math.Pow(boom1.X - boom2.X, 2) + Math.Pow(boom1.Y - boom2.Y, 2));
        }

        public double GetDistanceToBorder(Boom boom) {
            double afstand = (new List<double>()
            {
                XMaxValue - boom.X,
                YMaxValue - boom.Y,
                boom.X - 0,
                boom.Y - 0
            }).Min();
            return afstand;
        }

    }
}
