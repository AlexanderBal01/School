﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business_Layer.Model {
    public class Boom {
        public int Id { get; set; }
        public int X { get; set; }
        public int Y { get; set; }
        public Aap Aap { get; set; }

        public Boom() { }

        public Boom(int id) {
            Id = id; 
        }
    }
}
