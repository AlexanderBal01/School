﻿using Business_Layer.Model;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Business_Layer {
    public class Speler {
        public int BosReaper { get; set; }

        public Speler() {

        }

        public Speler(int bosReaper) {
            BosReaper = bosReaper;
        }

        public async Task<bool> LaatSpelerStart(int spelen, int bomen, int apen) {
            List<Task> tasks = new List<Task>();

            for (int i = 0; i < spelen; i++) {
                Task t = new Task(() => SpeelSpel(bomen, apen));
                tasks.Add(t);
            }
            foreach (Task t in tasks) {
                t.Start();
            }
            int count = GetFileCount();
            while (count != spelen) {
                Thread.Sleep(1000);
                count = GetFileCount();
            }
            await Task.WhenAll(LogController.Log.TakenList);
            return true;
        }

        public void SpeelSpel(int bomen, int apen) {
            Bos bos = new Bos(BosReaper++, bomen, apen);
            for (int i = 0; i < bos.Apen.Count; i++) {
                Aap aap = bos.Apen[i];
                aap.Spring(bos);
            }
            LogController.Log.WriteImage(bos.Id, bos.BitMap);
            LogController.Log.DefineTxtLog(bos);
        }

        public int GetFileCount() {
            DirectoryInfo di = new DirectoryInfo(LogController.Log.PathToFolder);
            int count = di.GetFiles().Where(x => x.Extension == ".jpg").Count();
            return count;
        }
    }
}
