﻿using Business_Layer.Model;
using Data_Layer.Model;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business_Layer {
    public class Log {
        public string PathToFolder = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + @"\EscapeFromTheWoods";
        public List<Task> TakenList = new List<Task>();
        private int S = 2;
        private int TH = 20;

        public Log() {
            DirectoryInfo dir = new DirectoryInfo(PathToFolder);
            if (!dir.Exists)
                dir.Create();

            foreach (FileInfo file in dir.GetFiles()) {
                file.Delete();
            }
        }

        public void CreateBitMap(Bos bos) {
            Console.WriteLine($"{bos.Id} Starting writing bitmap for forest {bos.Id}");
            Bitmap image = new Bitmap(bos.XMaxValue * S, bos.YMaxValue * S);
            Pen pen = new Pen(Color.Green);
            Graphics graphics = Graphics.FromImage(image);
            foreach (Boom boom in bos.Bomen) {
                graphics.DrawEllipse(pen, boom.X * S, boom.Y * S, TH, TH);
            }
            bos.BitMap = image;
        }

        public void TekenAapOpImage(Bos bos, Boom boom) {
            Brush aapBrush = new SolidBrush(Color.White);
            Image image = bos.BitMap;
            Graphics graphics = Graphics.FromImage(image);
            graphics.FillEllipse(aapBrush, boom.X * S, boom.Y * S, TH, TH);
        }

        public void LaatAapSlingerenInHetBos(Bos bos, Boom boom1, Boom boom2) {
            Pen pen = new Pen(Color.White);
            Image image = bos.BitMap;
            Graphics graphics = Graphics.FromImage(image);
            graphics.DrawLine(pen, new Point { X = boom1.X * S + TH / 2, Y = boom1.Y * S + TH / 2 },
                new Point { X = boom2.X * S + TH / 2, Y = boom2.Y * S + TH / 2 });
        }

        public void WriteImage(int key, Image image) {
            image.Save(Path.Combine(PathToFolder, $"Woodmap_{key}.jpg"), ImageFormat.Jpeg);
        }

        public void ActionLog(int bosId, int aapId, string bericht) {
            Console.WriteLine($"Writing log: {bericht}");
            LogController.DB.AddActieLog(
                new ActieLogEF {
                    BosId = bosId,
                    AapId = aapId,
                    Bericht = bericht
                }
                );
        }

        public void WriteAapLog(Bos bos, Aap aap, Boom boom) {
            Console.WriteLine($"Writing monkeylog: {aap.Id}, {aap.Naam}");
            LogController.DB.AddAapLog(
                new AapLogEF {
                    AapId = aap.Id,
                    AapNaam = aap.Naam,
                    BosId = bos.Id,
                    SequenceNumber = aap.Sprongen,
                    BoomId = boom.Id,
                    X = boom.X,
                    Y = boom.Y
                }
                );
        }

        public void TreeLog(Bos bos, Boom boom) {
            Console.WriteLine($"Writing TreeLog: Forest_{boom.Id} Tree_{boom.Id}");
            LogController.DB.AddBoomLog(
                new BoomLogEF {
                    BosId = bos.Id,
                    BoomId = boom.Id,
                    X = boom.X,
                    Y = boom.Y
                }
                );
        }

        public void DefineTxtLog(Bos bos) {
            Console.WriteLine($"Writing textlog: Forest_{bos.Id}");
            FileStream fs = new FileStream($"ForestLog_id_{bos.Id}", FileMode.OpenOrCreate);
            using (StreamWriter writer = new StreamWriter(PathToFolder + $@"\ForestLog_id_{bos.Id}.txt")) {
                foreach (string r in bos.Logs) {
                    writer.WriteLine(r);
                };
                fs.Close();
            }
        }
    }
}
