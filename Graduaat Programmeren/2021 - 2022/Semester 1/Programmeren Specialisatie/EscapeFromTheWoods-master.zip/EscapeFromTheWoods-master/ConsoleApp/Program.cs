﻿using Data_Layer;
using System;
using System.Configuration;

namespace ConsoleApp {
    internal class Program {
        static void Main(string[] args) {
            string ConnectionStringEF = ConfigurationManager.ConnectionStrings["connectionstringEF"].ConnectionString.ToString();
            //EscapeFromTheWoodsContext context = new EscapeFromTheWoodsContext(ConnectionStringEF);
            //context.Database.EnsureDeleted();
            //context.Database.EnsureCreated();

            AppGenerator app = new AppGenerator();
            app.SetTitelApp();
            app.CreateActieWithUI();
        }
    }
}
