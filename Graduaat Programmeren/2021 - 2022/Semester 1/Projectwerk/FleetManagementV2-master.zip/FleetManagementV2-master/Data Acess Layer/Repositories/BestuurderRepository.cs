﻿using Business_Layer;
using Business_Layer.Exceptions;
using Business_Layer.Interfaces;
using Data_Access_Layer.Exceptions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Access_Layer.Repositories {
    public class BestuurderRepository : IBestuurderRepository {
        private string ConnectionString;

        public BestuurderRepository(string connectionString) {
            ConnectionString = connectionString;
        }

        private SqlConnection GetConnection() {
            SqlConnection connection = new SqlConnection(ConnectionString);
            return connection;
        }

        public List<Bestuurder> GeefBestuurder(string zoekTekst) {
            SqlConnection connection = GetConnection();
            string query = "SELECT * FROM Bestuurder WHERE ((rijksregister LIKE '%'+ @rijksregister +'%') OR (naam LIKE '%'+ @naam +'%') OR (voorNaam LIKE'%'+ @voorNaam +'%'))";
            List<Bestuurder> bestuurders = new List<Bestuurder>();

            using (SqlCommand command = connection.CreateCommand()) {
                try {
                    connection.Open();
                    command.CommandText = query;

                    command.Parameters.Add(new SqlParameter("@naam", SqlDbType.NVarChar));
                    command.Parameters.Add(new SqlParameter("@voorNaam", SqlDbType.NVarChar));
                    command.Parameters.Add(new SqlParameter("@rijksregister", SqlDbType.NVarChar));

                    command.Parameters["@naam"].Value = zoekTekst;
                    command.Parameters["@voorNaam"].Value = zoekTekst;
                    command.Parameters["@rijksregister"].Value = zoekTekst;

                    SqlDataReader dataReader = command.ExecuteReader();
                    while (dataReader.Read()) {
                        string strhsnr = (string)dataReader["straatHuisnr"];
                        string[] a = strhsnr.Split(" ").ToArray();
                        Bestuurder bestuurder = new Bestuurder((string)dataReader["naam"], (string)dataReader["voorNaam"], (string)dataReader["rijksregister"], (string)dataReader["typeRijbewijs"],
                            (DateTime)dataReader["geboorteDatum"] , new Adres(a[0], a[1], (string)dataReader["stad"], (string)dataReader["postcode"]));
                        if (dataReader["voertuigID"] != DBNull.Value) bestuurder.SetVoertuig(new Voertuig((string)dataReader["voertuigID"]));
                        if (dataReader["tankKaartID"] != DBNull.Value) bestuurder.SetTankKaart(new TankKaart((int)dataReader["tankKaartID"]));
                        bestuurder.SetId((int)dataReader["id"]);
                        bestuurders.Add(bestuurder);
                    }
                    dataReader.Close();
                    return bestuurders;
                } catch (Exception ex) {
                    throw new BestuurderManagerException("GeefBestuurder niet gelukt", ex);
                } finally {
                    connection.Close();
                }
            }
        }

        public bool BestaatBestuurder(int id) {
            SqlConnection connection = GetConnection();
            string query = "SELECT COUNT(*) FROM Bestuurder WHERE id = @id";
            using (SqlCommand command = connection.CreateCommand()) {
                try {
                    connection.Open();
                    command.CommandText = query;

                    SqlParameter paramId = new SqlParameter();
                    paramId.ParameterName = "@id";
                    paramId.DbType = DbType.Int32;
                    paramId.Value = id;
                    command.Parameters.Add(paramId);

                    int bestuurderExist = (int)command.ExecuteScalar();
                    if (bestuurderExist >0) {
                        return true;
                    }
                    return false;
                } catch (Exception ex) {
                    throw new BestuurderRepositoryException("BestaatBestuurder niet gelukt", ex);
                } finally {
                    connection.Close();
                }
            }
        }

        public void BestuurderToevoegen(Bestuurder bestuurder) {
            SqlConnection connection = GetConnection();
            string query = "INSERT INTO dbo.Bestuurder VALUES(@naam, @voorNaam, @rijksregister, @typeRijbewijs, @geboorteDatum, @tankKaartID, @voertuigID, @straatHuisnr, @stad, @postcode)";
            using (SqlCommand command = connection.CreateCommand()) {
                try {
                    string straat = $"{bestuurder.Adres.Straat} {bestuurder.Adres.Huisnummer}";
                    connection.Open();
                    command.Parameters.Add(new SqlParameter("@naam", SqlDbType.NVarChar));
                    command.Parameters.Add(new SqlParameter("@voorNaam", SqlDbType.NVarChar));
                    command.Parameters.Add(new SqlParameter("@rijksregister", SqlDbType.NVarChar));
                    command.Parameters.Add(new SqlParameter("@typeRijbewijs", SqlDbType.NVarChar));
                    command.Parameters.Add(new SqlParameter("@geboorteDatum", SqlDbType.DateTime));
                    command.Parameters.Add(new SqlParameter("@tankKaartID", SqlDbType.Int));
                    command.Parameters.Add(new SqlParameter("@voertuigID", SqlDbType.NVarChar));
                    command.Parameters.Add(new SqlParameter("@straatHuisnr", SqlDbType.NVarChar));
                    command.Parameters.Add(new SqlParameter("@stad", SqlDbType.NVarChar));
                    command.Parameters.Add(new SqlParameter("@postcode", SqlDbType.NVarChar));

                    command.CommandText = query;
                    command.Parameters["@naam"].Value = bestuurder.Naam;
                    command.Parameters["@voorNaam"].Value = bestuurder.Voornaam;
                    command.Parameters["@rijksregister"].Value = bestuurder.Rijksregister;
                    command.Parameters["@typeRijbewijs"].Value = bestuurder.TypeRijbewijs;
                    command.Parameters["@geboorteDatum"].Value = bestuurder.GeboorteDatum;
                    if (bestuurder.TankKaart == null) {
                        command.Parameters["@tankKaartID"].Value = SqlInt32.Null;
                    } else {
                        command.Parameters["@tankKaartID"].Value = bestuurder.TankKaart.KaartNummer;
                    }
                    if (bestuurder.Voertuig == null) {
                        command.Parameters["@voertuigID"].Value = SqlInt32.Null;
                    } else {
                        command.Parameters["@voertuigID"].Value = bestuurder.Voertuig.ChassisNummer;
                    }


                    command.Parameters["@straatHuisnr"].Value = straat;
                    command.Parameters["@stad"].Value = bestuurder.Adres.Stad;
                    command.Parameters["@postcode"].Value = bestuurder.Adres.Postcode;
                    command.ExecuteNonQuery();
                } catch (Exception ex) {
                    throw new BestuurderRepositoryException("BestuurderToevoegen niet gelukt", ex);
                } finally {
                    connection.Close();
                }
            }
        }

        public void VerwijderBestuurder(int id) {
            SqlConnection connection = GetConnection();
            string query = "DELETE FROM dbo.Bestuurder WHERE id=@id";

            using (SqlCommand command = connection.CreateCommand()) {
                connection.Open();
                try {
                    command.Parameters.Add(new SqlParameter("@id", SqlDbType.Int));

                    command.CommandText = query;
                    command.Parameters["@id"].Value = id;

                    int n = command.ExecuteNonQuery();
                    if (n != 1) throw new BestuurderRepositoryException("Meer dan 1 rij gewist");
                } catch (Exception ex) {
                    throw new BestuurderRepositoryException("VerwijderBestuurder niet gelukt", ex);
                } finally {
                    connection.Close();
                }
            }
        }

        public void UpdateBestuurder(Bestuurder bestuurder) {
            string query = "UPDATE dbo.bestuurder SET naam=@naam, voorNaam=@voorNaam, rijksregister=@rijksregister," +
                "typeRijbewijs=@typeRijbewijs, geboorteDatum=@geboorteDatum, tankKaartID=@tankKaartID, voertuigID=@voertuigID, straatHuisnr=@straatHuisnr, stad=@stad, postcode=@postcode WHERE id=@id";
            SqlConnection conn = GetConnection();
            using (SqlCommand command = new SqlCommand(query, conn)) {
                try {
                    string straat = $"{bestuurder.Adres.Straat} {bestuurder.Adres.Huisnummer}";
                    conn.Open();
                    command.Parameters.Add(new SqlParameter("@id", SqlDbType.Int));
                    command.Parameters.Add(new SqlParameter("@naam", SqlDbType.NVarChar));
                    command.Parameters.Add(new SqlParameter("@voorNaam", SqlDbType.NVarChar));
                    command.Parameters.Add(new SqlParameter("@rijksregister", SqlDbType.NVarChar));
                    command.Parameters.Add(new SqlParameter("@typeRijbewijs", SqlDbType.NVarChar));
                    command.Parameters.Add(new SqlParameter("@geboorteDatum", SqlDbType.DateTime));
                    command.Parameters.Add(new SqlParameter("@tankKaartID", SqlDbType.Int));
                    command.Parameters.Add(new SqlParameter("@voertuigID", SqlDbType.NVarChar));
                    command.Parameters.Add(new SqlParameter("@straatHuisnr", SqlDbType.NVarChar));
                    command.Parameters.Add(new SqlParameter("@stad", SqlDbType.NVarChar));
                    command.Parameters.Add(new SqlParameter("@postcode", SqlDbType.Int));

                    command.CommandText = query;
                    command.Parameters["@id"].Value = bestuurder.Id;
                    command.Parameters["@naam"].Value = bestuurder.Naam;
                    command.Parameters["@voorNaam"].Value = bestuurder.Voornaam;
                    command.Parameters["@rijksregister"].Value = bestuurder.Rijksregister;
                    command.Parameters["@typeRijbewijs"].Value = bestuurder.TypeRijbewijs;
                    command.Parameters["@geboorteDatum"].Value = bestuurder.GeboorteDatum;
                    command.Parameters["@tankKaartID"].Value = bestuurder.TankKaart.KaartNummer;
                    command.Parameters["@voertuigID"].Value = bestuurder.Voertuig.ChassisNummer;
                    command.Parameters["@straatHuisnr"].Value = straat;
                    command.Parameters["@stad"].Value = bestuurder.Adres.Stad;
                    command.Parameters["@postcode"].Value = bestuurder.Adres.Postcode;
                    command.ExecuteNonQuery();
                } catch (Exception ex) {
                    BestuurderRepositoryException dbex = new BestuurderRepositoryException("UpdateBestuurder niet gelukt", ex);
                    dbex.Data.Add("Bestuurder", bestuurder);
                    throw dbex;
                } finally {
                    conn.Close();
                }
            }
        }

        public void VerwijderTankkaartVanBestuurder(Bestuurder bestuurder) {
            string query = "UPDATE dbo.bestuurder SET tankKaartID=@tankkaartIdNull WHERE tankKaartID=@tankkaartId";
            SqlConnection connection = GetConnection();
            using (SqlCommand command = new SqlCommand(query, connection)) {
                try {
                    connection.Open();
                    command.Parameters.Add(new SqlParameter("@tankkaartId", SqlDbType.Int));
                    command.Parameters.Add(new SqlParameter("@tankkaartIdNull", SqlDbType.Int));
                    command.Parameters["@tankkaartId"].Value = bestuurder.TankKaart.KaartNummer;
                    command.Parameters["@tankkaartIdNull"].Value = SqlInt32.Null;
                    command.ExecuteNonQuery();
                } catch (Exception ex) {
                    BestuurderRepositoryException dbex = new BestuurderRepositoryException("VerwijderTankkaartVanBestuurder niet gelukt", ex);
                    dbex.Data.Add("Bestuurder", bestuurder);
                    throw dbex;
                } finally {
                    connection.Close();
                }
            }
        }

        public void VerwijderVoertuigVanBestuurder(Bestuurder bestuurder) {
            string query = "UPDATE dbo.bestuurder SET voertuigID=@voertuigIDNull WHERE voertuigID=@id";
            SqlConnection connection = GetConnection();
            using (SqlCommand command = new SqlCommand(query, connection)) {
                try {
                    connection.Open();
                    command.Parameters.Add(new SqlParameter("@voertuigIDNull", SqlDbType.NVarChar));
                    command.Parameters.Add(new SqlParameter("@id", SqlDbType.NVarChar));
                    command.Parameters["@voertuigIDNull"].Value = SqlInt32.Null;
                    command.Parameters["@id"].Value = bestuurder.Voertuig.ChassisNummer;
                    command.ExecuteNonQuery();
                } catch (Exception ex) {
                    BestuurderRepositoryException dbex = new BestuurderRepositoryException("VerwijderVoertuigVanBestuurder niet gelukt", ex);
                    dbex.Data.Add("bestuurder", bestuurder);
                    throw dbex;
                } finally {
                    connection.Close();
                }
            }
        }
    }
}
