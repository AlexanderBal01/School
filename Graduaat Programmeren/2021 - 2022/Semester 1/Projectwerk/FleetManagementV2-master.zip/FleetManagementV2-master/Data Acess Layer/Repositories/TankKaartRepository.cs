﻿using Business_Layer;
using Business_Layer.Interfaces;
using Data_Access_Layer.Exceptions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Access_Layer.Repositories {
    public class TankKaartRepository : ITankKaartRepository {
        private string ConnectionString;

        public TankKaartRepository(string connectionString) {
            ConnectionString = connectionString;
        }

        private SqlConnection GetConnection() {
            SqlConnection connection = new SqlConnection(ConnectionString);
            return connection;
        }


        public List<BrandstofType> maakBrandstofList(string DbBrandstofString) {
            List<BrandstofType> bsList = new List<BrandstofType>();
            var substring = DbBrandstofString.Split(" ");
            foreach (var item in substring) {
                try {
                    var tussenitem = Enum.Parse<BrandstofType>(item);
                    bsList.Add(tussenitem);
                }
                catch (Exception ex)
                {
                    throw new TankKaartRepositoryException("CRINGE", ex);
                }
            }
            return bsList;
        }


        public bool BestaatTankkaart(int kaartNummer) {
            SqlConnection connection = GetConnection();
            string query = "SELECT COUNT(*) FROM TankKaart WHERE kaartNummer=@kaartNummer";

            using (SqlCommand command = connection.CreateCommand()) {
                try {
                    connection.Open();
                    command.CommandText = query;

                    SqlParameter paramId = new SqlParameter();
                    paramId.ParameterName = "@kaartNummer";
                    paramId.DbType = DbType.Int32;
                    paramId.Value = kaartNummer;
                    command.Parameters.Add(paramId);

                    int tankKaartExist = (int)command.ExecuteScalar();
                    if (tankKaartExist > 0) {
                        return true;
                    }
                    return false;
                } catch (Exception ex) {
                    throw new TankKaartRepositoryException("BestaatBestuurder niet gelukt", ex);
                } finally {
                    connection.Close();
                }
            }
        }

        public TankKaart GeefTankkaart(int kaartnummer) {
            SqlConnection connection = GetConnection();
            string query = "SELECT t1.id, t1.naam, t1.voorNaam, t1.rijksregister, t1.typeRijbewijs, t1.geboorteDatum, t2.* FROM Bestuurder t1 " +
                "INNER JOIN TankKaart t2 ON t1.tankKaartID=t2.kaartNummer WHERE t2.kaartNummer = @kaartNummer";

            using (SqlCommand command = connection.CreateCommand()) {
                try {
                    connection.Open();
                    command.CommandText = query;

                    SqlParameter paramKaartNummer = new SqlParameter();
                    paramKaartNummer.ParameterName = "@kaartNummer";
                    paramKaartNummer.DbType = DbType.Int32;
                    paramKaartNummer.Value = kaartnummer;
                    command.Parameters.Add(paramKaartNummer);

                    Bestuurder b = null;

                    SqlDataReader dataReader = command.ExecuteReader();
                    dataReader.Read();
                    if (b == null) {
                        b = new Bestuurder((int)dataReader["id"],(string)dataReader["naam"], (string)dataReader["voorNaam"], (string)dataReader["rijksregister"], (string)dataReader["typeRijbewijs"], (DateTime)dataReader["geboorteDatum"]);
                    }
                    TankKaart t = new TankKaart((int)dataReader["kaartNummer"], (DateTime)dataReader["geldigheidsDatum"], (int)dataReader["pincode"], maakBrandstofList((string)dataReader["brandstofType"]), b, (bool)dataReader["actiefStatus"]);
                    dataReader.Close();
                    return t;
                } catch (Exception ex) {
                    throw new TankKaartRepositoryException("GeefTankkaart niet gelukt", ex);
                } finally {
                    connection.Close();
                }
            }
        }

        public void UpdateTankkaart(TankKaart tankkaart) {
            string query = "UPDATE TankKaart SET kaartNummer=@kaartNummer, geldigheidsDatum=@geldigheidsDatum," +
                "pincode=@pincode, brandstofType=@brandstofType, actiefStatus=@actiefStatus WHERE kaartNummer=@kaartNummer";

            SqlConnection conn = GetConnection();
            using (SqlCommand command = new SqlCommand(query, conn)) {
                try {
                    conn.Open();
                    command.Parameters.Add(new SqlParameter("@kaartNummer", SqlDbType.Int));
                    command.Parameters.Add(new SqlParameter("@geldigheidsDatum", SqlDbType.DateTime));
                    command.Parameters.Add(new SqlParameter("@pincode", SqlDbType.Int));
                    command.Parameters.Add(new SqlParameter("@brandstofType", SqlDbType.NVarChar));
                    command.Parameters.Add(new SqlParameter("@actiefStatus", SqlDbType.Bit));

                    command.CommandText = query;
                    command.Parameters["@kaartNummer"].Value = tankkaart.KaartNummer;
                    command.Parameters["@geldigheidsDatum"].Value = tankkaart.Geldigheidsdatum;
                    command.Parameters["@pincode"].Value = tankkaart.Pincode;
                    command.Parameters["@brandstofType"].Value = tankkaart.BrandstofTypeToString();
                    command.Parameters["@actiefStatus"].Value = tankkaart.ActiefStatus;
                    command.ExecuteNonQuery();
                } catch (Exception ex) {
                    TankKaartRepositoryException dbex = new TankKaartRepositoryException("UpdateTankkaart niet gelukt", ex);
                    dbex.Data.Add("Tankkaart", tankkaart);
                    throw dbex;
                } finally {
                    conn.Close();
                }
            }
        }

        public void VoegTankkaartToe(TankKaart tankkaart) {
            string query = "INSERT INTO TankKaart VALUES(@kaartNummer, @geldigheidsDatum, @pincode, @brandstofType, @actiefStatus)";

            SqlConnection conn = GetConnection();
            using (SqlCommand command = new SqlCommand(query, conn)) {
                try {
                    conn.Open();
                    command.Parameters.Add(new SqlParameter("@kaartNummer", SqlDbType.Int));
                    command.Parameters.Add(new SqlParameter("@geldigheidsDatum", SqlDbType.DateTime));
                    command.Parameters.Add(new SqlParameter("@pincode", SqlDbType.Int));
                    command.Parameters.Add(new SqlParameter("@brandstofType", SqlDbType.NVarChar));
                    command.Parameters.Add(new SqlParameter("@actiefStatus", SqlDbType.Bit));

                    command.CommandText = query;
                    command.Parameters["@kaartNummer"].Value = tankkaart.KaartNummer;
                    command.Parameters["@geldigheidsDatum"].Value = tankkaart.Geldigheidsdatum;
                    command.Parameters["@pincode"].Value = tankkaart.Pincode;
                    command.Parameters["@brandstofType"].Value = tankkaart.BrandstofTypeToString();
                    command.Parameters["@actiefStatus"].Value = tankkaart.ActiefStatus;
                    command.ExecuteNonQuery();
                } catch (Exception ex) {
                    TankKaartRepositoryException dbex = new TankKaartRepositoryException("VoegTankkaartToe niet gelukt", ex);
                    dbex.Data.Add("Tankkaart", tankkaart);
                    throw dbex;
                } finally {
                    conn.Close();
                }
            }
        }
    }
}
