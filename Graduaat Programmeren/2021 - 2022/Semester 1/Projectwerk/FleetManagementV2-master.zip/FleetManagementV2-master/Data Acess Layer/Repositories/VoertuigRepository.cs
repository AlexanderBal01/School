﻿using Business_Layer;
using Business_Layer.Exceptions;
using Business_Layer.Interfaces;
using Data_Access_Layer.Exceptions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Access_Layer.Repositories {
    public class VoertuigRepository : IVoertuigRepository {
        private string ConnectionString;

        public VoertuigRepository(string connectionString) {
            ConnectionString = connectionString;
        }

        private SqlConnection GetConnection() {
            SqlConnection connection = new SqlConnection(ConnectionString);
            return connection;
        }


        public List<BrandstofType> maakBrandstofList(string DbBrandstofString) {
            List<BrandstofType> bsList = new List<BrandstofType>();
            var substring = DbBrandstofString.Split(",");
            foreach (var item in substring) {
                try {
                    var tussenitem = Enum.Parse<BrandstofType>(item);
                    bsList.Add(tussenitem);
                } catch (Exception) {

                    throw;
                }
            }
            return bsList;
        }


        public bool BestaatVoertuig(string chassisNummer) {
            SqlConnection connection = GetConnection();
            string query = "SELECT COUNT(*) FROM Voertuig WHERE chassisNummer = @chassisNummer";
            using (SqlCommand command = connection.CreateCommand()) {
                try {
                    connection.Open();
                    command.CommandText = query;

                    SqlParameter paramId = new SqlParameter();
                    paramId.ParameterName = "@chassisNummer";
                    paramId.DbType = DbType.String;
                    paramId.Value = chassisNummer;
                    command.Parameters.Add(paramId);

                    int voertuigExist = (int)command.ExecuteScalar();
                    if (voertuigExist > 0) {
                        return true;
                    }
                    return false;
                } catch (Exception ex) {
                    throw new VoertuigRepositoryException("BestaatVoertuig niet gelukt", ex);
                } finally {
                    connection.Close();
                }
            }
        }

        public List<Voertuig> GeefVoertuig(string tekst) {
            SqlConnection connection = GetConnection();
            string query = "SELECT t1.id, t1.naam, t1.voorNaam, t1.rijksregister, t1.typeRijbewijs, t1.geboorteDatum, t2.* FROM Bestuurder t1 " +
                "INNER JOIN Voertuig t2 ON t1.voertuigID=t2.chassisNummer WHERE(( t2.chassisNummer LIKE '%'+ @chassisNummer +'%') OR (t2.nummerPlaat LIKE '%'+ @nummerPlaat +'%') OR (t2.merk LIKE '%'+ @merk +'%'))";
 
            List<Voertuig> voertuigen = new List<Voertuig>();

            using (SqlCommand command = connection.CreateCommand()) {
                try {
                    connection.Open();
                    command.CommandText = query;

                    command.Parameters.Add(new SqlParameter("@chassisNummer", SqlDbType.NVarChar));
                    command.Parameters.Add(new SqlParameter("@nummerPlaat", SqlDbType.NVarChar));
                    command.Parameters.Add(new SqlParameter("@merk", SqlDbType.NVarChar));

                    command.Parameters["@chassisNummer"].Value = tekst;
                    command.Parameters["@nummerPlaat"].Value = tekst;
                    command.Parameters["@merk"].Value = tekst;

                    Bestuurder b = null;

                    SqlDataReader dataReader = command.ExecuteReader();
                    while (dataReader.Read()) {
                        if (b == null) {
                            b = new Bestuurder((int)dataReader["id"], (string)dataReader["naam"], (string)dataReader["voorNaam"], (string)dataReader["rijksregister"], (string)dataReader["typeRijbewijs"], (DateTime)dataReader["geboorteDatum"]);
                        }

                        Voertuig voertuig = new Voertuig((string)dataReader["chassisNummer"], (string)dataReader["nummerPlaat"], (string)dataReader["merk"],
                        (string)dataReader["model"], maakBrandstofList((string)dataReader["brandstofType"]), (string)dataReader["typeWagen"], (string)dataReader["kleur"], (int)dataReader["aantalDeuren"], b);
                        voertuigen.Add(voertuig);
                    }

                    dataReader.Close();
                    return voertuigen;
                } catch (Exception ex) {
                    throw new VoertuigManagerException("GeefVoertuig niet gelukt", ex);
                } finally {
                    connection.Close();
                }
            }
        }

        public void UpdateVoertuig(Voertuig voertuig) {
            string query = "UPDATE dbo.voertuig SET chassisNummer=@chassisNummer, nummerPlaat=@nummerplaat, merk=@merk," +
                " model=@model, brandstofType=@brandstofType, typeWagen=@typeWagen, kleur=@kleur, aantalDeuren=@aantalDeuren WHERE chassisNummer=@chassisNummer";
            SqlConnection conn = GetConnection();
            using (SqlCommand command = new SqlCommand(query, conn)) {
                try {
                    conn.Open();
                    command.Parameters.Add(new SqlParameter("@chassisNummer", SqlDbType.NVarChar));
                    command.Parameters.Add(new SqlParameter("@nummerplaat", SqlDbType.NVarChar));
                    command.Parameters.Add(new SqlParameter("@merk", SqlDbType.NVarChar));
                    command.Parameters.Add(new SqlParameter("@model", SqlDbType.NVarChar));
                    command.Parameters.Add(new SqlParameter("@brandstofType", SqlDbType.NVarChar));
                    command.Parameters.Add(new SqlParameter("@typeWagen", SqlDbType.NVarChar));
                    command.Parameters.Add(new SqlParameter("@kleur", SqlDbType.NVarChar));
                    command.Parameters.Add(new SqlParameter("@aantalDeuren", SqlDbType.Int));

                    command.CommandText = query;
                    command.Parameters["@chassisNummer"].Value = voertuig.ChassisNummer;
                    command.Parameters["@nummerplaat"].Value = voertuig.NummerPlaat;
                    command.Parameters["@merk"].Value = voertuig.Merk;
                    command.Parameters["@model"].Value = voertuig.Model;
                    command.Parameters["@brandstofType"].Value = voertuig.BrandstofTypeToString();
                    command.Parameters["@typeWagen"].Value = voertuig.TypeWagen;
                    command.Parameters["@kleur"].Value = voertuig.Kleur;
                    command.Parameters["@aantalDeuren"].Value = voertuig.AantalDeuren;
                    command.ExecuteNonQuery();
                } catch (Exception ex) {
                    VoertuigRepositoryException dbex = new VoertuigRepositoryException("UpdateVoertuig niet gelukt", ex);
                    dbex.Data.Add("Voertuig", voertuig);
                    throw dbex;
                } finally {
                    conn.Close();
                }
            }
        }

        public void VerwijderVoertuig(string chassisNummer) {
            SqlConnection connection = GetConnection();
            string VerwijderVoertuigVanBestuurder = "UPDATE dbo.Bestuurder SET voertuigID=@NULL WHERE voertuigID=@VoertuigID";
            string query = "DELETE FROM dbo.Voertuig WHERE chassisNummer=@chassisNummer";

            using (SqlCommand command = connection.CreateCommand()) {
                connection.Open();
                try {
                    command.Parameters.Add(new SqlParameter("@VoertuigID", SqlDbType.NVarChar));
                    command.Parameters.Add(new SqlParameter("@NULL", SqlString.Null));
                    command.CommandText = VerwijderVoertuigVanBestuurder;
                    command.Parameters["@VoertuigID"].Value = chassisNummer;
                    command.Parameters["@NULL"].Value = SqlString.Null;


                    int n = command.ExecuteNonQuery();
                    if (n != 1) throw new VoertuigRepositoryException("Meer dan 1 rij gewist");
                } catch (Exception ex) {
                    throw new VoertuigRepositoryException("Verwijder voertuig uit bestuurder mislukt", ex);
                }

                try {
                    command.Parameters.Add(new SqlParameter("@chassisNummer", SqlDbType.NVarChar));
                    command.CommandText = query;
                    command.Parameters["@chassisNummer"].Value = chassisNummer;

                    int n = command.ExecuteNonQuery();
                    if (n != 1) throw new VoertuigRepositoryException("Meer dan 1 rij gewist");
                } catch (Exception ex) {
                    throw new VoertuigRepositoryException("VerwijderVoertuig niet gelukt", ex);
                } finally {
                    connection.Close();
                }
            }
        }

        public void VerwijderVoertuigVanBestuurder(string chassisNummer) {
            SqlConnection connection = GetConnection();
            string query = "UPDATE Bestuurder SET voertuigID=NULL WHERE voertuigID=@voertuigID";

            using (SqlCommand command = connection.CreateCommand()) {
                connection.Open();
                try {
                    command.Parameters.Add(new SqlParameter("@voertuigID", SqlDbType.NVarChar));
                    command.CommandText = query;
                    command.Parameters["@voertuigID"].Value = chassisNummer;

                    int n = command.ExecuteNonQuery();
                    if (n != 1) throw new VoertuigRepositoryException("Meer dan 1 rij gewist");
                } catch (Exception ex) {
                    throw new VoertuigRepositoryException("VerwijderVoertuigVanBestuurder niet gelukt", ex);
                } finally {
                    connection.Close();
                }
            }
        }

        public void VoertuigToevoegen(Voertuig voertuig) {
            SqlConnection connection = GetConnection();
            string query = "INSERT INTO dbo.Voertuig VALUES(@chassisNummer, @nummerplaat, @merk," +
                " @model, @brandstofType, @typeWagen, @kleur, @aantalDeuren)";
            using (SqlCommand command = connection.CreateCommand()) {
                try {
                    connection.Open();
                    command.Parameters.Add(new SqlParameter("@chassisNummer", SqlDbType.NVarChar));
                    command.Parameters.Add(new SqlParameter("@nummerplaat", SqlDbType.NVarChar));
                    command.Parameters.Add(new SqlParameter("@merk", SqlDbType.NVarChar));
                    command.Parameters.Add(new SqlParameter("@model", SqlDbType.NVarChar));
                    command.Parameters.Add(new SqlParameter("@brandstofType", SqlDbType.NVarChar));
                    command.Parameters.Add(new SqlParameter("@typeWagen", SqlDbType.NVarChar));
                    command.Parameters.Add(new SqlParameter("@kleur", SqlDbType.NVarChar));
                    command.Parameters.Add(new SqlParameter("@aantalDeuren", SqlDbType.Int));

                    command.CommandText = query;
                    command.Parameters["@chassisNummer"].Value = voertuig.ChassisNummer;
                    command.Parameters["@nummerplaat"].Value = voertuig.NummerPlaat;
                    command.Parameters["@merk"].Value = voertuig.Merk;
                    command.Parameters["@model"].Value = voertuig.Model;
                    command.Parameters["@brandstofType"].Value = voertuig.BrandstofTypeToString();
                    command.Parameters["@typeWagen"].Value = voertuig.TypeWagen;
                    command.Parameters["@kleur"].Value = voertuig.Kleur;
                    command.Parameters["@aantalDeuren"].Value = voertuig.AantalDeuren;
                    command.ExecuteNonQuery();
                } catch (Exception ex) {
                    throw new VoertuigRepositoryException("VoertuigToevoegen niet gelukt", ex);
                } finally {
                    connection.Close();
                }
            }
        }

        public void VoertuigToevoegenMetBestuurder(Voertuig voertuig, Bestuurder bestuurder) {
            SqlConnection connection = GetConnection();
            string voegVoertuigToe = "INSERT INTO dbo.Voertuig VALUES(@chassisNummer, @nummerplaat, @merk, @model, @brandstofType, @typeWagen, @kleur, @aantalDeuren)";
            string voegBestuurderToe = "UPDATE dbo.Bestuurder SET voertuigID=@voertuigId WHERE id=@bestuurderId";

            using (SqlCommand command = connection.CreateCommand()) {
                connection.Open();
                try {
                    command.Parameters.Add(new SqlParameter("@chassisNummer", SqlDbType.NVarChar));
                    command.Parameters.Add(new SqlParameter("@nummerplaat", SqlDbType.NVarChar));
                    command.Parameters.Add(new SqlParameter("@merk", SqlDbType.NVarChar));
                    command.Parameters.Add(new SqlParameter("@model", SqlDbType.NVarChar));
                    command.Parameters.Add(new SqlParameter("@brandstofType", SqlDbType.NVarChar));
                    command.Parameters.Add(new SqlParameter("@typeWagen", SqlDbType.NVarChar));
                    command.Parameters.Add(new SqlParameter("@kleur", SqlDbType.NVarChar));
                    command.Parameters.Add(new SqlParameter("@aantalDeuren", SqlDbType.NVarChar));
                    command.CommandText = voegVoertuigToe;
                    command.Parameters["@chassisNummer"].Value = voertuig.ChassisNummer;
                    command.Parameters["@nummerplaat"].Value = voertuig.NummerPlaat;
                    command.Parameters["@merk"].Value = voertuig.Merk;
                    command.Parameters["@model"].Value = voertuig.Model;
                    command.Parameters["@brandstofType"].Value = voertuig.BrandstofTypeToString();
                    command.Parameters["@typeWagen"].Value = voertuig.TypeWagen;
                    command.Parameters["@kleur"].Value = voertuig.Kleur;
                    command.Parameters["@aantalDeuren"].Value = voertuig.AantalDeuren;
                    command.ExecuteNonQuery();
                } catch (Exception ex) {
                    throw new VoertuigRepositoryException("VoertuigToevoegenMetBestuurder - voertuig toevoegen niet gelukt" + ex.Message);
                }

                try {
                    command.Parameters.Add(new SqlParameter("@voertuigId", SqlDbType.Int));
                    command.Parameters.Add(new SqlParameter("@bestuurderId", SqlDbType.Int));
                    command.CommandText = voegBestuurderToe;
                    command.Parameters["@voertuigId"].Value = bestuurder.Voertuig.ChassisNummer;
                    command.Parameters["@bestuurderId"].Value = bestuurder.Id;
                    command.ExecuteNonQuery();
                } catch (Exception ex) {
                    throw new VoertuigRepositoryException("VoertuigToevoegenMetBestuurder - voertuig aan bestuurder toevoegen nuet gelukt" + ex.Message);
                } finally {
                    connection.Close();
                }
            }
        }
    }
}
