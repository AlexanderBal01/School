﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Data_Access_Layer.Exceptions {
    public class VoertuigRepositoryException : Exception {
        public VoertuigRepositoryException() {
        }

        public VoertuigRepositoryException(string message) : base(message) {
        }

        public VoertuigRepositoryException(string message, Exception innerException) : base(message, innerException) {
        }
    }
}
