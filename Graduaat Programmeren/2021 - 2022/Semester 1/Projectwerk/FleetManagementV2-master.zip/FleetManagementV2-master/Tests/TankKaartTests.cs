﻿using Business_Layer;
using Business_Layer.Exceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace Tests
{
    public class TankKaartTests
    {

        [Fact]
        public void Test_Ctor_Valid()
        {
            Adres adres = new Adres("martelarenlaan", "38", "Dendermonde", "9200");
            Voertuig voertuig = new Voertuig("1AGBH41XMN1091861", "1-TAT582", "Tesla", "Model S", new List<BrandstofType> { BrandstofType.Benzine }, "Convertible", "Navy Metallic", 5, new Bestuurder("Burrick", "Yens", "01.12.10 189.33", "B", new DateTime(1998, 12, 05)));
            Bestuurder bestuurder = new Bestuurder("naam", "voornaam", "123-123-123", "B",adres, new DateTime(1998, 12, 05), null, voertuig );
            var kaart = new TankKaart(1, new DateTime(1997, 12, 05), 1234, new List<BrandstofType> { BrandstofType.Benzine }, bestuurder, false);

            Assert.Equal(1,kaart.KaartNummer);
            Assert.Equal(new DateTime(1997, 12, 05), kaart.Geldigheidsdatum);
            Assert.Equal(1234, kaart.Pincode);
            Assert.Equal(new List<BrandstofType> { BrandstofType.Benzine },kaart.Brandstof);
            Assert.Equal(bestuurder, kaart.Bestuurder);
            Assert.False(kaart.ActiefStatus);

        }

        [Fact]
        public void Test_SetkaartNummer_Valid()
        {
            var kaart = new TankKaart(1, new DateTime(1997, 12, 05), 1234, new List<BrandstofType> { BrandstofType.Benzine }, new Bestuurder("naam", "voornaam", "123-123-123", "B", new Adres("martelarenlaan", "38", "Dendermonde", "9200"), new DateTime(1998, 12, 05), null, new Voertuig("1AGBH41XMN1091861", "1-TAT582", "Tesla", "Model S", new List<BrandstofType> { BrandstofType.Benzine }, "Convertible", "Navy Metallic", 5, new Bestuurder("Burrick", "Yens", "01.12.10 189.33", "B", new DateTime(1998, 12, 05)))), false);
            var kaartnr = 12;

            kaart.SetKaartNummer(kaartnr);
            Assert.Equal(kaartnr, kaart.KaartNummer);
        }

        [Theory]
        [InlineData(-1)]
        [InlineData(0)]
        public void Test_SetkaartNummer_Invalid(int cringe)
        {
            var kaart = new TankKaart(1, new DateTime(1997, 12, 05), 1234, new List<BrandstofType> { BrandstofType.Benzine }, new Bestuurder("naam", "voornaam", "123-123-123", "B", new Adres("martelarenlaan", "38", "Dendermonde", "9200"), new DateTime(1998, 12, 05), null, new Voertuig("1AGBH41XMN1091861", "1-TAT582", "Tesla", "Model S", new List<BrandstofType> { BrandstofType.Benzine }, "Convertible", "Navy Metallic", 5, new Bestuurder("Burrick", "Yens", "01.12.10 189.33", "B", new DateTime(1998, 12, 05)))), false);

            Assert.Throws<TankkaartException>(() => kaart.SetKaartNummer(cringe));
        }


        [Fact]
        public void Test_SetKaartGeldigheidsDatum_Valid()
        {
            var kaart = new TankKaart(1, new DateTime(1997, 12, 05), 1234, new List<BrandstofType> { BrandstofType.Benzine }, new Bestuurder("naam", "voornaam", "123-123-123", "B", new Adres("martelarenlaan", "38", "Dendermonde", "9200"), new DateTime(1998, 12, 05), null, new Voertuig("1AGBH41XMN1091861", "1-TAT582", "Tesla", "Model S", new List<BrandstofType> { BrandstofType.Benzine }, "Convertible", "Navy Metallic", 5, new Bestuurder("Burrick", "Yens", "01.12.10 189.33", "B", new DateTime(1998, 12, 05)))), false);
            var newdate = new DateTime(2020, 12, 05);
            kaart.SetKaartGeldigheidsDatum(newdate);

            Assert.Equal(newdate, kaart.Geldigheidsdatum);
        }

        [Fact]
        public void Test_SetPincode_Valid()
        {
            var kaart = new TankKaart(1, new DateTime(1997, 12, 05), 1234, new List<BrandstofType> { BrandstofType.Benzine }, new Bestuurder("naam", "voornaam", "123-123-123", "B", new Adres("martelarenlaan", "38", "Dendermonde", "9200"), new DateTime(1998, 12, 05), null, new Voertuig("1AGBH41XMN1091861", "1-TAT582", "Tesla", "Model S", new List<BrandstofType> { BrandstofType.Benzine }, "Convertible", "Navy Metallic", 5, new Bestuurder("Burrick", "Yens", "01.12.10 189.33", "B", new DateTime(1998, 12, 05)))), false);
            var pin = 1234;
        }

        [Theory]
        [InlineData(123)]
        [InlineData(12345)] 
        [InlineData(0)]
        public void Test_SetPincode_Invalid(int pin)
        {
            var kaart = new TankKaart(1, new DateTime(1997, 12, 05), 1234, new List<BrandstofType> { BrandstofType.Benzine }, new Bestuurder("naam", "voornaam", "123-123-123", "B", new Adres("martelarenlaan", "38", "Dendermonde", "9200"), new DateTime(1998, 12, 05), null, new Voertuig("1AGBH41XMN1091861", "1-TAT582", "Tesla", "Model S", new List<BrandstofType> { BrandstofType.Benzine }, "Convertible", "Navy Metallic", 5, new Bestuurder("Burrick", "Yens", "01.12.10 189.33", "B", new DateTime(1998, 12, 05)))), false);

            Assert.Throws<TankkaartException>(()=>kaart.SetPincode(pin));
        }


        [Fact]
        public void Test_SetBrandstofType_Valid()
        {
            var kaart = new TankKaart(1, new DateTime(1997, 12, 05), 1234, new List<BrandstofType> { BrandstofType.Benzine }, new Bestuurder("naam", "voornaam", "123-123-123", "B", new Adres("martelarenlaan", "38", "Dendermonde", "9200"), new DateTime(1998, 12, 05), null, new Voertuig("1AGBH41XMN1091861", "1-TAT582", "Tesla", "Model S", new List<BrandstofType> { BrandstofType.Benzine }, "Convertible", "Navy Metallic", 5, new Bestuurder("Burrick", "Yens", "01.12.10 189.33", "B", new DateTime(1998, 12, 05)))), false);
            var Brandstof = new List<BrandstofType> { BrandstofType.Benzine };
            kaart.SetBrandstofType(Brandstof);
            Assert.Equal(Brandstof,kaart.Brandstof);

        }

        [Fact]
        public void Test_SetBestuurder_Valid()
        {
            var kaart = new TankKaart(1, new DateTime(1997, 12, 05), 1234, new List<BrandstofType> { BrandstofType.Benzine }, new Bestuurder("naam", "voornaam", "123-123-123", "B", new Adres("martelarenlaan", "38", "Dendermonde", "9200"), new DateTime(1998, 12, 05), null, new Voertuig("1AGBH41XMN1091861", "1-TAT582", "Tesla", "Model S", new List<BrandstofType> { BrandstofType.Benzine }, "Convertible", "Navy Metallic", 5, new Bestuurder("Burrick", "Yens", "01.12.10 189.33", "B", new DateTime(1998, 12, 05)))), false);
            var Bestuurder = new Bestuurder("new name", "superman", "123-123-123", "B", new Adres("Voskeslaan", "30", "Gent", "9000"), new DateTime(1998, 12, 05), null, new Voertuig("1AGBH41XMN1091861", "1-TAT582", "Tesla", "Model S", new List<BrandstofType> { BrandstofType.Benzine }, "Convertible", "Navy Metallic", 5, new Bestuurder("Burrick", "Yens", "01.12.10 189.33", "B", new DateTime(1998, 12, 05))));
            kaart.SetBestuurder(Bestuurder);
            Assert.Equal(Bestuurder, kaart.Bestuurder);

        }

        [Fact]
        public void Test_SetBestuurder_Invalid()
        {
            var kaart = new TankKaart(1, new DateTime(1997, 12, 05), 1234, new List<BrandstofType> { BrandstofType.Benzine }, new Bestuurder("naam", "voornaam", "123-123-123", "B", new Adres("martelarenlaan", "38", "Dendermonde", "9200"), new DateTime(1998, 12, 05), null, new Voertuig("1AGBH41XMN1091861", "1-TAT582", "Tesla", "Model S", new List<BrandstofType> { BrandstofType.Benzine }, "Convertible", "Navy Metallic", 5, new Bestuurder("Burrick", "Yens", "01.12.10 189.33", "B", new DateTime(1998, 12, 05)))), false);
            Bestuurder Bestuurder = null;

            Assert.Throws<TankkaartException>(() =>kaart.SetBestuurder(Bestuurder));
        }



    }
}
