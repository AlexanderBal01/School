using Business_Layer;
using Business_Layer.Exceptions;
using System;
using Xunit;

namespace Tests {
    public class AdresTests {
        [Fact]
        public void Test_Ctor_Valid() {
            Adres adres = new Adres("martelarenlaan", "38", "Dendermonde", "9200");
            Assert.Equal("martelarenlaan", adres.Straat);
            Assert.Equal("38", adres.Huisnummer);
            Assert.Equal("Dendermonde", adres.Stad);
            Assert.Equal("9200", adres.Postcode);
        }

        [Fact]
        public void Test_SetPostcode_4Tekens_Valid() {
            Adres adres = new Adres("martelarenlaan", "38", "Dendermonde", "9200");
            adres.SetPostcode("9200");
            Assert.Equal("9200", adres.Postcode);
        }

        [Theory]
        [InlineData("999")]
        [InlineData("10000")]
        [InlineData("-1000")]
        public void Test_SetPostcode_4Tekens_Invalid(string postcode) {
            Adres adres = new Adres("martelarenlaan", "38", "Dendermonde", "9200");
            Assert.Throws<AdresException>(() => adres.SetPostcode(postcode));
        }

        [Fact]
        public void Test_SetPostcode_7Tekens_Valid() {
            Adres adres = new Adres("martelarenlaan", "38", "Dendermonde", "8011 PK");
            adres.SetPostcode("8011 PK");
            Assert.Equal("8011 PK", adres.Postcode);
        }

        [Theory]
        [InlineData("8011PK")]
        [InlineData("10000000")]
        public void Test_SetPostcode_7Tekens_Invalid(string postcode) {
            Adres adres = new Adres("martelarenlaan", "38", "Dendermonde", "9200");
            Assert.Throws<AdresException>(() => adres.SetPostcode(postcode));
        }

        [Fact]
        public void Test_SetStad_Valid() {
            Adres adres = new Adres("martelarenlaan", "38", "Dendermonde", "9200");
            adres.SetStad("Dendermonde");
            Assert.Equal("Dendermonde", adres.Stad);
        }

        [Theory]
        [InlineData("")]
        [InlineData(" ")]
        [InlineData(null)]
        public void Test_SetStad_Invalid(string stad) {
            Adres adres = new Adres("martelarenlaan", "38", "Dendermonde", "9200");
            Assert.Throws<AdresException>(() => adres.SetStad(stad));
        }

        [Fact]
        public void Test_SetHuisnummer_Valid() {
            Adres adres = new Adres("martelarenlaan", "38", "Dendermonde", "9200");
            adres.SetHuisnummer("38");
            Assert.Equal("38", adres.Huisnummer);
        }

        [Theory]
        [InlineData("")]
        [InlineData(" ")]
        [InlineData(null)]
        public void Test_SetHuisnummer_Invalid(string huisnummer) {
            Adres adres = new Adres("martelarenlaan", "38", "Dendermonde", "9200");
            Assert.Throws<AdresException>(() => adres.SetStad(huisnummer));
        }

        [Fact]
        public void Test_SetStraat_Valid() {
            Adres adres = new Adres("martelarenlaan", "38", "Dendermonde", "9200");
            adres.SetStraat("martelarenlaan");
            Assert.Equal("martelarenlaan", adres.Straat);
        }

        [Theory]
        [InlineData("")]
        [InlineData(" ")]
        [InlineData(null)]
        public void Test_SetStraat_Invalid(string straat) {
            Adres adres = new Adres("martelarenlaan", "38", "Dendermonde", "9200");
            Assert.Throws<AdresException>(() => adres.SetStad(straat));
        }
    }
}

