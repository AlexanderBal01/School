﻿using Business_Layer;
using Business_Layer.Exceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;


namespace Tests {
    public class VoertuigTests {
        [Fact]
        public void Test_Ctor_Valid() {
            Voertuig voertuig = new Voertuig("1AGBH41XMN1091861", "1-TAT582", "Tesla", "Model S", new List<BrandstofType> { BrandstofType.Benzine}, "Convertible", "Navy Metallic", 5, null);
            Assert.Equal("1AGBH41XMN1091861", voertuig.ChassisNummer);
            Assert.Equal("1-TAT582", voertuig.NummerPlaat);
            Assert.Equal("Tesla", voertuig.Merk);
            Assert.Equal("Model S", voertuig.Model);
            Assert.Equal("Convertible", voertuig.TypeWagen);
            Assert.Equal("Navy Metallic", voertuig.Kleur);
            Assert.Equal(5, voertuig.AantalDeuren);
            Assert.Null(voertuig.Bestuurder);
        }

        [Fact]
        public void Test_SetBestuurder_Valid() {
            Voertuig voertuig = new Voertuig("1AGBH41XMN1091861", "1-TAT582", "Tesla", "Model S", new List<BrandstofType> { BrandstofType.Benzine }, "Convertible", "Navy Metallic", 5, null);
            voertuig.SetBestuurder(null);
            Assert.Null(voertuig.Bestuurder);
        }

        [Fact]
        public void Test_SetChassis_Valid() {
            Voertuig voertuig = new Voertuig("1AGBH41XMN1091861", "1-TAT582", "Tesla", "Model S", new List<BrandstofType> { BrandstofType.Benzine }, "Convertible", "Navy Metallic", 5, null);
            voertuig.SetChassis("1AGBH41XMN1091861");
            Assert.Equal("1AGBH41XMN1091861", voertuig.ChassisNummer);
        }

        [Theory]
        [InlineData("")]
        [InlineData(" ")]
        [InlineData(null)]
        public void Test_SetChassis_Invalid(string chassis) {
            Voertuig voertuig = new Voertuig("1AGBH41XMN1091861", "1-TAT582", "Tesla", "Model S", new List<BrandstofType> { BrandstofType.Benzine }, "Convertible", "Navy Metallic", 5, null);
            Assert.Throws<VoertuigException>(() => voertuig.SetChassis(chassis));
        }

        [Fact]
        public void Test_SetNrPlaat_Valid() {
            Voertuig voertuig = new Voertuig("1AGBH41XMN1091861", "1-TAT582", "Tesla", "Model S", new List<BrandstofType> { BrandstofType.Benzine }, "Convertible", "Navy Metallic", 5, null);
            voertuig.SetNrPlaat("1-TAT582");
            Assert.Equal("1-TAT582", voertuig.NummerPlaat);
        }

        [Theory]
        [InlineData("")]
        [InlineData(" ")]
        [InlineData(null)]
        public void Test_SetNrPlaat_Invalid(string nrPlaat) {
            Voertuig voertuig = new Voertuig("1AGBH41XMN1091861", "1-TAT582", "Tesla", "Model S", new List<BrandstofType> { BrandstofType.Benzine }, "Convertible", "Navy Metallic", 5, null);
            Assert.Throws<VoertuigException>(() => voertuig.SetNrPlaat(nrPlaat));
        }

        [Fact]
        public void Test_SetMerk_Valid() {
            Voertuig voertuig = new Voertuig("1AGBH41XMN1091861", "1-TAT582", "Tesla", "Model S", new List<BrandstofType> { BrandstofType.Benzine }, "Convertible", "Navy Metallic", 5, null);
            voertuig.SetMerk("Tesla");
            Assert.Equal("Tesla", voertuig.Merk);
        }

        [Theory]
        [InlineData("")]
        [InlineData(" ")]
        [InlineData(null)]
        public void Test_SetMerk_Invalid(string merk) {
            Voertuig voertuig = new Voertuig("1AGBH41XMN1091861", "1-TAT582", "Tesla", "Model S", new List<BrandstofType> { BrandstofType.Benzine }, "Convertible", "Navy Metallic", 5, null);
            Assert.Throws<VoertuigException>(() => voertuig.SetMerk(merk));
        }

        [Fact]
        public void Test_SetModel_Valid() {
            Voertuig voertuig = new Voertuig("1AGBH41XMN1091861", "1-TAT582", "Tesla", "Model S", new List<BrandstofType> { BrandstofType.Benzine }, "Convertible", "Navy Metallic", 5, null);
            voertuig.SetMerk("Model S");
            Assert.Equal("Model S", voertuig.Model);
        }

        [Theory]
        [InlineData("")]
        [InlineData(" ")]
        [InlineData(null)]
        public void Test_SetModel_Invalid(string model) {
            Voertuig voertuig = new Voertuig("1AGBH41XMN1091861", "1-TAT582", "Tesla", "Model S", new List<BrandstofType> { BrandstofType.Benzine }, "Convertible", "Navy Metallic", 5, null);
            Assert.Throws<VoertuigException>(() => voertuig.SetModel(model));
        }

        [Fact]
        public void Test_SetBrandstof_Valid() {
            Voertuig voertuig = new Voertuig("1AGBH41XMN1091861", "1-TAT582", "Tesla", "Model S", new List<BrandstofType> { BrandstofType.Benzine }, "Convertible", "Navy Metallic", 5, null);
            voertuig.SetBrandstof(new List<BrandstofType> { BrandstofType.Benzine });
            Assert.Equal(new List<BrandstofType> { BrandstofType.Benzine }, voertuig.BrandstofType);
        }

        [Fact]
        public void Test_SetTypeWagen_Valid() {
            Voertuig voertuig = new Voertuig("1AGBH41XMN1091861", "1-TAT582", "Tesla", "Model S", new List<BrandstofType> { BrandstofType.Benzine }, "Convertible", "Navy Metallic", 5, null);
            voertuig.SetTypeWagen("Convertible");
            Assert.Equal("Convertible", voertuig.TypeWagen);
        }

        [Theory]
        [InlineData("")]
        [InlineData(" ")]
        [InlineData(null)]
        public void Test_SetTypeWagen_Invalid(string typeWage) {
            Voertuig voertuig = new Voertuig("1AGBH41XMN1091861", "1-TAT582", "Tesla", "Model S", new List<BrandstofType> { BrandstofType.Benzine }, "Convertible", "Navy Metallic", 5, null);
            Assert.Throws<VoertuigException>(() => voertuig.SetTypeWagen(typeWage));
        }

        [Fact]
        public void Test_SetKleur_Valid() {
            Voertuig voertuig = new Voertuig("1AGBH41XMN1091861", "1-TAT582", "Tesla", "Model S", new List<BrandstofType> { BrandstofType.Benzine }, "Convertible", "Navy Metallic", 5, null);
            voertuig.SetKleur("Navy Metallic");
            Assert.Equal("Navy Metallic", voertuig.Kleur);
        }

        [Theory]
        [InlineData("")]
        [InlineData(" ")]
        [InlineData(null)]
        public void Test_SetKleur_Invalid(string kleur) {
            Voertuig voertuig = new Voertuig("1AGBH41XMN1091861", "1-TAT582", "Tesla", "Model S", new List<BrandstofType> { BrandstofType.Benzine }, "Convertible", "Navy Metallic", 5, null);
            Assert.Throws<VoertuigException>(() => voertuig.SetKleur(kleur));
        }

        [Fact]
        public void Test_SetAantalDeuren_Valid() {
            Voertuig voertuig = new Voertuig("1AGBH41XMN1091861", "1-TAT582", "Tesla", "Model S", new List<BrandstofType> { BrandstofType.Benzine }, "Convertible", "Navy Metallic", 5, null);
            voertuig.SetAantalDeuren(5);
            Assert.Equal(5, voertuig.AantalDeuren);
        }

        [Theory]
        [InlineData(0)]
        public void Test_SetAantalDeuren_Invalid(int aantalDeuren) {
            Voertuig voertuig = new Voertuig("1AGBH41XMN1091861", "1-TAT582", "Tesla", "Model S", new List<BrandstofType> { BrandstofType.Benzine }, "Convertible", "Navy Metallic", 5, null);
            Assert.Throws<VoertuigException>(() => voertuig.SetAantalDeuren(aantalDeuren));
        }
    }
}