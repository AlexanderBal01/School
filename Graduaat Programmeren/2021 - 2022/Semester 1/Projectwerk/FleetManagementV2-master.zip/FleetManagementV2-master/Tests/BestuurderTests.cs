﻿using Business_Layer;
using Business_Layer.Exceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace Tests
{
    public class BestuurderTests
    {
        [Fact]
        public void Test_Ctor_Bestuurder_Verplicht_Valid()
        {
            Bestuurder b = new Bestuurder("Kipman", "Kip", "97.03.08-152.61", "B", new DateTime(1997, 03, 08));
            Assert.Equal("Kipman", b.Naam);
            Assert.Equal("Kip", b.Voornaam);
            Assert.Equal("97.03.08-152.61", b.Rijksregister);
            Assert.Equal("B", b.TypeRijbewijs);
            Assert.Equal(new DateTime(1997, 03, 08), b.GeboorteDatum);
        }

        [Fact]
        public void Test_Ctor_Bestuurder_MetNietVerplicht_Valid() {
            Bestuurder b = new Bestuurder("Kipman", "Kip", "97.03.08-152.61", "B", new Adres("Kipstraat", "4", "Gent", "9000"), new DateTime(1997, 03, 08), new TankKaart(1, new DateTime(2021, 12, 31)), new Voertuig("1AGBH41XMN1091861", "1-TAT582", "Tesla", "Model S", new List<BrandstofType> { BrandstofType.Benzine }, "Convertible", "Navy Metallic", 5, new Bestuurder("Kipman", "Kip", "97.03.08-152.61", "B", new DateTime(1997, 03, 08))));
            Assert.Equal("Kipman", b.Naam);
            Assert.Equal("Kip", b.Voornaam);
            Assert.Equal("97.03.08-152.61", b.Rijksregister);
            Assert.Equal("B", b.TypeRijbewijs);
            Assert.Equal(new Adres("Kipstraat", "4", "Gent", "9000"), b.Adres);
            Assert.Equal(new DateTime(1997, 03, 08), b.GeboorteDatum);
            Assert.Equal(new TankKaart(1, new DateTime(2021, 12, 31)), b.TankKaart);
            Assert.Equal(new Voertuig("1AGBH41XMN1091861", "1-TAT582", "Tesla", "Model S", new List<BrandstofType> { BrandstofType.Benzine }, "Convertible", "Navy Metallic", 5, b), b.Voertuig);
        }

        [Fact]
        public void Test_Ctor_Bestuurder_MetId_Valid() {
            Bestuurder b = new Bestuurder("Kipman", "Kip", "97.03.08-152.61", "B", new Adres("Kipstraat", "4", "Gent", "9000"), new DateTime(1997, 03, 08), new TankKaart(1, new DateTime(2021, 12, 31)), new Voertuig("1AGBH41XMN1091861", "1-TAT582", "Tesla", "Model S", new List<BrandstofType> { BrandstofType.Benzine }, "Convertible", "Navy Metallic", 5, new Bestuurder("Kipman", "Kip", "97.03.08-152.61", "B", new DateTime(1997, 03, 08))), 1);
            Assert.Equal("Kipman", b.Naam);
            Assert.Equal("Kip", b.Voornaam);
            Assert.Equal("97.03.08-152.61", b.Rijksregister);
            Assert.Equal("B", b.TypeRijbewijs);
            Assert.Equal(new Adres("Kipstraat", "4", "Gent", "9000"), b.Adres);
            Assert.Equal(new DateTime(1997, 03, 08), b.GeboorteDatum);
            Assert.Equal(new TankKaart(1, new DateTime(2021, 12, 31)), b.TankKaart);
            Assert.Equal(new Voertuig("1AGBH41XMN1091861", "1-TAT582", "Tesla", "Model S", new List<BrandstofType> { BrandstofType.Benzine }, "Convertible", "Navy Metallic", 5, b), b.Voertuig);
            Assert.Equal(1, b.Id);
        }

        [Fact]
        public void Test_SetVoertuig_Valid() {
            Bestuurder b = new Bestuurder("Kipman", "Kip", "97.03.08-152.61", "B", new Adres("Kipstraat", "4", "Gent", "9000"), new DateTime(1997, 03, 08), new TankKaart(1, new DateTime(2021, 12, 31)), new Voertuig("1AGBH41XMN1091861", "1-TAT582", "Tesla", "Model S", new List<BrandstofType> { BrandstofType.Benzine }, "Convertible"));
            b.SetVoertuig(new Voertuig("1AGBH41XMN1091861", "1-TAT593", "Tesla", "Model Y", new List<BrandstofType> { BrandstofType.Benzine }, "Stationwagen"));
            Assert.Equal(new Voertuig("1AGBH41XMN1091861", "1-TAT593", "Tesla", "Model Y", new List<BrandstofType> { BrandstofType.Benzine }, "Stationwagen", "Navy Metallic", 5, b), b.Voertuig);
        }

        [Fact]
        public void Test_SetAdres_Valid() {
            Bestuurder b = new Bestuurder("Kipman", "Kip", "97.03.08-152.61", "B", new Adres("Kipstraat", "4", "Gent", "9000"), new DateTime(1997, 03, 08), null, new Voertuig("1AGBH41XMN1091861", "1-TAT582", "Tesla", "Model S", new List<BrandstofType> { BrandstofType.Benzine }, "Convertible"));
            b.SetAdres(new Adres("Martelarenlaan", "38", "Dendermonde", "9200"));
            Assert.Equal(new Adres("Martelarenlaan", "38", "Dendermonde", "9200"), b.Adres);
        }

        [Theory]
        [InlineData(null)]
        public void Test_SetAdres_Invalid(Adres adres) {
            Bestuurder b = new Bestuurder("Kipman", "Kip", "97.03.08-152.61", "B", new Adres("Kipstraat", "4", "Gent", "9000"), new DateTime(1997, 03, 08), null, new Voertuig("1AGBH41XMN1091861", "1-TAT582", "Tesla", "Model S", new List<BrandstofType> { BrandstofType.Benzine }, "Convertible"));
            Assert.Throws<BestuurderException>(() => b.SetAdres(adres));
        }

        [Fact]
        public void Test_SetTankKaart_Valid() {
            Bestuurder b = new Bestuurder("Kipman", "Kip", "97.03.08-152.61", "B", new Adres("Kipstraat", "4", "Gent", "9000"), new DateTime(1997, 03, 08), null, new Voertuig("1AGBH41XMN1091861", "1-TAT582", "Tesla", "Model S", new List<BrandstofType> { BrandstofType.Benzine }, "Convertible"));
            b.SetTankKaart(new TankKaart(1, new DateTime(1997, 12, 05)));
            Assert.Equal(new TankKaart(1, new DateTime(1997, 12, 05)), b.TankKaart);
        }

        [Fact]
        public void Test_SetGeboorteDatum_Valid() {
            Bestuurder b = new Bestuurder("Kipman", "Kip", "97.03.08-152.61", "B", new Adres("Kipstraat", "4", "Gent", "9000"), new DateTime(1997, 03, 08), null, new Voertuig("1AGBH41XMN1091861", "1-TAT582", "Tesla", "Model S", new List<BrandstofType> { BrandstofType.Benzine }, "Convertible"));
            b.SetGeboorteDatum(new DateTime(1999, 12, 12));
            Assert.Equal(new DateTime(1999, 12, 12), b.GeboorteDatum);
        }

        [Fact]
        public void Test_SetTypeRijbewijs_Valid() {
            Bestuurder b = new Bestuurder("Kipman", "Kip", "97.03.08-152.61", "B", new Adres("Kipstraat", "4", "Gent", "9000"), new DateTime(1997, 03, 08), null, new Voertuig("1AGBH41XMN1091861", "1-TAT582", "Tesla", "Model S", new List<BrandstofType> { BrandstofType.Benzine }, "Convertible"));
            b.SetTypeRijbewijs("A");
            Assert.Equal("A", b.TypeRijbewijs);
        }

        [Theory]
        [InlineData(null)]
        public void Test_SetTypeRijbewijs_Invalid(string rijbewijs) {
            Bestuurder b = new Bestuurder("Kipman", "Kip", "97.03.08-152.61", "B", new Adres("Kipstraat", "4", "Gent", "9000"), new DateTime(1997, 03, 08), null, new Voertuig("1AGBH41XMN1091861", "1-TAT582", "Tesla", "Model S", new List<BrandstofType> { BrandstofType.Benzine }, "Convertible"));
            Assert.Throws<BestuurderException>(() => b.SetTypeRijbewijs(rijbewijs));
        }

        [Fact]
        public void Test_SetRijksregister_Valid() {
            Bestuurder b = new Bestuurder("Kipman", "Kip", "97.03.08-152.61", "B", new Adres("Kipstraat", "4", "Gent", "9000"), new DateTime(1997, 03, 08), null, new Voertuig("1AGBH41XMN1091861", "1-TAT582", "Tesla", "Model S", new List<BrandstofType> { BrandstofType.Benzine }, "Convertible"));
            b.SetRijksregister("123-123-123");
            Assert.Equal("123-123-123", b.Rijksregister);
        }

        [Theory]
        [InlineData(null)]
        public void Test_SetRijksregister_Invalid(string rijksregister) {
            Bestuurder b = new Bestuurder("Kipman", "Kip", "97.03.08-152.61", "B", new Adres("Kipstraat", "4", "Gent", "9000"), new DateTime(1997, 03, 08), null, new Voertuig("1AGBH41XMN1091861", "1-TAT582", "Tesla", "Model S", new List<BrandstofType> { BrandstofType.Benzine }, "Convertible"));
            Assert.Throws<BestuurderException>(() => b.SetRijksregister(rijksregister));
        }

        [Fact]
        public void Test_SetVoornaam_Valid() {
            Bestuurder b = new Bestuurder("Kipman", "Kip", "97.03.08-152.61", "B", new Adres("Kipstraat", "4", "Gent", "9000"), new DateTime(1997, 03, 08), null, new Voertuig("1AGBH41XMN1091861", "1-TAT582", "Tesla", "Model S", new List<BrandstofType> { BrandstofType.Benzine }, "Convertible"));
            b.SetVoornaam("Hond");
            Assert.Equal("Hond", b.Voornaam);
        }

        [Theory]
        [InlineData(null)]
        public void Test_SetVoornaam_Invalid(string voornaam) {
            Bestuurder b = new Bestuurder("Kipman", "Kip", "97.03.08-152.61", "B", new Adres("Kipstraat", "4", "Gent", "9000"), new DateTime(1997, 03, 08), null, new Voertuig("1AGBH41XMN1091861", "1-TAT582", "Tesla", "Model S", new List<BrandstofType> { BrandstofType.Benzine }, "Convertible"));
            Assert.Throws<BestuurderException>(() => b.SetVoornaam(voornaam));
        }

        [Fact]
        public void Test_SetNaam_Valid() {
            Bestuurder b = new Bestuurder("Kipman", "Kip", "97.03.08-152.61", "B", new Adres("Kipstraat", "4", "Gent", "9000"), new DateTime(1997, 03, 08), null, new Voertuig("1AGBH41XMN1091861", "1-TAT582", "Tesla", "Model S", new List<BrandstofType> { BrandstofType.Benzine }, "Convertible"));
            b.SetNaam("Hondman");
            Assert.Equal("Hondman", b.Naam);
        }

        [Theory]
        [InlineData(null)]
        public void Test_SetNaam_Invalid(string naam) {
            Bestuurder b = new Bestuurder("Kipman", "Kip", "97.03.08-152.61", "B", new Adres("Kipstraat", "4", "Gent", "9000"), new DateTime(1997, 03, 08), null, new Voertuig("1AGBH41XMN1091861", "1-TAT582", "Tesla", "Model S", new List<BrandstofType> { BrandstofType.Benzine }, "Convertible"));
            Assert.Throws<BestuurderException>(() => b.SetNaam(naam));
        }
    }
}
