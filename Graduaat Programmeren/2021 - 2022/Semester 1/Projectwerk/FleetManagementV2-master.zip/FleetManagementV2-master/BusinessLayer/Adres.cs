﻿using Business_Layer.Exceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business_Layer
{
    public class Adres
    {
        public string Straat { get; private set; }
        public string Huisnummer { get; private set; }
        public string Stad { get; private set; }
        public string Postcode { get; private set; }
        public int Id { get; private set;}

        public Adres(string straat, string huisnummer, string stad, string postcode) {
            SetStraat(straat);
            SetHuisnummer(huisnummer);
            SetStad(stad);
            SetPostcode(postcode);
        }

        /// <summary>
        /// Belgische postcode bestaat uit 4 cijfers
        /// Nederlandse postcode bestaat uit 7 karacters =>
        /// => 4 cijfers en een spatie gevolgd door 2 DRUKLETTERS
        /// </summary>
        /// <param name="postcode"></param>
        public void SetPostcode(string postcode) {
            if (!string.IsNullOrWhiteSpace(postcode)) {
                if (postcode.Length == 4 || postcode.Length==7) { //NL: 4 cijfers, spatie, 2 letters
                    Postcode = postcode;
                } else {
                    throw new AdresException("Adres - postcode ongeldig.");
                }
            } else {
                throw new AdresException("Adres - postcode ongeldig.");
            }
        }

        public void SetStad(string stad) {
            if (!string.IsNullOrWhiteSpace(stad)) {
                Stad = stad;
            } else {
                throw new AdresException("Adres - stad ongeldig.");
            }
        }

        public void SetHuisnummer(string huisnummer) {
            if (!string.IsNullOrWhiteSpace(huisnummer)) {
                Huisnummer = huisnummer;
            } else {
                throw new AdresException("Adres - huisnummer ongeldig.");
            }
        }

        public void SetStraat(string straat) {
            if (!string.IsNullOrWhiteSpace(straat)) {
                Straat = straat;
            } else {
                throw new AdresException("Adres - straat ongeldig.");
            }
        }

        public override bool Equals(object obj) {
            return obj is Adres adres &&
                   Straat == adres.Straat &&
                   Huisnummer == adres.Huisnummer &&
                   Stad == adres.Stad &&
                   Postcode == adres.Postcode &&
                   Id == adres.Id;
        }

        public override int GetHashCode() {
            return HashCode.Combine(Straat, Huisnummer, Stad, Postcode, Id);
        }
    }
}
