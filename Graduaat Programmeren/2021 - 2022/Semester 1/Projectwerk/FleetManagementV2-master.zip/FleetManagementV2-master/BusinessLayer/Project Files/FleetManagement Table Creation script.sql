
use FleetManagement;

Create table TankKaart(
kaartNummer int primary key not null,
geldigheidsDatum Date not null,
pincode int not null,
brandstofType NVarchar(100) not null,
actiefStatus bit not null
);

Create table Voertuig(
chassisNummer Nvarchar(200) primary key not null,
nummerPlaat NVarchar(200) not null,
merk NVarchar(200) not null,
model NVarchar(200) not null,
brandstofType NVarchar(200) not null,
typeWagen NVarchar(200) not null,
kleur NVarchar(200) not null,
aantalDeuren int not null
);

Create table Bestuurder(
id int primary key identity(1,1),
naam NVarchar(200) not null,
voorNaam NVarchar(200) not null,
rijksregister NVarchar(100) not null,
typeRijbewijs NVarchar(100) not null,
geboorteDatum DATE not null,
tankKaartID int foreign key references TankKaart(kaartNummer),
voertuigID Nvarchar(200) foreign key references Voertuig(chassisNummer),
straatHuisnr NVarchar(200) not null,
stad NVarchar(100) not null,
postcode NVarchar(20) not null
);
