﻿using Business_Layer.Exceptions;
using Business_Layer.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business_Layer.Managers {
    public class BestuurderManager {
        private IBestuurderRepository repo;

        public BestuurderManager() {
        }

        public BestuurderManager(IBestuurderRepository repo) {
            this.repo = repo;
        }

        public List<Bestuurder> GeefBestuurder(string tekst) {
            try {
                return repo.GeefBestuurder(tekst);
            } catch (Exception ex) {
                throw new BestuurderManagerException("GeefBestuurder", ex);
            }
        }

        public bool BestaatBestuurder(int id) {
            try {
                return repo.BestaatBestuurder(id);
            } catch (Exception ex) {
                throw new BestuurderManagerException("BestaatBestuurder", ex);
            }
        }

        public void BestuurderToevoegen(Bestuurder bestuurder) {
            try {
                if (bestuurder == null) throw new BestuurderManagerException("BestuurderToevoegen - bestuurder is null");
                if (repo.BestaatBestuurder(bestuurder.Id)) throw new BestuurderManagerException("BestuurderToevoegen - bestuurder bestaat reeds");
                repo.BestuurderToevoegen(bestuurder);
            } catch (Exception ex) {
                throw new BestuurderManagerException("BestuurderToevoegen", ex);
            }
        }

        public void VerwijderBestuurder(int id) {
            try {
                if (!repo.BestaatBestuurder(id)) throw new BestuurderManagerException("VerwijderBestuurder - bestuurder bestaat niet");
                repo.VerwijderBestuurder(id);
            } catch (Exception ex) {
                throw new BestuurderManagerException("VerwijderBestuurder", ex);
            }
        }

        public bool UpdateBestuurder(Bestuurder bestuurder) {
            try {
                if (bestuurder == null) throw new BestuurderManagerException("UpdateBestuurder - bestuurder is null");
                if (!repo.BestaatBestuurder(bestuurder.Id)) throw new BestuurderManagerException("UpdateBestuurder - bestuurder bestaat niet");
                Bestuurder bestuurderDB = repo.GeefBestuurder(bestuurder.Rijksregister)[0];
                if (bestuurder == bestuurderDB) throw new BestuurderManagerException("UpdateBestuurder - geen verschillen");
                if (bestuurder.TankKaart == null) bestuurder.SetTankKaart(new TankKaart(bestuurderDB.TankKaart.KaartNummer));
                if (bestuurder.Voertuig == null) bestuurder.SetVoertuig(new Voertuig(bestuurderDB.Voertuig.ChassisNummer));
                repo.UpdateBestuurder(bestuurder);
                return true;
            } catch (Exception ex) {
                throw new BestuurderManagerException("UpdateBestuurder", ex);
            }
        }

        public void VerwijderTankkaartVanBestuurder(Bestuurder bestuurder) {
            try {
                if (bestuurder == null) throw new BestuurderManagerException("VerwijderTankkaartVanBestuurder - bestuurder is null");
                if (bestuurder.TankKaart.KaartNummer <= 0) throw new BestuurderManagerException("VerwijderTankkaartVanBestuurder - bestuurder heeft geen tankkaart");
                repo.VerwijderTankkaartVanBestuurder(bestuurder);
            } catch (Exception ex) {
                throw new BestuurderManagerException("VerwijderTankkaartVanBestuurder", ex);
            }
        }


        public void VerwijderVoertuigVanBestuurder(Bestuurder bestuurder) {
            try {
                if (bestuurder == null) throw new BestuurderManagerException("VerwijderTankkaartVanBestuurder - bestuurder is null");
                repo.VerwijderVoertuigVanBestuurder(bestuurder);
            } catch (Exception ex) {
                throw new BestuurderManagerException("VerwijderVoertuigVanBestuurder", ex);
            }
        }
    }
}
