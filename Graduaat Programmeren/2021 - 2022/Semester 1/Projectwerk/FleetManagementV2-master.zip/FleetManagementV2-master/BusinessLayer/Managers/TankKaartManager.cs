﻿using Business_Layer.Exceptions;
using Business_Layer.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business_Layer.Managers
{
    public class TankKaartManager
    {
        private ITankKaartRepository repo;

        public TankKaartManager()
        {
        }

        public TankKaartManager(ITankKaartRepository repo)
        {
            this.repo = repo;
        }

        public TankKaart GeefTankkaart(int kaartnummer)
        {
            try {
                return repo.GeefTankkaart(kaartnummer);
            } catch (Exception ex) {
                throw new TankKaartManagerException("GeefTankkaart", ex);
            }
        }

        public void VoegTankkaartToe(TankKaart tankkaart)
        {
            try {
                if (tankkaart == null) {
                    throw new TankKaartManagerException("VoegTankkaartToe - tankkaart is null");
                }
                if (repo.BestaatTankkaart(tankkaart.KaartNummer)) {
                    throw new TankKaartManagerException("VoegTankkaartToe - tankkaart bestaat reeds");
                }
                repo.VoegTankkaartToe(tankkaart);
            } catch (Exception ex) {
                throw new TankKaartManagerException("VoegTankkaartToe", ex);
            }
        }

        public bool BestaatTankkaart(int kaartnummer) {
            try {
                return repo.BestaatTankkaart(kaartnummer);
            } catch (Exception ex) {
                throw new TankKaartManagerException("BestaatTankkaart", ex);
            }
        }

        public bool UpdateTankkaart(TankKaart tankkaart) {
            try {
                if (tankkaart == null) {
                    throw new TankKaartManagerException("VoegTankkaartToe - tankkaart is null");
                }
                if (!repo.BestaatTankkaart(tankkaart.KaartNummer)) {
                    throw new TankKaartManagerException("UpdateTankkaart - tankkaart bestaat niet");
                }
                TankKaart tankkaartDB = repo.GeefTankkaart(tankkaart.KaartNummer);
                if (tankkaart == tankkaartDB) {
                    throw new TankKaartManagerException("UpdateTankkaart - geen verschillen");
                }
                repo.UpdateTankkaart(tankkaart);
                return true;
            } catch (Exception ex) {
                throw new TankKaartManagerException("UpdateTankkaart", ex);
            }
        }
    }
}
