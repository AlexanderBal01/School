﻿using Business_Layer.Exceptions;
using Business_Layer.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business_Layer.Managers
{
    public class VoertuigManager
    {
        private IVoertuigRepository repo;

        public VoertuigManager()
        {

        }

        public VoertuigManager(IVoertuigRepository repo)
        {
            this.repo = repo;
        }

        public bool BestaatVoertuig(string chassisNummer) {
            try {
                return repo.BestaatVoertuig(chassisNummer);
            } catch (Exception ex) {
                throw new VoertuigManagerException("BestaatVoertuig", ex);
            }
        }

        public List<Voertuig> GeefVoertuig(string tekst) {
            try {
                return repo.GeefVoertuig(tekst);
            } catch (Exception ex) {
                throw new VoertuigManagerException("GeefVoertuig", ex);
            }
        }

        public void VoertuigToevoegen(Voertuig voertuig) {
            try {
                if (voertuig == null) throw new VoertuigManagerException("VoertuigToevoegen - voertuig is null");
                if (repo.BestaatVoertuig(voertuig.ChassisNummer)) throw new VoertuigManagerException("VoertuigToevoegen - voertuig bestaat reeds");
                repo.VoertuigToevoegen(voertuig);
            } catch (Exception ex) {
                throw new VoertuigManagerException("VoertuigToevoegen", ex);
            }
        }

        public void VoertuigToevoegenMetBestuurder(Voertuig voertuig, Bestuurder bestuurder) {
            try {
                if (voertuig == null) throw new VoertuigManagerException("VoertuigToevoegen - voertuig is null");
                if (bestuurder == null) throw new VoertuigManagerException("VoertuigToevoegen - voertuig is null");
                if (repo.BestaatVoertuig(voertuig.ChassisNummer)) throw new VoertuigManagerException("VoertuigToevoegen - voertuig bestaat reeds");
                repo.VoertuigToevoegenMetBestuurder(voertuig, bestuurder);
            } catch (Exception ex) {
                throw new VoertuigManagerException("VoertuigToevoegenMetBestuurder", ex);
            }
            
        }

        public void VerwijderVoertuig(string chassisNummer) {
            try {
                if (!repo.BestaatVoertuig(chassisNummer)) throw new VoertuigManagerException("VerwijderVoertuig - voertuig bestaat niet");
                repo.VerwijderVoertuigVanBestuurder(chassisNummer);
                repo.VerwijderVoertuig(chassisNummer);
            } catch (Exception ex) {
                throw new VoertuigManagerException("VerwijderVoertuig", ex);
            }
        }

        public bool UpdateVoertuig(Voertuig voertuig) {
            try {
                if (voertuig == null) throw new VoertuigManagerException("UpdateVoertuig - voertuig is null");
                if (!repo.BestaatVoertuig(voertuig.ChassisNummer)) throw new VoertuigManagerException("UpdateVoertuig - voertuig bestaat niet");
                Voertuig voertuigDB = repo.GeefVoertuig(voertuig.ChassisNummer)[0];
                if (voertuig == voertuigDB) throw new VoertuigManagerException("UpdateVoertuig - geen verschillen");
                repo.UpdateVoertuig(voertuig);
                return true;
            } catch (Exception ex) {
                throw new VoertuigManagerException("UpdateVoertuig", ex);
            }
        }
    } 
}
