﻿using Business_Layer.Exceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business_Layer
{
    public class TankKaart
    {
        public int KaartNummer { get; private set; }
        public DateTime Geldigheidsdatum { get; private set; }
        public int Pincode { get; set; }
        public List<BrandstofType> Brandstof { get; private set; }
        public Bestuurder Bestuurder { get; private set; }
        public bool ActiefStatus { get; private set; }

        public TankKaart(int kaartNummer) {
            SetKaartNummer(kaartNummer);
        }

        public TankKaart(int kaartNummer, DateTime geldigheidsdatum):this(kaartNummer) {
            SetKaartGeldigheidsDatum(geldigheidsdatum);
        }

        public TankKaart(int kaartNummer, DateTime geldigheidsdatum, int pincode, List<BrandstofType> brandstof, Bestuurder bestuurder, bool actiefStatus) : this(kaartNummer, geldigheidsdatum) {
            SetPincode(pincode);
            SetBrandstofType(brandstof);
            SetBestuurder(bestuurder);
            SetActiefStatus(actiefStatus);
        }

        /// <summary>
        /// Een kaartnummer mag niet 0 zijn
        /// </summary>
        /// <param name="kaartNummer"></param>
        public void SetKaartNummer(int kaartNummer) {
            if (kaartNummer > 0) {
                KaartNummer = kaartNummer;
            } else {
                throw new TankkaartException("Tankkaart - kaartnummer ongeldig.");
            }
        }

        public void SetKaartGeldigheidsDatum(DateTime datum)
        {
            if (!string.IsNullOrWhiteSpace(datum.ToLongDateString())) {
                Geldigheidsdatum = datum;
            } else {
                throw new TankkaartException("Tankkaart - geldigheidsdatum ongeldig.");
            }
        }

        /// <summary>
        /// Een pincode bestaat altijd uit 4 cijfers
        /// </summary>
        /// <param name="pincode"></param>
        public void SetPincode(int pincode)
        {
            if (pincode != 0) {
                if (pincode.ToString().Length == 4) {
                    Pincode = pincode;
                } else {
                    throw new TankkaartException("Tankkaart - pincode ongeldig.");
                }
            } else {
                throw new TankkaartException("Tankkaart - pincode ongeldig.");
            }
        }

        public void SetBrandstofType(List<BrandstofType> brandstof)
        {
            if (brandstof.Count > 0) {
                Brandstof = brandstof;
            } else {
                throw new TankkaartException("Tankkaart - brandstof ongeldig.");
            }
        }

        public void SetBestuurder(Bestuurder bestuurder)
        {
            if (bestuurder == Bestuurder && bestuurder != null) {
                throw new TankkaartException("Bestuurder is al toegewezen aan deze tankkaart");
            } else if (bestuurder == null && Bestuurder != null) {
                throw new TankkaartException("Tankkaart - bestuurder is leeg");
            }
            if (Bestuurder != null) {
                if (Bestuurder.HeeftTankkaart(this)) {
                    Bestuurder.VerwijderTankkaartVanBestuurder(this);
                }
            }

            if (bestuurder != null) {
                if (!bestuurder.HeeftTankkaart(this)) {
                    bestuurder.SetTankKaart(this);
                }
            }

            Bestuurder = bestuurder;
        }

        /// <summary>
        /// Toont aan of de tankkaart reeds in gebruik is of niet
        /// </summary>
        /// <param name="status"></param>
        public void SetActiefStatus(bool status)
        {
            ActiefStatus = status;
        }

        /// <summary>
        /// Deze writer leest door de lijst van brandstoftypes van een tankkaart en maakt er een string van voor de databank
        /// </summary>
        /// <returns></returns>
        public string BrandstofTypeToString() {
            string s = "";
            foreach (var brandstof in Brandstof) {
                s += brandstof.ToString();
                s += ",";
            }
            s = s.Remove(s.Length - 1);
            return s.Trim();

        }

        public override string ToString() {
            return $"kaartnummer: {KaartNummer}, Geldigheidsdatum: {Geldigheidsdatum}, pincode: {Pincode}, Brandstoftypes: {BrandstofTypeToString()}, actiefstatus: {ActiefStatus}, Bestuurder Naam : {Bestuurder.Voornaam}";
        }

        public override bool Equals(object obj) {
            return obj is TankKaart kaart &&
                   KaartNummer == kaart.KaartNummer &&
                   Geldigheidsdatum == kaart.Geldigheidsdatum &&
                   Pincode == kaart.Pincode &&
                   ActiefStatus == kaart.ActiefStatus;
        }

        public override int GetHashCode() {
            return HashCode.Combine(KaartNummer, Geldigheidsdatum, Pincode, Brandstof, Bestuurder, ActiefStatus);
        }
    }
}
