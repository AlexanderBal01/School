﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business_Layer.Tools
{
    public static class RijksRegisterValidatie
    {

        public static bool CheckRijksregister(string RijksregisterNummer)
        {
            bool validationsucceeded = false;
            if (RijksregisterNummer.Length == 15) /// Faalt als de string niet gelijk aant 15 is
            {
                string DatumSubString = RijksregisterNummer.Substring(0, 8); //Voorbeeld: 97.12.05
                char[] DatumArray = DatumSubString.ToCharArray();
                if (Char.IsDigit(DatumArray[0]) && Char.IsDigit(DatumArray[1]) && DatumArray[2] == '.' && Char.IsDigit(DatumArray[3]) && Char.IsDigit(DatumArray[4]) && DatumArray[5] == '.' && Char.IsDigit(DatumArray[6]) && Char.IsDigit(DatumArray[7]))
                {   /// Faalt als 1 van de datum chars niet correct is 
                    string[] DatumIn3Gesplits = DatumSubString.Split('.');
                    int JaarNummer = int.Parse(DatumIn3Gesplits[0]);
                    int MaandNummer = int.Parse(DatumIn3Gesplits[1]);
                    if (MaandNummer >= 1 && MaandNummer <= 12) /// Dit faalt als de maand niet binnen 1-12 ligt
                    {
                        int DagNummer = int.Parse(DatumIn3Gesplits[2]);
                        bool IsJaarNa2000 = false;
                        string JaarInterpretatie = "";
                        if (JaarNummer <= 30)
                        {
                            JaarInterpretatie = "20" + DatumIn3Gesplits[0]; /// Als de gebruiker na 2000 geboren is, voeg je 20 toe aan de method en check dan hoe veel dagen er in de maand zijn 
                            IsJaarNa2000 = true;
                        }
                        else
                        {
                            JaarInterpretatie = "19" + DatumIn3Gesplits[0];
                        }
                        int DagenInMaandEnJaar = DateTime.DaysInMonth(int.Parse(JaarInterpretatie), MaandNummer);
                        if (DagNummer <= DagenInMaandEnJaar) /// Dit faalt als er een foutive datum gegeven word (bv. 30 Februari)
                        {
                            /// Na dit wordt de datum ok gerekend
                            /// Volgende check is het geboorte getal 
                            bool Char8IsCorrect = false;
                            if (RijksregisterNummer.ElementAt(8) == '-')
                            {
                                Char8IsCorrect = true;
                            }
                            string HoeveelheidGeboortes = RijksregisterNummer.Substring(9, 3); //Voorbeeld 250
                            if (HoeveelheidGeboortes.All(char.IsDigit) && HoeveelheidGeboortes != "000" && Char8IsCorrect)
                            {
                                /// We weten nu dat het volgende getal maar 2 digits heeft en niet 000 is
                                if (RijksregisterNummer.ElementAt(12) == '.')
                                {
                                    string SamenGevoegdeStringNummers = DatumIn3Gesplits[0] + DatumIn3Gesplits[1] + DatumIn3Gesplits[2] + HoeveelheidGeboortes;
                                    if (IsJaarNa2000)
                                    {
                                        SamenGevoegdeStringNummers = "2" + DatumIn3Gesplits[0] + DatumIn3Gesplits[1] + DatumIn3Gesplits[2] + HoeveelheidGeboortes; ///extra validation needed for people born after 2000
                                    }
                                    int TeDelenNummer = int.Parse(SamenGevoegdeStringNummers); //Voorbeeld  900201999
                                    int BerekendeModulo= TeDelenNummer % 97;
                                    int BerekendControleNummer = 97 - BerekendeModulo;
                                    string BerekendControleNummerAlsText = BerekendControleNummer.ToString("00"); /// veranderd Nummers kleiner dan 10 in "02"
                                    if (BerekendControleNummerAlsText == RijksregisterNummer.Substring(13, 2))
                                    {
                                        validationsucceeded = true;
                                    }
                                }
                            }
                        }
                    }
                }
            }

            return validationsucceeded;
        }



    }
}
