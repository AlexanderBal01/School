﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business_Layer.Tools
{
    public static class ChassisNummerValidatie
    {

        /// <summary>
        /// Chassisnummers horen te voldoen aan bepaalde voorwaarden
        /// Er zijn tekens die niet mogen voorkomen nl. "I", "Q" en "O"
        /// De lengte van het chassisnummer is altijd 17 karakters lang
        /// </summary>
        /// <param name="chassisnummer"></param>
        /// <returns></returns>
        public static bool ValideerChassisNummer(string chassisnummer)
        {
            List<string> verbodentekens = new List<string>() { "I", "Q", "O" };
            chassisnummer.Trim().ToUpper();
            if (chassisnummer.Length != 17)
            {
                return false;
            }
            else if (chassisnummer.Contains("I") || chassisnummer.Contains("O") || chassisnummer.Contains("Q"))
            {
                return false;
            }
            else { return true; }
        }



    }
}
