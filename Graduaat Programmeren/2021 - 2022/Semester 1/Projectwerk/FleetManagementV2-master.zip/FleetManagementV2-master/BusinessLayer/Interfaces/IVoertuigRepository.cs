﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business_Layer.Interfaces
{
    public interface IVoertuigRepository
    {
        bool BestaatVoertuig(string chassisNummer);
        List<Voertuig> GeefVoertuig(string tekst);
        void UpdateVoertuig(Voertuig voertuig);
        void VerwijderVoertuig(string chassisNummer);
        void VerwijderVoertuigVanBestuurder(string chassisNummer);
        void VoertuigToevoegen(Voertuig voertuig);
        void VoertuigToevoegenMetBestuurder(Voertuig voertuig, Bestuurder bestuurder);
    }
}
