﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business_Layer.Interfaces
{
    public interface IBestuurderRepository 
    {
        bool BestaatBestuurder(int id);
        List<Bestuurder> GeefBestuurder(string tekst);
        void BestuurderToevoegen(Bestuurder bestuurder);
        void VerwijderBestuurder(int id);
        void UpdateBestuurder(Bestuurder b);
        void VerwijderTankkaartVanBestuurder(Bestuurder b);
        void VerwijderVoertuigVanBestuurder(Bestuurder bestuurder);
    }
}
