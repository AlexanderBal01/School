﻿using Business_Layer.Exceptions;
using Business_Layer.Tools;
using System;
using System.Collections.Generic;

namespace Business_Layer
{
    public class Voertuig
    {
        public string ChassisNummer { get; set; }
        public string NummerPlaat { get; set; }
        public string Merk { get; set; }
        public string Model { get; set; }
        public List<BrandstofType> BrandstofType { get; set; }
        public string TypeWagen { get; set; }
        public string Kleur { get; set; }
        public int AantalDeuren { get; set; }
        public Bestuurder Bestuurder { get; set; }

        public Voertuig(string chassisNummer) {
            SetChassis(chassisNummer);
        }

        public Voertuig(string chassisNummer, string nummerPlaat, string merk, string model, List<BrandstofType> brandstofType, string typeWagen) : this(chassisNummer) {
            SetNrPlaat(nummerPlaat);
            SetMerk(merk);
            SetModel(model);
            SetBrandstof(brandstofType);
            SetTypeWagen(typeWagen);
        }

        public Voertuig(string chassisNummer, string nummerPlaat, string merk, string model, List<BrandstofType> brandstofType, string typeWagen, string kleur, int aantalDeuren) : this(chassisNummer, nummerPlaat, merk, model, brandstofType, typeWagen) {
            SetKleur(kleur);
            SetAantalDeuren(aantalDeuren);
            
        }

        public Voertuig(string chassisNummer, string nummerPlaat, string merk, string model, List<BrandstofType> brandstofType, string typeWagen, string kleur, int aantalDeuren, Bestuurder bestuurder) : this(chassisNummer, nummerPlaat, merk, model, brandstofType, typeWagen, kleur, aantalDeuren) {
            SetBestuurder(bestuurder);
        }

        public void SetBestuurder(Bestuurder bestuurder) {
            if (bestuurder == Bestuurder && bestuurder!=null) {
                throw new VoertuigException("Bestuurder is al toegewezen aan dit voertuig");
            } else if(bestuurder==null && Bestuurder!=null) {
                throw new VoertuigException("Voertuig - bestuurder is leeg.");
            }
            if (Bestuurder != null) {
                if (Bestuurder.HeeftVoertuig(this)) {
                    Bestuurder.VerwijderVoertuigVanBestuurder(this);
                }
            }
            if(bestuurder != null) {
                if (!bestuurder.HeeftVoertuig(this)) {
                    bestuurder.SetVoertuig(this);
                }
            }
            
            Bestuurder = bestuurder;
        }     

        /// <summary>
        /// Een chassisnummer moet gecheckt worden op correcte compositie
        /// </summary>
        /// <param name="chassisNr"></param>
        public void SetChassis(string chassisNr) {
            if (!string.IsNullOrWhiteSpace(chassisNr)) {
                if (ChassisNummerValidatie.ValideerChassisNummer(chassisNr)) {
                    ChassisNummer = chassisNr;
                } else {
                    throw new VoertuigException("Voertuig - Chassisnummer klopt niet");
                }
            } else throw new VoertuigException("Voertuig - Chassisnummer is leeg");
        }
        public void SetNrPlaat(string nrPlaat) {
            if(!string.IsNullOrWhiteSpace(nrPlaat)) NummerPlaat = nrPlaat;
            else throw new VoertuigException("Voertuig - Nummerplaat is leeg");
        }
        public void SetMerk(string merk) {
            if (!string.IsNullOrWhiteSpace(merk)) Merk = merk;
            else throw new VoertuigException("Voertuig - Merknaam is leeg");
        }
        public void SetModel(string model) {
            if (!string.IsNullOrWhiteSpace(model)) Model = model;
            else throw new VoertuigException("Voertuig - Model van auto is leeg");
        }
        public void SetBrandstof(List<BrandstofType> brandstof) {
            if (brandstof.Count > 0) BrandstofType = brandstof;
            else throw new VoertuigException("Voertuig - Brandstoftype is leeg");
        }
        public void SetTypeWagen(string type) {
            if (!string.IsNullOrWhiteSpace(type)) TypeWagen = type;
            else throw new VoertuigException("Voertuig - Type wagen is leeg");
        }
        public void SetKleur(string kleur) {
            if (!string.IsNullOrWhiteSpace(kleur)) Kleur = kleur;
            else throw new VoertuigException("Voertuig - Kleur is leeg");
        }
        /// <summary>
        /// Een auto heeft minimum 1 deur
        /// </summary>
        /// <param name="aantal"></param>
        public void SetAantalDeuren(int aantal) {
            if(aantal > 0) AantalDeuren = aantal;
            else throw new VoertuigException("Voertuig - Aantal deuren is leeg");
        }

        public string BrandstofTypeToString() {
            string s = "";
            foreach (var brandstof in BrandstofType) {
                s += brandstof.ToString();
                s += ",";
            }
            s = s.Remove(s.Length - 1);
            return s.Trim();

        }

        public override string ToString() {
            if (BrandstofType.Count > 1) {
                return $"Chassisnummer: {ChassisNummer}, Nummerplaat: {NummerPlaat}, Merk, model & type: {Merk} {Model} {TypeWagen}," +
                $" Brandstof: {BrandstofType[0]},{BrandstofType[1]}, Kleur: {Kleur}, Aantal deuren: {AantalDeuren}";
            } else return $"Chassisnummer: {ChassisNummer}, Nummerplaat: {NummerPlaat}, Merk, model & type: {Merk} {Model} {TypeWagen}," +
                $" Brandstof: {BrandstofType[0]}, Kleur: {Kleur}, Aantal deuren: {AantalDeuren}";
        }

        public override bool Equals(object obj) {
            return obj is Voertuig voertuig &&
                   ChassisNummer == voertuig.ChassisNummer &&
                   NummerPlaat == voertuig.NummerPlaat &&
                   Merk == voertuig.Merk &&
                   Model == voertuig.Model &&
                   EqualityComparer<List<BrandstofType>>.Default.Equals(BrandstofType, voertuig.BrandstofType) &&
                   TypeWagen == voertuig.TypeWagen &&
                   Kleur == voertuig.Kleur &&
                   AantalDeuren == voertuig.AantalDeuren;
        }

        public override int GetHashCode() {
            HashCode hash = new HashCode();
            hash.Add(ChassisNummer);
            hash.Add(NummerPlaat);
            hash.Add(Merk);
            hash.Add(Model);
            hash.Add(BrandstofType);
            hash.Add(TypeWagen);
            hash.Add(Kleur);
            hash.Add(AantalDeuren);
            hash.Add(Bestuurder);
            return hash.ToHashCode();
        }
    }
}
