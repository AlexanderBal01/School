﻿using Business_Layer.Exceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business_Layer {
    public class Bestuurder {
        public string Naam { get; private set; }
        public string Voornaam { get; private set; }
        public string Rijksregister { get; private set; }
        public string TypeRijbewijs { get; private set; }
        public Adres Adres { get; private set; }
        public DateTime GeboorteDatum { get; private set; }
        public TankKaart TankKaart { get; private set; }
        public Voertuig Voertuig { get; private set; }
        public int Id { get; private set; }

        public Bestuurder(string naam, string voornaam, string rijksregister, string typeRijbewijs, DateTime geboorteDatum) {
            SetNaam(naam);
            SetVoornaam(voornaam);
            SetRijksregister(rijksregister);
            SetTypeRijbewijs(typeRijbewijs);
            SetGeboorteDatum(geboorteDatum);
        }

        public Bestuurder(int id, string naam, string voornaam, string rijksregister, string typeRijbewijs, DateTime geboorteDatum) : this(naam, voornaam, rijksregister, typeRijbewijs, geboorteDatum){
            SetId(id);
        }

        public Bestuurder(string naam, string voornaam, string rijksregister, string typeRijbewijs, DateTime geboorteDatum, Adres adres)
            : this(naam, voornaam, rijksregister, typeRijbewijs, geboorteDatum) {
            SetAdres(adres);
        }

        public Bestuurder(string naam, string voornaam, string rijksregister, string typeRijbewijs, Adres adres, DateTime geboorteDatum, TankKaart tankKaart) : this(naam, voornaam, rijksregister, typeRijbewijs, geboorteDatum, adres) {
            SetTankKaart(tankKaart);
        }

        public Bestuurder(string naam, string voornaam, string rijksregister, string typeRijbewijs, Adres adres, DateTime geboorteDatum, Voertuig voertuig) : this(naam, voornaam, rijksregister, typeRijbewijs, geboorteDatum, adres) {
            SetVoertuig(voertuig);
        }

        public Bestuurder(string naam, string voornaam, string rijksregister, string typeRijbewijs, Adres adres, DateTime geboorteDatum, TankKaart tankKaart, Voertuig voertuig)
            : this(naam, voornaam, rijksregister, typeRijbewijs, geboorteDatum, adres) {
            SetTankKaart(tankKaart);
            SetVoertuig(voertuig);
        }

        public Bestuurder(string naam, string voornaam, string rijksregister, string typeRijbewijs, Adres adres, DateTime geboorteDatum, TankKaart tankKaart, Voertuig voertuig, int id) : this(naam, voornaam, rijksregister, typeRijbewijs, adres, geboorteDatum, tankKaart, voertuig) {
            SetId(id);
        }

        public void SetId(int id) {
            if (id > 0) {
                Id = id;
            } else {
                throw new BestuurderException("Bestuurder - id ongeldig.");
            }
        }

        /// <summary>
        /// Indien de bestuurder geen rijbewijs heeft kan men geen voertuig toevoegen aan deze bestuurder
        /// </summary>
        /// <param name="voertuig"></param>
        public void SetVoertuig(Voertuig voertuig) {
            if (!string.IsNullOrWhiteSpace(TypeRijbewijs)) {
                Voertuig = voertuig;
                if (voertuig != null) {
                    voertuig.SetBestuurder(this);
                }

            } else {
                throw new BestuurderException("Bestuurder - voertuig ongeldig.");
            }
        }

        public void SetAdres(Adres adres) {
            if (adres != null) {
                Adres = adres;
            } else {
                throw new BestuurderException("Bestuurder - adres ongeldig.");
            }
        }

        public bool HeeftTankkaart(TankKaart tankKaart) {
            if (tankKaart == TankKaart) {
                return true;
            } else {
                return false;
            }
        }

        public void VerwijderTankkaartVanBestuurder(TankKaart tankKaart) {
            if (tankKaart == null) {
                throw new BestuurderException("Bestuurder - Kan voertuig niet verwijderen.");
            } else if (tankKaart == TankKaart) {
                TankKaart = null;
            }
        }

        /// <summary>
        /// Een tankkaart is geen vereiste en mag dus null zijn, vandaar geen check op null
        /// </summary>
        /// <param name="tankKaart"></param>
        public void SetTankKaart(TankKaart tankKaart) {
            TankKaart = tankKaart;
            if (tankKaart != null) {
                if (TankKaart.Bestuurder != this) {
                    tankKaart.SetBestuurder(this);
                } else {
                    throw new BestuurderException("Bestuurder - tankkaart Ongeldig");
                }
            }
        }

        public void SetGeboorteDatum(DateTime geboorteDatum) {
            if (!string.IsNullOrWhiteSpace(geboorteDatum.ToLongDateString())) {
                GeboorteDatum = geboorteDatum;
            } else {
                throw new BestuurderException("Bestuurder - geboortedatum ongeldig.");
            }
        }

        public void SetTypeRijbewijs(string typeRijbewijs) {
            if (!string.IsNullOrWhiteSpace(typeRijbewijs)) {
                TypeRijbewijs = typeRijbewijs;
            } else {
                throw new BestuurderException("Bestuurder - type rijbewijs ongeldig.");
            }
        }

        public void SetRijksregister(string rijksregister) {
            if (!string.IsNullOrWhiteSpace(rijksregister)) {
                Rijksregister = rijksregister;
            } else {
                throw new BestuurderException("Bestuurder - rijksregister ongeldig.");
            }
        }

        public void SetVoornaam(string voornaam) {
            if (!string.IsNullOrWhiteSpace(voornaam)) {
                Voornaam = voornaam;
            } else {
                throw new BestuurderException("Bestuurder - voornaam ongeldig.");
            }
        }

        public void SetNaam(string naam) {
            if (!string.IsNullOrWhiteSpace(naam)) {
                Naam = naam;
            } else {
                throw new BestuurderException("Bestuurder - naam ongeldig.");
            }
        }

        public bool HeeftVoertuig(Voertuig voertuig) {
            if (voertuig == Voertuig) {
                return true;
            } else {
                return false;
            }
        }

        public void VerwijderVoertuigVanBestuurder(Voertuig voertuig) {
            if (voertuig == null) {
                throw new BestuurderException("Bestuurder - Kan voertuig niet verwijderen.");
            } else if (voertuig == Voertuig) {
                Voertuig = null;
            }
        }

        public override string ToString() {
            return $"Bestuurder: {Id}, {Voornaam} {Naam}, Geboortedatum: {GeboorteDatum.ToShortDateString()}, Rijksregisternummer: {Rijksregister}, Type rijbewijs: {TypeRijbewijs}";
        }

        public override bool Equals(object obj) {
            return obj is Bestuurder bestuurder &&
                   Naam == bestuurder.Naam &&
                   Voornaam == bestuurder.Voornaam &&
                   Rijksregister == bestuurder.Rijksregister &&
                   GeboorteDatum == bestuurder.GeboorteDatum &&
                   Id == bestuurder.Id;
        }

        public override int GetHashCode() {
            return HashCode.Combine(Naam, Voornaam, Rijksregister, GeboorteDatum, Id);
        }
    }
}
