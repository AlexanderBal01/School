﻿using Business_Layer;
using Business_Layer.Managers;
using Data_Access_Layer.Repositories;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace User_Interface
{
    /// <summary>
    /// Interaction logic for SearchWindow.xaml
    /// </summary>
    public partial class SearchWindow : Window
    {
        public SearchWindow(string zoekOnderwerp)
        { 
            InitializeComponent();
            if (zoekOnderwerp.ToLower() == "tankkaart")
            {
                LblDialogWindow.Content = "Tankkaart Selecteren";
                txtBoxDialogSearch.Text = "Zoek TankKaart op ID";
                ZoekOnderwerp = zoekOnderwerp;
            }
            else if (zoekOnderwerp.ToLower() == "voertuig")
            {
                LblDialogWindow.Content = "Voertuig Selecteren";
                txtBoxDialogSearch.Text = "Zoek Voertuig op ChassisNummer of op NummerPlaat";
                ZoekOnderwerp = zoekOnderwerp;
            }
            else if (zoekOnderwerp.ToLower() == "bestuurder")
            {
                LblDialogWindow.Content = "Bestuurder Selecteren";
                txtBoxDialogSearch.Text = "Zoek Bestuurder op Naam, Achternaam of RijksregisterNummer";
                ZoekOnderwerp = zoekOnderwerp;
            }
        }

        TankKaartManager TM = new TankKaartManager(new TankKaartRepository(ConfigurationManager.ConnectionStrings["connectionString"].ToString()));
        VoertuigManager VM = new VoertuigManager(new VoertuigRepository(ConfigurationManager.ConnectionStrings["connectionString"].ToString()));
        BestuurderManager BM = new BestuurderManager(new BestuurderRepository(ConfigurationManager.ConnectionStrings["connectionString"].ToString()));


        string ZoekOnderwerp = "";
        string VorigeText = "";

        public TankKaart tankKaart = null;
        public Voertuig voertuig = null;
        public Bestuurder bestuurder = null;

        private TankKaart GevondenTankkaart = null;
        private List<Voertuig> GevondenVoertuigen = null;
        private List<Bestuurder> GevondenBestuurders = null;

        public void Search()
        {
            //Bestuurder ook toevoegen
            ListBoxDialogResult.IsEnabled = true;
            ListBoxDialogResult.Items.Clear();
            try
            {
                if (ZoekOnderwerp.ToLower() == "voertuig")
                {
                    string tekst = txtBoxDialogSearch.Text;
                    List<Voertuig> voertuigen = VM.GeefVoertuig(tekst);
                    foreach (var v in voertuigen) ListBoxDialogResult.Items.Add(v);
                    GevondenVoertuigen = voertuigen;
                }
                else if (ZoekOnderwerp.ToLower() == "bestuurder")
                {
                    string tekst = txtBoxDialogSearch.Text;
                    List<Bestuurder> bestuurders = BM.GeefBestuurder(tekst);
                    foreach (var v in bestuurders) ListBoxDialogResult.Items.Add(v);
                    GevondenBestuurders = bestuurders;
                }
                else if (ZoekOnderwerp.ToLower() == "tankkaart")
                {
                    int tekst = int.Parse(txtBoxDialogSearch.Text);
                    TankKaart t = TM.GeefTankkaart(tekst);
                    ListBoxDialogResult.Items.Add(t);
                    GevondenTankkaart = t;
                }

                if (ListBoxDialogResult.Items.Count == 0)
                {
                    ListBoxDialogResult.Items.Add("-- Geen Resultaten Gevonden --");
                    ListBoxDialogResult.IsEnabled = false;
                }
            }
            catch (Exception e)
            {
                ListBoxDialogResult.Items.Add(e);
            }


        }

        private void BtnDialogCancel_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult messageBoxResult = MessageBox.Show("Ben je zeker?", "Confirmation", MessageBoxButton.YesNo);
            if (messageBoxResult == MessageBoxResult.Yes)
            {
                Close();
            }
            
        }

        private void BtnDialogSelect_Click(object sender, RoutedEventArgs e)
        {
            //obj maken
            if (ListBoxDialogResult.SelectedItem == null)
            {
                MessageBoxResult messageBoxResult = MessageBox.Show("Niets geselecteerd", "Confirmation", MessageBoxButton.OK);
                
            }
            else if (ZoekOnderwerp.ToLower() == "voertuig")
            {
                try
                {
                    var tussenItem  = ListBoxDialogResult.SelectedIndex;
                    var tussenvoertuig  = GevondenVoertuigen[tussenItem];
                    voertuig = tussenvoertuig;
                }
                catch (Exception)
                {
                    throw;
                }
                DialogResult = true;
                Close();
            }
            else if (ZoekOnderwerp.ToLower() == "tankkaart")
            {
                try
                {
                    tankKaart = (TankKaart)ListBoxDialogResult.SelectedItem;
                }
                catch (Exception)
                {
                    throw;
                }
                DialogResult = true;
                Close();
            }
            else if (ZoekOnderwerp.ToLower() == "bestuurder")
            {
                try
                {
                    var tussenItem = ListBoxDialogResult.SelectedIndex;
                    var tussenBestuurder = GevondenBestuurders[tussenItem];
                    bestuurder = tussenBestuurder;
                }
                catch (Exception)
                {
                    throw;
                }
                DialogResult = true;
                Close();
            }
            


            
        }

        private void BtnSearchDialog_Click(object sender, RoutedEventArgs e)
        {
            Search();
        }

        private void txtBoxDialogSearch_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Return)
            {
                Search();
            }
        }

        public void RemoveText(object sender, EventArgs e)
        {
            var txtbox = (TextBox)sender;
            if (!string.IsNullOrWhiteSpace(txtbox.Text))
            {
                VorigeText = txtbox.Text;
                txtbox.Text = "";
            }
        }

        public void AddText(object sender, EventArgs e)
        {
            var txtbox = (TextBox)sender;
            if (string.IsNullOrWhiteSpace(txtbox.Text))
                txtbox.Text = VorigeText;
        }

        
    }
}
