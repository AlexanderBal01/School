﻿using Business_Layer;
using Business_Layer.Managers;
using Data_Access_Layer.Repositories;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace User_Interface.Aanpassen_Windows
{
    /// <summary>
    /// Interaction logic for VoertuigAanpassen.xaml
    /// </summary>
    public partial class VoertuigAanpassen : Window
    {
        public VoertuigAanpassen(string AanTePassen, Voertuig voertuig)
        {
            InitializeComponent();
            _aanTePassen = AanTePassen;
            AanTePassenVoertuig = voertuig;

            SetValues(voertuig);

        }

        public Voertuig AanTePassenVoertuig { get; set; }
        public Bestuurder BestaandeBestuurder { get; set; }
        private string _aanTePassen { get; set; }
        string VorigeText = "";
        public bool isClosed = false;
        private VoertuigManager VM = new VoertuigManager(new VoertuigRepository(ConfigurationManager.ConnectionStrings["connectionString"].ToString()));


        public void RemoveText(object sender, EventArgs e)
        {
            var txtbox = (TextBox)sender;
            if (!string.IsNullOrWhiteSpace(txtbox.Text))
            {
                VorigeText = txtbox.Text;
                txtbox.Text = "";
            }
        }
        public void AddText(object sender, EventArgs e)
        {
            var txtbox = (TextBox)sender;
            if (string.IsNullOrWhiteSpace(txtbox.Text))
                txtbox.Text = VorigeText;
        }

        public void SetValues(Voertuig voertuig)
        {
            txtBoxVoertuigChassisNr.Text = voertuig.ChassisNummer;
            txtBoxVoertuigMerk.Text = voertuig.Merk;
            txtBoxVoertuigKleur.Text = voertuig.Kleur;
            txtBoxVoertuigTypeWage.Text = voertuig.TypeWagen;
            txtBoxVoertuigNrplaat.Text = voertuig.NummerPlaat;
            txtBoxVoertuigModel.Text = voertuig.Model;
            ComboBoxVoertuigAantalDeuren.SelectedItem = voertuig.AantalDeuren;
            foreach (ListBoxItem item in ListboxVoertuigBrandstof.Items) {
                if (item.Content.ToString() == "Brandstof Type") {
                    continue;
                } else if (voertuig.BrandstofType.Contains(Enum.Parse<BrandstofType>(item.Content.ToString()))) {
                    item.IsSelected = true;
                }
            }
            if (voertuig.Bestuurder == null) LblVoertuigBestaandeBestuurder.Content = $"Geen Gelinkte Bestuurder";
            else LblVoertuigBestaandeBestuurder.Content = $"Gelinkte Bestuurder : {voertuig.Bestuurder.Voornaam} {voertuig.Bestuurder.Naam}";

        }


        private void BtnAanpassen_Click(object sender, RoutedEventArgs e) {
            try {
                if (!isClosed) {
                    List<BrandstofType> BrandstofTypes = GeefBrandstofTypes(ListboxVoertuigBrandstof);
                    AanTePassenVoertuig = new Voertuig(txtBoxVoertuigChassisNr.Text, txtBoxVoertuigNrplaat.Text, txtBoxVoertuigMerk.Text, txtBoxVoertuigModel.Text,
                        BrandstofTypes, txtBoxVoertuigTypeWage.Text, txtBoxVoertuigKleur.Text, int.Parse(ComboBoxVoertuigAantalDeuren.Text), AanTePassenVoertuig.Bestuurder);
                    isClosed = true;
                }
                if (isClosed) {
                    bool isGelukt = VM.UpdateVoertuig(AanTePassenVoertuig);
                    if (isGelukt) {
                        MessageBoxResult messageBoxResult = MessageBox.Show("Voertuig Geüpdatet", "Voertuig Update", MessageBoxButton.OK, MessageBoxImage.Information);
                        if (messageBoxResult == MessageBoxResult.OK) {
                            Close();
                        }
                    } else {
                        MessageBox.Show("Voertuig Update gefaald", "Voertuig Update", MessageBoxButton.OK, MessageBoxImage.Warning);
                    }
                    isClosed = false;
                }
            } catch (Exception ex) {
                MessageBox.Show(ex.Message, "Voertuig updaten mislukt", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        public List<BrandstofType> GeefBrandstofTypes(ListBox brandstofListbox) {
            List<BrandstofType> BrandstofTypes = new List<BrandstofType>();
            foreach (ListBoxItem item in brandstofListbox.Items) {
                if (item.IsSelected) {
                    BrandstofTypes.Add(Enum.Parse<BrandstofType>(item.Content.ToString()));
                }
            }

            return BrandstofTypes;
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult messageBoxResult = MessageBox.Show("Ben je zeker?", "Confirmation", MessageBoxButton.YesNo);
            if (messageBoxResult == MessageBoxResult.Yes)
            {
                Close();
            }
        }

        private void BtnvoertuigBestaandeBestuurder_Click(object sender, RoutedEventArgs e)
        {
            SearchWindow Search = new SearchWindow("bestuurder");
            if (Search.ShowDialog() == true)
            {
                BestaandeBestuurder = Search.bestuurder;
            }
        }



    }    
}
          