﻿using Business_Layer;
using Business_Layer.Managers;
using Data_Access_Layer.Repositories;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace User_Interface.Aanpassen_Windows
{
    /// <summary>
    /// Interaction logic for BestuurderAanpassen.xaml
    /// </summary>
    public partial class BestuurderAanpassen : Window
    {
        public BestuurderAanpassen(string AanTePassen, Bestuurder bestuurder)
        {
            InitializeComponent();
            AanTePassenBestuurder = bestuurder;
            _aanTePassen = AanTePassen;

            SetValues(bestuurder);
        }

        public Bestuurder AanTePassenBestuurder { get; set; }
        public Voertuig BestaandVoertuig { get; set; }
        public TankKaart BestaandeTankKaart { get; set; }
        private string _aanTePassen { get; set; }
        string VorigeText = "";
        public bool isClosed = false;
        BestuurderManager BM = new BestuurderManager(new BestuurderRepository(ConfigurationManager.ConnectionStrings["connectionString"].ToString()));
        TankKaartManager TM = new TankKaartManager(new TankKaartRepository(ConfigurationManager.ConnectionStrings["connectionString"].ToString()));
        VoertuigManager VM = new VoertuigManager(new VoertuigRepository(ConfigurationManager.ConnectionStrings["connectionString"].ToString()));


        public void SetValues(Bestuurder bestuurder) {
            lblBestuurderId.Content += bestuurder.Id.ToString();
            txtBoxBestuurderVoornaam.Text = bestuurder.Voornaam;
            txtBoxBestuurderNaam.Text = bestuurder.Naam;
            txtBoxBestuurderTypeRijbewijs.Text = bestuurder.TypeRijbewijs;
            txtBoxBestuurderRRN.Text = bestuurder.Rijksregister;
            txtBoxBestuurderStraat.Text = bestuurder.Adres.Straat;
            txtBoxBestuurderHuisNr.Text = bestuurder.Adres.Huisnummer;
            txtBoxBestuurderStad.Text = bestuurder.Adres.Stad;
            txtBoxBestuurderpostcode.Text = bestuurder.Adres.Postcode;
            DatepickerBestuurderGebDatum.SelectedDate = bestuurder.GeboorteDatum;
            if (bestuurder.TankKaart != null) LblBestaandeTankkart.Content = "Geselecteerde TankKaart: " + bestuurder.TankKaart.KaartNummer;
            if (bestuurder.Voertuig != null) LblBestaandVoertuig.Content = "Geselecteerd Voertuig: " + bestuurder.Voertuig.ChassisNummer;
        }

        public void RemoveText(object sender, EventArgs e)
        {
            var txtbox = (TextBox)sender;
            if (!string.IsNullOrWhiteSpace(txtbox.Text))
            {
                VorigeText = txtbox.Text;
                txtbox.Text = "";
            }
        }
        public void AddText(object sender, EventArgs e)
        {
            var txtbox = (TextBox)sender;
            if (string.IsNullOrWhiteSpace(txtbox.Text))
                txtbox.Text = VorigeText;
        }


        private void BtnBestuurderBestaandeTankkaart_Click(object sender, RoutedEventArgs e)
        {
            SearchWindow Search = new SearchWindow("tankkaart");
            if (Search.ShowDialog() == true)
            {
                BestaandeTankKaart = Search.tankKaart;
                LblBestaandeTankkart.Content = $"Geselecteerde TankKaart : " + BestaandeTankKaart.KaartNummer;
                AanTePassenBestuurder.SetTankKaart(BestaandeTankKaart);
            }
        }

        private void BtnBestuurderBestaandVoertuig_Click(object sender, RoutedEventArgs e) {
            SearchWindow Search = new SearchWindow("voertuig");
            if (Search.ShowDialog() == true) {
                BestaandVoertuig = Search.voertuig;
                LblBestaandVoertuig.Content = $"Geselecteerd Voertuig: " + BestaandVoertuig.ChassisNummer;
                AanTePassenBestuurder.SetVoertuig(BestaandVoertuig);
            }
        }

        private void BtnAanpassen_Click(object sender, RoutedEventArgs e)
        {
            try {
                if (!isClosed) {
                    AanTePassenBestuurder = new Bestuurder(txtBoxBestuurderNaam.Text, txtBoxBestuurderVoornaam.Text,
                        txtBoxBestuurderRRN.Text, txtBoxBestuurderTypeRijbewijs.Text, (DateTime)DatepickerBestuurderGebDatum.SelectedDate, 
                        new Adres(txtBoxBestuurderStraat.Text, txtBoxBestuurderHuisNr.Text, txtBoxBestuurderStad.Text, txtBoxBestuurderpostcode.Text));
                    AanTePassenBestuurder.SetId(int.Parse(lblBestuurderId.Content.ToString().Remove(0, 15)));
                    if(LblBestaandeTankkart.Content.ToString() != "Geselecteerde TankKaart: ") {
                        AanTePassenBestuurder.SetTankKaart(new TankKaart(int.Parse(LblBestaandeTankkart.Content.ToString().Remove(0,25))));
                    }
                    if(LblBestaandVoertuig.Content.ToString() != "Geselecteerd Voertuig: ") {
                        AanTePassenBestuurder.SetVoertuig(new Voertuig(LblBestaandVoertuig.Content.ToString().Remove(0,23)));
                    }
                    isClosed = true;
                }
                if (isClosed) {
                    TankKaart t = TM.GeefTankkaart(AanTePassenBestuurder.TankKaart.KaartNummer);
                    if(t.Bestuurder != null) {
                        BM.VerwijderTankkaartVanBestuurder(t.Bestuurder);
                    }
                    Voertuig v = VM.GeefVoertuig(AanTePassenBestuurder.Voertuig.ChassisNummer)[0];
                    if(v.Bestuurder != null) {
                        BM.VerwijderVoertuigVanBestuurder(v.Bestuurder);
                    }

                    bool isGelukt = BM.UpdateBestuurder(AanTePassenBestuurder);
                    if (isGelukt) {
                        MessageBoxResult messageBoxResult = MessageBox.Show("Bestuurder Geüpdatet", "Bestuurder Update", MessageBoxButton.OK, MessageBoxImage.Information);
                        if (messageBoxResult == MessageBoxResult.OK) {
                            Close();
                        }
                    } else {
                        MessageBox.Show("Bestuurder Update gefaald", "Bestuurder Update", MessageBoxButton.OK, MessageBoxImage.Warning);
                    }
                    isClosed = false;

                }
            } catch (Exception ex) {
                MessageBox.Show(ex.Message, "Bestuurder updaten mislukt", MessageBoxButton.OK, MessageBoxImage.Warning);

            }
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult messageBoxResult = MessageBox.Show("Ben je zeker?", "Confirmation", MessageBoxButton.YesNo);
            if (messageBoxResult == MessageBoxResult.Yes)
            {
                Close();
            }
        }



    }
}
