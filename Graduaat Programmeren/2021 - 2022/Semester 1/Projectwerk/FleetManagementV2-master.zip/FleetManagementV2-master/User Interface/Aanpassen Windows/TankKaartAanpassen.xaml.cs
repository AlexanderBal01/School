﻿using Business_Layer;
using Business_Layer.Managers;
using Data_Access_Layer.Repositories;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace User_Interface.Aanpassen_Windows
{
    /// <summary>
    /// Interaction logic for TankKaartAanpassen.xaml
    /// </summary>
    public partial class TankKaartAanpassen : Window
    {
        public TankKaartAanpassen(string AanTePassen, TankKaart tankKaart)
        {
            InitializeComponent();
            _aanTePassen = AanTePassen;
            AanTePassenTankKaart = tankKaart;

            SetValues(tankKaart);
        }

        public TankKaart AanTePassenTankKaart { get; set; }
        public Bestuurder BestaandeBestuurder { get; set; }
        private string _aanTePassen { get; set; }
        string VorigeText = "";
        public bool isClosed = false;
        TankKaartManager TM = new TankKaartManager(new TankKaartRepository(ConfigurationManager.ConnectionStrings["connectionString"].ToString()));


        public void RemoveText(object sender, EventArgs e)
        {
            var txtbox = (TextBox)sender;
            if (!string.IsNullOrWhiteSpace(txtbox.Text))
            {
                VorigeText = txtbox.Text;
                txtbox.Text = "";
            }
        }
        public void AddText(object sender, EventArgs e)
        {
            var txtbox = (TextBox)sender;
            if (string.IsNullOrWhiteSpace(txtbox.Text))
                txtbox.Text = VorigeText;
        }

        public void SetValues(TankKaart tankKaart) {
            if (tankKaart.Bestuurder == null) LblTankkaartBestaandeBestuurder.Content = $"Geen Gelinkte Bestuurder";
            else LblTankkaartBestaandeBestuurder.Content = $"Gelinkte Bestuurder : {tankKaart.Bestuurder.Voornaam} {tankKaart.Bestuurder.Naam}";

            txtBoxTankKaartNr.Text = tankKaart.KaartNummer.ToString();
            txtBoxTankKaartPin.Text = tankKaart.Pincode.ToString();
            foreach (ListBoxItem item in ListboxTankKaartBrandstof.Items) {
                if (item.Content.ToString() == "Brandstof Type") {
                    continue;
                } else if (tankKaart.Brandstof.Contains(Enum.Parse<BrandstofType>(item.Content.ToString()))) {
                    item.IsSelected = true;
                }
            }
            CheckBoxTankKaartactief.IsChecked = tankKaart.ActiefStatus;
            DatePickerTankKaartGeldigheidsDatum.SelectedDate = tankKaart.Geldigheidsdatum;
        }

        public List<BrandstofType> GeefBrandstofTypes(ListBox brandstofListbox) {
            List<BrandstofType> BrandstofTypes = new List<BrandstofType>();
            foreach (ListBoxItem item in brandstofListbox.Items) {
                if (item.IsSelected) {
                    BrandstofTypes.Add(Enum.Parse<BrandstofType>(item.Content.ToString()));
                }
            }

            return BrandstofTypes;
        }

        private void BtnAanpassen_Click(object sender, RoutedEventArgs e)
        {
            try {
                if (!isClosed) {
                    List<BrandstofType> BrandstofTypes = GeefBrandstofTypes(ListboxTankKaartBrandstof);
                    AanTePassenTankKaart = new TankKaart(Int32.Parse(txtBoxTankKaartNr.Text),
                                                       (DateTime)DatePickerTankKaartGeldigheidsDatum.SelectedDate,
                                                       Int32.Parse(txtBoxTankKaartPin.Text),
                                                       BrandstofTypes,
                                                       AanTePassenTankKaart.Bestuurder,
                                                       (bool)CheckBoxTankKaartactief.IsChecked);
                    isClosed = true;
                }
                if (isClosed) {
                    bool isGelukt = TM.UpdateTankkaart(AanTePassenTankKaart);
                    if (isGelukt) {
                        MessageBoxResult messageBoxResult = MessageBox.Show("Tankkaart Geüpdatet", "Tankkaart Update", MessageBoxButton.OK, MessageBoxImage.Information);
                        if (messageBoxResult == MessageBoxResult.OK) {
                            Close();
                        }
                    } else {
                        MessageBox.Show("Tankkaart Update gefaald", "Tankkaart Update", MessageBoxButton.OK, MessageBoxImage.Warning);
                    }
                    isClosed = false;
                }
            } catch (Exception ex) {
                MessageBox.Show(ex.Message, "Tankkaart updaten mislukt", MessageBoxButton.OK, MessageBoxImage.Warning);

            }
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult messageBoxResult = MessageBox.Show("Ben je zeker?", "Confirmation", MessageBoxButton.YesNo);
            if (messageBoxResult == MessageBoxResult.Yes)
            {
                Close();
            }
        }


        private void BtnTankkaartBestaandeBestuurder_Click(object sender, RoutedEventArgs e)
        {
            SearchWindow Search = new SearchWindow("bestuurder");
            if (Search.ShowDialog() == true)
            {
                BestaandeBestuurder = Search.bestuurder;
            }
        }
    }
}
