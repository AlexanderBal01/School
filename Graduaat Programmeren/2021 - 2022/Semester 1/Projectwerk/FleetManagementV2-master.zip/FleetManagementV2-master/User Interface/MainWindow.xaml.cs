﻿using Business_Layer;
using Business_Layer.Interfaces;
using Business_Layer.Managers;
using Data_Access_Layer.Repositories;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using User_Interface.Aanpassen_Windows;

namespace User_Interface {
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window {
        public MainWindow() {
            InitializeComponent();
            CheckboxBestuurder.IsChecked = true;
            CheckboxTankKaart.IsChecked = true;
            CheckboxTankKaart.IsChecked = false;
            CheckboxVoertuig.IsChecked = true;
            CheckboxVoertuig.IsChecked = false;

            System.Globalization.DateTimeFormatInfo dtinfo = new System.Globalization.DateTimeFormatInfo();
            dtinfo.ShortDatePattern = "dd-Mon-yyyy";
            dtinfo.DateSeparator = "-";

            if (listBx.SelectedItem != null) {

            }
        }
        BestuurderManager BM = new BestuurderManager(new BestuurderRepository(ConfigurationManager.ConnectionStrings["connectionString"].ToString()));
        TankKaartManager TM = new TankKaartManager(new TankKaartRepository(ConfigurationManager.ConnectionStrings["connectionString"].ToString()));
        VoertuigManager VM = new VoertuigManager(new VoertuigRepository(ConfigurationManager.ConnectionStrings["connectionString"].ToString()));
        string VorigeText = "";

        TankKaart BestaandeTankKaart = null;
        Voertuig BestaandVoertuig = null;
        Bestuurder BestaandeBestuurder = null;

        List<Bestuurder> SearchBestuurders = null;
        List<Voertuig> SearchVoertuig = null;
        TankKaart SearchTankKaart = null;



        #region WINDOW EVENTS   
        // Styling
        public void RemoveText(object sender, EventArgs e) {
            var txtbox = (TextBox)sender;
            if (!string.IsNullOrWhiteSpace(txtbox.Text)) {
                VorigeText = txtbox.Text;
                txtbox.Text = "";
            }
        }
        public void AddText(object sender, EventArgs e) {
            var txtbox = (TextBox)sender;
            if (string.IsNullOrWhiteSpace(txtbox.Text))
                txtbox.Text = VorigeText;
        }

        private void CheckboxVoertuig_Checked(object sender, RoutedEventArgs e) {
            //Enable
            ListboxVoertuigBrandstof.IsEnabled = true;
            txtBoxVoertuigTypeWage.IsEnabled = true;
            txtBoxVoertuigKleur.IsEnabled = true;
            txtBoxVoertuigModel.IsEnabled = true;
            txtBoxVoertuigMerk.IsEnabled = true;
            txtBoxVoertuigNrplaat.IsEnabled = true;
            txtBoxVoertuigChassisNr.IsEnabled = true;
            ComboBoxVoertuigAantalDeuren.IsEnabled = true;
            BtnvoertuigBestaandeBestuurder.IsEnabled = true;

            //disable voertuig bij bestuurder
            BtnBestuurderBestaandVoertuig.IsEnabled = false;
        }
        private void CheckboxVoertuig_Unchecked(object sender, RoutedEventArgs e) {
            //Disable
            ListboxVoertuigBrandstof.IsEnabled = false;
            txtBoxVoertuigTypeWage.IsEnabled = false;
            txtBoxVoertuigKleur.IsEnabled = false;
            txtBoxVoertuigModel.IsEnabled = false;
            txtBoxVoertuigMerk.IsEnabled = false;
            txtBoxVoertuigNrplaat.IsEnabled = false;
            txtBoxVoertuigChassisNr.IsEnabled = false;
            ComboBoxVoertuigAantalDeuren.IsEnabled = false;
            BtnvoertuigBestaandeBestuurder.IsEnabled = false;

            //enable voertuig bij bestuurder
            BtnBestuurderBestaandVoertuig.IsEnabled = true;
        }

        private void CheckboxBestuurder_Checked(object sender, RoutedEventArgs e) {
            //Enable
            txtBoxBestuurderNaam.IsEnabled = true;
            txtBoxBestuurderVoornaam.IsEnabled = true;
            txtBoxBestuurderRRN.IsEnabled = true;
            txtBoxBestuurderTypeRijbewijs.IsEnabled = true;
            DatepickerBestuurderGebDatum.IsEnabled = true;
            txtBoxBestuurderStraat.IsEnabled = true;
            txtBoxBestuurderHuisNr.IsEnabled = true;
            txtBoxBestuurderStad.IsEnabled = true;
            txtBoxBestuurderpostcode.IsEnabled = true;
            BtnBestuurderBestaandeTankkaart.IsEnabled = true;
            BtnBestuurderBestaandVoertuig.IsEnabled = true;
        }
        private void CheckboxBestuurder_Unchecked(object sender, RoutedEventArgs e) {
            //Disable
            txtBoxBestuurderNaam.IsEnabled = false;
            txtBoxBestuurderVoornaam.IsEnabled = false;
            txtBoxBestuurderRRN.IsEnabled = false;
            txtBoxBestuurderTypeRijbewijs.IsEnabled = false;
            DatepickerBestuurderGebDatum.IsEnabled = false;
            txtBoxBestuurderHuisNr.IsEnabled = false;
            txtBoxBestuurderStraat.IsEnabled = false;
            txtBoxBestuurderStad.IsEnabled = false;
            txtBoxBestuurderpostcode.IsEnabled = false;
            BtnBestuurderBestaandeTankkaart.IsEnabled = false;
            BtnBestuurderBestaandVoertuig.IsEnabled = false;

        }

        private void CheckboxTankKaart_Checked(object sender, RoutedEventArgs e) {
            //Enable
            txtBoxTankKaartNr.IsEnabled = true;
            txtBoxTankKaartPin.IsEnabled = true;
            DatePickerTankKaartGeldigheidsDatum.IsEnabled = true;
            ListboxTankKaartBrandstof.IsEnabled = true;
            CheckBoxTankKaartactief.IsEnabled = true;
            BtnTankkaartBestaandeBestuurder.IsEnabled = true;

            //disable voertuig bij bestuurder
            BtnBestuurderBestaandeTankkaart.IsEnabled = false;
        }
        private void CheckboxTankKaart_Unchecked(object sender, RoutedEventArgs e) {
            //Disable
            txtBoxTankKaartNr.IsEnabled = false;
            txtBoxTankKaartPin.IsEnabled = false;
            DatePickerTankKaartGeldigheidsDatum.IsEnabled = false;
            ListboxTankKaartBrandstof.IsEnabled = false;
            CheckBoxTankKaartactief.IsEnabled = false;
            BtnTankkaartBestaandeBestuurder.IsEnabled = false;

            //enable voertuig bij bestuurder
            BtnBestuurderBestaandeTankkaart.IsEnabled = true;
        }



        //bestaande dingen zoeken button
        private void BtnBestuurderBestaandeTankkaart_Click(object sender, RoutedEventArgs e) {
            SearchWindow Search = new SearchWindow("tankkaart");
            if (Search.ShowDialog() == true) {
                BestaandeTankKaart = Search.tankKaart;
                LblBestaandeTankkart.Content = $"Geselecteerde TankKaart : " + BestaandeTankKaart.KaartNummer;
            }
        }

        private void BtnBestuurderBestaandVoertuig_Click(object sender, RoutedEventArgs e) {
            SearchWindow Search = new SearchWindow("voertuig");
            if (Search.ShowDialog() == true) {
                BestaandVoertuig = Search.voertuig;
                LblBestaandVoertuig.Content = $"Geselecteerd Voertuig Nummerplaat : " + BestaandVoertuig.NummerPlaat;
            }

        }

        private void BtnTankkaartBestaandeBestuurder_Click(object sender, RoutedEventArgs e) {
            SearchWindow Search = new SearchWindow("bestuurder");
            if (Search.ShowDialog() == true) {
                BestaandeBestuurder = Search.bestuurder;
                LblTankkaartBestaandeBestuurder.Content = $"Geselecteerde Bestuurder : {BestaandeBestuurder.Voornaam} {BestaandeBestuurder.Naam}";
            }
        }

        private void BtnvoertuigBestaandeBestuurder_Click(object sender, RoutedEventArgs e) {
            SearchWindow Search = new SearchWindow("bestuurder");
            if (Search.ShowDialog() == true) {
                BestaandeBestuurder = Search.bestuurder;
                LblVoertuigBestaandeBestuurder.Content = $"Geselecteerde Bestuurder : {BestaandeBestuurder.Voornaam} {BestaandeBestuurder.Naam}";
            }
        }

        /// <summary>
        /// deze shitshow van een functie bepaald hoe dingen worden toegevoegd als je op voeg toe drukt
        /// </summary>
        private void BtnVoegToe_Click(object sender, RoutedEventArgs e) {
            if ((bool)CheckboxBestuurder.IsChecked && (bool)CheckboxTankKaart.IsChecked && (bool)CheckboxVoertuig.IsChecked) {
                var TankKaart = VoegTankKaartToe(null);
                var Voertuig = VoegVoertuigToe(null);
                VoegBestuurderToe(TankKaart, Voertuig);
                RefreshWindow();
            } else if ((bool)CheckboxBestuurder.IsChecked && (bool)CheckboxTankKaart.IsChecked) {
                var TankKaart = VoegTankKaartToe(null);
                if ((string)LblBestaandVoertuig.Content != "Geselecteerd Voertuig: ") {
                    VoegBestuurderToe(TankKaart, BestaandVoertuig);
                } else {
                    VoegBestuurderToe(TankKaart, null);
                }
                RefreshWindow();
            } else if ((bool)CheckboxBestuurder.IsChecked && (bool)CheckboxVoertuig.IsChecked) {
                var Voertuig = VoegVoertuigToe(null);
                if ((string)LblBestaandeTankkart.Content != "Geselecteerde TankKaart: ") {
                    VoegBestuurderToe(BestaandeTankKaart, Voertuig);
                } else {
                    VoegBestuurderToe(null, Voertuig);
                }
                RefreshWindow();
            } else if ((bool)CheckboxBestuurder.IsChecked) {
                if ((string)LblBestaandeTankkart.Content != "Geselecteerde TankKaart: " && (string)LblBestaandVoertuig.Content != "Geselecteerd Voertuig: ") {
                    VoegBestuurderToe(BestaandeTankKaart, BestaandVoertuig);
                } else if ((string)LblBestaandeTankkart.Content != "Geselecteerde TankKaart: " && (string)LblBestaandVoertuig.Content == "Geselecteerd Voertuig: ") {
                    VoegBestuurderToe(BestaandeTankKaart, null);
                } else if ((string)LblBestaandeTankkart.Content == "Geselecteerde TankKaart: " && (string)LblBestaandVoertuig.Content != "Geselecteerd Voertuig: ") {
                    VoegBestuurderToe(null, BestaandVoertuig);
                } else {
                    VoegBestuurderToe(null, null);
                }
                RefreshWindow();
            } else if ((bool)CheckboxVoertuig.IsChecked) {
                if ((string)LblVoertuigBestaandeBestuurder.Content != "Geselecteerde Bestuurder: ") {
                    VoegVoertuigToe(BestaandeBestuurder);
                } else {
                    VoegVoertuigToe(null);
                }
                RefreshWindow();
            } else if ((bool)CheckboxTankKaart.IsChecked) {
                if ((string)LblTankkaartBestaandeBestuurder.Content != "Geselecteerde Bestuurder: ") {
                    VoegTankKaartToe(BestaandeTankKaart);
                } else {
                    VoegTankKaartToe(null);
                }
                RefreshWindow();
            } else {
                MessageBox.Show("Kies aub een Item dat je wilt toevoegen", "Hold Up!", MessageBoxButton.OK, MessageBoxImage.Hand);
            }
        }

        private void RefreshWindow() {
            MainWindow mw = new MainWindow();
            mw.TabToevoegen.IsSelected = true;
            mw.Show();
            this.Close();
        }

        private void comboBoxTypeZoeken_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (comboBoxTypeZoeken.SelectedItem.ToString().Contains("Bestuurder"))
            {
                txtBoxZoeken.Text = "Bestuurder Zoeken op Naam, Id en Rijksregister";
            }
            else if (comboBoxTypeZoeken.SelectedItem.ToString().Contains("Voertuig"))
            {
                txtBoxZoeken.Text = "Voertuig Zoeken op Chassisnummer, Merk en Nummerplaat";
            }
            else if (comboBoxTypeZoeken.SelectedItem.ToString().Contains("Tankkaart"))
            {
                txtBoxZoeken.Text = "Tankkaart Zoeken op Nummer";
            }
        }

        #endregion

        #region VOEG TOE

        public List<BrandstofType> GeefBrandstofTypes(ListBox brandstofListbox) {
            List<BrandstofType> BrandstofTypes = new List<BrandstofType>();
            foreach (ListBoxItem item in brandstofListbox.Items) {
                if (item.IsSelected) {
                    BrandstofTypes.Add(Enum.Parse<BrandstofType>(item.Content.ToString()));
                }
            }

            return BrandstofTypes;
        }


        /// <summary>
        /// Returnt een object om bij voeg bestuurder toe de optie te hebben om deze ineens te linken
        /// </summary>
        public TankKaart VoegTankKaartToe(TankKaart tankkaartProperty) {
            if (tankkaartProperty != null) {
                TM.VoegTankkaartToe(tankkaartProperty);
                return tankkaartProperty;
            } else {
                List<BrandstofType> BrandstofTypes = GeefBrandstofTypes(ListboxTankKaartBrandstof);
                TankKaart tankKaart = new TankKaart(Int32.Parse(txtBoxTankKaartNr.Text),
                                                   (DateTime)DatePickerTankKaartGeldigheidsDatum.SelectedDate,
                                                   Int32.Parse(txtBoxTankKaartPin.Text),
                                                   BrandstofTypes,
                                                   null,
                                                   (bool)CheckBoxTankKaartactief.IsChecked);

                TM.VoegTankkaartToe(tankKaart);
                return tankKaart;
            }
        }

        /// <summary>
        /// Returnt een object om bij voeg bestuurder toe de optie te hebben om deze ineens te linken
        /// </summary>
        public Voertuig VoegVoertuigToe(Bestuurder bestuurder) {
            if (bestuurder != null) {
                if (bestuurder.Voertuig != null) {
                    BM.VerwijderVoertuigVanBestuurder(bestuurder);
                }
                
                List<BrandstofType> brandstofTypes = GeefBrandstofTypes(ListboxVoertuigBrandstof);
                var Voertuig = new Voertuig(txtBoxVoertuigChassisNr.Text,
                                            txtBoxVoertuigNrplaat.Text,
                                            txtBoxVoertuigMerk.Text,
                                            txtBoxVoertuigModel.Text,
                                            brandstofTypes,
                                            txtBoxVoertuigTypeWage.Text,
                                            txtBoxVoertuigKleur.Text,
                                            int.Parse(ComboBoxVoertuigAantalDeuren.Text), 
                                            bestuurder);
                VM.VoertuigToevoegenMetBestuurder(Voertuig, bestuurder);
                return Voertuig;
            } else {
                List<BrandstofType> brandstofTypes = GeefBrandstofTypes(ListboxVoertuigBrandstof);
                var voertuig = new Voertuig(txtBoxVoertuigChassisNr.Text,
                                            txtBoxVoertuigNrplaat.Text,
                                            txtBoxVoertuigMerk.Text,
                                            txtBoxVoertuigModel.Text,
                                            brandstofTypes,
                                            txtBoxVoertuigTypeWage.Text,
                                            txtBoxVoertuigKleur.Text,
                                            int.Parse(ComboBoxVoertuigAantalDeuren.Text));
                VM.VoertuigToevoegen(voertuig);
                return voertuig;
            }
        }

        /// <summary>
        /// Voegt een bestuurder toe met tankaart en voertuig, OF zonder als een parameter leeg is
        /// </summary>
        /// <param name="tankKaart">mag null zijn</param>
        /// <param name="voertuig"> mag null zijn</param>
        public void VoegBestuurderToe(TankKaart tankKaart, Voertuig voertuig) {
            if (voertuig != null && tankKaart != null) {
                if (BestaandVoertuig != null) {
                    BM.VerwijderVoertuigVanBestuurder(BestaandVoertuig.Bestuurder);
                }
                if (BestaandeTankKaart != null) {
                    BM.VerwijderTankkaartVanBestuurder(BestaandeTankKaart.Bestuurder);
                }
                
                var adres = new Adres(txtBoxBestuurderStraat.Text,
                      txtBoxBestuurderHuisNr.Text,
                      txtBoxBestuurderStad.Text,
                      txtBoxBestuurderpostcode.Text);
                var bestuurder = new Bestuurder(txtBoxBestuurderNaam.Text,
                                           txtBoxBestuurderVoornaam.Text,
                                           txtBoxBestuurderRRN.Text,
                                           txtBoxBestuurderTypeRijbewijs.Text,
                                           adres,
                                           (DateTime)DatepickerBestuurderGebDatum.SelectedDate,
                                           tankKaart,
                                           voertuig);

                BM.BestuurderToevoegen(bestuurder);
            } else if (voertuig != null && tankKaart == null) {
                if (BestaandVoertuig != null) {
                    BM.VerwijderVoertuigVanBestuurder(BestaandVoertuig.Bestuurder);
                }
               
                var adres = new Adres(txtBoxBestuurderStraat.Text,
                                      txtBoxBestuurderHuisNr.Text,
                                      txtBoxBestuurderStad.Text,
                                      txtBoxBestuurderpostcode.Text);
                var bestuurder = new Bestuurder(txtBoxBestuurderNaam.Text,
                                           txtBoxBestuurderVoornaam.Text,
                                           txtBoxBestuurderRRN.Text,
                                           txtBoxBestuurderTypeRijbewijs.Text,
                                           adres,
                                           (DateTime)DatepickerBestuurderGebDatum.SelectedDate,
                                           voertuig);
                bestuurder.SetTankKaart(null);
                BM.BestuurderToevoegen(bestuurder);

            } else if (voertuig == null && tankKaart != null) {
                if (BestaandeTankKaart != null) {
                    BM.VerwijderTankkaartVanBestuurder(BestaandeTankKaart.Bestuurder);
                }
                
                var adres = new Adres(txtBoxBestuurderStraat.Text,
                      txtBoxBestuurderHuisNr.Text,
                      txtBoxBestuurderStad.Text,
                      txtBoxBestuurderpostcode.Text);
                var bestuurder = new Bestuurder(txtBoxBestuurderNaam.Text,
                                           txtBoxBestuurderVoornaam.Text,
                                           txtBoxBestuurderRRN.Text,
                                           txtBoxBestuurderTypeRijbewijs.Text,
                                           adres,
                                           (DateTime)DatepickerBestuurderGebDatum.SelectedDate,
                                           tankKaart);
                bestuurder.SetVoertuig(null);
                BM.BestuurderToevoegen(bestuurder);
            } else {
                var bestuurder = new Bestuurder(txtBoxBestuurderNaam.Text,
                                           txtBoxBestuurderVoornaam.Text,
                                           txtBoxBestuurderRRN.Text,
                                           txtBoxBestuurderTypeRijbewijs.Text,
                                           (DateTime)DatepickerBestuurderGebDatum.SelectedDate);
                var adres = new Adres(txtBoxBestuurderStraat.Text,
                                      txtBoxBestuurderHuisNr.Text,
                                      txtBoxBestuurderStad.Text,
                                      txtBoxBestuurderpostcode.Text);
                bestuurder.SetAdres(adres);
                bestuurder.SetTankKaart(null);
                bestuurder.SetVoertuig(null);
                BM.BestuurderToevoegen(bestuurder);
            }
        }



        #endregion

        #region AANPASSEN

        private void BtnAanpassen_Click(object sender, RoutedEventArgs e) {
            try {
                if (listBx.SelectedItem != null) {
                    var selectedValue = listBx.SelectedItem;
                    string ZoekType = comboBoxTypeZoeken.SelectedValue.ToString();
                    if (ZoekType.ToLower().Contains("bestuurder")) {
                        try {
                            Bestuurder bestuurder = selectedValue as Bestuurder;
                            BestuurderAanpassen BA = new BestuurderAanpassen("bestuurder", bestuurder);
                            if (BA.ShowDialog() == true)
                            {
                                if (BA.isClosed == true) BM.UpdateBestuurder(BA.AanTePassenBestuurder);
                            }

                        } catch (Exception Ex) {
                            MessageBox.Show("Bestuurder Updaten Mislukt : \n" + Ex.Message, "Fout", MessageBoxButton.OK, MessageBoxImage.Warning);
                        }
                    } else if (ZoekType.ToLower().Contains("voertuig")) {
                        try {
                            Voertuig voertuig = selectedValue as Voertuig;
                            VoertuigAanpassen VA = new VoertuigAanpassen("voertuig", voertuig);
                            if (VA.ShowDialog() == true)
                            {
                                if (VA.isClosed == true) VM.UpdateVoertuig(VA.AanTePassenVoertuig);
                            }

                        } catch (Exception Ex) {
                            MessageBox.Show("Voertuig Updaten Mislukt : \n" + Ex.Message, "Fout", MessageBoxButton.OK, MessageBoxImage.Warning);
                        }
                    } else if (ZoekType.ToLower().Contains("tankkaart")) {
                        try {
                            TankKaart tankkaart = selectedValue as TankKaart;
                            TankKaartAanpassen TA = new TankKaartAanpassen("tankkaart", tankkaart);
                            if (TA.ShowDialog() == true)
                            {
                                if (TA.isClosed == true) TM.UpdateTankkaart(TA.AanTePassenTankKaart);
                            }

                        } catch (Exception Ex) {
                            MessageBox.Show("Tankkaart Updaten Mislukt : \n" + Ex.Message, "Fout", MessageBoxButton.OK, MessageBoxImage.Warning);
                        }
                    }
                } else { throw new Exception("Niets Geselecteerd"); }
            } catch (Exception Ex) {
                MessageBox.Show(Ex.Message, "Fout", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        #endregion

        #region VERWIJDEREN
        private void BtnVerwijderen_Click(object sender, RoutedEventArgs e) {
            try {
                if (listBx.SelectedItem != null) {
                    var selectedValue = listBx.SelectedItem;
                    if (comboBoxTypeZoeken.SelectedValue.ToString().ToLower() == "bestuurder") {
                        try {
                            Bestuurder bestuurder = (Bestuurder)selectedValue;
                            BM.VerwijderBestuurder(bestuurder.Id);
                        } catch (Exception Ex) {
                            MessageBox.Show("Bestuurder Verwijderen Mislukt \n" + Ex.Message, "Fout", MessageBoxButton.OK, MessageBoxImage.Warning);
                        }
                    } 
                    else if (comboBoxTypeZoeken.SelectedItem.ToString().ToLower() == "voertuig") {
                        try {
                            Voertuig voertuig = (Voertuig)selectedValue;
                            VM.VerwijderVoertuig(voertuig.ChassisNummer);
                        } catch (Exception Ex) {
                            MessageBox.Show("Voertuig Verwijderen Mislukt \n" + Ex.Message, "Fout", MessageBoxButton.OK, MessageBoxImage.Warning);
                        }
                    } 
                    else if (comboBoxTypeZoeken.SelectedItem.ToString().ToLower() == "tankkaart") {
                        try {
                            TankKaart tankkaart = (TankKaart)selectedValue;
                            tankkaart.SetActiefStatus(false);
                            TM.UpdateTankkaart(tankkaart);
                        } catch (Exception Ex) {
                            MessageBox.Show("Voertuig Verwijderen Mislukt \n" + Ex.Message, "Fout", MessageBoxButton.OK, MessageBoxImage.Warning);
                        }
                    }
                } else { throw new Exception("Niets Geselecteerd"); }
            } catch (Exception Ex) {
                MessageBox.Show(Ex.Message, "Fout", MessageBoxButton.OK, MessageBoxImage.Warning);
            }

        }


        #endregion

        #region SEARCH

        private void Search() {
            try {
                listBx.IsEnabled = true;
                listBx.Items.Clear();
                if (comboBoxTypeZoeken.Text == "Bestuurder") {
                    string tekst = txtBoxZoeken.Text;
                    List<Bestuurder> bestuurders = BM.GeefBestuurder(tekst);
                    foreach (var v in bestuurders) { listBx.Items.Add(v); }
                    SearchBestuurders = bestuurders;

                } else if (comboBoxTypeZoeken.Text == "Voertuig") {
                    string tekst = txtBoxZoeken.Text;
                    List<Voertuig> voertuigen = VM.GeefVoertuig(tekst);
                    foreach (var v in voertuigen) { listBx.Items.Add(v); }
                    SearchVoertuig = voertuigen;

                } else if (comboBoxTypeZoeken.Text == "Tankkaart") {
                    int tekst = int.Parse(txtBoxZoeken.Text);
                    TankKaart t = TM.GeefTankkaart(tekst);
                    listBx.Items.Add(t);
                    SearchTankKaart = t;
                }
                if (listBx.Items.Count == 0) {
                    listBx.Items.Add("-- Geen Resultaten Gevonden --");
                    listBx.IsEnabled = false;
                }
            } catch (Exception e) {
                MessageBox.Show(e.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void searchBtn_Click(object sender, RoutedEventArgs e) {
            Search();
        }

        private void txtBoxZoeken_KeyDown(object sender, KeyEventArgs e) {
            if (e.Key == Key.Return) {
                Search();
            }
        }


        #endregion

      
    }
}
