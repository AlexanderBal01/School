﻿using Bussiness_Layer.Managers;
using Bussiness_Layer.Model;
using REST_Layer.Exceptions;
using REST_Layer.Model.Input;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace REST_Layer.Mappers {
    public class MapToDomain {
        #region Methods
        public static Klant MapToKlantDomain(KlantRESTInputDTO restDTO) {
            try {
                Klant klant = null;
                if (restDTO.Id == null) {
                    klant = new Klant(restDTO.Naam, restDTO.Adres);
                } else {
                    klant = new Klant((int)restDTO.Id, restDTO.Naam, restDTO.Adres);
                }
                return klant;
            } catch (Exception ex) {
                throw new MapException("MapToKlantException", ex);
            }
        }

        public static Bestelling MapToBestellingDomain(BestellingRESTInputDTO restDTO, KlantManager klantManager, ProductManager productManager) {
            try {
                Bestelling b = null;
                Klant k = klantManager.GeefKlant(restDTO.KlantId);
                Product p = productManager.GeefProduct(restDTO.Product);
                if (restDTO.Id == null) {
                    b = new Bestelling(p, restDTO.Aantal, k);
                } else {
                    b = new Bestelling((int)restDTO.Id, p, restDTO.Aantal, k);
                }
                return b;
            } catch (Exception ex) {
                throw new MapException("MapToBestellingDomain", ex);
            }
        }
        #endregion
    }
}
