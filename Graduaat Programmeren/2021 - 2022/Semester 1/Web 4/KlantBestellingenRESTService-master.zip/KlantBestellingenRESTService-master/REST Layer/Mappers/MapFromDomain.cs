﻿using Bussiness_Layer.Managers;
using Bussiness_Layer.Model;
using Microsoft.AspNetCore.Mvc;
using REST_Layer.Exceptions;
using REST_Layer.Model.Output;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace REST_Layer.Mappers {
    public class MapFromDomain {
        public static KlantRESTOutputDTO MapFromKlantDomain(string url, Klant klant, BestellingManager bestellingManager) {
            try {
                string klantUrl = $"{url}api/klant/{klant.ID}";
                List<string> bestellingen = bestellingManager.GeefBestellingenKlant(klant.ID).Select(x => klantUrl + $"/bestelling/{x.ID}").ToList();
                KlantRESTOutputDTO dto = new KlantRESTOutputDTO(klantUrl, klant.Naam, klant.Adres, bestellingen.Count, bestellingen);
                return dto;
            } catch (Exception ex) {
                throw new MapException("MapFromKlantDomain", ex);
            }
        }

        public static BestellingRESTOutputDTO MapFromBestellingDomain(string url, Bestelling bestelling, ProductManager productManager) {
            try {
                string klantUrl = $"{url}api/klant/{bestelling.Klant.ID}";
                string bestellingUrl = $"{klantUrl}/bestelling/{bestelling.ID}";
                string product = productManager.GeefProductBestelling(bestelling.ID).ToString();
                BestellingRESTOutputDTO dto = new BestellingRESTOutputDTO(bestellingUrl, klantUrl, product, bestelling.Aantal);
                return dto;
            } catch (Exception ex) {
                throw new MapException("MapFromBestellingDomain", ex);
            }
        }
    }
}
