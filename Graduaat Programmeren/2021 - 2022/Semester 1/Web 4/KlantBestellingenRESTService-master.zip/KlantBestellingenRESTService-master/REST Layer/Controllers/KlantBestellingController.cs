﻿using Bussiness_Layer.Managers;
using Bussiness_Layer.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using REST_Layer.Mappers;
using REST_Layer.Model.Input;
using REST_Layer.Model.Output;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace REST_Layer.Controllers {
    [Route("api/klant")]
    [ApiController]
    public class KlantBestellingController : ControllerBase {
        #region Properties
        private string hostURL = "http://localhost:5000/";
        private KlantManager KlantManager;
        private BestellingManager BestellingManager;
        private ProductManager ProductManager;
        #endregion

        #region Ctor
        public KlantBestellingController(KlantManager klantManager, BestellingManager bestellingManager, ProductManager productManager) {
            KlantManager = klantManager;
            BestellingManager = bestellingManager;
            ProductManager = productManager;
        }
        #endregion

        #region Klant
        [HttpGet("{id}")]
        public ActionResult<KlantRESTOutputDTO> GetKlant(int id) {
            try {
                Klant klant = KlantManager.GeefKlant(id);
                return Ok(MapFromDomain.MapFromKlantDomain(hostURL, klant, BestellingManager));
            } catch (Exception ex) {
                return NotFound(ex.Message);
            }
        }

        [HttpPost]
        public ActionResult<KlantRESTOutputDTO> PostKlant([FromBody] KlantRESTInputDTO restDTO) {
            try {
                Klant klant = KlantManager.MaakKlantAan(MapToDomain.MapToKlantDomain(restDTO));
                return CreatedAtAction(nameof(GetKlant), new { id = klant.ID },
                    MapFromDomain.MapFromKlantDomain(hostURL, klant, BestellingManager));
            } catch (Exception ex) {
                return BadRequest(ex.Message);
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteKlant(int id) {
            try {
                KlantManager.VerwijderKlant(id);
                return NoContent();
            } catch (Exception ex) {
                return NotFound(ex.Message);
            }
        }

        [HttpPut("{id}")]
        public IActionResult PutKlant(int id, [FromBody] KlantRESTInputDTO restDTO) {
            try {
                if (id != restDTO.Id) {
                    return BadRequest();
                }

                if (KlantManager.BestaatKlant(id)) {
                    Klant klant = KlantManager.UpdateKlant(MapToDomain.MapToKlantDomain(restDTO));
                    return CreatedAtAction(nameof(GetKlant), new { id = restDTO.Id },
                        MapFromDomain.MapFromKlantDomain(hostURL, klant, BestellingManager));
                } else {
                    return BadRequest("Klant bestaat niet");
                }
            } catch (Exception ex) {
                return NotFound(ex.Message);
            }
        }
        #endregion

        #region Bestelling
        [HttpGet]
        [Route("{klantId}/Bestelling/{bestellingId}")]
        public ActionResult<BestellingRESTOutputDTO> GetBestelling(int klantId, int bestellingId) {
            try {
                Bestelling bestelling = BestellingManager.GeefBestelling(bestellingId, klantId);
                if (bestelling.Klant.ID != klantId) {
                    return BadRequest("klantId klopt niet met url");
                }
                return Ok(MapFromDomain.MapFromBestellingDomain(hostURL, bestelling, ProductManager));
            } catch (Exception ex) {
                return NotFound(ex.Message);
            }
        }

        [HttpPost]
        [Route("{klantId}/Bestelling/")]
        public ActionResult<BestellingRESTOutputDTO> PostBestelling(int klantId, [FromBody] BestellingRESTInputDTO restDTO) {
            try {
                if (restDTO.KlantId != klantId) {
                    return BadRequest("KlantId klopt niet");
                }
                Bestelling bestelling = BestellingManager.MaakBestellingAan(MapToDomain.MapToBestellingDomain(restDTO, KlantManager, ProductManager));
                return CreatedAtAction(nameof(GetBestelling), new { klantId = klantId, bestellingId = bestelling.ID }, MapFromDomain.MapFromBestellingDomain(hostURL, bestelling, ProductManager));
            } catch (Exception ex) {
                return BadRequest(ex.Message);
            }
        }

        [HttpDelete]
        [Route("{klantId}/Bestelling/{bestellingId}")]
        public IActionResult DeleteBestelling(int klantId, int bestellingId) {
            try {
                BestellingManager.VerwijderBestelling(bestellingId, klantId);
                return NoContent();
            } catch (Exception ex) {
                return NotFound(ex.Message);
            }
        }

        [HttpPut]
        [Route("{klantId}/Bestelling/{bestellingId}")]
        public IActionResult PutBestelling(int klantId, int bestellingId, [FromBody] BestellingRESTInputDTO restDTO) {
            try {
                if (klantId != restDTO.KlantId) {
                    return BadRequest("klantId niet correct");
                }
                if (!KlantManager.BestaatKlant(klantId)) {
                    return BadRequest("Klant bestaat niet");
                }
                if (BestellingManager.BestaatBestelling(bestellingId)) {
                    if (BestellingManager.GeefBestelling(bestellingId, klantId).Klant.ID != klantId) {
                        return BadRequest("klantId niet correct");
                    }
                    Bestelling bestelling = BestellingManager.UpdateBestelling(MapToDomain.MapToBestellingDomain(restDTO, KlantManager, ProductManager));
                    return CreatedAtAction(nameof(GetBestelling), new { klantId = klantId, bestellingId = bestellingId }, MapFromDomain.MapFromBestellingDomain(hostURL, bestelling, ProductManager));
                } else {
                    return BadRequest("Bestelling bestaat niet");
                }
            } catch (Exception ex) {
                return NotFound(ex.Message);
            }
        }
        #endregion
    }
}
