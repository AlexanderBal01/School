﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace REST_Layer.Model.Input {
    public class KlantRESTInputDTO {
        #region Properties
        public string Naam { get; set; }
        public string Adres { get; set; }
        public int? Id { get; set; }
        #endregion
    }
}
