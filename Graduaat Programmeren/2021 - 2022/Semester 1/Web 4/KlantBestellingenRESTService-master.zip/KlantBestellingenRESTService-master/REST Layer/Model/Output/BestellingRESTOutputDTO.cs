﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace REST_Layer.Model.Output {
    public class BestellingRESTOutputDTO {
        public string BestellingId { get; private set; }
        public string KlantId { get; private set; }
        public string Product { get; private set; }
        public int Aantal { get; private set; }

        public BestellingRESTOutputDTO(string bestellingId, string klantId, string product, int aantal) {
            BestellingId = bestellingId;
            KlantId = klantId;
            Product = product;
            Aantal = aantal;
        }
    }
}
