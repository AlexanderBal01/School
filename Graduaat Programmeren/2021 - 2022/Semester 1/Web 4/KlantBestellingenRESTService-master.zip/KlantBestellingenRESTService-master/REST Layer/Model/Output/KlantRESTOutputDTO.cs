﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace REST_Layer.Model.Output {
    public class KlantRESTOutputDTO {
        #region Properties
        public string Id { get; private set; }
        public string Naam { get; private set; }
        public string Adres { get; private set; }
        public int AantalBestellingen { get; private set; }
        public List<string> Bestellingen { get; private set; }
        #endregion

        #region Ctor
        public KlantRESTOutputDTO(string id, string naam, string adres) {
            Id = id;
            Naam = naam;
            Adres = adres;
        }

        public KlantRESTOutputDTO(string id, string naam, string adres, int aantalBestellingen, List<string> bestellingen) : this(id, naam, adres) {
            AantalBestellingen = aantalBestellingen;
            Bestellingen = bestellingen;
        }
        #endregion
    }
}
