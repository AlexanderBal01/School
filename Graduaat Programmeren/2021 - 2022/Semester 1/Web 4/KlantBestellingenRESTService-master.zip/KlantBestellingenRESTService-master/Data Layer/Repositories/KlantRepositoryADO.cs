﻿using Bussiness_Layer.Interfaces;
using Bussiness_Layer.Model;
using Data_Layer.Exceptions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Layer.Repositories {
    public class KlantRepositoryADO : IKlantRepository {
        #region Properties
        private string ConnectionString;
        #endregion

        #region Ctor
        public KlantRepositoryADO(string connenctionString) {
            ConnectionString = connenctionString;
        }
        #endregion

        #region Methods
        private SqlConnection GetConnection() {
            SqlConnection connection = new SqlConnection(ConnectionString);
            return connection;
        }

        public bool BestaatKlant(int id) {
            string query = "SELECT COUNT(*) FROM klant WHERE Id = @id";
            SqlConnection connection = GetConnection();
            using (SqlCommand command = new SqlCommand(query, connection)) {
                try {
                    connection.Open();
                    command.Parameters.Add(new SqlParameter("@id", SqlDbType.Int));
                    command.Parameters["@id"].Value = id;
                    int klantBestaat = (int)command.ExecuteScalar();
                    if (klantBestaat > 0) {
                        return true;
                    }
                    return false;
                } catch (Exception ex) {
                    KlantRepositoryException klantRepositoryEx = new KlantRepositoryException("BestaatKlant niet gelukt", ex);
                    klantRepositoryEx.Data.Add("id", id);
                    throw klantRepositoryEx;
                } finally {
                    connection.Close();
                }
            }
        }

        public Klant MaakKlantAan(Klant klant) {
            string query = "INSERT INTO klant (Naam, Adres) output INSERTED.Id VALUES (@Naam, @Adres)";
            SqlConnection connection = GetConnection();
            using (SqlCommand command = new SqlCommand(query, connection)) {
                try {
                    connection.Open();
                    command.Parameters.Add(new SqlParameter("@Naam", SqlDbType.NVarChar));
                    command.Parameters.Add(new SqlParameter("@Adres", SqlDbType.NVarChar));
                    command.Parameters["@Naam"].Value = klant.Naam;
                    command.Parameters["@Adres"].Value = klant.Adres;
                    int newId = (int)command.ExecuteScalar();
                    klant.ZetId(newId);
                    return klant;
                } catch (Exception ex) {
                    KlantRepositoryException klantRepositoryEx = new KlantRepositoryException("MaakKlantAan niet gelukt", ex);
                    klantRepositoryEx.Data.Add("klant", klant);
                    throw klantRepositoryEx;
                } finally {
                    connection.Close();
                }
            }
        }

        public void UpdateKlant(Klant klant) {
            string query = "UPDATE klant SET Naam=@naam, Adres=@adres WHERE Id=@id";
            SqlConnection connection = GetConnection();
            using (SqlCommand command = new SqlCommand(query, connection)) {
                try {
                    connection.Open();
                    command.Parameters.Add(new SqlParameter("@naam", SqlDbType.NVarChar));
                    command.Parameters.Add(new SqlParameter("@adres", SqlDbType.NVarChar));
                    command.Parameters.Add(new SqlParameter("@id", SqlDbType.Int));
                    command.Parameters["@naam"].Value = klant.Naam;
                    command.Parameters["@adres"].Value = klant.Adres;
                    command.Parameters["@id"].Value = klant.ID;
                    command.ExecuteNonQuery();
                } catch (Exception ex) {
                    KlantRepositoryException klantRepositoryEx = new KlantRepositoryException("UpdateKlant niet gelukt", ex);
                    klantRepositoryEx.Data.Add("klant", klant);
                    throw klantRepositoryEx;
                } finally {
                    connection.Close();
                }
            }
        }

        public Klant GeefKlant(int id) {
            string query = "SELECT * FROM klant WHERE Id=@Id";
            SqlConnection connection = GetConnection();
            using (SqlCommand command = new SqlCommand(query, connection)) {
                try {
                    connection.Open();
                    command.Parameters.Add(new SqlParameter("@Id", SqlDbType.Int));
                    command.Parameters["@Id"].Value = id;
                    IDataReader dataReader = command.ExecuteReader();
                    dataReader.Read();
                    Klant klant = new Klant((int)dataReader["Id"], (string)dataReader["Naam"], (string)dataReader["Adres"]);
                    dataReader.Close();
                    return klant;

                } catch (Exception ex) {
                    KlantRepositoryException klantRepositoryEx = new KlantRepositoryException("GeefKlant niet gelukt", ex);
                    klantRepositoryEx.Data.Add("id", id);
                    throw klantRepositoryEx;
                } finally {
                    connection.Close();
                }
            }
        }

        public void VerwijderKlant(int id) {
            string query = "DELETE FROM klant WHERE Id=@id";
            SqlConnection connection = GetConnection();
            using (SqlCommand command = new SqlCommand(query, connection)) {
                try {
                    connection.Open();
                    command.Parameters.Add(new SqlParameter("@id", SqlDbType.Int));
                    command.Parameters["@id"].Value = id;
                    command.ExecuteNonQuery();
                } catch (Exception ex) {
                    KlantRepositoryException klantRepositoryEx = new KlantRepositoryException("VerwijderKlant niet gelukt", ex);
                    klantRepositoryEx.Data.Add("Id", id);
                    throw klantRepositoryEx;
                } finally {
                    connection.Close();
                }
            }
        }

        public bool HeeftBestellingen(int id) {
            string query = "SELECT count(*) FROM bestelling WHERE klantId=@klantId";
            SqlConnection connection = GetConnection();
            using (SqlCommand command = new SqlCommand(query, connection)) {
                try {
                    connection.Open();
                    command.Parameters.Add(new SqlParameter("@klantId", SqlDbType.Int));
                    command.Parameters["@klantId"].Value = id;
                    int bestellingBestaat = (int)command.ExecuteScalar();
                    if (bestellingBestaat > 0) {
                        return true;
                    }
                    return false;
                } catch (Exception ex) {
                    KlantRepositoryException klantRepositoryEx = new KlantRepositoryException("HeeftBestellingen niet gelukt", ex);
                    klantRepositoryEx.Data.Add("klantId", id);
                    throw klantRepositoryEx;
                } finally {
                    connection.Close();
                }
            }
        }
        #endregion
    }
}
