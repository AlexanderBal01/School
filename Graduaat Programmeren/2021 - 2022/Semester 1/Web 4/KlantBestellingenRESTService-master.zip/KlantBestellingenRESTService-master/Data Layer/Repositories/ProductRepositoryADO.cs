﻿using Bussiness_Layer.Interfaces;
using Bussiness_Layer.Model;
using Data_Layer.Exceptions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Layer.Repositories {
    public class ProductRepositoryADO : IProductRepository {
        #region Properties
        private string ConnectionString;
        #endregion

        #region Ctor
        public ProductRepositoryADO(string connectionString) {
            ConnectionString = connectionString;
        }
        #endregion

        #region Methods
        private SqlConnection GetConnection() {
            SqlConnection connection = new SqlConnection(ConnectionString);
            return connection;
        }

        public Product GeefProductBestelling(int bestellingId) {
            string query = "SELECT t1.* FROM product t1 " +
                " INNER JOIN bestelling t2 ON t2.productId=t1.Id WHERE t2.Id=@Id";
            SqlConnection connection = GetConnection();
            using(SqlCommand command = new SqlCommand(query, connection)) {
                try {
                    connection.Open();
                    command.Parameters.Add(new SqlParameter("@Id", SqlDbType.Int));
                    command.Parameters["@Id"].Value = bestellingId;
                    SqlDataReader dataReader = command.ExecuteReader();
                    dataReader.Read();
                    Product p = new Product((string)dataReader["productType"]);
                    dataReader.Close();
                    return p;
                } catch (Exception ex) {
                    ProductRepositoryException productRepositoryEx = new ProductRepositoryException("GeefProductBestelling niet gelukt", ex);
                    productRepositoryEx.Data.Add("bestellingId", bestellingId);
                    throw productRepositoryEx;
                } finally {
                    connection.Close();
                }
            }
        }

        public Product GeefProduct(string product) {
            string query = "SELECT * FROM product WHERE productType=@productType";
            SqlConnection connection = GetConnection();
            using (SqlCommand command = new SqlCommand(query, connection)) {
                try {
                    connection.Open();
                    command.Parameters.Add(new SqlParameter("@productType", SqlDbType.NVarChar));
                    command.Parameters["@productType"].Value = product;
                    SqlDataReader dataReader = command.ExecuteReader();
                    dataReader.Read();
                    Product p = new Product((int)dataReader["Id"], (string)dataReader["productType"]);
                    dataReader.Close();
                    return p;
                } catch (Exception ex) {
                    ProductRepositoryException productRepositoryEx = new ProductRepositoryException("GeefProduct niet gelukt", ex);
                    productRepositoryEx.Data.Add("product", product);
                    throw productRepositoryEx;
                } finally {
                    connection.Close();
                }
            }
        }
        #endregion
    }
}
