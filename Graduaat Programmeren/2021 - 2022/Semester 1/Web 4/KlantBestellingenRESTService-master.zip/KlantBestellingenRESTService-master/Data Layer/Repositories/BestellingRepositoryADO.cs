﻿using Bussiness_Layer.Interfaces;
using Bussiness_Layer.Model;
using Data_Layer.Exceptions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Layer.Repositories {
    public class BestellingRepositoryADO : IBestellingRepository {
        #region Properties
        private string ConnectionString;
        #endregion

        #region Ctor
        public BestellingRepositoryADO(string connectionString) {
            ConnectionString = connectionString;
        }
        #endregion

        #region Methods
        private SqlConnection GetConnection() {
            SqlConnection connection = new SqlConnection(ConnectionString);
            return connection;
        }

        public bool BestaatBestelling(int id) {
            string query = "SELECT COUNT(*) FROM bestelling WHERE Id=@id";
            SqlConnection connection = GetConnection();
            using (SqlCommand command = new SqlCommand(query, connection)) {
                try {
                    connection.Open();
                    command.Parameters.Add(new SqlParameter("@id", SqlDbType.Int));
                    command.Parameters["@id"].Value = id;
                    int n = (int)command.ExecuteScalar();
                    if (n > 0) {
                        return true;
                    }
                    return false;
                } catch (Exception ex) {
                    BestellingRepositoryException bestellingRepositoryEx = new BestellingRepositoryException("BestaatBestelling niet gelukt", ex);
                    bestellingRepositoryEx.Data.Add("bestellingId", id);
                    throw bestellingRepositoryEx;
                } finally {
                    connection.Close();
                }
            }
        }

        public Bestelling GeefBestelling(int bestellingId, int klantId) {
            string query = "SELECT bestelling.Id, bestelling.Aantal, klant.Id AS klantId, klant.Naam, klant.Adres, product.* FROM bestelling " +
                "INNER JOIN product ON bestelling.productId=product.Id " +
                "INNER JOIN klant ON bestelling.klantId=klant.Id WHERE bestelling.Id=@Id AND bestelling.klantId=@klantId";
            SqlConnection connection = GetConnection();
            using (SqlCommand command = new SqlCommand(query, connection)) {
                try {
                    connection.Open();
                    command.Parameters.Add(new SqlParameter("@Id", SqlDbType.Int));
                    command.Parameters.Add(new SqlParameter("@klantId", SqlDbType.Int));
                    command.Parameters["@Id"].Value = bestellingId;
                    command.Parameters["@klantId"].Value = klantId;
                    SqlDataReader dataReader = command.ExecuteReader();
                    dataReader.Read();
                    Klant k = new Klant((int)dataReader["klantId"], (string)dataReader["Naam"], (string)dataReader["Adres"]);
                    Product p = new Product((string)dataReader["productType"]);
                    Bestelling b = new Bestelling((int)dataReader["Id"], p, (int)dataReader["Aantal"], k);
                    dataReader.Close();
                    return b;
                } catch (Exception ex) {
                    BestellingRepositoryException bestellingRepositoryEx = new BestellingRepositoryException("GeefBestelling niet gelukt", ex);
                    bestellingRepositoryEx.Data.Add("bestellingId", bestellingId);
                    bestellingRepositoryEx.Data.Add("klantId", klantId);
                    throw bestellingRepositoryEx;
                } finally {
                    connection.Close();
                }
            }
        }

        public List<Bestelling> GeefBestellingenKlant(int klantId) {
            string query = "SELECT t1.*, t2.* FROM bestelling t1 " +
                "INNER JOIN klant t2 ON t1.klantId=t2.Id " +
                "INNER JOIN product ON t1.productId=product.Id WHERE t1.klantId=@klantId";
            SqlConnection connection = GetConnection();
            using (SqlCommand command = new SqlCommand(query, connection)) {
                try {
                    List<Bestelling> bestellingen = new List<Bestelling>();

                    connection.Open();
                    command.Parameters.Add(new SqlParameter("@klantId", SqlDbType.Int));
                    command.Parameters["@klantId"].Value = klantId;
                    SqlDataReader dataReader = command.ExecuteReader();
                    Klant k = null;
                    Product p = null;
                    while (dataReader.Read()) {
                        if (k == null) {
                            k = new Klant((int)dataReader["t2.Id"], (string)dataReader["t2.Naam"], (string)dataReader["t2.Adres"]);
                        }
                        if (p == null) {
                            p = new Product((string)dataReader["productType"]);
                        }
                        Bestelling b = new Bestelling((int)dataReader["t1.Id"], p, (int)dataReader["t1.Aantal"], k);
                        bestellingen.Add(b);
                    }
                    dataReader.Close();
                    return bestellingen;
                } catch (Exception ex) {
                    BestellingRepositoryException bestellingRepositoryEx = new BestellingRepositoryException("GeefBestellingenKlant niet gelukt", ex);
                    bestellingRepositoryEx.Data.Add("klantId", klantId);
                    throw bestellingRepositoryEx;
                } finally {
                    connection.Close();
                }
            }
        }

        public bool BestaatBestelling(int bestellingId, int klantId) {
            string query = "SELECT COUNT(*) FROM bestelling WHERE klantId=@klantId AND Id=@bestellingId";
            SqlConnection connection = GetConnection();
            using (SqlCommand command = new SqlCommand(query, connection)) {
                try {
                    connection.Open();
                    command.Parameters.Add(new SqlParameter("@klantId", SqlDbType.Int));
                    command.Parameters.Add(new SqlParameter("@bestellingId", SqlDbType.Int));
                    command.Parameters["@klantId"].Value = klantId;
                    command.Parameters["@bestellingId"].Value = bestellingId;
                    int? n = (int?)command.ExecuteScalar();
                    if (n > 0 || n != null) {
                        return true;
                    }
                    return false;
                } catch (Exception ex) {
                    BestellingRepositoryException bestellingRepositoryEx = new BestellingRepositoryException("BestaatBestelling niet gelukt", ex);
                    bestellingRepositoryEx.Data.Add("klantId", klantId);
                    bestellingRepositoryEx.Data.Add("bestellingId", bestellingId);
                    throw bestellingRepositoryEx;
                } finally {
                    connection.Close();
                }
            }
        }

        public Bestelling MaakBestellingAan(Bestelling bestelling) {
            string query = "INSERT INTO bestelling (klantId, productId, Aantal) output INSERTED.Id VALUES (@klantId, @productId, @Aantal)";
            SqlConnection connection = GetConnection();
            using (SqlCommand command = new SqlCommand(query, connection)) {
                try {
                    connection.Open();
                    command.Parameters.Add(new SqlParameter("@klantId", SqlDbType.Int));
                    command.Parameters.Add(new SqlParameter("@productId", SqlDbType.Int));
                    command.Parameters.Add(new SqlParameter("@Aantal", SqlDbType.Int));
                    command.Parameters["@klantId"].Value = bestelling.Klant.ID;
                    command.Parameters["@productId"].Value = bestelling.Product.ID;
                    command.Parameters["@Aantal"].Value = bestelling.Aantal;
                    int newId = (int)command.ExecuteScalar();
                    bestelling.ZetId(newId);
                    return bestelling;
                } catch (Exception ex) {
                    BestellingRepositoryException bestellingRepositoryEx = new BestellingRepositoryException("MaakBestellingAan niet gelukt", ex);
                    bestellingRepositoryEx.Data.Add("bestelling", bestelling);
                    throw bestellingRepositoryEx;
                } finally {
                    connection.Close();
                }
            }
        }

        public void VerwijderBestelling(int bestellingId) {
            string query = "DELETE FROM bestelling WHERE Id=@Id";
            SqlConnection connection = GetConnection();
            using (SqlCommand command = new SqlCommand(query, connection)) {
                try {
                    connection.Open();
                    command.Parameters.Add(new SqlParameter("@Id", SqlDbType.Int));
                    command.Parameters["@Id"].Value=bestellingId;
                    command.ExecuteNonQuery();
                } catch (Exception ex) {
                    BestellingRepositoryException bestellingRepositoryEx = new BestellingRepositoryException("VerwijderBestelling niet gelukt", ex);
                    bestellingRepositoryEx.Data.Add("bestellingId", bestellingId);
                    throw bestellingRepositoryEx;
                } finally {
                    connection.Close();
                }
            }

        }

        public void UpdateBestelling(Bestelling bestelling) {
            string query = "UPDATE bestelling SET Aantal=@Aantal, klantId=@klantId, productId=@productId WHERE Id=@Id";
            SqlConnection connection = GetConnection();
            using (SqlCommand command = new SqlCommand(query, connection)) {
                try {
                    connection.Open();
                    command.Parameters.Add(new SqlParameter("@Aantal", SqlDbType.Int));
                    command.Parameters.Add(new SqlParameter("@klantId", SqlDbType.Int));
                    command.Parameters.Add(new SqlParameter("@productId", SqlDbType.Int));
                    command.Parameters.Add(new SqlParameter("@Id", SqlDbType.Int));
                    command.Parameters["@Aantal"].Value = bestelling.Aantal;
                    command.Parameters["@klantId"].Value = bestelling.Klant.ID;
                    command.Parameters["@productId"].Value = bestelling.Product.ID;
                    command.Parameters["@Id"].Value = bestelling.ID;
                    command.ExecuteNonQuery();
                } catch (Exception ex) {
                    BestellingRepositoryException bestellingRepositoryEx = new BestellingRepositoryException("UpdateBestelling niet gelukt", ex);
                    bestellingRepositoryEx.Data.Add("bestelling", bestelling);
                    throw bestellingRepositoryEx;
                } finally {
                    connection.Close();
                }
            }
        }
        #endregion
    }
}
