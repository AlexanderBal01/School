﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Layer.Exceptions {
    class KlantRepositoryException : Exception {
        #region Ctor
        public KlantRepositoryException(string message) : base(message) {
        }

        public KlantRepositoryException(string message, Exception innerException) : base(message, innerException) {
        }
        #endregion
    }
}
