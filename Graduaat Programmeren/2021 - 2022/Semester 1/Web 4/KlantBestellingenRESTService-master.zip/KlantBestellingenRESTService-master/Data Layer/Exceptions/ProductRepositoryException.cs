﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Layer.Exceptions {
    public class ProductRepositoryException : Exception {
        #region Ctor
        public ProductRepositoryException(string message) : base(message) {
        }

        public ProductRepositoryException(string message, Exception innerException) : base(message, innerException) {
        }
        #endregion
    }
}
