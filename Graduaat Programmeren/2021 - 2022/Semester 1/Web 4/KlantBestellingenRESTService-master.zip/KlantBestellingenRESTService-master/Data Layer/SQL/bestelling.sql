CREATE TABLE bestelling (
	Id INT NOT NULL IDENTITY(1,1) PRIMARY KEY,
	Aantal INT NOT NULL,
	klantId INT,
	productId INT,
	CONSTRAINT FK_KlantBestelling FOREIGN KEY (klantId) REFERENCES klant(Id),
	CONSTRAINT FK_ProductBestelling FOREIGN KEY (productId) REFERENCES product(Id)
);