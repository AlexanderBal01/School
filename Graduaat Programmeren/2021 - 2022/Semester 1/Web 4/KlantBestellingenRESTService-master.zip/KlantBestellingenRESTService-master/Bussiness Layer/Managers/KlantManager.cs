﻿using Bussiness_Layer.Exceptions.Managers;
using Bussiness_Layer.Interfaces;
using Bussiness_Layer.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bussiness_Layer.Managers {
    public class KlantManager {
        #region Properties
        private IKlantRepository repo;
        #endregion

        #region Ctor
        public KlantManager(IKlantRepository repo) {
            this.repo = repo;
        }
        #endregion

        #region Methods
        public Klant GeefKlant(int id) {
            try {
                return repo.GeefKlant(id);
            } catch (Exception ex) {
                throw new KlantManagerException("GeefKlant", ex);
            }
        }

        public Klant MaakKlantAan(Klant klant) {
            try {
                if (klant == null) {
                    throw new KlantManagerException("MaakKlantAan - Klant is null.");
                }
                if (repo.BestaatKlant(klant.ID)) {
                    throw new KlantManagerException("MaakKlantAan - Klant bestaat reeds.");
                }
                return repo.MaakKlantAan(klant);
            } catch (Exception ex) { 
                throw new KlantManagerException("MaakKlantAan", ex);
            }
        }

        public bool BestaatKlant(int klantId) {
            try {
                return repo.BestaatKlant(klantId);
            } catch (Exception ex) {
                throw new KlantManagerException("BestaatKlant", ex);
            }
        }

        public Klant UpdateKlant(Klant klant) {
            try {
                if (klant == null) {
                    throw new KlantManagerException("UpdateKlant - klant is null");
                }
                if (!repo.BestaatKlant(klant.ID)) {
                    throw new KlantManagerException("UpdateKlant - klant bestaat niet");
                }
                Klant klantDB = repo.GeefKlant(klant.ID);
                if (klant == klantDB) {
                    throw new KlantManagerException("UpdateKlant - geen verschillen");
                }
                repo.UpdateKlant(klant);
                return klant;
            } catch (Exception ex) {
                throw new KlantManagerException("UpdateKlant", ex);
            }
        }

        public void VerwijderKlant(int id) {
            try {
                if (!repo.BestaatKlant(id)) {
                    throw new KlantManagerException("VerwijderKlant - klant bestaat nog niet");
                }
                if (repo.HeeftBestellingen(id)) {
                    throw new KlantManagerException("VerwijderKlant - bestellingen niet leeg");
                }
                repo.VerwijderKlant(id);
            } catch (Exception ex) {
                throw new KlantManagerException("VerwijderKlant", ex);
            }
        }
        #endregion
    }
}
