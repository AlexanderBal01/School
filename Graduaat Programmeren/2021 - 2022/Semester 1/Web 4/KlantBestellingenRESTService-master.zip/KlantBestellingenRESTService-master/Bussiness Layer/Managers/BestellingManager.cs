﻿using Bussiness_Layer.Exceptions.Managers;
using Bussiness_Layer.Interfaces;
using Bussiness_Layer.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bussiness_Layer.Managers {
    public class BestellingManager {
        #region Properties
        private IBestellingRepository repo;
        #endregion

        #region Ctor
        public BestellingManager(IBestellingRepository repo) {
            this.repo = repo;
        }
        #endregion

        #region Methods
        public List<Bestelling> GeefBestellingenKlant(int id) {
            try {
                return repo.GeefBestellingenKlant(id);
            } catch (Exception ex) {
                throw new BestellingManagerException("GeefBestellingenKlant", ex);
            }
        }

        public Bestelling GeefBestelling(int bestellingId, int klantId) {
            try {
                return repo.GeefBestelling(bestellingId, klantId);
            } catch (Exception ex) {
                throw new BestellingManagerException("GeefBestelling", ex);
            }
        }

        public Bestelling MaakBestellingAan(Bestelling bestelling) {
            try {
                if (bestelling == null) {
                    throw new BestellingManagerException("MaakBestellingAan - null");
                }
                if (repo.BestaatBestelling(bestelling.ID)) {
                    throw new BestellingManagerException("MaakBestellingAan - bestaat al");
                }
                return repo.MaakBestellingAan(bestelling);
            } catch (Exception ex) {
                throw new BestellingManagerException("MaakBestellingAan", ex);
            }
        }

        public bool BestaatBestelling(int id) {
            try {
                return repo.BestaatBestelling(id);
            } catch (Exception ex) {
                throw new BestellingManagerException("BestaatBestelling", ex);
            }
        }

        public bool BestaatBestelling(int bestellingId, int klantId) {
            try {
                return repo.BestaatBestelling(bestellingId, klantId);
            } catch (Exception ex) {
                throw new BestellingManagerException("BestaatBestelling", ex);
            }
        }

        public void VerwijderBestelling(int bestellingId, int klantId) {
            try {
                if (!repo.BestaatBestelling(bestellingId, klantId)) {
                    throw new BestellingManagerException("VerwijderBestelling - bestelling bestaat niet bij deze klant");
                }
                repo.VerwijderBestelling(bestellingId);
            } catch (Exception ex) {
                throw new BestellingManagerException("VerwijderBestelling", ex);
            }
        }

        public Bestelling UpdateBestelling(Bestelling bestelling) {
            try {
                if (bestelling == null) {
                    throw new BestellingManagerException("UpdateBestelling - bestelling is null");
                }
                if (!repo.BestaatBestelling(bestelling.ID)) {
                    throw new BestellingManagerException("UpdateBestelling - bestelling bestaat niet");
                }
                Bestelling bestellingDB = repo.GeefBestelling(bestelling.ID, bestelling.Klant.ID);
                if (bestelling == bestellingDB) {
                    throw new BestellingManagerException("UpdateBestelling - geen verschillen");
                }
                repo.UpdateBestelling(bestelling);
                return bestelling;
            } catch (Exception ex) {
                throw new BestellingManagerException("UpdateBestelling", ex);
            }
        }
        #endregion
    }
}
