﻿using Bussiness_Layer.Exceptions.Managers;
using Bussiness_Layer.Interfaces;
using Bussiness_Layer.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bussiness_Layer.Managers {
    public class ProductManager {
        #region Properties
        private IProductRepository repo;
        #endregion

        #region Ctor
        public ProductManager(IProductRepository repo) {
            this.repo = repo;
        }
        #endregion

        #region Methods
        public Product GeefProductBestelling(int id) {
            try {
                return repo.GeefProductBestelling(id);
            } catch (Exception ex) {
                throw new ProductManagerException("GeefProductBestelling", ex);
            }
        }

        public Product GeefProduct(string product) {
            try {
                return repo.GeefProduct(product);
            } catch (Exception ex) {
                throw new ProductManagerException("GeefProduct", ex);
            }
        }
        #endregion
    }
}
