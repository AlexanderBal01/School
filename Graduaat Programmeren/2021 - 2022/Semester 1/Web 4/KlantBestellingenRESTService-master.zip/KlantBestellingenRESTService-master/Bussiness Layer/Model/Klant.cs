﻿ using Bussiness_Layer.Exceptions.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bussiness_Layer.Model {
    public class Klant {
        #region Properties
        public int ID { get; private set; }
        public string Naam { get; private set; }
        public string Adres { get; private set; }
        #endregion

        #region Ctor
        public Klant(string naam, string adres) {
            ZetNaam(naam);
            ZetAdres(adres);
        }

        public Klant(int id, string naam, string adres) : this(naam, adres) {
            ZetId(id);
        }
        #endregion

        #region Methods
        public void ZetNaam(string naam) {
            if (!string.IsNullOrWhiteSpace(naam)) {
                Naam = naam;
            } else {
                throw new KlantException("Klant naam moet ingevuld zijn.");
            }
        }

        public void ZetAdres(string adres) {
            if (!string.IsNullOrWhiteSpace(adres)) {
                if(adres.Length >= 10) {
                    Adres = adres;
                } else {
                    throw new KlantException("Klant adres moet minstens 10 tekens lang zijn.");
                }
            } else {
                throw new KlantException("Klant adres moet ingevuld zijn.");
            }
        }

        public void ZetId(int id) {
            if (id > 0) {
                ID = id;
            } else {
                throw new KlantException("klant - Invalid id.");
            }
        }

        public override bool Equals(object obj)
        {
            return obj is Klant klant &&
                   ID == klant.ID &&
                   Naam == klant.Naam &&
                   Adres == klant.Adres;
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(ID, Naam, Adres);
        }
        #endregion
    }
}
