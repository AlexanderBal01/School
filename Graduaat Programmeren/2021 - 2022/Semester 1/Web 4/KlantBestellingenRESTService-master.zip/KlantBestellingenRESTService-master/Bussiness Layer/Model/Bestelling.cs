﻿using Bussiness_Layer.Exceptions.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bussiness_Layer.Model {
    public class Bestelling {
        #region Properties
        public int ID { get; private set; }
        public Product Product { get; private set; }
        public int Aantal { get; private set; }
        public Klant Klant { get; private set; }
        #endregion

        #region Ctor
        public Bestelling(Product product, int aantal, Klant klant) {
            ZetProduct(product);
            ZetAantal(aantal);
            ZetKlant(klant);
        }

        public Bestelling(int id, Product product, int aantal, Klant klant) : this(product, aantal, klant) {
            ZetId(id);
        }
        #endregion

        #region Methods
        public void ZetProduct(Product product) {
            if (product == null) {
                throw new BestellingException("ZetProduct - null");
            }
            if (product == Product) {
                throw new BestellingException("ZetProduct - net nieuw");
            }
            Product = product;
        }

        public void ZetAantal(int aantal) {
            if (!string.IsNullOrWhiteSpace(aantal.ToString())) {
                if (aantal > 1) {
                    Aantal = aantal;
                } else {
                    throw new BestellingException("Aantal moet groter zijn dan 1.");
                }
            } else {
                throw new BestellingException("Aantal moet ingevuld zijn.");
            }
        }

        public void ZetKlant(Klant klant) {
            if (klant == null) {
                throw new BestellingException("ZetKlant - null");
            }
            if (klant == Klant) {
                throw new BestellingException("ZetKlant - net nieuw");
            }
            Klant = klant;
        }

        public void ZetId(int id) {
            if (id > 0) {
                ID = id;
            } else {
                throw new BestellingException("Bestelling - Invalid id");
            }
        }

        public override bool Equals(object obj)
        {
            return obj is Bestelling bestelling &&
                   ID == bestelling.ID &&
                   EqualityComparer<Product>.Default.Equals(Product, bestelling.Product) &&
                   Aantal == bestelling.Aantal &&
                   EqualityComparer<Klant>.Default.Equals(Klant, bestelling.Klant);
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(ID, Product, Aantal, Klant);
        }
        #endregion
    }
}
