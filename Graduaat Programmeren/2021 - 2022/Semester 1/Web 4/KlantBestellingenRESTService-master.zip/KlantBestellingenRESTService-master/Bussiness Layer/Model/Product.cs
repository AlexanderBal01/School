﻿using Bussiness_Layer.Exceptions.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bussiness_Layer.Model {
    public class Product {
        #region Properties
        public int ID { get; private set; }
        public string ProductNaam { get; private set; }
        #endregion

        #region Ctor
        public Product(string productNaam) {
            ZetProductNaam(productNaam);
        }
        
        public Product(int id, string productNaam) : this(productNaam) {
            ZetId(id);
        }
        #endregion

        #region Methods
        public void ZetProductNaam(string productNaam) {
            if (!string.IsNullOrWhiteSpace(productNaam)) {
                ProductNaam = productNaam;
            } else {
                throw new ProductException("Product - Invalid productnaam");
            }
        }

        public void ZetId(int id) {
            if (id > 0) {
                ID = id;
            } else {
                throw new ProductException("Product - Invalid id");
            }
        }

        public override bool Equals(object obj)
        {
            return obj is Product product &&
                   ID == product.ID &&
                   ProductNaam == product.ProductNaam;
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(ID, ProductNaam);
        }

        public override string ToString()
        {
            return $"{ProductNaam}";
        }
        #endregion
    }
}
