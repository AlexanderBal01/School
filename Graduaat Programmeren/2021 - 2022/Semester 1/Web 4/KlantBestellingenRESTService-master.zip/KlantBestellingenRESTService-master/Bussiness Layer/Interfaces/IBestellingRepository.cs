﻿using Bussiness_Layer.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bussiness_Layer.Interfaces {
    public interface IBestellingRepository {
        List<Bestelling> GeefBestellingenKlant(int klantId);
        bool BestaatBestelling(int id);
        Bestelling MaakBestellingAan(Bestelling bestelling);
        Bestelling GeefBestelling(int bestellingId, int klantId);
        bool BestaatBestelling(int bestellingId, int klantId);
        void VerwijderBestelling(int bestellingId);
        void UpdateBestelling(Bestelling bestelling);
    }
}
