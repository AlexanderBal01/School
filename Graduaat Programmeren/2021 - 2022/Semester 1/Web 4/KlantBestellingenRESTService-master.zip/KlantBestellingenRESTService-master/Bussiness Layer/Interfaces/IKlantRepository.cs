﻿using Bussiness_Layer.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bussiness_Layer.Interfaces {
    public interface IKlantRepository {
        bool BestaatKlant(int id);
        Klant MaakKlantAan(Klant klant);
        void VerwijderKlant(int id);
        void UpdateKlant(Klant klant);
        Klant GeefKlant(int id);
        bool HeeftBestellingen(int id);
    }
}
