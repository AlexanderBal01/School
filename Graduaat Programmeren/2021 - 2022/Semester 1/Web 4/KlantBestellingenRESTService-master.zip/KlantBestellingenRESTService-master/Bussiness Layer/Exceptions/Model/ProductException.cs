﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bussiness_Layer.Exceptions.Model {
    public class ProductException : Exception {
        public ProductException(string message) : base(message) {
        }

        public ProductException(string message, Exception innerException) : base(message, innerException) {
        }
    }
}
