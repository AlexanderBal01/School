﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bussiness_Layer.Exceptions.Managers {
    public class ProductManagerException : Exception {
        public ProductManagerException(string message) : base(message) {
        }

        public ProductManagerException(string message, Exception innerException) : base(message, innerException) {
        }
    }
}
