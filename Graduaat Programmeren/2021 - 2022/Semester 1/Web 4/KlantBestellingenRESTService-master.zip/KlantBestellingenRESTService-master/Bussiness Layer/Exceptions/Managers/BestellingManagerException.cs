﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bussiness_Layer.Exceptions.Managers {
    public class BestellingManagerException : Exception {
        #region Ctor
        public BestellingManagerException(string message) : base(message) {
        }

        public BestellingManagerException(string message, Exception innerException) : base(message, innerException) {
        }
        #endregion
    }
}
