﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bussiness_Layer.Exceptions.Managers {
    public class KlantManagerException : Exception {
        public KlantManagerException(string message) : base(message) {
        }

        public KlantManagerException(string message, Exception innerException) : base(message, innerException) {
        }
    }
}
