using Bussiness_Layer.Model;
using Bussiness_Layer.Exceptions;
using System;
using Xunit;

namespace TestProjectBussinessLayer {
    public class UnitTestProduct {
        [Fact]
        public void Test_Ctor_NoId_Valid() {
            Product product = new Product("Leffe");
            Assert.Equal("Leffe", product.ProductNaam);
        }

        [Fact]
        public void Test_Ctor_WithId_Valid() {
            Product product = new Product(1, "Leffe");
            Assert.Equal(1, product.ID);
            Assert.Equal("Leffe", product.ProductNaam);
        }

        [Fact]
        public void Test_ZetProductNaam_Valid() {
            Product product = new Product("Leffe");
            product.ZetProductNaam("Leffe");
            Assert.Equal("Leffe", product.ProductNaam);
        }

        [Theory]
        [InlineData("")]
        [InlineData(" ")]
        [InlineData(null)]
        public void Test_ZetProductNaam_Invalid(string productnaam) {
            Product product = new Product("Leffe");
            Assert.Throws<ProductException>(() => product.ZetProductNaam(productnaam));
        }

        [Fact]
        public void Test_ZetId_Valid() {
            Product product = new Product(1, "Leffe");
            product.ZetId(1);
            Assert.Equal(1, product.ID);
        }

        [Theory]
        [InlineData(-1)]
        [InlineData(0)]
        public void Test_ZetId_Invalid(int id) {
            Product product = new Product(1, "Leffe");
            Assert.Throws<ProductException>(() => product.ZetId(id));
        }
    }
}
