﻿using Bussiness_Layer.Model;
using Bussiness_Layer.Exceptions;
using System;
using Xunit;

namespace TestProjectBussinessLayer {
    public class UnitTestBestelling {
        #region Tests Ctor
        [Fact]
        public void Test_Ctor_NoId_Valid() {
            Bestelling bestelling = new Bestelling(new Product("Leffe"), 1, new Klant("Alexander Bal", "martelarenlaan 38, 9200 Dendermonde"));
            Assert.Equal(new Product("Leffe"), bestelling.Product);
            Assert.Equal(1, bestelling.Aantal);
            Assert.Equal(new Klant("Alexander Bal", "martelarenlaan 38, 9200 Dendermonde"), bestelling.Klant);
        }

        [Fact]
        public void Test_Ctor_WithId_Valid() {
            Bestelling bestelling = new Bestelling(1, new Product("Leffe"), 1, new Klant("Alexander Bal", "martelarenlaan 38, 9200 Dendermonde"));
            Assert.Equal(1, bestelling.ID);
            Assert.Equal(new Product("Leffe"), bestelling.Product);
            Assert.Equal(1, bestelling.Aantal);
            Assert.Equal(new Klant("Alexander Bal", "martelarenlaan 38, 9200 Dendermonde"), bestelling.Klant);
        }
        #endregion

        #region Tests Methods
        [Fact]
        public void Test_ZetProduct_Valid() {
            Bestelling bestelling = new Bestelling(1, new Product("Leffe"), 1, new Klant("Alexander Bal", "martelarenlaan 38, 9200 Dendermonde"));
            bestelling.ZetProduct(new Product("Leffe"));
            Assert.Equal(new Product("Leffe"), bestelling.Product);
        }

        [Theory]
        [InlineData("")]
        [InlineData(" ")]
        [InlineData(null)]
        public void Test_ZetNaam_Invalid(string naam) {
            Klant klant = new Klant("Alexander Bal", "martelarenlaan 38, 9200 Dendermonde");
            Assert.Throws<KlantException>(() => klant.ZetNaam(naam));
        }

        [Fact]
        public void Test_ZetAdres_Valid() {
            Klant klant = new Klant("Alexander Bal", "martelarenlaan 38, 9200 Dendermonde");
            klant.ZetAdres("martelarenlaan 38, 9200 Dendermonde");
            Assert.Equal("martelarenlaan 38, 9200 Dendermonde", klant.Adres);
        }

        [Theory]
        [InlineData("abcd12345")]
        [InlineData("")]
        [InlineData(" ")]
        [InlineData(null)]
        public void Test_ZetAdres_Invalid(string adres) {
            Klant klant = new Klant("Alexander Bal", "martelarenlaan 38, 9200 Dendermonde");
            Assert.Throws<KlantException>(() => klant.ZetAdres(adres));
        }

        [Fact]
        public void Test_ZetId_Valid() {
            Product product = new Product(1, "Leffe");
            product.ZetId(1);
            Assert.Equal(1, product.ID);
        }

        [Theory]
        [InlineData(-1)]
        [InlineData(0)]
        public void Test_ZetId_Invalid(int id) {
            Klant klant = new Klant(1, "Leffe", "martelarenlaan 38, 9200 Dendermonde");
            Assert.Throws<KlantException>(() => klant.ZetId(id));
        }
        #endregion
    }
}
