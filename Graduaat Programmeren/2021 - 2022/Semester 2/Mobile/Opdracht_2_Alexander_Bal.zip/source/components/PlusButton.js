import { StyleSheet, Text, TouchableOpacity } from 'react-native'
import React from 'react'

const PlusButton = ({updateTeam, Teams}) => {
  const pressHandler = () => {
    const newTeams = [...Teams];
    const Index = newTeams.findIndex(team => team.bgColor == '#ffa500');
    newTeams[Index].score = newTeams[Index].score + 1;
    updateTeam(newTeams);
  }

  return (
    <TouchableOpacity style={styles.button} onPress={() => pressHandler()}>
        <Text style={styles.buttonText}>+</Text>
    </TouchableOpacity>
  )
}

export default PlusButton;

const styles = StyleSheet.create({
  button: {
    marginHorizontal: 60,
    height: 40,
    backgroundColor: "lightgrey",
    marginBottom: 20,
  },
  buttonText: {
    textAlign: 'center',
    paddingTop: 15,
    color: '#000',
  },
})