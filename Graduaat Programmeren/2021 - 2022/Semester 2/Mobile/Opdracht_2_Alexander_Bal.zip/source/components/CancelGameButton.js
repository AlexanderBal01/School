import { StyleSheet, Text, TouchableOpacity, Alert } from 'react-native'
import React from 'react'

const CancelGameButton = ({updateTeam, Teams}) => {
  const intialstate = [];

  const onPressHandler = () => {
    if (Teams.length > 0){
      updateTeam(intialstate);
    } else {
      Alert.alert("Fout", 
        "Er bestaat nog geen Team",
        [
          {
              text: 'ok'
          }
        ]
      );
    }
  }

  return (
    <TouchableOpacity style={styles.button} onPress={() => onPressHandler()}>
        <Text style={styles.buttonText}>Cancel game</Text>
    </TouchableOpacity>
  )
}

export default CancelGameButton

const styles = StyleSheet.create({
  button: {
    marginHorizontal: 60,
    height: 40,
    backgroundColor: "lightgrey",
    marginBottom: 20,
  },
  buttonText: {
    textAlign: 'center',
    paddingTop: 15,
    color: '#000',
  },
})