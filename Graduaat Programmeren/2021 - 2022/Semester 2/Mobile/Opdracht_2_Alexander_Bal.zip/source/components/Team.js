import { StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import React from 'react';

const Team = ({item, pressHandler, bgColor}) => {

  return (
    <View style={styles.flex}>
      <TouchableOpacity style={[styles.container, {backgroundColor:bgColor}]} onPress={pressHandler}>
        <Text style={styles.teamNaam}>{item.teamNaam}</Text>
        <Text style= {styles.score}>{item.score}</Text>
      </TouchableOpacity>
    </View>
  )
}

export default Team

const styles = StyleSheet.create({
  flex: {
    flex: 1,
    flexDirection: 'column', 
    justifyContent: 'center',
  },
  container: {
    marginHorizontal: 60,
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 10,
    marginTop: 10,
    borderRadius: 10,
    borderColor: 'lightgrey',
    borderWidth: 1,
  },
  teamNaam: {
    paddingVertical: 10,
    paddingStart: 5,
    fontSize: 18
  },
  score: {
    paddingVertical: 10,
    paddingEnd: 5,
    fontSize: 18,
    fontWeight: 'bold',
  }
})