import { StyleSheet, TouchableOpacity, Text } from 'react-native';
import React from 'react';

const AddTeamButton = ({pressHandler}) => {
  return (
    <TouchableOpacity style={styles.button} onPress={pressHandler}>
        <Text style={styles.buttonText}>ADD NEW TEAM</Text>
    </TouchableOpacity>
  )
}

export default AddTeamButton

const styles = StyleSheet.create({
    button: {
        marginHorizontal: 60,
        height: 40,
        backgroundColor: "coral",
    },
    buttonText: {
        textAlign: 'center',
        paddingTop: 15,
        color: '#fff',
    },
})