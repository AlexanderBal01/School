import { StyleSheet, TextInput, View, Alert, FlatList} from 'react-native'
import React, {useState} from 'react'
import AddTeamButton from './AddTeamButton';
import Team from './Team';
import Footer from './Footer';

const Overzicht = () => {
  const [team, addTeam] = useState("");
  const [addedteams, setTeam] = useState([]);
  const [Click, setClick] = useState(null);

  const pressHandlerAddTeam = (item) => {
    if (item.length >= 5) {
      if(!addedteams.some(el => el.teamNaam == item)) {
        setTeam((prevTeams) => {
          return [...prevTeams, {teamNaam: item, score: 0, key: Math.random().toString(), bgColor: '#fff'}]
        });
      } else {
        Alert.alert("Fout", 
          "Een team met deze naam bestaat reeds",
          [
            {
              text: 'ok'
            }
          ]
        );
      }
    } else {
      Alert.alert("Langere input nodig", 
        "De naam van een team bestaat uit minstens 5 karakters",
        [
          {
              text: 'ok'
          }
        ]
      );
    }
  }

  const pressHandlerBgColor = (key) => {
    setClick(key);
    const index = addedteams.findIndex(addedteam => addedteam.key==key);
    addedteams[index].bgColor = '#ffa500';
    const index2 = addedteams.findIndex(addedteam => addedteam.key != key);
    addedteams[index2].bgColor = '#fff';
    console.log(addedteams);
  }

  if (addedteams.length == 2) {
    addedteams.map(addedteam => addedteam.score = 0);

    return (
      <View style={styles.container}>
        <FlatList 
          data={addedteams}
          renderItem={({item}) => (
            <Team item={item} pressHandler={() => pressHandlerBgColor(item.key)}  bgColor={item.key === Click? "#ffa500":"#fff"} />
          )}
          keyExtractor={(item) => item.key}
        />
        <Footer updateTeam={setTeam} Teams={addedteams} />
      </View>
    )
  }

  return (
    <View style={styles.container}>
        <TextInput
          style={styles.input}
          placeholder="New teams Name..."
          onChangeText={newTeam => addTeam(newTeam)}
        />
      <AddTeamButton pressHandler={() => pressHandlerAddTeam(team)} />
      <FlatList 
        data={addedteams}
        renderItem={({item}) => (
          <Team item={item} pressHandler={() => setClick(item.key) }
          bgColor={item.key === Click? "#ffa500":"#fff"} />
        )}
        keyExtractor={(item) => item.key}
      />
      <Footer updateTeam={setTeam} Teams={addedteams} />
    </View>
  )
}

export default Overzicht;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center'
  },
  input: {
    marginBottom: 10,
    paddingHorizontal: 8,
    marginHorizontal: 60,
    paddingVertical: 6,
    borderBottomWidth: 1,
    borderBottomColor: "#ddd",
  },
})