import { StyleSheet, Text, View } from 'react-native'
import React from 'react'
import PlusButton from './PlusButton'
import CancelGameButton from './CancelGameButton'

const Footer = ({updateTeam, Teams}) => {
  return (
    <View>
      <PlusButton updateTeam={updateTeam} Teams={Teams}/>
      <CancelGameButton updateTeam={updateTeam} Teams={Teams}/>
    </View>
  )
}

export default Footer

const styles = StyleSheet.create({
    container: {
      flex: 1,
      marginBottom: 25,
      alignItems: 'center',
      justifyContent: 'flex-end'
    },
})