import { StyleSheet, Text, View, TouchableWithoutFeedback, Keyboard } from 'react-native';
import React from 'react';
import { globalStyles } from '../styles/globalStyles';
import Header from '../components/Header';
import Overzicht from '../components/Overzicht';
import Footer from '../components/Footer';

const Home = () => {
  return (
    <TouchableWithoutFeedback onPress={() => Keyboard.dismiss()}>
      <View style={globalStyles.container}>
        <Header/>
        <Overzicht />
      </View>
    </TouchableWithoutFeedback>
  )
}

export default Home;

const styles = StyleSheet.create({})