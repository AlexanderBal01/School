import { StyleSheet } from 'react-native'

export const globalStyles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
        justifyContent: 'space-between',
    },
    titleText: {
        fontFamily: 'Shadows-Into-Light',
        fontSize: 30,
        color:"#0317fc",
    },

    bodyText: {
        fontFamily: 'Shadows-Into-Light',
        fontSize: 30,
    },
});