import Home from './source/screens/Home';

const App = () => {
  return (
    <Home/>
  );
}

export default App;