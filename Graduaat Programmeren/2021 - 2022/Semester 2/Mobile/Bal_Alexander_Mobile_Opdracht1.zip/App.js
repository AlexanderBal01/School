import { StatusBar } from 'expo-status-bar';
import React, { useState } from "react";
import { Button, StyleSheet, Text, View } from 'react-native';

const App = () => {
  const [bgColor, setBgColor] = useState("#fff");
  const [colorName, setColorName] = useState("Wit");
  const [teller, setTeller] = useState(0);

  const colors = [{ color: "#ff0000", colorName: "Rood" }, { color: "#1e00ff", colorName: "Blauw" }, { color: "#00ff1a", colorName: "Groen" }];

  const buttonHandlerChangeColor = () => {
    if (teller == 0) {
      setBgColor(colors[0].color);
      setColorName(colors[0].colorName);
    } else if (teller == 1) {
      setBgColor(colors[1].color);
      setColorName(colors[1].colorName);
    } else if (teller == 2) {
      setBgColor(colors[2].color);
      setColorName(colors[2].colorName);
    }

    if (teller == 0) {
      setTeller(1);
    } else if (teller == 1) {
      setTeller(2);
    } else if (teller == 2) {
      setTeller(0);
    }
  }

  return (
    <View style={[styles.container, { backgroundColor: bgColor }]}>
      <Text>De achtergrondkleur is {colorName}</Text>
      <Button onPress={buttonHandlerChangeColor} title="CHANGE COLOR" color="#000" accessibilityLabel="Change Color"/>
      <StatusBar style="auto" />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
});

export default App;