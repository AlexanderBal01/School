/* Denk eraan dit bestand aan index.html te koppelen! */

const initialTrackId = "barbizon12k";

/* Schrijf al je eigen code hieronder */


// Functie : setup
// Deze voegt o.a. alle tracks dynamisch toe aan de linkerkant, nadat de pagina is ingeladen.
// Op het einde moet de juiste track geselecteerd worden op basis van de identifier in 'initialTrackId'.
const setup = () => {
    let overviewSection = document.querySelector("section.overview");
    for (let i = 0; i < tracks.length; i++) {
        let htmlTrackOverview = `<section class="track" data-identifier="${tracks[i].identifier}">
                                    <h1>${tracks[i].name}</h1>
                                        <div class="overlay-container">
                                            <img class="thumbnail" src="${tracks[i].thumbnail}">
                                            <span class="level ${tracks[i].level}">${tracks[i].level}</span>
                                            <input type="button" class="deleteButton" value="X">
                                        </div>
                                        <p class="stats">
                                            <span class="distance">${tracks[i].distance}</span> 
                                            <span class="time">${tracks[i].time}</span>
                                        </p>
                                </section>`;
        overviewSection.insertAdjacentHTML("beforeend", htmlTrackOverview);
    }

    let overviewChildren = overviewSection.children;
    for (let i = 0; i < overviewChildren.length; i++) {
        overviewChildren[i].addEventListener("click", selectTrackElement);
        let inputButtonDelete = overviewChildren[i].querySelector("input[type=button].deleteButton");
        inputButtonDelete.addEventListener('click', deleteTrackElement);
    }

    selectTrackById(initialTrackId);
}

// Functie : findTrackById met 1 parameter 'identifier'
// Deze functie doorzoekt het 'tracks' array en retourneert het track object met de meegegeven identifier.
// Indien er geen object gevonden wordt, wordt null teruggegeven
// Ze wordt gebruikt in selectTrackById om het juiste object te bemachtigen met alle track informatie.
const findTrackById = (identifier) => {
    for (let i = 0; i < tracks.length; i++) {
        if (tracks[i].identifier === identifier) {
            return tracks[i];
        }
    }
    return null;
}


// Functie : selectTrackElement met eventueel een 'event' parameter
// Dit is de click event listener voor het selecteren van een andere track (klik in kader aan de linkerkant)
// Deze achterhaalt de identifier van de geklikte track en roept dan selectTrackById op om deze te selecteren.
const selectTrackElement = (event) => {
    let trackElement = event.currentTarget;
    let track = findTrackById(trackElement.getAttribute('data-identifier'));
    selectTrackById(track.identifier);
}

// Functie : selectTrackById met 1 parameter 'identifier'
// Deze wordt opgeroepen door selectTrackElement en realiseert het eigenlijke selecteren in de DOM-tree.
// Ze gebruikt findTrackById om het juiste track object uit het 'tracks' array te achterhalen. Dit track
// object bevat alle gegevens van de te selecteren track.
// Deze functie doet de nodige aanpassingen in de DOM-tree en zorgt er o.a. voor dat
// - de juiste elementen een rood/grijs kader krijgen
// - de details ingevuld worden aan de rechterkant
// - de juiste delete buttons getoond/verborgen worden
const selectTrackById = (identifier) => {
    let indexTrack = tracks.findIndex((track) => track.identifier === identifier);
    let track = tracks[indexTrack];
    let trackElements = document.querySelectorAll("section.track");
    for (let i = 0; i < trackElements.length; i++) {
        let trackElement = trackElements[i];

        if (trackElement.getAttribute('data-identifier') === identifier) {
            trackElement.classList.add('selected');

            let buttonTrackElement = trackElement.querySelector('input[type=button].deleteButton');
            buttonTrackElement.classList.add('hidden');

            let detailSection = document.querySelector('section.detail');
            detailSection.querySelector("h1.name").innerText = track.name;
            detailSection.querySelector("span.source").innerText = track.source;

            let img = detailSection.querySelector('img.full-image');
            img.src = track.image;

        } else {
            trackElement.classList.remove('selected');
            let buttonTrackElement = trackElement.querySelector('input[type=button].deleteButton');
            buttonTrackElement.classList.remove('hidden');
        }
    }
}

// Functie deleteTrackElement met eventueel een 'event' parameter
// Dit is de click event listener voor het verwijderen van een andere track (klik op een delete button)
// Deze verwijdert het/de juiste element(en) uit de DOM-tree.
const deleteTrackElement = (event) => {
    event.preventDefault();
    let deleteButton = event.currentTarget;
    let toDeleteElement = deleteButton.parentElement.parentElement;
    toDeleteElement.remove();
}


window.addEventListener("load", setup);
