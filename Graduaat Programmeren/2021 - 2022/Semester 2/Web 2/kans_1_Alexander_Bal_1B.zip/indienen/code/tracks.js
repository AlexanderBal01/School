// In deze file mag je niks aanpassen

let tracks = [{
    identifier: "gare",
    name: 'Randonnée de gare en gare entre Bois-le-Roi et Fontainebleau-Avon',
    thumbnail: 'asset/01-thumb.jpg',
    image: 'asset/01-full.png',
    distance: 10.7,
    time: '2:50',
    level: 'moderate',
    source: 'editor'
}, {
    identifier: "brigands",
    name: 'Gorges d\'Apremont et Caverne des Brigands depuis Barbizon',
    thumbnail: 'asset/02-thumb.jpg',
    image: 'asset/02-full.png',
    distance: 6.7,
    time: '1:50',
    level: 'easy',
    source: 'editor'
}, {
    identifier: "usvbarbizon",
    name: 'USV Rando Barbizon, Gorges d\'Apremont',
    thumbnail: 'asset/03-thumb.jpg',
    image: 'asset/03-full.png',
    distance: 10.4,
    time: '2:44',
    level: 'moderate',
    source: 'community'
}, {
    identifier: "gorgesdapremont",
    name: 'Gorges d\'Apremont',
    thumbnail: 'asset/04-thumb.jpg',
    image: 'asset/04-full.png',
    distance: 6.5,
    time: '1:44',
    level: 'easy',
    source: 'community'
}, {
    identifier: "barbizon12k",
    name: 'Barbizon12k',
    thumbnail: 'asset/05-thumb.png',
    image: 'asset/05-full.png',
    distance: 11.8,
    time: '4:32',
    level: 'moderate',
    source: 'community'
}, {
    identifier: "usvrando",
    name: 'USV Rando La table du grand Maitre',
    thumbnail: 'asset/06-thumb.png',
    image: 'asset/06-full.png',
    distance: 14.2,
    time: '3:40',
    level: 'moderate',
    source: 'community'
}, {
    identifier: "cassepot",
    name: 'rocher cassepot',
    thumbnail: 'asset/07-thumb.jpg',
    image: 'asset/07-full.png',
    distance: 4.1,
    time: '1:06',
    level: 'easy',
    source: 'community'
}, {
    identifier: "saintgermain",
    name: 'Ft Rocher Saint Germain & Cassepot',
    thumbnail: 'asset/08-thumb.png',
    image: 'asset/08-full.png',
    distance: 13.0,
    time: '3:28',
    level: 'difficult',
    source: 'community'
}];


