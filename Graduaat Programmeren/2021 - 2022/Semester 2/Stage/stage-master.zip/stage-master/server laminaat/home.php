<?php
ini_set('display_errors', 'On');
error_reporting(E_ALL & ~E_NOTICE);
//include $_SERVER['DOCUMENT_ROOT'] . "/auth/main.php";
//check_loggedin($belingrodb);
require_once $_SERVER['DOCUMENT_ROOT'] . "/vendor/autoload.php";
include_once $_SERVER['DOCUMENT_ROOT'] . "/auth/db.php";
?>

<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta name=”robots” content=”noindex,nofollow” />
  <meta name="viewport" content="width=device-width,minimum-scale=1">
  <title>Home Page</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  <script src="https://cdn.tiny.cloud/1/0t2cxcupmmqz093srjgwoxjkqkq241oktpjodj8yjs3mlhj5/tinymce/5/tinymce.min.js" referrerpolicy="origin"></script>
  <script type="text/javascript" src="https://code.jquery.com/jquery-3.5.1.js"></script>
  <script type="text/javascript" src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>
  <script type="text/javascript" src="https://cdn.datatables.net/1.11.3/js/dataTables.bootstrap5.min.js"></script>
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.1/css/bootstrap.min.css" />
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.3/css/dataTables.bootstrap5.min.css" />





  <style>
    .page-item.active .page-link {
      z-index: 3;
      color: #fff;
      background-color: #35363a;
      border-color: #35363a;
    }

    .table {
      --bs-table-striped-bg: unset;
    }
  </style>



  <script>
    tinymce.init({
      selector: '#textareanewinternalmemo',
      branding: false,
      menubar: false,
      statusbar: false,
      height: "480"


    });
    tinymce.init({
      selector: '#textareanewmessage',
      branding: false,
      menubar: false,
      statusbar: false,
      height: "480"


    });
  </script>
  <script>
    $(document).ready(function() {
      $('#tableinternalmemo').DataTable({
        "order": [
          [0, "asc"]
        ],
        "searching": false,
        "lengthMenu": [
          [10, 20, 30, 50, -1],
          [10, 20, 30, 50, "All"]
        ],
        "lengthChange": false,
        "bInfo": false,
        "language": {
          "lengthMenu": "Toon _MENU_ records per pagina",
          "zeroRecords": "Geen records gevonden",
          "info": "Toon pagina _PAGE_ van _PAGES_",
          "infoEmpty": "Geen records beschikbaar",
          "infoFiltered": "(gefilterd uit _MAX_ records)",
          "paginate": {
            "first": "Eerst",
            "last": "Laatst",
            "next": "Volgende",
            "previous": "Vorige"
          },
          "search": "Zoeken:",



        }




      });
    });
  </script>


</head>

<body>
  <?php
  include $_SERVER['DOCUMENT_ROOT'] . "/menu/menu.php";
  //include $_SERVER['DOCUMENT_ROOT']."/menu/submenu-ecomm-bol.php";
  ?>
  <div class="maincontent">
    <h1 class="h1maincontent">Boekhouding portaal</h1><br>
    <div class="subcontent">
      <div class="col-xl-3 col-md-3" style="float:left;display:block;">
        <div class="tablelisttopnoborder">
        </div>
        <div class="tablecontent">
          <ul class="sidenav">

            <?php if ($_GET['page'] == 'homeboekhouder' || $_GET['page'] == 'boekhouder-maandelijks' || $_GET['page'] == 'facturatie') { ?>
              <li class="side-notactive">
              <? } else { ?>
              <li class="side-active">
              <? } ?>
              <table>
                <tr>
                  <td class="iconleftmenu">
                    <a href="home.php"><i class="far fa-eye"></i></a>
                  </td>
                  <td><a href="home.php"><b>Overzicht</b></a></td>
                </tr>
              </table>
              </li>
              <?php if ($_GET['page'] == 'homeboekhouder' || $_GET['page'] == 'boekhouder-maandelijks')  { ?>
                <li class="side-active">
                <? } else { ?>
                <li class="side-notactive">
                <? } ?>
                <table>
                  <tr>
                    <td class="iconleftmenu">
                      <a href="home.php?page=homeboekhouder"><i class="fas fa-calendar-alt"></i></a>
                    </td>
                    <td><a href="home.php?page=homeboekhouder"><b>Boekhouder</b></a></td>
                  </tr>
                </table>
                </li>
              <?php if ($_GET['page'] == 'facturatie') { ?>
                <li class="side-active">
                <? } else { ?>
                  <li class="side-notactive">
                <? } ?>
                <table>
                  <tr>
                    <td class="iconleftmenu">
                      <a href="home.php?page=facturatie"><i class="fas fa-file-alt"></i></a>
                    </td>
                    <td><a href="home.php?page=facturatie"><b>Facturatie</b></a></td>
                  </tr>
                </table>
                </li>
          </ul>
        </div>
        <div class="tablebottom">
        </div>
      </div>
      <?php if ($_GET['page'] == 'facturatie') { //////// hier starten alex?>
        <div class="col-xl-9 col-md-9" style="float:left;display:block;">
          <div class="tablelisttop">
            <table style="width: 100%;">
              <tr>
                <td class="icon">
                  <a href="./facturatie/example.php?page=nieuwe-factuur"><i class="fas fa-file-upload"></i></i></a>
                </td>
                <td>
                  <a href="./facturatie/example.php?page=nieuwe-factuur"><b>Nieuwe factuur</b><br>
                    Maak een nieuwe factuur aan</a>
                </td>
              </tr>
            </table>
          </div>
          <div class="tablelistmiddle">
            <table style="width: 100%;">
              <tr>
                <td class="icon">
                  <a href="./facturatie/example.php?page=facturen-list"><i class="fas fa-file-invoice-dollar"></i></a>
                </td>
                <td>
                  <a href="./facturatie/example.php?page=facturen-list"><b>Lijst facturen</b><br>
                    Zoek een factuur op</a>
                </td>
              </tr>
            </table>
          </div>
          <div class="tablelistbottom">
            <table style="width: 100%;">
              <tr>
                <td class="icon">
                  <a href="#">
                    <i class="fas fa-box-open"></i>
                  </a>
                </td>
                <td>
                  <a href="#"><b>Test</b><br>
                    Test</a>
                </td>
              </tr>
            </table>
          </div>
        </div>
      <?php //////// hier stoppen alex
    } elseif ($_GET['page'] == 'homeboekhouder') { ?>
        <div class="col-xl-9 col-md-9" style="float:left;display:block;">
          <div class="tablelisttop">
            <table style="width: 100%;">
              <tr>
                <td class="icon">
                  <a href="home.php?page=boekhouder-maandelijks"><i class="fas fa-calendar-alt"></i></a>
                </td>
                <td>
                  <a href="home.php?page=boekhouder-maandelijks"><b>Maandelijkse afsluiting</b><br>
                    Verwerk de boekhoudkundige maandelijkse afsluiting</a>
                </td>
              </tr>
            </table>
          </div>
          <div class="tablelistmiddle">
            <table style="width: 100%;">
              <tr>
                <td class="icon">
                  <a href="home.php?page=online-listorders"><i class="fas fa-file-invoice-dollar"></i></a>
                </td>
                <td>
                  <a href="home.php?page=online-listorders"><b>Lijst bestellingen</b><br>
                    Zoek een bestelling op</a>
                </td>
              </tr>
            </table>
          </div>
          <div class="tablelistbottom">
            <table style="width: 100%;">
              <tr>
                <td class="icon">
                  <a href="retour.php">
                    <i class="fas fa-box-open"></i>
                  </a>
                </td>
                <td>
                  <a href="retour.php"><b>Retours</b><br>
                    Beheer en verwerk retours</a>
                </td>
              </tr>
            </table>
          </div>
        </div>
      <?php } elseif ($_GET['page'] == 'boekhouder-maandelijks') { ?>

        <div class="col-xl-9 col-md-9" style="float:left;display:block;">
          <div style="background:#ffffff;margin-bottom: 20px;border-radius: 10px; padding-bottom: 20px; padding-top: 20px;">
            <div class="field" style="display:flow-root;">
              <form action="home.php?page=boekhouder-maandelijks" method="POST">
                <div class="col-xl-10 col-md-10" style="float:left;">
                  <span style="font-size: 18px; text-align: left; font-weight: bold; color:black;"><i class="fas fa-calendar-alt"></i> <b></b>Maandelijkse afsluiting</span>
                </div>
                <div class="col-xl-2 col-md-2" style="float:left; text-align:right;">
                  <input type="submit" name="submitperiode" value="Pas periode toe">
                </div>

                <?php
                if (isset($_POST['submitperiode'])) {
                  $cur_month = $_POST['month'];
                  $cur_year = $_POST['year'];
                } else {
                  $cur_month = date('m');
                  $cur_year = date('Y');
                }
                ?>

                <div class="col-xl-4 col-md-4" style="float:left;">
                  <label for="month" style="font-size:14px;">Periode</label><br>

                  <select id="month" name="month">
                    <option value="01" <?php if ($cur_month == "01") { ?>selected<?php } ?>>Januari</option>
                    <option value="02" <?php if ($cur_month == "02") { ?>selected<?php } ?>>Februari</option>
                    <option value="03" <?php if ($cur_month == "03") { ?>selected<?php } ?>>Maart</option>
                    <option value="04" <?php if ($cur_month == "04") { ?>selected<?php } ?>>April</option>
                    <option value="05" <?php if ($cur_month == "05") { ?>selected<?php } ?>>Mei</option>
                    <option value="06" <?php if ($cur_month == "06") { ?>selected<?php } ?>>Juni</option>
                    <option value="07" <?php if ($cur_month == "07") { ?>selected<?php } ?>>Juli</option>
                    <option value="08" <?php if ($cur_month == "08") { ?>selected<?php } ?>>Augustus</option>
                    <option value="09" <?php if ($cur_month == "09") { ?>selected<?php } ?>>September</option>
                    <option value="10" <?php if ($cur_month == "10") { ?>selected<?php } ?>>Oktober</option>
                    <option value="11" <?php if ($cur_month == "11") { ?>selected<?php } ?>>November</option>
                    <option value="12" <?php if ($cur_month == "12") { ?>selected<?php } ?>>December</option>
                  </select>

                  <select id="year" name="year">
                    <option value="2020" <?php if ($cur_year == "2020") { ?>selected<?php } ?>>2020</option>
                    <option value="2021" <?php if ($cur_year == "2021") { ?>selected<?php } ?>>2021</option>
                    <option value="2022" <?php if ($cur_year == "2022") { ?>selected<?php } ?>>2022</option>
                  </select>
                </div>
                <div class="col-xl-4 col-md-4" style="float:left;">
                </div>
                <div class="col-xl-4 col-md-4" style="float:left;">
                </div>
              </form>
            </div>
          </div>

          <?php
          $countinvoicesSQL = "SELECT COUNT(*) AS qtyinvoices FROM invoice_invoices WHERE YEAR(date(invoice_date))='$cur_year' AND MONTH(date(invoice_date))='$cur_month'";
          $countinvoicesSQLresult = $belingrodb->query($countinvoicesSQL);
          while ($countinvoicesSQLrow = $countinvoicesSQLresult->fetch_assoc()) {
            $qtyinvoices = $countinvoicesSQLrow['qtyinvoices'];
          }

          $countinvoicessumexvatSQL = "SELECT SUM(invoice_totalprice_vatex) AS monthlyinvoicedtotalexvat FROM invoice_invoices WHERE YEAR(date(invoice_date))='$cur_year' AND MONTH(date(invoice_date))='$cur_month' AND invoice_soort='FA'";
          $countinvoicessumexvatSQLresult = $belingrodb->query($countinvoicessumexvatSQL);
          while ($countinvoicessumexvatSQLrow = $countinvoicessumexvatSQLresult->fetch_assoc()) {
            $monthlyinvoicedtotalexvatFA = $countinvoicessumexvatSQLrow['monthlyinvoicedtotalexvat'];
          }

          $countinvoicessumexvatCNSQL = "SELECT SUM(invoice_totalprice_vatex) AS monthlyinvoicedtotalexvatCN FROM invoice_invoices WHERE YEAR(date(invoice_date))='$cur_year' AND MONTH(date(invoice_date))='$cur_month' AND invoice_soort='CN'";
          $countinvoicessumexvatCNSQLresult = $belingrodb->query($countinvoicessumexvatCNSQL);
          while ($countinvoicessumexvatCNSQLrow = $countinvoicessumexvatCNSQLresult->fetch_assoc()) {
            $monthlyinvoicedtotalexvatCN = $countinvoicessumexvatCNSQLrow['monthlyinvoicedtotalexvatCN'];
          }

          $monthlyinvoicedtotalexvat = $monthlyinvoicedtotalexvatFA - $monthlyinvoicedtotalexvatCN;
          $monthlyinvoicedtotalexvat = number_format($monthlyinvoicedtotalexvat, 2, ',', ' ');


          $countinvoicessuminvatSQL = "SELECT SUM(invoice_totalprice_vatin) AS monthlyinvoicedtotalinvat FROM invoice_invoices WHERE YEAR(date(invoice_date))='$cur_year' AND MONTH(date(invoice_date))='$cur_month' AND invoice_soort='FA'";
          $countinvoicessuminvatSQLresult = $belingrodb->query($countinvoicessuminvatSQL);
          while ($countinvoicessuminvatSQLrow = $countinvoicessuminvatSQLresult->fetch_assoc()) {
            $monthlyinvoicedtotalinvatFA = $countinvoicessuminvatSQLrow['monthlyinvoicedtotalinvat'];
          }

          $countinvoicessuminvatCNSQL = "SELECT SUM(invoice_totalprice_vatin) AS monthlyinvoicedtotalinvatCN FROM invoice_invoices WHERE YEAR(date(invoice_date))='$cur_year' AND MONTH(date(invoice_date))='$cur_month' AND invoice_soort='CN'";
          $countinvoicessuminvatCNSQLresult = $belingrodb->query($countinvoicessuminvatCNSQL);
          while ($countinvoicessuminvatCNSQLrow = $countinvoicessuminvatCNSQLresult->fetch_assoc()) {
            $monthlyinvoicedtotalinvatCN = $countinvoicessuminvatCNSQLrow['monthlyinvoicedtotalinvatCN'];
          }
          $monthlyinvoicedtotalinvat = $monthlyinvoicedtotalinvatFA - $monthlyinvoicedtotalinvatCN;
          $monthlyinvoicedtotalinvat = number_format($monthlyinvoicedtotalinvat, 2, ',', ' ');

          $countinvoicessumvatSQL = "SELECT SUM(invoice_totalprice_vatamount) AS monthlyinvoicedtotalvat FROM invoice_invoices WHERE YEAR(date(invoice_date))='$cur_year' AND MONTH(date(invoice_date))='$cur_month' AND invoice_soort='FA'";
          $countinvoicessumvatSQLresult = $belingrodb->query($countinvoicessumvatSQL);
          while ($countinvoicessumvatSQLrow = $countinvoicessumvatSQLresult->fetch_assoc()) {
            $monthlyinvoicedtotalvatFA = $countinvoicessumvatSQLrow['monthlyinvoicedtotalvat'];
          }

          $countinvoicessumvatCNSQL = "SELECT SUM(invoice_totalprice_vatamount) AS monthlyinvoicedtotalvatCN FROM invoice_invoices WHERE YEAR(date(invoice_date))='$cur_year' AND MONTH(date(invoice_date))='$cur_month' AND invoice_soort='CN'";
          $countinvoicessumvatCNSQLresult = $belingrodb->query($countinvoicessumvatCNSQL);
          while ($countinvoicessumvatCNSQLrow = $countinvoicessumvatCNSQLresult->fetch_assoc()) {
            $monthlyinvoicedtotalvatCN = $countinvoicessumvatCNSQLrow['monthlyinvoicedtotalvatCN'];
          }

          $monthlyinvoicedtotalvat = $monthlyinvoicedtotalvatFA - $monthlyinvoicedtotalvatCN;
          $monthlyinvoicedtotalvat = number_format($monthlyinvoicedtotalvat, 2, ',', ' ');

          $countinvoicesxmlSQL = "SELECT COUNT(*) AS qtyxmlfiles FROM invoice_invoices WHERE YEAR(date(invoice_date))='$cur_year' AND MONTH(date(invoice_date))='$cur_month' AND XML_created='Y' ";
          $countinvoicesxmlSQLresult = $belingrodb->query($countinvoicesxmlSQL);
          while ($countinvoicesxmlSQLrow = $countinvoicesxmlSQLresult->fetch_assoc()) {
            $qtyxmlfiles = $countinvoicesxmlSQLrow['qtyxmlfiles'];
          }


          ?>
          <div class="tablelisttopnoborder">
          </div>
          <div class="tablecontent" style="display: flow-root;">
            <div class="col-xl-9 col-md-9" style="float:left;display: block;">
              <span style="text-align: left; font-weight: bold; color:#dd2781;"><i class="fas fa-search-dollar"></i> Overzicht <?php echo $cur_month; ?>/<?php echo $cur_year; ?></span>
            </div>
            <div class="col-xl-3 col-md-3" style="float:right;display: block;text-align:right;">
            </div>
            <?php if ($qtyinvoices >= 1) { ?>
              <div class="col-xl-12 col-md-12" style="float:left;display: block;margin-top: 20px;">
                <div class="col-xl-3 col-md-3" style="float:left;display: block;margin: unset;   padding: unset;">
                  <b>Aantal facturen</b><br>
                  <?php echo $qtyinvoices; ?> facturen
                </div>
                <div class="col-xl-3 col-md-3" style="float:left;display: block;margin: unset;   padding: unset;">
                  <b>Maandomzet <p style="font-size:10px; display: contents; margin: unset;">(ex. btw)</p></b><br>
                  € <?php echo $monthlyinvoicedtotalexvat; ?>
                </div>
                <div class="col-xl-3 col-md-3" style="float:left;display: block;margin: unset;   padding: unset;">
                  <b>Maandomzet <p style="font-size:10px; display: contents; margin: unset;">(btw incl.)</p></b><br>
                  € <?php echo $monthlyinvoicedtotalinvat; ?>
                </div>
                <div class="col-xl-3 col-md-3" style="float:left;display: block;margin: unset;   padding: unset;">
                  <b>BTW omzet <p style="font-size:10px; display: contents; margin: unset;">(btw incl.)</p></b><br>
                  € <?php echo $monthlyinvoicedtotalvat; ?>
                </div>
              </div>
              <div class="col-xl-12 col-md-12" style="float:left;display: block;margin-top: 20px;">
                <span style="text-align: left; font-weight: bold; color:#dd2781;"><i class="fas fa-book"></i> Afsluitingsprotocol</span>
              </div>
              <div class="col-xl-12 col-md-12" style="float:left;display: block;margin-top: 20px;">
                <b><?php if ($qtyxmlfiles == $qtyinvoices) { ?><i class="fas fa-check-circle" style="color:#56B26C"></i><?php } else { ?>1.<?php } ?> Creeër XML/UBL bestanden</b><br>

                <?php if ($qtyxmlfiles == 0) { ?>
                  Er zijn nog geen XML bestanden aangemaakt <br><button class="standbuttonpink" onclick="window.open('http://efact.laminaatshop.be','WebSonic', 'width=800,height=800,scrollbars=no,toolbar=no,location=no'); return false">Maak nu XML bestanden aan</button>
                <?php } elseif ($qtyxmlfiles == $qtyinvoices) { ?>
                  <b><?php echo $qtyxmlfiles; ?></b> van de <b><?php echo $qtyinvoices; ?></b> bestanden zijn aangemaakt.
                <?php } else { ?>
                  <?php echo $qtyxmlfiles; ?> van de <?php echo $qtyinvoices; ?> bestanden zijn reeds aangemaakt.
                <?php } ?>
              </div>
              <?php
              $datestring = $cur_year . "-" . $cur_month . "-01";
              $startdate = strtotime($datestring);
              $enddate = strtotime(date("Y-m-t", $startdate));
              $checkruleexistSQL = "SELECT * FROM accounting_afsluitingecomm_lijst WHERE maand='$cur_month' AND jaar='$cur_year'";
              $checkruleexistSQLresult = mysqli_query($belingrodb, $checkruleexistSQL);
              if (mysqli_num_rows($checkruleexistSQLresult) == 0) {
                $monthlydocumentexist = "N";
              } else {
                $monthlydocumentexist = "Y";
                $getpdfurlSQL = "SELECT * FROM accounting_afsluitingecomm_lijst WHERE maand='$cur_month' AND jaar='$cur_year'";
                $getpdfurlSQLresult = mysqli_query($belingrodb, $getpdfurlSQL);
                while ($getpdfurlSQLrow = mysqli_fetch_assoc($getpdfurlSQLresult)) {
                  $pdfurlmonthlydocument = $getpdfurlSQLrow['pdf_url'];
                }
              }
              ?>
              <div class="col-xl-12 col-md-12" style="float:left;display: block;margin-top: 20px;">
                <b><?php if ($monthlydocumentexist == "Y") { ?><i class="fas fa-check-circle" style="color:#56B26C"></i><?php } else { ?>2.<?php } ?> Creeër boekhoudkundig overzicht (PDF)</b><br>
                <?php if ($enddate < time()) { ?>
                  <?
                  if ($monthlydocumentexist == "N") { ?>
                    <button class="standbuttonpink" onclick="window.open('https://efact.laminaatshop.be/accounting/monthlydocuments/processdocument.php?m=<?php echo $cur_month; ?>&y=<?php echo $cur_year; ?>','Creatie maandelijkse afsluiting', 'width=900,height=500,scrollbars=no,toolbar=no,location=no'); return false">Maak nu een boekhoudkundig overzicht aan</button>
                    <?php } else { ?>Er is reeds een maandelijks overzicht aangemaakt, <a href="<?php echo $pdfurlmonthlydocument; ?>" target="_blank">bekijk het hier</a><?php } ?>
                    <?php } else { ?>U kan deze handeling pas uitvoeren als deze maand voorbij is.<?php } ?>
              </div>
            <?php } else { ?>
              <div class="col-xl-12 col-md-12" style="float:left;display: block;margin-top: 20px;">
                Sorry deze periode is niet gevonden
              </div>
            <?php } ?>
          </div>
          <div class="tablebottom">
          </div>


        </div>

      <?php } else { ?>
        <div class="col-xl-9 col-md-9" style="float:left;display:block;">
          <div class="tablelisttopnoborder">
          </div>
          <div class="tablecontent" style="display: flow-root;">
            <div class="col-xl-9 col-md-9" style="float:left;display: block;">
              <span style="font-size: 18px; text-align: left; font-weight: bold; color:black;"><i class="far fa-eye"></i> <b></b>Overzicht</span>
            </div>
            <div class="col-xl-3 col-md-3" style="float:right;display: block;text-align:right;">
            </div>
            <div class="col-xl-12 col-md-12" style="float:left;display: block;margin-top: 20px;">

            </div>
          </div>
          <div class="tablebottom">
          </div>
        </div>
      <?php } ?>
    </div>

</body>

</html>