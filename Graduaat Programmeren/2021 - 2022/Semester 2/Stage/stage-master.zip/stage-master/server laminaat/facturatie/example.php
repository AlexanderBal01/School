<?php
//include $_SERVER['DOCUMENT_ROOT'] . "/auth/main.php";
//check_loggedin($belingrodb);
error_reporting(E_ALL);
require_once $_SERVER['DOCUMENT_ROOT'] . "/vendor/autoload.php";
include_once $_SERVER['DOCUMENT_ROOT'] . "/auth/db.php";
?>
<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta name=”robots” content=”noindex,nofollow” />
  <meta name="viewport" content="width=device-width,minimum-scale=1">
  <title>Home Page</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/jq-3.3.1/dt-1.10.24/datatables.min.css" />
  <script type="text/javascript" src="https://cdn.datatables.net/v/dt/jq-3.3.1/dt-1.10.24/datatables.min.js"></script>
  <script>
    $(document).ready(function() {
      $('#listorders').DataTable({
        "order": [
          [0, "desc"]
        ],
        "searching": false,
        "lengthMenu": [
          [10, 20, 30, 50, -1],
          [10, 20, 30, 50, "All"]
        ],
        "lengthChange": false,
        "bInfo": false,
        "language": {
          "lengthMenu": "Toon _MENU_ records per pagina",
          "zeroRecords": "Geen records gevonden",
          "info": "Toon pagina _PAGE_ van _PAGES_",
          "infoEmpty": "Geen records beschikbaar",
          "infoFiltered": "(gefilterd uit _MAX_ records)",
          "paginate": {
            "first": "Eerst",
            "last": "Laatst",
            "next": "Volgende",
            "previous": "Vorige"
          },
          "search": "Zoeken:",



        }




      });
    });
    $(document).ready(function() {
      $('#searchtablenew').DataTable({
        "columnDefs": [{
          orderable: false,
          targets: [1, 2, 3, 4, 5]
        }],
        "order": [
          [0, "asc"]
        ],
        "searching": false,
        "lengthMenu": [
          [15, 30, 50, -1],
          [15, 30, 50, "All"]
        ],
        "bPaginate": false,
        "bInfo": false,
        "language": {
          "lengthMenu": "Toon _MENU_ records per pagina",
          "zeroRecords": "Geen records gevonden",
          "info": "Toon pagina _PAGE_ van _PAGES_",
          "infoEmpty": "Geen records beschikbaar",
          "infoFiltered": "(gefilterd uit _MAX_ records)",
          "paginate": {
            "first": "Eerst",
            "last": "Laatst",
            "next": "Volgende",
            "previous": "Vorige"
          },
          "search": "Zoeken:",
        }
      });
    });

    $(document).ready(function() {
      $('#neworders').DataTable({
        "columnDefs": [{
          orderable: false,
          targets: [1, 2, 3, 4, 5, 6, 7]
        }],
        "order": [
          [0, "asc"]
        ],
        "searching": false,
        "lengthMenu": [
          [15, 30, 50, -1],
          [15, 30, 50, "All"]
        ],
        "bPaginate": false,
        "bInfo": false,
        "language": {
          "lengthMenu": "Toon _MENU_ records per pagina",
          "zeroRecords": "Geen records gevonden",
          "info": "Toon pagina _PAGE_ van _PAGES_",
          "infoEmpty": "Geen records beschikbaar",
          "infoFiltered": "(gefilterd uit _MAX_ records)",
          "paginate": {
            "first": "Eerst",
            "last": "Laatst",
            "next": "Volgende",
            "previous": "Vorige"
          },
          "search": "Zoeken:",
        }
      });
    });
  </script>
</head>

<body>
  <?php
  include $_SERVER['DOCUMENT_ROOT'] . "/menu/menu.php";
  //include $_SERVER['DOCUMENT_ROOT']."/menu/submenu-ecomm-bol.php";
  ?>
  <div class="maincontent">
    <h1 class="h1maincontent">Facturatie portaal</h1><br>
    <div class="subcontent">
      <div class="col-xl-3 col-md-3" style="float:left;display:block;">
        <?php if (isset($_GET['search'])) { ?>
        <?php } else { ?>
          <div class="tablelisttopnoborder">
          </div>
          <div class="tablecontent">
            <ul class="sidenav">

              <?php if ($_GET['page'] == 'overzicht') { ?>
                <li class="side-active">
                <? } else { ?>
                <li class="side-notactive">
                <? } ?>
                <table>
                  <tr>
                    <td class="iconleftmenu">
                      <a href="../home.php"><i class="far fa-eye"></i></a>
                    </td>
                    <td><a href="../home.php"><b>Overzicht</b></a></td>
                  </tr>
                </table>
                </li>
                <?php if ($_GET['page'] == 'boekhouding') { ?>
                  <li class="side-active">
                  <? } else { ?>
                  <li class="side-notactive">
                  <? } ?>
                  <table>
                    <tr>
                      <td class="iconleftmenu">
                        <a href="../home.php?page=homeboekhouder"><i class="fas fa-calendar-alt"></i></a>
                      </td>
                      <td><a href="../home.php?page=homeboekhouder"><b>Boekhouder</b></a></td>
                  </tr>
                  </table>
                <?php if ($_GET['page'] == 'facturatie' || $_GET['page'] == 'nieuwe-factuur' || $_GET['page'] == 'facturen-list') { ?>
                  <li class="side-active">
                  <? } else { ?>
                  <li class="side-notactive">
                  <? } ?>
                  <table>
                    <tr>
                      <td class="iconleftmenu">
                        <a href="../home.php?page=facturatie"><i class="fas fa-file-alt"></i></a>
                      </td>
                      <td><a href="../home.php?page=facturatie"><b>Facturatie</b></a></td>
                  </tr>
                    <tr>
                      <td class="iconleftmenu">
                        <a href="example.php?page=nieuwe-factuur"></a>
                      </td>
                      <td style="font-size:12px; line-height: 25px;"><a href="example.php?page=nieuwe-factuur">Nieuwe factuur</a></td>
                    </tr>
                    <tr>
                      <td class="iconleftmenu">
                        <a href="example.php?page=lijst-factuur"></a>
                      </td>
                      <td style="font-size:12px; line-height: 25px;"><a href="example.php?page=lijst-factuur">Lijst facturen</a></td>
                    </tr>
                    <tr>
                      <td class="iconleftmenu">
                        <a href="#"></a>
                      </td>
                      <td style="font-size:12px; line-height: 25px;"><a href="#">Test</a></td>
                    </tr>
                  </table>
                  </li>
            </ul>
          </div>
          <div class="tablebottom">
          </div>
        <?php } ?>

        <?php if (isset($_GET['search'])) { ?>
          <div class="tablelisttopnoborder">
          <?php } else { ?>
            <div class="tablelisttopnoborder" style="margin-top:20px;">
            <?php } ?>
            </div>
            <div class="tablecontent">
              <b>Snel zoeken</b>
              <div class="field">
                <form action=""><input class="field" style="width: 100%;margin: unset;margin-top: 10px;margin-bottom: 10px;" type="text" id="search" name="search"><br>
                  <div style=" display: table-cell;  width: 75%;">
                    <input type="checkbox" id="Online" name="Online" value="Y" checked>
                    <label for="Online"> Online</label>
                    <input type="checkbox" id="Winkel" name="Winkel" value="Y">
                    <label for="Winkel"> Winkel</label>
                  </div>
                  <div style="text-align:right;display: table-cell;width: 20%;height: 50px;"><input type="submit" value="Zoek"></div>
                </form>
              </div>
            </div>
            <div class="tablebottom">
            </div>


          </div>
          <div class="col-xl-9 col-md-9" style="float:left;display:block;">

            <?php if (isset($_GET['search'])) { ?>
              <div class="tablelisttopnoborder">
              </div>
              <div class="tablecontent">
                <table id="searchtablenew" class="display" style="width:100%">
                  <thead>
                    <tr>
                      <th style="font-size:14px; text-align:center">Datum</th>
                      <th style="font-size:14px; text-align:center">Ordernummer</th>
                      <th style="font-size:14px; text-align:center">Status</th>
                      <th style="font-size:14px; text-align:center">Klantnaam</th>
                      <th style="font-size:14px; text-align:center">Locatie</th>
                      <th style="width: 1%;"></th>
                    </tr>
                  </thead>
                  <tbody>
                    <?
                    if ($_GET['Online'] == 'Y') {
                      $searchtext = $_GET['search'];
                      $searchsql = "SELECT * FROM orders_clients WHERE (`orderid` LIKE '%$searchtext%') OR (`billing_firstname` LIKE '%$searchtext%') OR (`billing_surname` LIKE '%$searchtext%') OR (`billing_city` LIKE '%$searchtext%')";
                      $searchsql_result = $belingrodb->query($searchsql);
                      while ($searchsql_row = $searchsql_result->fetch_assoc()) {

                        $search_orderid = $searchsql_row['orderid'];
                        $search_fname = $searchsql_row['billing_firstname'];
                        $search_sname = $searchsql_row['billing_surname'];
                        $search_city = $searchsql_row['billing_city'];
                        $search_name = $search_sname . ' ' . $search_fname;
                        $search_name = ucwords(strtolower($search_name));
                        $search_city = ucwords(strtolower($search_city));

                        $orderlistsql = "SELECT orderid,orderstatus,order_date_creation FROM orders_list WHERE orderid='$search_orderid'";
                        $orderlistsql_result = $belingrodb->query($orderlistsql);
                        while ($orderlistsql_row = $orderlistsql_result->fetch_assoc()) {
                          $datumordersql = $orderlistsql_row['order_date_creation'];
                          $hidden_to_order_date = date('YmdHi', strtotime($datumordersql));
                          $datumordersql = strtotime($datumordersql);
                          $datumorder = date("d/m/Y", $datumordersql);
                          $orderstatus = $orderlistsql_row['orderstatus'];
                        }

                    ?>
                        <tr style="height:30px;">
                          <td style="font-size:12px; text-align:center"><a href="orderdetail.php?orderid=<?php echo $search_orderid; ?>"><span style="display:none"><?php echo $hidden_to_order_date; ?></span><?php echo $datumorder; ?></a></td>
                          <td style="font-size:12px; text-align:center"><a href="orderdetail.php?orderid=<?php echo $search_orderid; ?>"><?php echo $search_orderid; ?></a></td>
                          <td style="font-size:12px; text-align:center"><a href="orderdetail.php?orderid=<?php echo $search_orderid; ?>"><?php echo $orderstatus; ?></a></td>
                          <td style="font-size:12px; text-align:center"><a href="orderdetail.php?orderid=<?php echo $search_orderid; ?>"><?php echo $search_name; ?></a></td>
                          <td style="font-size:12px; text-align:center"><a href="orderdetail.php?orderid=<?php echo $search_orderid; ?>"><?php echo $search_city; ?></a></td>
                          <td style="font-size:12px; text-align:center"><a href="orderdetail.php?orderid=<?php echo $search_orderid; ?>"><i class="fas fa-search"></i></a></td>
                        </tr>
                      <?
                      }
                    }
                    if ($_GET['Winkel'] == 'Y') {
                      $searchtext = $_GET['search'];
                      $searchsql2 = "SELECT * FROM `ORDER` WHERE (`ORDERNR` LIKE '%$searchtext%') OR (`NAAM` LIKE '%$searchtext%') OR (`GEMEENTE` LIKE '%$searchtext%')";
                      $searchsql2_result = $briljantdb->query($searchsql2);
                      while ($searchsql2_row = $searchsql2_result->fetch_assoc()) {

                        $search_orderid = "OR" . $searchsql2_row['ORDERNR'];
                        $search_city = $searchsql2_row['GEMEENTE'];
                        $search_name = $searchsql2_row['NAAM'];
                        $search_name = ucwords(strtolower($search_name));
                        $search_city = ucwords(strtolower($search_city));
                        $datumordersql = $searchsql2_row['DATUM'];
                        $hidden_to_order_date = date('Ymd', strtotime($datumordersql));
                        $datumorder = date("d/m/Y", strtotime($datumordersql));
                        $orderstatus = $searchsql2_row['STATUS'];

                      ?>
                        <tr style="height:30px;">
                          <td style="font-size:12px; text-align:center"><a href="orderdetail.php?orderid=<?php echo $search_orderid; ?>"><span style="display:none"><?php echo $hidden_to_order_date; ?></span><?php echo $datumorder; ?></a></td>
                          <td style="font-size:12px; text-align:center"><a href="orderdetail.php?orderid=<?php echo $search_orderid; ?>"><?php echo $search_orderid; ?></a></td>
                          <td style="font-size:12px; text-align:center"><a href="orderdetail.php?orderid=<?php echo $search_orderid; ?>"><?php echo $orderstatus; ?></a></td>
                          <td style="font-size:12px; text-align:center"><a href="orderdetail.php?orderid=<?php echo $search_orderid; ?>"><?php echo $search_name; ?></a></td>
                          <td style="font-size:12px; text-align:center"><a href="orderdetail.php?orderid=<?php echo $search_orderid; ?>"><?php echo $search_city; ?></a></td>
                          <td style="font-size:12px; text-align:center"><a href="orderdetail.php?orderid=<?php echo $search_orderid; ?>"><i class="fas fa-search"></i></a></td>
                        </tr>
                    <?
                      }
                    }
                    ?>
                  </tbody>
                </table>
              </div>
              <div class="tablebottom">
              </div>
            <?php } elseif ($_GET['page'] == 'nieuwe-factuur') { ?>
              <div class="tablelisttop">
                <table style="width: 100%;">
                  <tr>
                    <td class="icon">
                      <i class="fas fa-tasks"></i>
                    </td>
                    <td>
                      <a href="fa-beheeropleidingen.php"><b>Beheer opleidingen</b><br>
                        Beheer alle fysieke opleidingen en data</a>
                    </td>
                  </tr>
                </table>
              </div>
              <div class="tablelistmiddle">
                <table style="width: 100%;">
                  <tr>
                    <td class="icon">
                      <a href="fa-inschrijvingen.php"><i class="fas fa-user-plus"></i></a>
                    </td>
                    <td>
                      <a href="fa-inschrijvingen.php"><b>Beheer inschrijvingen</b><br>
                        Beheer alle inschrijvingen van klanten van de fysieke opleidingen</a>
                    </td>
                  </tr>
                </table>
              </div>
              <div class="tablelistbottom">
                <table style="width: 100%;">
                  <tr>
                    <td class="icon">
                      <a href="fa-klanten.php">
                        <i class="fas fa-users"></i>
                      </a>
                    </td>
                    <td>
                      <a href="fa-klanten.php"><b>Beheer klanten</b><br>
                        Beheer alle klanten die fysiek een opleiding gevolgd hebben of gaan volgen </a>
                    </td>
                  </tr>
                </table>
              </div>
            <?php } elseif ($_GET['page'] == 'online-neworders') {

              $warningduplicatecount = "SELECT orderid, COUNT(orderid) FROM orders_list GROUP BY orderid HAVING COUNT(orderid) > 1";
              $warningduplicatecountresult = $belingrodb->query($warningduplicatecount);
              if ($warningduplicatecountresult->num_rows > 0) {
                $counterrorduplicatewarning = $warningduplicatecountresult->num_rows;
                $errorduplicatewarning = "YES";
              } else {
              }

              $ordercount = "SELECT COUNT(*) AS neworderqty FROM orders_list WHERE orderstatus='PROCESSING'";
              $ordercountresult = $belingrodb->query($ordercount);
              while ($ordercountrow = $ordercountresult->fetch_assoc()) {
                $neworderqty = $ordercountrow['neworderqty'];
              }

              $waitordercount = "SELECT COUNT(*) AS waitorderqty FROM orders_list WHERE orderstatus='WAITING'";
              $waitordercount_result = $belingrodb->query($waitordercount);
              while ($waitordercount_row = $waitordercount_result->fetch_assoc()) {
                $waitorderqty = $waitordercount_row['waitorderqty'];
              }

              $orderpricecount = "SELECT SUM(totalprice_vatin) AS neworderamount FROM orders_list WHERE orderstatus='PROCESSING'";
              $orderpricecountresult = $belingrodb->query($orderpricecount);
              while ($orderpricecountrow = $orderpricecountresult->fetch_assoc()) {
                $neworderamount = $orderpricecountrow['neworderamount']; // haal de totaalprijs op 
              }
            ?>
              <?php if ($errorduplicatewarning == "YES") { ?>
                <div style="border-radius: 10px 10px 10px 10px;background: red;margin-block-end: 0px;margin-bottom: 20px;padding: 10px 20px 10px 20px;color: white;">
                  <i class="fas fa-exclamation-triangle"></i><b> Critical Error! Er zijn bestellingen die meerdere keren in de database zitten. U kan tijdelijk geen bestellingen verwerken.</b><br>
                  <p style="font-size:12px; margin:unset;">Orders die gedupliceerd zijn: 
                 <?php  while ($warningduplicatecountrow = $warningduplicatecountresult->fetch_assoc()) {
                $duplicatedorderid = $warningduplicatecountrow['orderid'];
                echo $duplicatedorderid. " - ";
                ?>

                <?
              } ?>
                  </div>
              <?php } else { ?>

              <div class="rowneworders">
                <div class="column3">
                  <div class="row">
                    <div class="leftnewordersbttn">
                      <span style="font-size: 60px; color:white;">
                        <i class="fas fa-dollar-sign"></i></span>
                    </div>
                    <div class="rightnewordersbttn">
                      <p style="font-size: 12px; color:white;margin-top: revert;margin-bottom:unset;">Bedrag van de openstaande orders<br></p>
                      <p style="font-size: 37px; color:white;margin-bottom: unset;"><b>€ <?php echo round($neworderamount, 2); ?></b></p>
                    </div>
                  </div>
                </div>
                <div class="column3space">
                </div>
                <div class="column3">
                  <a href="processorder.php">
                    <div class="row">
                      <div class="leftnewordersbttn">
                        <span style="font-size: 60px; color:white;">
                          <i class="fas fa-search-dollar"></i></span>
                      </div>
                      <div class="rightnewordersbttn">
                        <p style="font-size: 12px; color:white;margin-top: revert;margin-bottom:unset;">Openstaande orders<br></p>
                        <p style="font-size: 37px; color:white;margin-bottom: unset;"><b><?php echo $neworderqty; ?></b></p>
                      </div>
                    </div>
                  </a>
                </div>
                <div class="column3space">
                </div>
                <div class="column3">
                  <div class="row">
                    <div class="leftnewordersbttn">
                      <span style="font-size: 60px; color:white;">
                        <i class="fas fa-box-open"></i></span>
                    </div>
                    <div class="rightnewordersbttn">
                      <p style="font-size: 12px; color:white;margin-top: revert;margin-bottom:unset;">Verzonden orders vandaag<br></p>
                      <p style="font-size: 37px; color:white;margin-bottom: unset;"><b><?php echo $neworderqty; ?></b></p>
                    </div>
                  </div>
                </div>
              </div>
              <?php } ?>
              <?php if ($waitorderqty == "0") {
              } else { ?>
                <a href="example.php?page=online-waitorders">
                  <div style="border-radius: 10px 10px 10px 10px;background: #ebb434;margin-block-end: 0px;margin-bottom: 20px;padding: 10px 20px 10px 20px;color: white;">
                    <?php if ($waitorderqty == "1") { ?>
                      <i class="fas fa-pause-circle"></i><b> Er staat <?php echo $waitorderqty ?> order in wacht </b>
                    <?php } elseif ($waitorderqty > "1") { ?>
                      <i class="fas fa-pause-circle"></i><b> Er staan <?php echo $waitorderqty ?> orders in wacht </b>
                    <?php } ?>
                  </div>
                </a>
              <?php } ?>
              <div class="tablelisttopnoborder">
              </div>
              <div class="tablecontent" style="min-height: 500px;">
                <span style="font-size: 20px; text-align: left; font-weight: bold;"><b></b>Overzicht openstaande orders</span>
                <br><br>
                <table id="neworders" class="display" style="width:100%">
                  <thead>
                    <tr>
                      <th style="font-size:14px; text-align:center">Order ID</th>
                      <th style="font-size:14px; text-align:center">Order Datum </th>
                      <th style="font-size:14px; text-align:center">Klantnaam</th>
                      <th style="font-size:14px; text-align:center">Plaats</th>
                      <th style="font-size:14px; text-align:center">Land</th>
                      <th></th>
                    </tr>
                  </thead>
                  <tbody>
                    <?
                    $openorders = "SELECT * FROM orders_list WHERE orderstatus='PROCESSING'";
                    $openordersresult = $belingrodb->query($openorders);
                    while ($openordersrow = $openordersresult->fetch_assoc()) {
                      $orderid = $openordersrow['orderid'];
                      $orderdatum = DateTime::createFromFormat('Y-m-d H:i:s', $openordersrow['order_date_creation']);

                      $openordersclient = "SELECT * FROM orders_clients WHERE orderid='$orderid'";
                      $openordersclientresult = $belingrodb->query($openordersclient);
                      while ($openordersclientrow = $openordersclientresult->fetch_assoc()) {
                        $client_firstname = $openordersclientrow['billing_firstname'];
                        $client_firstname = ucwords(strtolower($client_firstname));
                        $client_surname = $openordersclientrow['billing_surname'];
                        $client_surname = ucwords(strtolower($client_surname));
                        $client_ship_zipcode = $openordersclientrow['shipment_zipcode'];
                        $client_ship_city = $openordersclientrow['shipment_city'];
                        $client_ship_country = $openordersclientrow['shipment_countrycode'];
                      }


                    ?>
                      <tr style="height:30px;">
                        <td style="font-size:12px; text-align:center"><a href="orderdetail.php?orderid=<?php echo $orderid; ?>"><?php echo $orderid; ?></a></td>
                        <td style="font-size:12px; text-align:center"><a href="orderdetail.php?orderid=<?php echo $orderid; ?>"><?php echo $orderdatum->format('d/m/Y'); ?></a></td>
                        <td style="font-size:12px; text-align:center"><a href="orderdetail.php?orderid=<?php echo $orderid; ?>"><?php echo $client_surname; ?> <?php echo $client_firstname; ?></a></td>
                        <td style="font-size:12px; text-align:center"><a href="orderdetail.php?orderid=<?php echo $orderid; ?>"><?php echo $client_ship_zipcode; ?> <?php echo $client_ship_city; ?></a></td>
                        <td style="font-size:12px; text-align:center"><a href="orderdetail.php?orderid=<?php echo $orderid; ?>"><?php echo $client_ship_country; ?></a> </td>
                        <td style="font-size:12px; text-align:center"><a style="color:#dd2781;" href="processorder.php?orderid=<?php echo $orderid; ?>">Verwerken</a></td>
                      </tr>
                    <?

                    }
                    ?>
                  </tbody>
                </table>
              </div>
              <div class="tablebottom">
              </div>

            <?php } elseif ($_GET['page'] == 'online-waitorders') {

              if (isset($_GET['orderid'])) {
                $getorderidbyurl = $_GET['orderid'];
                if ($_GET['action'] == 'activateorder') {

                  $updateorderstatus = "UPDATE orders_list SET orderstatus='PROCESSING' WHERE orderid='$getorderidbyurl' AND orderstatus='WAITING'";
                  if ($belingrodb->query($updateorderstatus) === TRUE) {
                  }
                }
              }

              $ordercount = "SELECT COUNT(*) AS neworderqty FROM orders_list WHERE orderstatus='PROCESSING'";
              $ordercountresult = $belingrodb->query($ordercount);
              while ($ordercountrow = $ordercountresult->fetch_assoc()) {
                $neworderqty = $ordercountrow['neworderqty'];
              }

              $waitordercount = "SELECT COUNT(*) AS waitorderqty FROM orders_list WHERE orderstatus='WAITING'";
              $waitordercount_result = $belingrodb->query($waitordercount);
              while ($waitordercount_row = $waitordercount_result->fetch_assoc()) {
                $waitorderqty = $waitordercount_row['waitorderqty'];
              }

              $orderpricecount = "SELECT SUM(totalprice_vatin) AS waitorderamount FROM orders_list WHERE orderstatus='WAITING'";
              $orderpricecountresult = $belingrodb->query($orderpricecount);
              while ($orderpricecountrow = $orderpricecountresult->fetch_assoc()) {
                $waitorderamount = $orderpricecountrow['waitorderamount']; // haal de totaalprijs op 
              }
            ?>

              <div class="rowneworders">
                <div class="column3" style="background: #ebb434;">
                  <div class="row">
                    <div class="leftnewordersbttn">
                      <span style="font-size: 60px; color:white;">
                        <i class="fas fa-dollar-sign"></i></span>
                    </div>
                    <div class="rightnewordersbttn">
                      <p style="font-size: 12px; color:white;margin-top: revert;margin-bottom:unset;">Bedrag van de wachtende orders<br></p>
                      <p style="font-size: 37px; color:white;margin-bottom: unset;"><b>€ <?php echo round($waitorderamount, 2); ?></b></p>
                    </div>
                  </div>
                </div>
                <div class="column3space">
                </div>
                <div class="column3" style="background: #ebb434;">
                  <div class="row">
                    <div class="leftnewordersbttn">
                      <span style="font-size: 60px; color:white;">
                        <i class="fas fa-search-dollar"></i></span>
                    </div>
                    <div class="rightnewordersbttn">
                      <p style="font-size: 12px; color:white;margin-top: revert;margin-bottom:unset;">Orders met status wacht<br></p>
                      <p style="font-size: 37px; color:white;margin-bottom: unset;"><b><?php echo $waitorderqty; ?></b></p>
                    </div>
                  </div>
                </div>
                <div class="column3space">
                </div>
                <div class="column3">
                  <a href="example.php?page=online-neworders">
                    <div class="row">
                      <div class="leftnewordersbttn">
                        <span style="font-size: 60px; color:white;">
                          <i class="fas fa-search-dollar"></i></span>
                      </div>
                      <div class="rightnewordersbttn">
                        <p style="font-size: 12px; color:white;margin-top: revert;margin-bottom:unset;">Openstaande orders<br></p>
                        <p style="font-size: 37px; color:white;margin-bottom: unset;"><b><?php echo $neworderqty; ?></b></p>
                      </div>
                    </div>
                  </a>
                </div>
              </div>
              <div class="tablelisttopnoborder">
              </div>
              <div class="tablecontent" style="min-height: 500px;">
                <span style="font-size: 20px; text-align: left; font-weight: bold;"><b></b>Overzicht orders met status wacht</span>
                <br><br>
                <table id="neworders" class="display" style="width:100%">
                  <thead>
                    <tr>
                      <th style="font-size:14px; text-align:center">Order ID</th>
                      <th style="font-size:14px; text-align:center">Order Datum </th>
                      <th style="font-size:14px; text-align:center">Klantnaam</th>
                      <th style="font-size:14px; text-align:center">Plaats</th>
                      <th style="font-size:14px; text-align:center">Land</th>
                      <th></th>
                    </tr>
                  </thead>
                  <tbody>
                    <?
                    $openorders = "SELECT * FROM orders_list WHERE orderstatus='WAITING'";
                    $openordersresult = $belingrodb->query($openorders);
                    while ($openordersrow = $openordersresult->fetch_assoc()) {
                      $orderid = $openordersrow['orderid'];
                      $orderdatum = DateTime::createFromFormat('Y-m-d H:i:s', $openordersrow['order_date_creation']);

                      $openordersclient = "SELECT * FROM orders_clients WHERE orderid='$orderid'";
                      $openordersclientresult = $belingrodb->query($openordersclient);
                      while ($openordersclientrow = $openordersclientresult->fetch_assoc()) {
                        $client_firstname = $openordersclientrow['billing_firstname'];
                        $client_firstname = ucwords(strtolower($client_firstname));
                        $client_surname = $openordersclientrow['billing_surname'];
                        $client_surname = ucwords(strtolower($client_surname));
                        $client_ship_zipcode = $openordersclientrow['shipment_zipcode'];
                        $client_ship_city = $openordersclientrow['shipment_city'];
                        $client_ship_country = $openordersclientrow['shipment_countrycode'];


                    ?>
                        <tr style="height:30px;">
                          <td style="font-size:12px; text-align:center"><a href="orderdetail.php?orderid=<?php echo $orderid; ?>"><?php echo $orderid; ?></a></td>
                          <td style="font-size:12px; text-align:center"><a href="orderdetail.php?orderid=<?php echo $orderid; ?>"><?php echo $orderdatum->format('d/m/Y'); ?></a></td>
                          <td style="font-size:12px; text-align:center"><a href="orderdetail.php?orderid=<?php echo $orderid; ?>"><?php echo $client_surname; ?> <?php echo $client_firstname; ?></a></td>
                          <td style="font-size:12px; text-align:center"><a href="orderdetail.php?orderid=<?php echo $orderid; ?>"><?php echo $client_ship_zipcode; ?> <?php echo $client_ship_city; ?></a></td>
                          <td style="font-size:12px; text-align:center"><a href="orderdetail.php?orderid=<?php echo $orderid; ?>"><?php echo $client_ship_country; ?></a> </td>
                          <td style="font-size:12px; text-align:center"><button class="standbuttonpink" onclick="window.location.href='example.php?page=online-waitorders&action=activateorder&orderid=<?php echo $orderid; ?>'">Activeer order</button></td>
                        </tr>
                    <?
                      }
                    }
                    ?>
                  </tbody>
                </table>
              </div>
              <div class="tablebottom">
              </div>

            <?php } elseif ($_GET['page'] == 'online-listorders') { ?>

              <div style="background:#ffffff;margin-bottom: 20px;border-radius: 10px; padding-bottom: 20px; padding-top: 20px;">
                <div class="field" style="display:flow-root;">
                  <form action="">
                    <div class="col-xl-10 col-md-10" style="float:left;">
                      <span style="font-size: 15px; text-align: left; font-weight: bold; color:black;"><i class="fas fa-filter"></i> <b></b>Filter</span>
                    </div>
                    <div class="col-xl-2 col-md-2" style="float:left; text-align:right;">
                      <input type="submit" name="submitnewmemo" value="Pas filter toe">
                    </div>

                    <div class="col-xl-4 col-md-4" style="float:left;">
                      <label for="searchtime" style="font-size:14px;">Periode</label><br>
                      <select id="searchtime" name="searchtime">
                        <option value="30d">Laatste 30 dagen</option>
                        <option value="3m">Laatste 3 maanden</option>
                        <option value="6m">Laatste 6 maanden</option>
                        <option value="12m">Laatste 12 maanden</option>
                        <option value="all">Alles</option>
                      </select>
                    </div>
                    <div class="col-xl-4 col-md-4" style="float:left;">
                      <label for="searchstatus" style="font-size:14px;">Status</label><br>
                      <select id="searchstatus" name="searchstatus">
                        <option value="all">Alles</option>
                        <option value="processing">Te verwerken</option>
                        <option value="complete">Afgewerkt</option>
                        <option value="cancelled">Geannulleerd</option>
                        <option value="readycollection">Klaar voor afhaling</option>

                      </select>
                    </div>
                    <input type="hidden" name="page" value="online-listorders">
                    <div class="col-xl-4 col-md-4" style="float:left;">
                      <label for="searchtext" style="font-size:14px;">Zoeken</label><br>
                      <input class="field" type="text" id="searchtext" name="searchtext">
                    </div>
                  </form>
                </div>
              </div>


              <div class="tablelisttopnoborder">
              </div>
              <div class="tablecontent" style="">
                <span style="font-size: 20px; text-align: left; font-weight: bold;"><b></b>Lijst orders</span>

                <table id="listorders" class="display" style="width:100%">
                  <thead>
                    <tr>
                      <th style="font-size:14px; text-align:center">Status</th>
                      <th style="font-size:14px; text-align:center">Datum</th>
                      <th style="font-size:14px; text-align:center">Order ID (BOL)</th>
                      <th style="font-size:14px; text-align:center">Klantnaam</th>
                      <th style="font-size:14px; text-align:center">Plaats</th>
                      <th></th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php


                    if (isset($_GET['searchtime'])) {
                      if ($_GET['searchtime'] == '30d') {
                        $searchtime = "order_date_creation BETWEEN DATE_SUB(NOW(), INTERVAL 30 DAY) AND NOW()";
                      } elseif ($_GET['searchtime'] == '3m') {
                        $searchtime = "order_date_creation BETWEEN DATE_SUB(NOW(), INTERVAL 3 MONTH) AND NOW()";
                      } elseif ($_GET['searchtime'] == '6m') {
                        $searchtime = "order_date_creation BETWEEN DATE_SUB(NOW(), INTERVAL 6 MONTH) AND NOW()";
                      } elseif ($_GET['searchtime'] == '12m') {
                        $searchtime = "WHERE order_date_creation BETWEEN DATE_SUB(NOW(), INTERVAL 12 MONTH) AND NOW()";
                      } elseif ($_GET['searchtime'] == 'all') {
                        $searchtime = "";
                      }
                    }

                    if (isset($_GET['searchstatus'])) {
                      if ($_GET['searchstatus'] == 'processing') {
                        $searchstatus = "orderstatus = 'PROCESSING'";
                      } elseif ($_GET['searchstatus'] == 'cancelled') {
                        $searchstatus = "orderstatus = 'CANCELLED'";
                      } elseif ($_GET['searchstatus'] == 'complete') {
                        $searchstatus = "orderstatus = 'COMPLETE'";
                      } elseif ($_GET['searchstatus'] == 'readycollection') {
                        $searchstatus = "orderstatus = 'READY_COLLECTION'";
                      } elseif ($_GET['searchstatus'] == 'all') {
                        $searchstatus = "";
                      }
                    }

                    $searchtext = $_GET['searchtext'];

                    if (empty($searchstatus) && !empty($searchtime) && empty($searchtext)) {
                      $orderlist = "SELECT orderid,orderstatus,order_date_creation FROM orders_list WHERE " . $searchtime . "";
                    } elseif (empty($searchstatus) && !empty($searchtime) && !empty($searchtext)) {
                      $orderlist = "SELECT orderid,orderstatus,order_date_creation FROM orders_list WHERE " . $searchtime . " AND (orderid LIKE '%" . $searchtext . "%')";
                    } elseif (!empty($searchstatus) && empty($searchtime) && empty($searchtext)) {
                      $orderlist = "SELECT orderid,orderstatus,order_date_creation FROM orders_list WHERE " . $searchstatus . "";
                    } elseif (!empty($searchstatus) && empty($searchtime) && !empty($searchtext)) {
                      $orderlist = "SELECT orderid,orderstatus,order_date_creation FROM orders_list WHERE " . $searchstatus . " AND (orderid LIKE '%" . $searchtext . "%')";
                    } elseif (empty($searchstatus) && empty($searchtime) && !empty($searchtext)) {
                      $orderlist = "SELECT orderid,orderstatus,order_date_creation FROM orders_list WHERE (orderid LIKE '%" . $searchtext . "%')";
                    } elseif (!empty($searchstatus) && !empty($searchtime) && empty($searchtext)) {
                      $orderlist = "SELECT orderid,orderstatus,order_date_creation FROM orders_list WHERE " . $searchstatus . " AND " . $searchtime . "";
                    } elseif (!empty($searchstatus) && !empty($searchtime) && !empty($searchtext)) {
                      $orderlist = "SELECT orderid,orderstatus,order_date_creation FROM orders_list WHERE " . $searchstatus . " AND " . $searchtime . " AND (orderid LIKE '%" . $searchtext . "%')";
                    } else {
                      $orderlist = "SELECT orderid,orderstatus,order_date_creation FROM orders_list WHERE order_date_creation BETWEEN DATE_SUB(NOW(), INTERVAL 30 DAY) AND NOW()";
                    }

                    $orderlistresult = $belingrodb->query($orderlist);
                    if ($orderlistresult->num_rows > 0) {
                      while ($orderlistrow = $orderlistresult->fetch_assoc()) {
                        $orderid = $orderlistrow['orderid'];
                        $orderstatus = $orderlistrow['orderstatus'];
                        $datumordersql = $orderlistrow['order_date_creation'];
                        $hidden_to_order_date = date('YmdHi', strtotime($datumordersql));
                        $datumordersql = strtotime($datumordersql);
                        $datumorder = date("d/m/y", $datumordersql);
                        $orderstatus = $orderlistrow['orderstatus'];


                        $orderclient = "SELECT billing_surname,billing_firstname,billing_countrycode,billing_city,billing_zipcode FROM orders_clients WHERE orderid='$orderid'";
                        $orderclientresult = $belingrodb->query($orderclient);
                        if ($orderclientresult->num_rows > 0) {
                          while ($orderclientrow = $orderclientresult->fetch_assoc()) {
                            $naam = $orderclientrow['billing_surname'];
                            $voornaam = $orderclientrow['billing_firstname'];
                            $naamcompleet = $naam . ' ' . $voornaam;
                            $naamcompleet = ucwords($naamcompleet);
                            $country = $orderclientrow['billing_countrycode'];
                            $city = $orderclientrow['billing_city'];
                            $city = strtoupper($city);
                            $zipcode =  $orderclientrow['billing_zipcode'];
                          }
                        }
                    ?>
                        <tr>
                          <td>
                            <?php
                            if ($orderstatus == 'PROCESSING') {
                            ?>
                              <button class="buttonopenorder" style="font-family: 'Poppins', sans-serif; background-color: #ff8800; border: none; outline: none; cursor: pointer; padding: 3px 3px; transition: 0.3s; font-size: 12px; color: white; float: center;" onClick="">&nbsp;&nbsp;<i class="fas fa-lock-open"></i>&nbsp;Te verwerken&nbsp;&nbsp;</button>
                            <?php
                            } elseif ($orderstatus == 'COMPLETE') {
                            ?>
                              <button class="buttonopenorder" style="font-family: 'Poppins', sans-serif; background-color: #2bca50; border: none; outline: none; cursor: pointer; padding: 3px 3px; transition: 0.3s; font-size: 12px; color: white; float: center;" onClick="">&nbsp;&nbsp;<i class="fas fa-check-circle"></i>&nbsp;Afgewerkt&nbsp;&nbsp;</button>
                            <?php
                            } elseif ($orderstatus == 'canceled' || $orderstatus == 'CANCELLED' || $orderstatus == 'closed' || $orderstatus == 'holded') {
                            ?>
                              <button class="buttonopenorder" style="font-family: 'Poppins', sans-serif; background-color: #ff0800; border: none; outline: none; cursor: pointer; padding: 3px 3px; transition: 0.3s; font-size: 12px; color: white; float: center;" onClick="">&nbsp;&nbsp;<i class="fas fa-check-circle"></i>&nbsp;Geannuleerd&nbsp;&nbsp;</button>
                            <?php
                            } elseif ($orderstatus == 'READY_COLLECTION') {
                            ?>
                              <button class="buttonopenorder" style="font-family: 'Poppins', sans-serif; background-color: #c9cc02; border: none; outline: none; cursor: pointer; padding: 3px 3px; transition: 0.3s; font-size: 12px; color: white; float: center;" onClick="">&nbsp;&nbsp;<i class="fas fa-user-clock"></i>&nbsp;Klaar voor afhaling&nbsp;&nbsp;</button>
                            <?php
                            }
                            ?>
                          </td>
                          <td style="font-size:12px; text-align:center"><a href="orderdetail.php?orderid=<?php echo $search_orderid; ?>"><span style="display:none"><?php echo $hidden_to_order_date; ?></span><?php echo $datumorder; ?></a></td>

                          <td style="font-size:12px; text-align:center"><?php echo $orderid; ?></td>
                          <td style="font-size:12px; text-align:center"><?php echo $naamcompleet; ?></td>
                          <td style="font-size:12px; text-align:center">
                            <?php if ($country == 'BE') {
                              $client_country_img = 'https://efact.laminaatshop.be/img/be.svg';
                            } elseif ($country == 'NL') {
                              $client_country_img = 'https://efact.laminaatshop.be/img/nl.svg';
                            }
                            ?>
                            <img src="<?php echo $client_country_img; ?>" alt="Country" style="display:inline; max-height: 10px; width: 10px;"> <?php echo $zipcode; ?> <?php echo $city; ?>
                          </td>
                          <td style="font-size:12px; text-align:center">
                            <a href="orderdetail.php?orderid=<?php echo $orderid; ?>"> Bekijk order <i class="fa fa-search-plus">
                        </tr>
                    <?php

                      }
                    }
                    ?>
                  </tbody>
                </table>



              </div>
              <div class="tablebottom">
              </div>


            <?php } elseif ($_GET['page'] == 'online-retours') { ?>

              <div style="background:#ffffff;margin-bottom: 20px;border-radius: 10px; padding-bottom: 20px; padding-top: 20px; display: grid;">
                <div class="col-xl-12 col-md-12" style="float:left;">
                  <span style="font-size: 15px; text-align: left; font-weight: bold; color:black;"><i class="fas fa-cogs"></i> <b></b>Verwerk nieuwe retour</span>
                </div>

                <div class="col-xl-12 col-md-12" style="float:left;     margin-top: 20px;">
                  <div class="field" style="display:flow-root;">
                    <form action="retour.php">
                      <input type="hidden" name="page" value="online-retours">
                      <div class="col-xl-4 col-md-4" style="float:left;">
                        <label for="searchtext" style="font-size:14px;">Retour ID</label>
                        <input class="field" type="text" id="retourid" name="retourid">
                      </div>
                      <div class="col-xl-12 col-md-12" style="float:left;"><br>
                        <input type="submit" value="Retour verwerken">
                      </div>
                    </form>
                  </div>
                </div>








              </div>

              <div class="tablelisttopnoborder">
              </div>
              <div class="tablecontent">
              </div>
              <div class="tablebottom">
              </div>
            <? } else { ?>
              <div class="tablelisttop">
                <table style="width: 100%;">
                  <tr>
                    <td class="icon">
                      <a href="example.php?page=nieuwe-factuur"><i class="fas fa-file-upload"></i></a>
                    </td>
                    <td>
                      <a href="example.php?page=nieuwe-factuur"><b>Nieuwe factuur</b><br>
                        Maak een nieuwe factuur aan</a>
                    </td>
                  </tr>
                </table>
              </div>
              <div class="tablelistmiddle">
                <table style="width: 100%;">
                  <tr>
                    <td class="icon">
                      <a href="example.php?page=facturen-list"><i class="fas fa-file-invoice-dollar"></i></a>
                    </td>
                    <td>
                      <a href="example.php?page=facturen-list"><b>Lijst facturen</b><br>
                        Zoek een factuur op</a>
                    </td>
                  </tr>
                </table>
              </div>
              <div class="tablelistbottom">
                <table style="width: 100%;">
                  <tr>
                    <td class="icon">
                      <a href="#">
                        <i class="fas fa-box-open"></i>
                      </a>
                    </td>
                    <td>
                      <a href="#"><b>Test</b><br>
                        Test</a>
                    </td>
                  </tr>
                </table>
              </div>
            <? } ?>




          </div>
      </div>
      <?php //<iframe id="synchroniseer" style='display:none;' src='https://efact.laminaatshop.be/sales/ecomm/bol/bolapi/cronbolapiorders.php'></iframe>
      //<iframe id="synchroniseer2" style='display:none;' src='https://efact.laminaatshop.be/sales/ecomm/bol/magapi/cronmagentoapi.php'></iframe> 
      ?>

</body>

</html>