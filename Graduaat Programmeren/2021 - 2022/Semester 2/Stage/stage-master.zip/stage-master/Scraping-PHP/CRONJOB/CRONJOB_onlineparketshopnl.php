<?php
    include_once "../../../auth/db.php";
?>

<?php
    $prijsarray = array();
    $prijsarraytussendb = array();
    $prijsarraydb = "";
    $minprijs;
    $maxprijs;

    // example of how to use advanced selector features
    include('../simple_html_dom.php');

    $selectScraper_Cronjobs_FrequencyOnWebsite = "SELECT Frequency, Last_Checked FROM Scraper_Cronjobs WHERE Website='onlineparketshopnl'";
    $resultsScraper_Cronjobs_FrequencyOnWebsite = $efactsandboxdb->query($selectScraper_Cronjobs_FrequencyOnWebsite);
    if ($resultsScraper_Cronjobs_FrequencyOnWebsite->num_rows > 0) {
        while ($rowScraper_Cronjobs_FrequencyOnWebsite = $resultsScraper_Cronjobs_FrequencyOnWebsite->fetch_assoc()) {
            $frequency = mysqli_real_escape_string($efactsandboxdb, $rowScraper_Cronjobs_FrequencyOnWebsite['Frequency']);
            $last_checked = mysqli_real_escape_string($efactsandboxdb, $rowScraper_Cronjobs_FrequencyOnWebsite['Last_Checked']);

            $selectScraper_Cronjobs = "SELECT * FROM Scraper_Cronjobs WHERE Website='onlineparketshopnl' AND Frequency='$frequency' AND DATE_ADD('$last_checked', INTERVAL $frequency DAY)=CURRENT_DATE()";
            $resultsScraper_Cronjobs = $efactsandboxdb->query($selectScraper_Cronjobs);
            if ($resultsScraper_Cronjobs->num_rows > 0) {
                while ($rowScraper_Cronjobs = $resultsScraper_Cronjobs->fetch_assoc()) {
                    $id = mysqli_real_escape_string($efactsandboxdb, $rowScraper_Cronjobs['Id']);
                    $website = mysqli_real_escape_string($efactsandboxdb, $rowScraper_Cronjobs['Website']);
                    $brand = mysqli_real_escape_string($efactsandboxdb, $rowScraper_Cronjobs['Brand']);
                    $collection = mysqli_real_escape_string($efactsandboxdb, $rowScraper_Cronjobs['Collection']);
                    $url = mysqli_real_escape_string($efactsandboxdb, $rowScraper_Cronjobs['Url']);
                    $Scraper_Url = mysqli_real_escape_string($efactsandboxdb, $rowScraper_Cronjobs['Scraper_Url']);
                    
                    if (!empty($url)) {
                        $html = file_get_html($url);
                        foreach($html->find('div[class=priceBlock]') as $div) {
                            foreach($div->find('span[class=price]') as $span) {
                                $spanresult = $span->innertext;
                                $spangetallen = (int)filter_var($spanresult, FILTER_SANITIZE_NUMBER_INT);
                                $spandefinitief = (double)$spangetallen/100;
                                array_push($prijsarray, $spandefinitief);
                            }
                        }
                        $minprijs = min($prijsarray);
                        $maxprijs = max($prijsarray);

                        $prijsarraytussendb = array_unique($prijsarray);
                        foreach($prijsarraytussendb as $prijs) {
                            $prijsarraydb = $prijsarraydb.$prijs.";";
                        }

                        $insertIntoScraper_Results = "INSERT INTO Scraper_Results (Website, url,  Brand, Collection, Datum_Tijd, Min_Prijs, Max_prijs, 
                        Array_Prijs, screenshot) VALUES ('$website', '$url', '$brand', '$collection', current_timestamp(), $minprijs, $maxprijs, '$prijsarraydb', '')";
                        if ($efactsandboxdb->query($insertIntoScraper_Results) === TRUE) {
                            $updateLast_Checked = "UPDATE Scraper_Cronjobs SET Last_Checked=CURDATE()";
                            if ($efactsandboxdb->query($updateLast_Checked) === TRUE) {
                            } else {
                                echo 'update mislukt';
                            }
                        } else {
                            echo 'insert mislukt';
                        }
                    }
                }
            }
        }
    } else {
        echo 'mislukt';
    }
?>