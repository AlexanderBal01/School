<?php
// example of how to use advanced selector features
include('../simple_html_dom.php');


$str = 'https://www.onlineparketshop.nl/laminaat/quickstep/signature/';
$html = file_get_html($str);
foreach($html->find('div[class=priceBlock]') as $div) {
    foreach($div->find('span[class=price]') as $span) 
        echo $span->innertext . '<br>';
  
}



?>