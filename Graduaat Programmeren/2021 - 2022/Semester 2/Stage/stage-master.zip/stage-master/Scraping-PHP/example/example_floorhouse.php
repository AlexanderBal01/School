<?php
// example of how to use advanced selector features
include('../simple_html_dom.php');

$html = file_get_html('https://www.floorhouse.be/laminaat/berry-alloc-laminaat/berryalloc-smart-7-spirit-bruin-62001117-berr11013');
echo $html->find('div[class=control control-price prices-action-price] div[class=field] div[class=prices-action] div span[class=prices] span[class=lbl-price]', 0)->innertext . '<br>';
echo $html->find('div[class=control control-price control-floorhouse] div[class=field] div[class=prices-action] div span[class=prices] span[class=lbl-price]', 0)->innertext . '<br>';


?>