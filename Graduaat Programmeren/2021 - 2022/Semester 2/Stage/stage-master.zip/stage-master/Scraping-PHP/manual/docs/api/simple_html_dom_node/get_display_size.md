# get_display_size

```php
get_display_size ( ) : mixed
```

Returns false if the current node is not an image.

Returns an associative array of two elements - `height` and `width` - that represent the display size of the image.