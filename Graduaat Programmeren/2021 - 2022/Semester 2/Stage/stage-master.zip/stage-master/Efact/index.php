<!DOCTYPE html>
<html>

<head>
    <title>E-Fact - Laminaatshop</title>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css" integrity="sha384-zCbKRCUGaJDkqS1kPbPd7TveP5iyJE0EjAuZQTgFLD2ylzuqKfdKlfG/eSrtxUkn" crossorigin="anonymous">
    <link rel="stylesheet" href="./Source/CSS/index.css" type="text/css">
    <link rel="stylesheet" href="./Source/CSS/Artikel.css" type="text/css">
    <link rel="stylesheet" href="./Source/CSS/Totaalprijs.css" type="text/css">
</head>

<body>
    <div class="klantDiv">
        <div class="container">
            <div class="row">
                <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 d-flex justify-content-center">
                </div>
                <div class="col-lg-6 col-md-6 col-sm-12 zoeken">
                    <!-- onsubmit moet false zijn ander herlaad hij de pagina -->
                    <form class="klantnummerform d-flex justify-content-start" action="" onsubmit="return false">
                    <!--  -->
                        <label class="input-margin-right"><strong>Klant: </strong></label>
                        <!-- Gekozen voor onkeyup event omdat vanaf er een resultaat is deze wordt ingeladen -->
                        <input class="input-margin-right input-margin-left" type="text" placeholder="Klantnummer" id="InputKlant_Klantnummer" name="InputKlant_Klantnummer" maxlength="5" onkeyup="ShowCustomerOnCustomerid(this.value)" />
                        <!--  -->

                        <!-- knop voor het openen van de zoekklantmodal -->
                        <a data-toggle="modal" href="#zoekKlantModal" class="zoekvensteropenen input-margin-left">Zoeken</a>
                        <!--  -->
                    </form>

                </div>
            </div>
        </div>

        <!-- hier wordt de klant informatie ingeladen -->
        <div id="selectedKlantItem">
            <div class="container">
                <div class="row">
                    <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 d-flex justify-content-center">
                    </div>
                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 d-flex justify-content-center">
                        <!-- onsubmit moet false zijn ander herlaad hij de pagina -->
                        <form class="w-100" action="" onsubmit="return false">
                        <!--  -->

                            <!-- Moet disabled zijn anders kunnen ze de klant informatie wijzigen -->
                            <input type="text" class="w-100" id="Klantnaamselected" name="naam" disabled>
                            <!--  -->
                        </form>
                    </div>
                </div>
                <div class="row">
                    <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 d-flex justify-content-center">
                    </div>
                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 d-flex justify-content-center">
                        <!-- onsubmit moet false zijn ander herlaad hij de pagina -->
                        <form class="w-100" action="" onsubmit="return false">
                        <!--  -->

                            <!-- Moet disabled zijn anders kunnen ze de klant informatie wijzigen -->
                            <input type="text" class="w-100" id="Klantadresselected" name="adres" disabled>
                            <!--  -->
                        </form>
                    </div>
                </div>
                <div class="row">
                    <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 d-flex justify-content-center">
                    </div>
                    <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 d-flex justify-content-center">
                        <!-- onsubmit moet false zijn ander herlaad hij de pagina -->
                        <form class="w-100" action="" onsubmit="return false">
                        <!--  -->

                            <!-- Moet disabled zijn anders kunnen ze de klant informatie wijzigen -->
                            <input type="text" class="w-100" id="Klanttelefoonnrselected" name="telefoonnr" disabled>
                            <!--  -->
                        </form>
                    </div>
                    <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 d-flex justify-content-center">
                        <!-- onsubmit moet false zijn ander herlaad hij de pagina -->
                        <form class="w-100" action="" onsubmit="return false">
                        <!--  -->

                            <!-- Moet disabled zijn anders kunnen ze de klant informatie wijzigen -->
                            <input type="text" class="w-100" id="Klantbtwnummerselected" name="btwnummer" disabled>
                            <!--  -->
                        </form>
                    </div>
                </div>
                <div class="row">
                    <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 d-flex justify-content-center">
                    </div>
                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 d-flex justify-content-center">
                        <!-- onsubmit moet false zijn ander herlaad hij de pagina -->
                        <form class="w-100" action="" onsubmit="return false">
                        <!--  -->

                            <!-- Moet disabled zijn anders kunnen ze de klant informatie wijzigen -->
                            <input type="text" class="w-100" id="Klantemailselected" name="email" disabled>
                            <!--  -->
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!--  -->
    </div>


    <div class="artikelDiv">
        <div class="container">
            <div class="row">
                <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 d-flex justify-content-center">
                </div>
                <div class="col-lg-6 col-md-6 col-sm-12 zoeken">
                    <!-- onsubmit moet false zijn ander herlaad hij de pagina -->
                    <form class="d-flex justify-content-start" id="Artikelnummerform" action="" onsubmit="return false">
                    <!--  -->
                        <label class="input-margin-right"><strong>Artikelnummer: </strong></label>

                        <!-- Onkeydown event gespecifeerd omdat anders de functie niet wou zoeken -->
                        <input class="input-margin-right input-margin-left" type="text" placeholder="Artikelnummer" id="InputArtikelnummer" name="InputArtikelnummer" onkeydown="" />
                        <!--  -->

                        <!-- knop voor het openen van de zoekartikelmodal -->
                        <a data-toggle="modal" href="#zoekArtikelModal" id="ArtikelZoeken" class="zoekvensteropenen input-margin-left">Zoeken</a>
                        <!--  -->
                    </form>

                </div>
            </div>
        </div>

        <div class="container">
            <div class="d-flex justify-content-center">
                <!-- Knop voor het deleten van een rij uit de tabel als deze geselecteerd is via de checkbox -->
                <input type="button" value="Delete Row" onclick="DeleteRow('artikelsTabel')" />
                <!--  -->
            </div>
            <div class="d-flex justify-content-center">
                <table id="artikelsTabel">
                    <tr>
                        <th></th>
                        <th>Artikel</th>
                        <th>Omschrijving</th>
                        <th>Aantal</th>
                        <th>Std Prijs</th>
                        <th>korting</th>
                        <th>Eenheidsprijs</th>
                        <th>Eenheid</th>
                        <th>BTW code</th>
                        <th>BTW %</th>
                        <th>Totaal ex. BTW</th>
                        <th>Totaal incl. BTW</th>
                        <th>Stocks</th>
                    </tr>
                    <tr>
                        <td><input type="checkbox" name="chkbox[]"></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                </table>
            </div>
        </div>

        <!-- hier worden de data ingeladen om dan doortesturen naar de tabel, Deze div is niet zichtbaar op het scherm -->
        <div id="VerborgenGevondenArtikelen">

        </div>
        <!--  -->
    </div>

    <div class="totaalPrijsDiv">
        <div class="container">
            <div class="d-flex justify-content-center">
                <table class="totaal-border">
                    <tr class="totaal">
                        <th class="totaal"></th>
                        <th class="totaal">Excl.</th>
                        <th class="totaal">BTW</th>
                        <th class="totaal">Te Betalen</th>
                        <th class="totaal"></th>
                    </tr>
                    <tr class="totaal">
                        <th class="totaal">Totalen EUR</th>
                        <!-- Deze zijn disabled zodat je de berekende eindprijzen niet kan bewerken -->
                        <th class="totaal"><input type="number" id="totaalExclBTW" value="0" step=".01" disabled/></th>
                        <th class="totaal"><input type="number" id="totaalBTW" value="0" step=".01" disabled/></th>
                        <th class="totaal"><input type="number" id="totaalTeBetalen" value="0" step=".01" disabled/></th>
                        <th class="totaal"></th>
                        <!--  -->
                    </tr>
                </table>
            </div>
        </div>
    </div>

        <div class="modal fade" id="zoekKlantModal" tabindex="-1" aria-labelledby="zoekKlantModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-scrollable modal-xl">
                <div class="modal-content">
                    <div class="modal-header">
                        <div class="tab">
                            <button class="tablinks active" onclick="OpenModalMenuItemKlant(event, 'KlantNaam')">Naam</button>
                            <button class="tablinks" onclick="OpenModalMenuItemKlant(event, 'KlantAdres')">Adres</button>
                            <button class="tablinks" onclick="OpenModalMenuItemKlant(event, 'KlantTelefoonnummer')">Telefoonnummer</button>
                            <button class="tablinks" onclick="OpenModalMenuItemKlant(event, 'KlantEmail')">Email</button>
                            <button class="tablinks" onclick="OpenModalMenuItemKlant(event, 'KlantBTW_nummer')">BTW nummer</button>
                        </div>
                    </div>
                    <div class="modal-body">
                        <div id="KlantNaam" class="tabcontent active" style="display: block;">
                            <h3>Zoeken op naam</h3>
                            <form action="" onsubmit="return false">
                                <input type="text" placeholder="Naam" id="InputKlantNaam" name="InputNaam" onkeyup="ShowCustomerOnNaam(this.value)" />
                            </form>
                            <div id="geavanceerdSelectedKlantItemNaam">
                            </div>
                        </div>

                        <div id="KlantAdres" class="tabcontent">
                            <h3>Zoeken op adres</h3>
                            <form action="" onsubmit="return false">
                                <input type="text" placeholder="Adres" id="InputKlantStraat" name="InputStraat" onkeyup="AddStraatToAdres(this.value), ShowCustomerOnAdres()" />
                                <input type="text" placeholder="Postcode" id="InputKlantPostcode" name="InputPostcode" onkeyup="AddPostcodeToAdres(this.value), ShowCustomerOnAdres()" />
                                <input type="text" placeholder="Gemeente" id="InputKlantGemeente" name="InputGemeente" onkeyup="AddGemeenteToAdres(this.value), ShowCustomerOnAdres()" />
                            </form>
                            <div id="geavanceerdSelectedKlantItemAdres">
                            </div>
                        </div>

                        <div id="KlantTelefoonnummer" class="tabcontent">
                            <h3>Zoeken op telefoonnummer</h3>
                            <form action="" onsubmit="return false">
                                <input type="text" placeholder="telefoonnummer" id="InputKlanttelefoonnummer" name="Inputtelefoonnummer" onkeyup="ShowCustomerOnTelefoonnummer(this.value)" />
                            </form>
                            <div id="geavanceerdSelectedKlantItemTelefoon">
                            </div>
                        </div>

                        <div id="KlantEmail" class="tabcontent">
                            <h3>Zoeken op email</h3>
                            <form action="" onsubmit="return false">
                                <input type="text" placeholder="email" id="InputKlantemail" name="Inputemail" onkeyup="ShowCustomerOnEmail(this.value)" />
                            </form>
                            <div id="geavanceerdSelectedKlantItemEmail">
                            </div>
                        </div>

                        <div id="KlantBTW_nummer" class="tabcontent">
                            <h3>Zoeken op BTW nummer</h3>
                            <form action="" onsubmit="return false">
                                <input type="text" placeholder="BTW nummer" id="InputKlantBTW_nummer" name="InputBTW_nummer" value="BE" onkeyup="ShowCustomerOnBTWnummer(this.value)" />
                            </form>
                            <div id="geavanceerdSelectedKlantItemBTW">
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade" id="zoekArtikelModal" tabindex="-1" aria-labelledby="zoekArtikelModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-scrollable modal-xl">
                <div class="modal-content">
                    <div class="modal-header">
                        <div class="tab">
                            <button class="tablinks active" onclick="OpenModalMenuItemArtikel(event, 'Artikelnummer')">Artikelnummer</button>
                            <button class="tablinks" onclick="OpenModalMenuItemArtikel(event, 'ArtikelNaam')">Naam</button>
                            <button class="tablinks" onclick="OpenModalMenuItemArtikel(event, '')"></button>
                            <button class="tablinks" onclick="OpenModalMenuItemArtikel(event, '')"></button>
                            <button class="tablinks" onclick="OpenModalMenuItemArtikel(event, '')"></button>
                        </div>
                    </div>
                    <div class="modal-body">
                        <div id="Artikelnummer" class="tabcontent active" style="display: block;">
                            <h3>Zoeken op Artikelnummer</h3>
                            <form action="" onsubmit="return false">
                                <input type="text" placeholder="Artikelnummer" id="InputArtikelnummermodal" name="InputArtikelnummermodal" onkeydown="" autofocus="" />
                            </form>
                            <div id="geavanceerdSelectedItemArtikelNummer">
                            </div>
                        </div>

                        <div id="ArtikelNaam" class="tabcontent">
                            <h3>Zoeken op Naam</h3>
                            <form action="" onsubmit="return false">
                                <input type="text" placeholder="Naam" id="InputArtikelNaammodal" name="InputArtikelNaammodal" onkeydown="" autofocus="" />
                            </form>
                            <div id="geavanceerdSelectedItemArtikelNaam">
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
        <!-- het script ZoekArtikel moet onder de bootstrap.min.js file & boven de jquery.min.js file van googleapis blijven -->
        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
        <script src="./Source/JS/ZoekArtikel.js"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
        <script src="./Source/JS/ZoekKlant.js"></script>
        <script src="./Source/JS/SelecteerKlant.js"></script>
        <!-- -->

        <script>
            // functie voor het togglen naar andere zoekitems in het zoekvenster van de klanten 
            const OpenModalMenuItemKlant = (evt, item) => {
                let i, tabcontent, tablinks;
                tabcontent = document.getElementsByClassName("tabcontent");
                for (i = 0; i < tabcontent.length; i++) {
                    tabcontent[i].style.display = "none";
                }
                tablinks = document.getElementsByClassName("tablinks");
                for (i = 0; i < tablinks.length; i++) {
                    tablinks[i].className = tablinks[i].className.replace(" active", "");
                }
                document.getElementById(item).style.display = "block";
                evt.currentTarget.className += " active";
            }
            //

            // functie voor het togglen naar andere zoekitems in het zoekvenster van de klanten 
            const OpenModalMenuItemArtikel = (evt, item) => {
                let i, tabcontent, tablinks;
                tabcontent = document.getElementsByClassName("tabcontent");
                for (i = 0; i < tabcontent.length; i++) {
                    tabcontent[i].style.display = "none";
                }
                tablinks = document.getElementsByClassName("tablinks");
                for (i = 0; i < tablinks.length; i++) {
                    tablinks[i].className = tablinks[i].className.replace(" active", "");
                }
                document.getElementById(item).style.display = "block";
                evt.currentTarget.className += " active";
            }
            //
        </script>
</body>

</html>