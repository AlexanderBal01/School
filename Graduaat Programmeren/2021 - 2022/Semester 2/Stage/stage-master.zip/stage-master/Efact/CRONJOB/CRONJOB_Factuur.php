<?php
    // legt een verbinding met databasefile
    include_once $_SERVER['DOCUMENT_ROOT'] . "/config/config.php";
    //
?>

<?php
    $selectFactuur = "SELECT * FROM FACTUUR WHERE LIDSTAAT <> 'UP'";
    $resultsFactuur = $mysqli->query($selectFactuur);

    // controle of er wel iets gevonden wordt in databank
    if ($resultsFactuur->num_rows > 0) {
    //
        // haalt alle gevonden rijen op
        while ($rowFactuur = $resultsFactuur->fetch_assoc()) {
        //
            // we gebruiken mysqli_real_escape_string om slashes toe te voegen voor " & '
            $dagboek = mysqli_real_escape_string($mysqli, $rowFactuur['DAGBOEK']);
            $boekjaar = mysqli_real_escape_string($mysqli, $rowFactuur['BOEKJAAR']);
            $factnr = mysqli_real_escape_string($mysqli, $rowFactuur['FACTNR']);
            $klant = mysqli_real_escape_string($mysqli, $rowFactuur['KLANT']);
            $valuta = mysqli_real_escape_string($mysqli, $rowFactuur['VALUTA']);
            $codefc = mysqli_real_escape_string($mysqli, $rowFactuur['CODEFC']);
            $datum = mysqli_real_escape_string($mysqli, str_replace('-', ',', $rowFactuur['DATUM']));
            $vervdat = mysqli_real_escape_string($mysqli, str_replace('-', ',', $rowFactuur['VERVDAT']));
            $btwregime = mysqli_real_escape_string($mysqli, $rowFactuur['BTWREGIME']);
            $vertegenw = mysqli_real_escape_string($mysqli, $rowFactuur['VERTEGENW']);
            $kredbeperk = mysqli_real_escape_string($mysqli, $rowFactuur['KREDBEPERK']);
            $bedragkb = mysqli_real_escape_string($mysqli, $rowFactuur['BEDRAGKB']);
            $bedragkbiv = mysqli_real_escape_string($mysqli, $rowFactuur['BEDRAGKBIV']);
            $kortcont = mysqli_real_escape_string($mysqli, $rowFactuur['KORTCONT']);
            $bedragkc = mysqli_real_escape_string($mysqli, $rowFactuur['BEDRAGKC']);
            $bedragkciv = mysqli_real_escape_string($mysqli, $rowFactuur['BEDRAGKCIV']);
            $totexcl = mysqli_real_escape_string($mysqli, $rowFactuur['TOTEXCL']);
            $totexcliv = mysqli_real_escape_string($mysqli, $rowFactuur['TOTEXCLIV']);
            $totbtw = mysqli_real_escape_string($mysqli, $rowFactuur['TOTBTW']);
            $totbtwiv = mysqli_real_escape_string($mysqli, $rowFactuur['TOTBTWIV']);
            $tebet = mysqli_real_escape_string($mysqli, $rowFactuur['TEBET']);
            $tebetiv = mysqli_real_escape_string($mysqli, $rowFactuur['TEBETIV']);
            $ontvangeniv = mysqli_real_escape_string($mysqli, $rowFactuur['ONTVANGENIV']);
            $ontvangen = mysqli_real_escape_string($mysqli, $rowFactuur['ONTVANGEN']);
            $project = mysqli_real_escape_string($mysqli, $rowFactuur['PROJECT']);
            $globkort = mysqli_real_escape_string($mysqli, $rowFactuur['GLOBKORT']);
            $bedraggk = mysqli_real_escape_string($mysqli, $rowFactuur['BEDRAGGK']);
            $bedraggkiv = mysqli_real_escape_string($mysqli, $rowFactuur['BEDRAGGKIV']);
            $omschr = mysqli_real_escape_string($mysqli, $rowFactuur['OMSCHR']);
            $gewicht = mysqli_real_escape_string($mysqli, $rowFactuur['GEWICHT']);
            $ivk = mysqli_real_escape_string($mysqli, $rowFactuur['IVK']);
            $ivkiv = mysqli_real_escape_string($mysqli, $rowFactuur['IVKIV']);
            $vervwijze = mysqli_real_escape_string($mysqli, $rowFactuur['VERVWIJZE']);
            $aardtrans = mysqli_real_escape_string($mysqli, $rowFactuur['AARDTRANS']);
            $lidstaat = mysqli_real_escape_string($mysqli, $rowFactuur['LIDSTAAT']);
            $admkost = mysqli_real_escape_string($mysqli, $rowFactuur['ADMKOST']);
            $admkostiv = mysqli_real_escape_string($mysqli, $rowFactuur['ADMKOSTIV']);
            $gewest = mysqli_real_escape_string($mysqli, $rowFactuur['GEWEST']);
            $incoterm = mysqli_real_escape_string($mysqli, $rowFactuur['INCOTERM']);
            $betaald = mysqli_real_escape_string($mysqli, $rowFactuur['BETAALD']);
            $betaaldatum = mysqli_real_escape_string($mysqli, str_replace('-', ',', $rowFactuur['BETAALDATUM']));
            $betaalopm = mysqli_real_escape_string($mysqli, $rowFactuur['BETAALOPM']);
            $betaalbedriv = mysqli_real_escape_string($mysqli, $rowFactuur['BETAALBEDRIV']);
            $isbtwincl = mysqli_real_escape_string($mysqli, $rowFactuur['ISBTWINCL']);
            $elektronisch = mysqli_real_escape_string($mysqli, $rowFactuur['ELEKTRONISCH']);
            $tekst = mysqli_real_escape_string($mysqli, $rowFactuur['TEKST']);
            //
            
            $selectFactuurNew = "SELECT * FROM FACTUUR_NEW WHERE FACTNR=$factnr LIMIT 1";
            $resultsFactuurNew = $mysqli->query($selectFactuurNew);
            // controle of er wel iets gevonden wordt in databank
            if ($resultsFactuurNew->num_rows > 0) {
            //
                // haalt alle gevonden rijen op
                while ($rowFactuurNew = $resultsFactuurNew->fetch_assoc()) {
                //
                    // controle of de rijen dat werden opgehaald uit de twee tabellen het zelfde zijn, zo niet updaten we de FactuurTabel tabel
                    if ($rowFactuurNew == $rowFactuur) {
                    //
                    } else {
                        $updateFactuurNew = "UPDATE FACTUUR_NEW SET DAGBOEK='$dagboek', BOEKJAAR=$boekjaar, FACTNR=$factnr, KLANT='$klant', 
                        VALUTA='$valuta', CODEFC='$codefc', DATUM=STR_TO_DATE('$datum', '%Y,%m,%d'), VERVDAT=STR_TO_DATE('$vervdat', '%Y,%m,%d'), 
                        BTWREGIME='$btwregime', VERTEGENW='$vertegenw', KREDBEPERK=$kredbeperk, BEDRAGKB=$bedragkb, BEDRAGKBIV=$bedragkbiv, 
                        KORTCONT=$kortcont, BEDRAGKC=$bedragkc, BEDRAGKCIV=$bedragkciv, TOTEXCL=$totexcl, TOTEXCLIV=$totexcliv, TOTBTW=$totbtw, 
                        TOTBTWIV=$totbtwiv, TEBET=$tebet, TEBETIV=$tebetiv, ONTVANGENIV=$ontvangeniv, ONTVANGEN=$ontvangen, PROJECT='$project', 
                        GLOBKORT=$globkort, BEDRAGGK=$bedraggk, BEDRAGGKIV=$bedraggkiv, OMSCHR='$omschr', GEWICHT=$gewicht, IVK=$ivk, IVKIV=$ivkiv, 
                        VERVWIJZE='$vervwijze', AARDTRANS='$aardtrans', LIDSTAAT='$lidstaat', ADMKOST=$admkost, ADMKOSTIV=$admkostiv, GEWEST='$gewest', 
                        INCOTERM='$incoterm', BETAALD='$betaald', BETAALDATUM=STR_TO_DATE('$betaaldatum', '%Y,%m,%d'), BETAALOPM='$betaalopm', 
                        BETAALBEDRIV=$betaalbedriv, ISBTWINCL='$isbtwincl', ELEKTRONISCH='$elektronisch', TEKST='$tekst' WHERE FACTNR=$factnr LIMIT 1";

                        // controle of de query succesvol is uitgevoerd
                        if ($mysqli->query($updateFactuurNew) === TRUE) {
                        //
                            // controle of de rijen verschillend zijn, indien ja voert hij één van de query's
                            if ($rowFactuur != $rowFactuurNew) {
                            //
                                foreach ($rowFactuur as $x => $val) {
                                    // kijkt of de de veranderde value leeg is gezet
                                    if ($rowFactuurNew["$x"] != $val && $val == "") {
                                    //
                                        $insertIntoLogginFactuur = "INSERT INTO LOGGING_FACTUUR (FACTNR, TypeChange, ColumnName, OldValue, 
                                        NewValue, DatumTijd) VALUES ('$factnr', 'DELETE', '$x', '". mysqli_real_escape_string($mysqli, $rowFactuurNew["$x"]). "', '', CURRENT_TIMESTAMP)";
                                        // controle of de query succesvol is uitgevoerd
                                        if ($mysqli->query($insertIntoLogginFactuur) === TRUE) {
                                        //
                                        } else {
                                            echo "<p>" . mysqli_error($mysqli) ; "</p>";
                                        }
                                        // kijkt of de value is veranderd, maar ingevuld is
                                    } elseif ($rowFactuurNew["$x"] != $val) {
                                        //
                                        $insertIntoLogginFactuur = "INSERT INTO LOGGING_FACTUUR (FACTNR, TypeChange, ColumnName, OldValue, 
                                        NewValue, DatumTijd) VALUES ('$factnr', 'UPDATE', '$x', '". mysqli_real_escape_string($mysqli, $rowFactuurNew["$x"]). "', '". mysqli_real_escape_string($mysqli, $val) ."', CURRENT_TIMESTAMP)";
                                        // controle of de query succesvol is uitgevoerd
                                        if ($mysqli->query($insertIntoLogginFactuur) === TRUE) {
                                        //
                                        } else {
                                            echo "<p>" . mysqli_error($mysqli) ; "</p>";
                                        }
                                    }
                                }
                            }
                        } else {
                            echo "<p>" . mysqli_error($mysqli) ; "</p>";
                        }
                    }
                }
                // als er van de zoekopdracht geen resultaten zijn dan voegen we deze toe in FactuurNew tabel
            } else {
                //
                $insertIntoFactuurNew = "INSERT INTO FACTUUR_NEW (DAGBOEK, BOEKJAAR, FACTNR, KLANT, VALUTA, CODEFC, DATUM, VERVDAT, BTWREGIME, 
                VERTEGENW, KREDBEPERK, BEDRAGKB, BEDRAGKBIV, KORTCONT, BEDRAGKC, BEDRAGKCIV, TOTEXCL, TOTEXCLIV, TOTBTW, TOTBTWIV, TEBET, 
                TEBETIV, ONTVANGENIV, ONTVANGEN, PROJECT, GLOBKORT, BEDRAGGK, BEDRAGGKIV, OMSCHR, GEWICHT, IVK, IVKIV, VERVWIJZE, AARDTRANS, 
                LIDSTAAT, ADMKOST, ADMKOSTIV, GEWEST, INCOTERM, BETAALD, BETAALDATUM, BETAALOPM, BETAALBEDRIV, ISBTWINCL, ELEKTRONISCH, TEKST)
                VALUES ('$dagboek', $boekjaar, $factnr, '$klant', '$valuta', '$codefc', STR_TO_DATE('$datum', '%Y,%m,%d'), STR_TO_DATE('$vervdat', '%Y,%m,%d'), 
                '$btwregime', '$vertegenw', $kredbeperk, $bedragkb, $bedragkbiv, $kortcont, $bedragkc, $bedragkciv, $totexcl, $totexcliv, $totbtw, $totbtwiv, 
                $tebet, $tebetiv, $ontvangeniv, $ontvangen, '$project', $globkort, $bedraggk, $bedraggkiv, '$omschr', $gewicht, $ivk, $ivkiv, 
                '$vervwijze', '$aardtrans', '$lidstaat', $admkost, $admkostiv, '$gewest', '$incoterm', '$betaald', STR_TO_DATE('$betaaldatum', '%Y,%m,%d'), 
                '$betaalopm', $betaalbedriv, '$isbtwincl', '$elektronisch', '$tekst')";
                
                // controle of de query succesvol is uitgevoerd
                if ($mysqli->query($insertIntoFactuurNew) === TRUE) {
                    // 
                    foreach ($rowFactuur as $x  => $val) {
                        // controle of de val niet leeg is, anders moet deze niet ingevoerd worden in logging tabel
                        if (!empty($val)) {
                            // 
                            $insertIntoLogginFactuur = "INSERT INTO LOGGING_FACTUUR (FACTNR, TypeChange, ColumnName, OldValue, 
                            NewValue, DatumTijd) VALUES ('$factnr', 'INSERT', '$x', '', '". mysqli_real_escape_string($mysqli, $val) ."', CURRENT_TIMESTAMP)";
                            // controle of de query succesvol is uitgevoerd
                            if ($mysqli->query($insertIntoLogginFactuur) === TRUE) {
                                // 
                            } else {
                                echo "<p>" . mysqli_error($mysqli) ; "</p>";
                            }
                        }
                    }
                } else {
                    echo "<p>" . mysqli_error($mysqli) ; "</p>";
                }
            }
// deze query zorgt er voor als de cronjob niet voledig is uitgevoert dat hij deze nadien verder doet van waar hij gestopt is
            $updateFactuur = "UPDATE FACTUUR SET LIDSTAAT='UP' WHERE FACTNR=$factnr";
            // 
            // controle of de query succesvol is uitgevoerd
            if ($mysqli->query($updateFactuur) === TRUE) {
                // 
            } else {
                echo "<p>" . mysqli_error($mysqli) ; "</p>";
            }
        }
    } else {
        echo 'niets gebeurt';
    }
?>