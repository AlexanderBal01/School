<?php
// legt een verbinding met databasefile
    include_once $_SERVER['DOCUMENT_ROOT'] . "/config/config.php";
//
?>

<?php
    $selectAflever = "SELECT * FROM AFLEVER WHERE LIDSTAAT <> 'UP'";
    $resultsAflever = $mysqli->query($selectAflever);
    // controle of er wel iets gevonden wordt in databank
    if ($resultsAflever->num_rows > 0) {
    //  
        // haalt alle gevonden rijen op
        while ($rowAflever = $resultsAflever->fetch_assoc()) {
        //  
            // we gebruiken mysqli_real_escape_string om slashes toe te voegen voor " & '
            $afleverbk = mysqli_real_escape_string($mysqli, $rowAflever['AFLEVERBK']); 
            $aflevernr = mysqli_real_escape_string($mysqli, $rowAflever['AFLEVERNR']); 
            $kodefc = mysqli_real_escape_string($mysqli, $rowAflever['KODEFC']); 
            $datum = mysqli_real_escape_string($mysqli, str_replace('-', ',', $rowAflever['DATUM']));
            $klant = mysqli_real_escape_string($mysqli, $rowAflever['KLANT']); 
            $lvanr = mysqli_real_escape_string($mysqli, $rowAflever['LVANR']);
            $naam = mysqli_real_escape_string($mysqli, $rowAflever['NAAM']);
            $adres1 = mysqli_real_escape_string($mysqli, $rowAflever['ADRES1']);
            $adres2 = mysqli_real_escape_string($mysqli, $rowAflever['ADRES2']);
            $adres3 = mysqli_real_escape_string($mysqli, $rowAflever['ADRES3']);
            $land = mysqli_real_escape_string($mysqli, $rowAflever['LAND']);
            $postnr = mysqli_real_escape_string($mysqli, $rowAflever['POSTNR']);
            $gemeente = mysqli_real_escape_string($mysqli, $rowAflever['GEMEENTE']);
            $valuta = mysqli_real_escape_string($mysqli, $rowAflever['VALUTA']);
            $koers = mysqli_real_escape_string($mysqli, $rowAflever['KOERS']);
            $btwregime = mysqli_real_escape_string($mysqli, $rowAflever['BTWREGIME']);
            $omschr = mysqli_real_escape_string($mysqli, $rowAflever['OMSCHR']);
            $prijscat = mysqli_real_escape_string($mysqli, $rowAflever['PRIJSCAT']);
            $globkort = mysqli_real_escape_string($mysqli, $rowAflever['GLOBKORT']);
            $kortkont = mysqli_real_escape_string($mysqli, $rowAflever['KORTKONT']);
            $kredbeperk = mysqli_real_escape_string($mysqli, $rowAflever['KREDBEPERK']);
            $totexcl = mysqli_real_escape_string($mysqli, $rowAflever['TOTEXCL']);
            $totexcliv = mysqli_real_escape_string($mysqli, $rowAflever['TOTEXCLIV']);
            $totbtw = mysqli_real_escape_string($mysqli, $rowAflever['TOTBTW']);
            $totbtwiv = mysqli_real_escape_string($mysqli, $rowAflever['TOTBTWIV']);
            $tebet = mysqli_real_escape_string($mysqli, $rowAflever['TEBET']);
            $tebetiv = mysqli_real_escape_string($mysqli, $rowAflever['TEBETIV']);
            $gevrledat = mysqli_real_escape_string($mysqli, str_replace('-', ',', $rowAflever['GEVRLEVDAT']));
            $bevledat = mysqli_real_escape_string($mysqli, str_replace('-', ',', $rowAflever['BEVLEVDAT']));
            $persoon = mysqli_real_escape_string($mysqli, $rowAflever['PERSOON']);
            $vertegenw = mysqli_real_escape_string($mysqli, $rowAflever['VERTEGENW']);
            $vervwijze = mysqli_real_escape_string($mysqli, $rowAflever['VERVWIJZE']);
            $transporteur = mysqli_real_escape_string($mysqli, $rowAflever['TRANSPORTEUR']);
            $dagboek = mysqli_real_escape_string($mysqli, $rowAflever['DAGBOEK']);
            $boekjaar = mysqli_real_escape_string($mysqli, $rowAflever['BOEKJAAR']);
            $faktnr = mysqli_real_escape_string($mysqli, $rowAflever['FAKTNR']);
            $factdat = mysqli_real_escape_string($mysqli, str_replace('-', ',', $rowAflever['FAKTDAT']));
            $vervdat = mysqli_real_escape_string($mysqli, str_replace('-', ',', $rowAflever['VERVDAT']));
            $stfakt = mysqli_real_escape_string($mysqli, $rowAflever['STFAKT']);
            $bedragkk = mysqli_real_escape_string($mysqli, $rowAflever['BEDRAGKK']);
            $bedragkb = mysqli_real_escape_string($mysqli, $rowAflever['BEDRAGKB']);
            $project = mysqli_real_escape_string($mysqli, $rowAflever['PROJECT']);
            $ontvangeniv = mysqli_real_escape_string($mysqli, $rowAflever['ONTVANGENIV']);
            $ontvangen = mysqli_real_escape_string($mysqli, $rowAflever['ONTVANGEN']);
            $ctpnr = mysqli_real_escape_string($mysqli, $rowAflever['CTPNR']);
            $contactp = mysqli_real_escape_string($mysqli, $rowAflever['CONTACTP']);
            $collis = mysqli_real_escape_string($mysqli, $rowAflever['COLLIS']);
            $paletten = mysqli_real_escape_string($mysqli, $rowAflever['PALETTEN']);
            $ivk = mysqli_real_escape_string($mysqli, $rowAflever['IVK']);
            $ivkiv = mysqli_real_escape_string($mysqli, $rowAflever['IVKIV']);
            $gewicht = mysqli_real_escape_string($mysqli, $rowAflever['GEWICHT']);
            $bedraggk = mysqli_real_escape_string($mysqli, $rowAflever['BEDRAGGK']);
            $totcomiv = mysqli_real_escape_string($mysqli, $rowAflever['TOTCOMIV']);
            $aardtrans = mysqli_real_escape_string($mysqli, $rowAflever['AARDTRANS']);
            $lidstaat = mysqli_real_escape_string($mysqli, $rowAflever['LIDSTAAT']);
            $admkost = mysqli_real_escape_string($mysqli, $rowAflever['ADMKOST']);
            $admkostiv = mysqli_real_escape_string($mysqli, $rowAflever['ADMKOSTIV']);
            $gewest = mysqli_real_escape_string($mysqli, $rowAflever['GEWEST']);
            $incoterm = mysqli_real_escape_string($mysqli, $rowAflever['INCOTERM']);
            $factklant = mysqli_real_escape_string($mysqli, $rowAflever['FACTKLANT']);
            $creadatum = mysqli_real_escape_string($mysqli, str_replace('-', ',', $rowAflever['CREADATUM']));
            $creauur = mysqli_real_escape_string($mysqli, $rowAflever['CREAUUR']);
            $creauser = mysqli_real_escape_string($mysqli, $rowAflever['CREAUSER']);
            $wijzdatum = mysqli_real_escape_string($mysqli, str_replace('-', ',', $rowAflever['WIJZDATUM']));
            $wijzuur = mysqli_real_escape_string($mysqli, $rowAflever['WIJZUUR']);
            $wijzuser = mysqli_real_escape_string($mysqli, $rowAflever['WIJZUSER']);
            $transpbk = mysqli_real_escape_string($mysqli, $rowAflever['TRANSPBK']);
            $transpnr = mysqli_real_escape_string($mysqli, $rowAflever['TRANSPNR']);
            $isverltar = mysqli_real_escape_string($mysqli, $rowAflever['ISVERLTAR']);
            $uitvoorraad = mysqli_real_escape_string($mysqli, $rowAflever['UITVOORRAAD']);
            $uitvdat = mysqli_real_escape_string($mysqli, str_replace('-', ',', $rowAflever['UITVDAT']));
            $taalkode = mysqli_real_escape_string($mysqli, $rowAflever['TAALKODE']);
            $isbtwincl = mysqli_real_escape_string($mysqli, $rowAflever['ISBTWINCL']);
            $bpointfactid = mysqli_real_escape_string($mysqli, $rowAflever['BPOINTFACTID']);
            $betvoorw = mysqli_real_escape_string($mysqli, $rowAflever['BETVOORW']);
            $domicil = mysqli_real_escape_string($mysqli, $rowAflever['DOMICIL']);
            $voorschotfct = mysqli_real_escape_string($mysqli, $rowAflever['VOORSCHOTFCT']);
            $opeisdatum = mysqli_real_escape_string($mysqli, str_replace('-', ',', $rowAflever['OPEISDATUM']));
            $referentie = mysqli_real_escape_string($mysqli, $rowAflever['REFERENTIE']);
            //
            
            $selectAfleverNew = "SELECT * FROM AFLEVER_NEW WHERE AFLEVERNR = $aflevernr LIMIT 1";
            $resultsAfleverNew = $mysqli->query($selectAfleverNew);;
            // controle of er wel iets gevonden wordt in databank
            if ($resultsAfleverNew->num_rows > 0) {
            //  
                // haalt alle gevonden rijen op
                while ($rowAfleverNew = $resultsAfleverNew->fetch_assoc()) {
                //
                    // controle of de rijen dat werden opgehaald uit de twee tabellen het zelfde zijn, zo niet updaten we de AfleverNew tabel
                    if ($rowAfleverNew == $rowAflever) {
                    //
                    } else {
                        $updateAfleverNew = "UPDATE AFLEVER_NEW SET AFLEVERBK='$afleverbk', AFLEVERNR=$aflevernr, KODEFC='$kodefc', DATUM=STR_TO_DATE('$datum', '%Y,%m,%d'), 
                        KLANT='$klant', LVANR=$lvanr, NAAM='$naam', ADRES1='$adres1', ADRES2='$adres2', Adres3='$adres3', 
                        LAND='$land', POSTNR='$postnr', GEMEENTE='$gemeente', VALUTA='$valuta', KOERS=$koers, BTWREGIME='$btwregime', 
                        omschr='$omschr', PRIJSCAT='$prijscat', GLOBKORT=$globkort, KORTKONT=$kortkont, KREDBEPERK=$kredbeperk, 
                        TOTEXCL=$totexcl, TOTBTW=$totbtw, TOTBTWIV=$totbtwiv, TEBET=$tebet, TEBETIV=$tebetiv, GEVRLEVDAT=STR_TO_DATE('$gevrledat', '%Y,%m,%d'), 
                        BEVLEVDAT=STR_TO_DATE('$bevledat', '%Y,%m,%d'), PERSOON='$persoon', VERTEGENW='$vertegnw', VERVWIJZE='$vervwijze', 
                        TRANSPORTEUR='$transporteur', DAGBOEK='$dagboek', BOEKJAAR=$boekjaar, FAKTNR=$faktnr, FAKTDAT=STR_TO_DATE('$factdat', '%Y,%m,%d'), 
                        VERVDAT=STR_TO_DATE('$vervdat', '%Y,%m,%d'), STFAKT='$stfakt', BEDRAGKK=$bedragkk, BEDRAGKB=$bedragkb, PROJECT='$project', 
                        ONTVANGENIV=$ontvangeniv, ONTVANGEN=$ontvangen, CTPNR=$ctpnr, CONTACTP='$contactp', COLLIS=$collis, PALETTEN=$paletten, 
                        IVK=$ivk, IVKIV=$ivkiv, GEWICHT=$gewicht, BEDRAGGK=$bedraggk, TOTCOMIV=$totcomiv, AARDTRANS='$aardtrans', 
                        LIDSTAAT='$lidstaat', ADMKOST=$admkost, ADMKOSTIV=$admkostiv, GEWEST='$gewest', INCOTERM='$incoterm', 
                        FACTKLANT='$factklant', CREADATUM=STR_TO_DATE('$creadatum', '%Y,%m,%d'), CREAUUR='$creauur', CREAUSER='$creauser', 
                        WIJZDATUM=STR_TO_DATE('$wijzdatum', '%Y,%m,%d'), WIJZUUR='$wijzuur', WIJZUSER='$wijzuser', TRANSPBK='$transpbk', 
                        TRANSPNR=$transpnr, ISVERLTAR='$isverltar', UITVOORRAAD='$uitvoorraad', UITVDAT=STR_TO_DATE('$uitvdat', '%Y,%m,%d'), 
                        TAALKODE='$taalkode', ISBTWINCL='$isbtwincl', BPOINTFACTID='$bpointfactid', BETVOORW='$betvoorw', DOMICIL='$domicil', 
                        VOORSCHOTFCT='$voorschotfct', OPEISDATUM=STR_TO_DATE('$opeisdatum', '%Y,%m,%d'), REFERENTIE='$referentie' WHERE AFLEVERNR = $aflevernr LIMIT 1";
                        // controle of de query succesvol is uitgevoerd
                        if ($mysqli->query($updateAfleverNew) === TRUE) {
                        //
                            // controle of de rijen verschillend zijn, indien ja voert hij één van de query's
                            if ($rowAfleverNew != $rowAflever) {
                            //
                                foreach ($rowAflever as $x => $val) {
                                    // kijkt of de de veranderde value leeg is gezet
                                    if ($rowAfleverNew["$x"] != $val && $val =="") {
                                    //
                                        $insertIntoLoggingAflever = "INSERT INTO LOGGING_AFLEVER (AfleverNummer, TypeChange, ColumnName, OldValue, NewValue, DatumTijd) 
                                        VALUES ('$aflevernr', 'DELETE', '$x', '" . mysqli_real_escape_string($mysqli, $rowAfleverNew["$x"]) . "', '', CURRENT_TIMESTAMP)";
                                        // kijkt of de data succesvol is ingevoerd in de logging tabel
                                        if ($mysqli->query($insertIntoLoggingAflever) === TRUE) {
                                        //
                                        } else {
                                            echo "<p>" . mysqli_error($mysqli) ; "</p>";
                                        }
                                        // kijkt of de value is veranderd, maar ingevuld is
                                    } elseif ($rowAfleverNew["$x"] != $val) {
                                        //
                                        $insertIntoLoggingAflever = "INSERT INTO LOGGING_AFLEVER (AfleverNummer, TypeChange, ColumnName, OldValue, NewValue, DatumTijd) 
                                        VALUES ('$aflevernr', 'UPDATE', '$x', '" . mysqli_real_escape_string($mysqli, $rowAfleverNew["$x"]) . "', '" . mysqli_real_escape_string($mysqli, $val) . "', CURRENT_TIMESTAMP)";
                                        // kijkt of de data succesvol is ingevoerd in de logging tabel
                                        if ($mysqli->query($insertIntoLoggingAflever) === TRUE) {
                                        //
                                        } else {
                                            echo "<p>" . mysqli_error($mysqli) ; "</p>";
                                        }
                                    }
                                }
                            }    
                        } else {
                            echo "<p>" . mysqli_error($mysqli) ; "</p>";
                        }
                    }
                }
                // als er van de zoekopdracht geen resultaten zijn dan voegen we deze toe in Aflevernew tabel
            } else {
                //
                $insertIntoAfleverNEW = "INSERT INTO AFLEVER_NEW (AFLEVERBK, AFLEVERNR, KODEFC, DATUM, KLANT, LVANR, NAAM, ADRES1, ADRES2, ADRES3, LAND, POSTNR, GEMEENTE, 
                VALUTA, KOERS, BTWREGIME, OMSCHR, PRIJSCAT, GLOBKORT, KORTKONT, KREDBEPERK, TOTEXCL, TOTEXCLIV, TOTBTW, TOTBTWIV, TEBET, TEBETIV, GEVRLEVDAT, BEVLEVDAT, 
                PERSOON, VERTEGENW, VERVWIJZE, TRANSPORTEUR, DAGBOEK, BOEKJAAR, FAKTNR, FAKTDAT, VERVDAT, STFAKT, BEDRAGKK, BEDRAGKB, PROJECT, ONTVANGENIV, ONTVANGEN, CTPNR, 
                CONTACTP, COLLIS, PALETTEN, IVK, IVKIV, GEWICHT, BEDRAGGK, TOTCOMIV, AARDTRANS, LIDSTAAT, ADMKOST, ADMKOSTIV, GEWEST, INCOTERM, FACTKLANT, CREADATUM, CREAUUR, 
                CREAUSER, WIJZDATUM, WIJZUUR, WIJZUSER, TRANSPBK, TRANSPNR, ISVERLTAR, UITVOORRAAD, UITVDAT, TAALKODE, ISBTWINCL, BPOINTFACTID, BETVOORW, DOMICIL, VOORSCHOTFCT, 
                OPEISDATUM, REFERENTIE) VALUES ('$afleverbk', $aflevernr, '$kodefc', STR_TO_DATE('$datum', '%Y,%m,%d'), '$klant', 
                $lvanr, '$naam', '$adres1', '$adres2', '$adres3', '$land', '$postnr', '$gemeente',
                '$valuta', $koers, '$btwregime', '$omschr', '$prijscat', $globkort, $kortkont, $kredbeperk,
                $totexcl, $totexcliv, $totbtw, $totbtwiv, $tebet, $tebetiv, STR_TO_DATE('$gevrledat', '%Y,%m,%d'),
                STR_TO_DATE('$bevledat', '%Y,%m,%d'), '$persoon', '$vertegenw', '$vervwijze', '$transporteur', '$dagboek',
                $boekjaar, $faktnr, STR_TO_DATE('$factdat', '%Y,%m,%d'), STR_TO_DATE('$vervdat', '%Y,%m,%d'), '$stfakt',
                $bedragkk, $bedragkb, '$project', $ontvangeniv, $ontvangen, $ctpnr, '$contactp', $collis,
                $paletten, $ivk, $ivkiv, $gewicht, $bedraggk, $totcomiv, '$aardtrans', '$lidstaat',
                $admkost, $admkostiv, '$gewest', '$incoterm', '$factklant', STR_TO_DATE('$creadatum', '%Y,%m,%d'),
                '$creauur', '$creauser', STR_TO_DATE('$wijzdatum', '%Y,%m,%d'), '$wijzuur', '$wijzuser', '$transpbk',
                $transpnr, '$isverltar', '$uitvoorraad', STR_TO_DATE('$uitvdat', '%Y,%m,%d'), '$taalkode', '$isbtwincl',
                '$bpointfactid', '$betvoorw', '$domicil', '$voorschotfct', STR_TO_DATE('$opeisdatum', '%Y,%m,%d'), '$referentie')";
                // kijkt of de query gelukt is
                if ($mysqli->query($insertIntoAfleverNEW) === TRUE) {
                //
                    foreach ($rowAflever as $x => $val) {
                        // controle of de val niet leeg is, anders moet deze niet ingevoerd worden in logging tabel
                        if (!empty($val)) {
                        //
                            $insertIntoLoggingAflever = "INSERT INTO LOGGING_AFLEVER (AfleverNummer, TypeChange, ColumnName, OldValue, NewValue, DatumTijd) 
                            VALUES ('$aflevernr', 'INSERT', '$x', '', '" . mysqli_real_escape_string($mysqli, $val) . "', CURRENT_TIMESTAMP)";
                            // kijkt of de data succesvol is ingevoerd in de logging tabel
                            if ($mysqli->query($insertIntoLoggingAflever) === TRUE) {
                            //
                            } else {
                                echo "<p>" . mysqli_error($mysqli) ; "</p>";
                            }
                        }
                    }
                } else {
                    echo "<p>" . mysqli_error($mysqli) ; "</p>";
                }
            }
            // deze query zorgt er voor als de cronjob niet voledig is uitgevoert dat hij deze nadien verder doet van waar hij gestopt is
            $updateAflever = "UPDATE AFLEVER SET LIDSTAAT='UP' WHERE AFLEVERNR=$aflevernr";
            //

            // kijkt of de query gelukt is
            if ($mysqli->query($updateAflever) === TRUE) {
            } else {
                echo "<p>" . mysqli_error($mysqli) ; "</p>";
            }
        }
    } else {
        echo 'niets gebeurt';
    }
    
?>