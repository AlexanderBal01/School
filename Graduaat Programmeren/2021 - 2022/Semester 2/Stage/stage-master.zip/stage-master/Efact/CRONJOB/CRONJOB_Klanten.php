<?php
// legt een verbinding met databasefile
    include_once $_SERVER['DOCUMENT_ROOT'] . "/config/config.php";
// 
?>

<?php
    $selectKlanten = "SELECT * FROM KLANTEN WHERE PROVIDER <> '1'";
    $resultsKlanten = $mysqli->query($selectKlanten);
    // controle of er wel iets gevonden wordt in databank
    if ($resultsKlanten->num_rows > 0) {
    //
        // haalt alle gevonden rijen op
        while ($rowKlanten = $resultsKlanten->fetch_assoc()) {
        //
            // we gebruiken mysqli_real_escape_string om slashes toe te voegen voor " & '
            $klantnummer = mysqli_real_escape_string($mysqli, $rowKlanten['NUMMER']);
            $Aansprek = mysqli_real_escape_string($mysqli, $rowKlanten['AANSPREK']);
            $Naam = mysqli_real_escape_string($mysqli, $rowKlanten['NAAM']);
            $Adres1 = mysqli_real_escape_string($mysqli, $rowKlanten['ADRES1']);
            $Adres2 = mysqli_real_escape_string($mysqli, $rowKlanten['ADRES2']);
            $Adres3 = mysqli_real_escape_string($mysqli, $rowKlanten['ADRES3']);
            $Land = mysqli_real_escape_string($mysqli, $rowKlanten['LAND']);
            $Postcode = mysqli_real_escape_string($mysqli, $rowKlanten['POSTNR']);
            $Gemeente = mysqli_real_escape_string($mysqli, $rowKlanten['GEMEENTE']);
            $TelefoonNummer1 = mysqli_real_escape_string($mysqli, $rowKlanten['TELEFOON1']);
            $TelefoonNummer2 = mysqli_real_escape_string($mysqli, $rowKlanten['TELEFOON2']);
            $Telefax = mysqli_real_escape_string($mysqli, $rowKlanten['TELEFAX']);
            $Email = mysqli_real_escape_string($mysqli, $rowKlanten['URL']);
            $TaalCode = mysqli_real_escape_string($mysqli, $rowKlanten['TAALKODE']);
            $BTW_Regime = mysqli_real_escape_string($mysqli, $rowKlanten['BTWREGIME']);
            $BTW_Nummer = mysqli_real_escape_string($mysqli, $rowKlanten['BTWNR']);
            $Bank = mysqli_real_escape_string($mysqli, $rowKlanten['BANK']);
            $Bank_Nummer = mysqli_real_escape_string($mysqli, $rowKlanten['BANKNR']);
            $BankNaam = mysqli_real_escape_string($mysqli, $rowKlanten['BANKNAAM']);
            $BankAdres1 = mysqli_real_escape_string($mysqli, $rowKlanten['BANKADRES1']);
            $BankAdres2 = mysqli_real_escape_string($mysqli, $rowKlanten['BANKADRES2']);
            $BankPlaats = mysqli_real_escape_string($mysqli, $rowKlanten['BANKPLAATS']);
            $Vertegenw = mysqli_real_escape_string($mysqli, $rowKlanten['VERTEGENW']);
            $Groep1 = mysqli_real_escape_string($mysqli, $rowKlanten['GROEP1']);
            $Groep2 = mysqli_real_escape_string($mysqli, $rowKlanten['GROEP2']);
            $Groep3 = mysqli_real_escape_string($mysqli, $rowKlanten['GROEP3']);
            $Maningen = mysqli_real_escape_string($mysqli, $rowKlanten['MANINGEN']);
            $Domicil = mysqli_real_escape_string($mysqli, $rowKlanten['DOMICIL']);
            $Kredlimiet = mysqli_real_escape_string($mysqli, $rowKlanten['KREDLIMIET']);
            $Betvoorw = mysqli_real_escape_string($mysqli, $rowKlanten['BETVOORW']);
            $Valuta = mysqli_real_escape_string($mysqli, $rowKlanten['VALUTA']);
            $IsstdBoek = mysqli_real_escape_string($mysqli, $rowKlanten['ISSTDBOEK']);
            $stdboek = mysqli_real_escape_string($mysqli, $rowKlanten['STDBOEK']);
            $Tegenboek = mysqli_real_escape_string($mysqli, $rowKlanten['TEGENBOEK']);
            $prijscat = mysqli_real_escape_string($mysqli, $rowKlanten['PRIJSCAT']);
            $korting1 = mysqli_real_escape_string($mysqli, $rowKlanten['KORTING1']);
            $korting2 = mysqli_real_escape_string($mysqli, $rowKlanten['KORTING2']);
            $factperbon = mysqli_real_escape_string($mysqli, $rowKlanten['FACTPERBON']);
            $tekst = mysqli_real_escape_string($mysqli, $rowKlanten['TEKST']);
            $kortcont = mysqli_real_escape_string($mysqli, $rowKlanten['KORTCONT']);
            $globkort = mysqli_real_escape_string($mysqli, $rowKlanten['GLOBKORT']);
            $centrreknr = mysqli_real_escape_string($mysqli, $rowKlanten['CENTRREKNR']);
            $melding = mysqli_real_escape_string($mysqli, $rowKlanten['MELDING']);
            $zndivk = mysqli_real_escape_string($mysqli, $rowKlanten['ZNDIVK']);
            $factklant = mysqli_real_escape_string($mysqli, $rowKlanten['FACTKLANT']);
            $metadmkost = mysqli_real_escape_string($mysqli, $rowKlanten['METADMKOST']);
            $creadatum = mysqli_real_escape_string($mysqli, str_replace('-', ',', $rowKlanten['CREADATUM']));
            $creauur = mysqli_real_escape_string($mysqli, $rowKlanten['CREAUUR']);
            $creauser = mysqli_real_escape_string($mysqli, $rowKlanten['CREAUSER']);
            $wijzdatum = mysqli_real_escape_string($mysqli, str_replace('-', ',', $rowKlanten['WIJZDATUM']));
            $wijzuur = mysqli_real_escape_string($mysqli, $rowKlanten['WIJZUUR']);
            $wijzuser = mysqli_real_escape_string($mysqli, $rowKlanten['WIJZUSER']);
            $dombanknr = mysqli_real_escape_string($mysqli, $rowKlanten['DOMBANKNR']);
            $altcode = mysqli_real_escape_string($mysqli, $rowKlanten['ALTCODE']);
            $zndklkrt = mysqli_real_escape_string($mysqli, $rowKlanten['ZNDKLKRT']);
            $sla = mysqli_real_escape_string($mysqli, $rowKlanten['SLA']);
            $verltar = mysqli_real_escape_string($mysqli, $rowKlanten['VERLTAR']);
            $vrijberoep = mysqli_real_escape_string($mysqli, $rowKlanten['VRIJBEROEP']);
            $dagboek = mysqli_real_escape_string($mysqli, $rowKlanten['DAGBOEK']);
            $factafdruk = mysqli_real_escape_string($mysqli, $rowKlanten['FACTAFDRUK']);
            $goedkeurdat = mysqli_real_escape_string($mysqli, str_replace('-', ',', $rowKlanten['GOEDKEURDAT']));
            $goedkeurnaam = mysqli_real_escape_string($mysqli, $rowKlanten['GOEDKEURNAAM']);
            $glncode = mysqli_real_escape_string($mysqli, $rowKlanten['GLNCODE']);
            $mandaat = mysqli_real_escape_string($mysqli, $rowKlanten['MANDAAT']);
            $elektronisch = mysqli_real_escape_string($mysqli, $rowKlanten['ELEKTRONISCH']);
            $elektrtype = mysqli_real_escape_string($mysqli, $rowKlanten['ELEKTRTYPE']);
            $archief = mysqli_real_escape_string($mysqli, $rowKlanten['ARCHIEF']);
            $cwalert = mysqli_real_escape_string($mysqli, $rowKlanten['CWALERT']);
            $betalingweb = mysqli_real_escape_string($mysqli, $rowKlanten['BETALINGWEB']);
            $provider = mysqli_real_escape_string($mysqli, $rowKlanten['PROVIDER']);
            $providertype = mysqli_real_escape_string($mysqli, $rowKlanten['PROVIDERTYPE']);
            $participant = mysqli_real_escape_string($mysqli, $rowKlanten['PARTICIPANT']);
            $belgiangov = mysqli_real_escape_string($mysqli, $rowKlanten['BELGIANGOV']);
            //

            $selectKlantenNew = "SELECT * FROM KLANTEN_NEW WHERE NUMMER='$klantnummer' LIMIT 1 ";
            $resultsKlantenNew = $mysqli->query($selectKlantenNew);
            // controle of er wel iets gevonden wordt in databank
            if ($resultsKlantenNew->num_rows > 0) {
            //

                // haalt alle gevonden rijen op
                while ($rowKlantenNew = $resultsKlantenNew->fetch_assoc()) {
                //
                    // controle of de rijen dat werden opgehaald uit de twee tabellen het zelfde zijn, zo niet updaten we de KlantenNew tabel
                    if ($rowKlantenNew == $rowKlanten) {
                    //
                    } else {
                        $updateKLANTENNEW = "UPDATE KLANTEN_NEW SET AANSPREK='$Aansprek', NAAM='$Naam', ADRES1='$Adres1', ADRES2='$Adres2', ADRES3='$Adres3',
                            LAND='$Land', POSTNR='$Postcode', GEMEENTE='$Gemeente', TELEFOON1='$TelefoonNummer1',
                            TELEFOON2='$TelefoonNummer2', TELEFAX='$Telefax', URL='$Email', TAALKODE='$TaalCode',
                            BTWREGIME='$BTW_Regime', BTWNR='$BTW_Nummer', BANK='$Bank', BANKNR='$Bank_Nummer',
                            BANKNAAM='$BankNaam', BANKADRES1='$BankAdres1', BANKADRES2='$BankAdres2', BANKPLAATS='$BankPlaats', 
                            VERTEGENW='$Vertegenw', GROEP1='$Groep1', GROEP2='$Groep2', GROEP3='$Groep3', MANINGEN='$Maningen',
                            DOMICIL='$Domicil', KREDLIMIET=$Kredlimiet, BETVOORW='$Betvoorw', VALUTA='$Valuta',
                            ISSTDBOEK='$IsstdBoek', STDBOEK='$stdboek', TEGENBOEK='$Tegenboek', PRIJSCAT='$prijscat', 
                            KORTING1=$korting1, KORTING2=$korting2, FACTPERBON='$factperbon', TEKST='$tekst',
                            KORTCONT=$kortcont, GLOBKORT=$globkort, CENTRREKNR='$centrreknr', MELDING='$melding',
                            ZNDIVK='$zndivk', FACTKLANT='$factklant', METADMKOST='$metadmkost', CREADATUM=STR_TO_DATE('$creadatum', '%Y,%m,%d'), 
                            CREAUUR='$creauur', CREAUSER='$creauser', WIJZDATUM=STR_TO_DATE('$wijzdatum', '%Y,%m,%d'), WIJZUUR='$wijzuur',
                            WIJZUSER='$wijzuser', DOMBANKNR='$dombanknr', ALTCODE='$altcode', ZNDKLKRT='$zndklkrt',
                            SLA='$sla', VERLTAR='$verltar', VRIJBEROEP='$vrijberoep', DAGBOEK='$dagboek',
                            FACTAFDRUK='$factafdruk', GOEDKEURDAT=STR_TO_DATE('$goedkeurdat', '%Y,%m,%d'), GOEDKEURNAAM='$goedkeurnaam',
                            GLNCODE='$glncode', MANDAAT=$mandaat, ELEKTRONISCH='$elektronisch', ELEKTRTYPE='$elektrtype',
                            ARCHIEF='$archief', CWALERT='$cwalert', BETALINGWEB='$betalingweb', PROVIDER='$provider',
                            PROVIDERTYPE='$providertype', PARTICIPANT='$participant', BELGIANGOV='$belgiangov' WHERE NUMMER='$klantnummer' LIMIT 1";
                        // controle of de query succesvol is uitgevoerd
                        if ($mysqli->query($updateKLANTENNEW) === TRUE) {
                        //
                            // controle of de rijen verschillend zijn, indien ja voert hij één van de query's
                            if ($rowKlanten != $rowKlantenNew) {
                            //
                                foreach ($rowKlanten as $x => $val) {
                                    // kijkt of de de veranderde value leeg is gezet
                                    if ($rowKlantenNew["$x"] != $val && $val == "") {
                                    //
                                        $insertIntoLoggingKlanten = "INSERT INTO LOGGING_KLANTEN (klantNummer, TypeChange, ColumnName, OldValue, NewValue, DatumTijd) 
                                        VALUES ('$klantnummer', 'DELETE', '$x', '" . mysqli_real_escape_string($mysqli, $rowKlantenNew["$x"]) . "', '', CURRENT_TIMESTAMP)";
                                        // controle of de query succesvol is uitgevoerd
                                        if ($mysqli->query($insertIntoLoggingKlanten) === TRUE) {
                                        //
                                        } else {
                                            echo "<p>" . mysqli_error($mysqli) ; "</p>";
                                        }
                                        // kijkt of de value is veranderd, maar ingevuld is
                                    } elseif ($rowKlantenNew["$x"] != $val) {
                                        //
                                        $insertIntoLoggingKlanten = "INSERT INTO LOGGING_KLANTEN (klantNummer, TypeChange, ColumnName, OldValue, NewValue, DatumTijd) 
                                        VALUES ('$klantnummer', 'UPDATE', '$x', '" . mysqli_real_escape_string($mysqli, $rowKlantenNew["$x"]) . "', '" . mysqli_real_escape_string($mysqli, $val) . "', CURRENT_TIMESTAMP)";
                                        // controle of de query succesvol is uitgevoerd
                                        if ($mysqli->query($insertIntoLoggingKlanten) === TRUE) {
                                            // 
                                        } else {
                                            echo "<p>" . mysqli_error($mysqli) ; "</p>";
                                        }
                                    }
                                }
                            }
                        } else {
                            echo "<p>" . mysqli_error($mysqli) ; "</p>";
                        }
                    }
                }
                // als er van de zoekopdracht geen resultaten zijn dan voegen we deze toe in klantenNew tabel
            } else {
                //
                $insertIntoKLANTENNEW = "INSERT INTO KLANTEN_NEW (NUMMER, AANSPREK, NAAM, ADRES1, ADRES2, ADRES3, LAND, POSTNR, GEMEENTE,
                    TELEFOON1, TELEFOON2, TELEFAX, URL, TAALKODE, BTWREGIME, BTWNR, BANK, BANKNR, BANKNAAM, BANKADRES1, BANKADRES2, BANKPLAATS, 
                    VERTEGENW, GROEP1, GROEP2, GROEP3, MANINGEN, DOMICIL, KREDLIMIET, BETVOORW, VALUTA, ISSTDBOEK, STDBOEK, TEGENBOEK, PRIJSCAT, 
                    KORTING1, KORTING2, FACTPERBON, TEKST, KORTCONT, GLOBKORT, CENTRREKNR, MELDING, ZNDIVK, FACTKLANT, METADMKOST, CREADATUM, 
                    CREAUUR, CREAUSER, WIJZDATUM, WIJZUUR, WIJZUSER, DOMBANKNR, ALTCODE, ZNDKLKRT, SLA, VERLTAR, VRIJBEROEP, DAGBOEK, FACTAFDRUK, 
                    GOEDKEURDAT, GOEDKEURNAAM, GLNCODE, MANDAAT, ELEKTRONISCH, ELEKTRTYPE, ARCHIEF, CWALERT, BETALINGWEB, PROVIDER, PROVIDERTYPE, 
                    PARTICIPANT, BELGIANGOV) VALUES ('$klantnummer', '$Aansprek', '$Naam', '$Adres1', '$Adres2', 
                    '$Adres3', '$Land','$Postcode', '$Gemeente', '$TelefoonNummer1', '$TelefoonNummer2', 
                    '$Telefax', '$Email', '$TaalCode', '$BTW_Regime', '$BTW_Nummer', '$Bank', 
                    '$Bank_Nummer', '$BankNaam', '$BankAdres1', '$BankAdres2', '$BankPlaats', '$Vertegenw', 
                    '$Groep1', '$Groep2', '$Groep3', '$Maningen', '$Domicil', $Kredlimiet, 
                    '$Betvoorw', '$Valuta', '$IsstdBoek', '$stdboek', '$Tegenboek', '$prijscat', 
                    $korting1, $korting2, '$factperbon', '$tekst', $kortcont, $globkort, 
                    '$centrreknr', '$melding', '$zndivk', '$factklant', '$metadmkost', STR_TO_DATE('$creadatum', '%Y,%m,%d'), 
                    '$creauur', '$creauser', STR_TO_DATE('$wijzdatum', '%Y,%m,%d'), '$wijzuur', '$wijzuser', '$dombanknr', 
                    '$altcode', '$zndklkrt', '$sla', '$verltar', '$vrijberoep', '$dagboek', 
                    '$factafdruk', STR_TO_DATE('$goedkeurdat', '%Y,%m,%d'), '$goedkeurnaam', '$glncode', $mandaat, '$elektronisch', 
                    '$elektrtype', '$archief', '$cwalert', '$betalingweb', '$provider', '$providertype', 
                    '$participant', '$belgiangov')";
                // kijkt of de query gelukt is
                if ($mysqli->query($insertIntoKLANTENNEW) === TRUE) {
                    foreach ($rowKlanten as $x => $val) {
                        // controle of de val niet leeg is, anders moet deze niet ingevoerd worden in logging tabel
                        if (!empty($val)) {
                        //
                            $insertIntoLoggingKlanten = "INSERT INTO LOGGING_KLANTEN (klantNummer, TypeChange, ColumnName, OldValue, NewValue, DatumTijd) 
                            VALUES ('$klantnummer', 'INSERT', '$x', '', '" . mysqli_real_escape_string($mysqli, $val) . "', CURRENT_TIMESTAMP)";
                            // kijkt of de query gelukt is
                            if ($mysqli->query($insertIntoLoggingKlanten) === TRUE) {
                            //
                            } else {
                                echo "<p>" . mysqli_error($mysqli) ; "</p>";
                            }
                        }
                    }
                } else {
                    echo "<p>" . mysqli_error($mysqli) ; "</p>";
                }
            }
            // deze query zorgt er voor als de cronjob niet voledig is uitgevoert dat hij deze nadien verder doet van waar hij gestopt is
            $updateKlanten = "UPDATE KLANTEN SET PROVIDER='1' WHERE NUMMER='$klantnummer'";
            //
            // kijkt of de query gelukt is
            if ($mysqli->query($updateKlanten) === TRUE) {
            //
            } else {
                echo "<p>" . mysqli_error($mysqli) ; "</p>";
            }
        }
    } else {
        echo 'niets gebeurt';
    }
?>