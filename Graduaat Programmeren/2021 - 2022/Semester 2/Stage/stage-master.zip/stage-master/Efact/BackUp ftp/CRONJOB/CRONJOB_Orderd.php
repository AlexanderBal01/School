<?php
    include_once $_SERVER['DOCUMENT_ROOT'] . "/config/config.php";
?>

<?php
    $selectOrderd = "SELECT * FROM ORDERD WHERE KODESAMENST <> '1'";
    $resultsOrderd = $mysqli->query($selectOrderd);
    if ($resultsOrderd->num_rows > 0) {
        while ($rowOrderd = $resultsOrderd->fetch_assoc()) {
            $orderbk = mysqli_real_escape_string($mysqli, $rowOrderd['ORDERBK']);
            $ordernr = mysqli_real_escape_string($mysqli, $rowOrderd['ORDERNR']);
            $lijnnr = mysqli_real_escape_string($mysqli, $rowOrderd['LIJNNR']);
            $typeln = mysqli_real_escape_string($mysqli, $rowOrderd['TYPELN']);
            $typelnindex = mysqli_real_escape_string($mysqli, $rowOrderd['TYPELNINDEX']);
            $artikel = mysqli_real_escape_string($mysqli, $rowOrderd['ARTIKEL']);
            $benaming = mysqli_real_escape_string($mysqli, $rowOrderd['BENAMING']);
            $aantal = mysqli_real_escape_string($mysqli, $rowOrderd['AANTAL']);
            $stdprijs = mysqli_real_escape_string($mysqli, $rowOrderd['STDPRIJS']);
            $korting1 = mysqli_real_escape_string($mysqli, $rowOrderd['KORTING1']);
            $korting2 = mysqli_real_escape_string($mysqli, $rowOrderd['KORTING2']);
            $eenhpr = mysqli_real_escape_string($mysqli, $rowOrderd['EENHPR']);
            $totaal = mysqli_real_escape_string($mysqli, $rowOrderd['TOTAAL']);
            $btwkode = mysqli_real_escape_string($mysqli, $rowOrderd['BTWKODE']);
            $verkrek = mysqli_real_escape_string($mysqli, $rowOrderd['VERKREK']);
            $magazijn = mysqli_real_escape_string($mysqli, $rowOrderd['MAGAZIJN']);
            $project = mysqli_real_escape_string($mysqli, $rowOrderd['PROJECT']);
            $eenhpriv = mysqli_real_escape_string($mysqli, $rowOrderd['EENHPRIV']);
            $totaaliv = mysqli_real_escape_string($mysqli, $rowOrderd['TOTAALIV']);
            $valuta = mysqli_real_escape_string($mysqli, $rowOrderd['VALUTA']);
            $kodefc = mysqli_real_escape_string($mysqli, $rowOrderd['KODEFC']);
            $klant = mysqli_real_escape_string($mysqli, $rowOrderd['KLANT']);
            $eenhprincl = mysqli_real_escape_string($mysqli, $rowOrderd['EENHPRINCL']);
            $eenhprincliv = mysqli_real_escape_string($mysqli, $rowOrderd['EENHPRINCLIV']);
            $kostprijs = mysqli_real_escape_string($mysqli, $rowOrderd['KOSTPRIJS']);
            $kostprijsiv = mysqli_real_escape_string($mysqli, $rowOrderd['KOSTPRIJSIV']);
            $akwaarde = mysqli_real_escape_string($mysqli, $rowOrderd['AKWAARDE']);
            $kodesamenst = mysqli_real_escape_string($mysqli, $rowOrderd['KODESAMENST']);
            $datum = mysqli_real_escape_string($mysqli, str_replace('-', ',', $rowOrderd['DATUM']));
            $gehelen = mysqli_real_escape_string($mysqli, $rowOrderd['GEHELEN']);
            $tpgeheel = mysqli_real_escape_string($mysqli, $rowOrderd['TPGEHEEL']);
            $afgelev = mysqli_real_escape_string($mysqli, $rowOrderd['AFGELEV']);
            $onderdelen = mysqli_real_escape_string($mysqli, $rowOrderd['ONDERDELEN']);
            $offertebk = mysqli_real_escape_string($mysqli, $rowOrderd['OFFERTEBK']);
            $offertenr = mysqli_real_escape_string($mysqli, $rowOrderd['OFFERTENR']);
            $offertelijn = mysqli_real_escape_string($mysqli, $rowOrderd['OFFERTELIJN']);
            $volledig = mysqli_real_escape_string($mysqli, $rowOrderd['VOLLEDIG']);
            $offertetpln = mysqli_real_escape_string($mysqli, $rowOrderd['OFFERTETPLN']);
            $gevrledat = mysqli_real_escape_string($mysqli, str_replace('-', ',', $rowOrderd['GEVRLEVDAT']));
            $bevledat = mysqli_real_escape_string($mysqli, str_replace('-', ',', $rowOrderd['BEVLEVDAT']));
            $doorbestel = mysqli_real_escape_string($mysqli, $rowOrderd['DOORBESTEL']);
            $levnrbestel = mysqli_real_escape_string($mysqli, $rowOrderd['LEVNRBESTEL']);
            $comperc = mysqli_real_escape_string($mysqli, $rowOrderd['COMPERC']);
            $commissieiv = mysqli_real_escape_string($mysqli, $rowOrderd['COMMISSIEIV']);
            $totcomiv = mysqli_real_escape_string($mysqli, $rowOrderd['TOTCOMIV']);
            $collis = mysqli_real_escape_string($mysqli, $rowOrderd['COLLIS']);
            $paletten = mysqli_real_escape_string($mysqli, $rowOrderd['PALETTEN']);
            $job = mysqli_real_escape_string($mysqli, $rowOrderd['JOB']);
            $soortprijs = mysqli_real_escape_string($mysqli, $rowOrderd['SOORTPRIJS']);
            $refvord = mysqli_real_escape_string($mysqli, $rowOrderd['REFVORD']);
            $refnacalc = mysqli_real_escape_string($mysqli, $rowOrderd['REFNACALC']);
            $gnbonkorting = mysqli_real_escape_string($mysqli, $rowOrderd['GNBONKORTING']);
            $hfdartlijnnr = mysqli_real_escape_string($mysqli, $rowOrderd['HFDARTLIJNNR']);
            $bkmvolgnr = mysqli_real_escape_string($mysqli, $rowOrderd['BKMVOLGNR']);
            $bkmgedrag = mysqli_real_escape_string($mysqli, $rowOrderd['BKMGEDRAG']);
            $stdprijsincl = mysqli_real_escape_string($mysqli, $rowOrderd['STDPRIJSINCL']);
            $omschr = mysqli_real_escape_string($mysqli, $rowOrderd['OMSCHR']);

            $selectOrderdNew = "SELECT * FROM ORDERD_NEW WHERE ORDERNR=$ordernr AND LIJNNR=$lijnnr LIMIT 1";
            $resultsOrderdNew = $mysqli->query($selectOrderdNew);
            if ($resultsOrderdNew->num_rows > 0) {
                while ($rowOrderdNew = $resultsOrderdNew->fetch_assoc()) {
                    if ($rowOrderdNew == $rowOrderd) {
                    } else {
                        $updateOrderdNew = "UPDATE ORDERD_NEW SET ORDERBK='$orderbk', ORDERNR=$ordernr, LIJNNR=$lijnnr, TYPELN='$typeln', 
                        TYPELNINDEX='$typelnindex', ARTIKEL='$artikel', BENAMING='$benaming', AANTAL=$aantal, STDPRIJS=$stdprijs, KORTING1=$korting1, 
                        KORTING2=$korting2, EENHPR=$eenhpr, TOTAAL=$totaal, BTWKODE='$btwkode', VERKREK='$verkrek', MAGAZIJN='$magazijn', 
                        PROJECT='$project', EENHPRIV=$eenhpriv, TOTAALIV=$totaaliv, VALUTA='$valuta', KODEFC='$kodefc', KLANT='$klant', EENHPRINCL=$eenhprincl, 
                        EENHPRINCLIV=$eenhprincliv, KOSTPRIJS=$kostprijs, KOSTPRIJSIV=$kostprijsiv, AKWAARDE=$akwaarde, KODESAMENST='$kodesamenst', 
                        DATUM=STR_TO_DATE('$datum', '%Y,%m,%d'), GEHELEN=$gehelen, TPGEHEEL='$tpgeheel', AFGELEV=$afgelev, ONDERDELEN=$onderdelen, 
                        OFFERTEBK='$offertebk', OFFERTENR=$offertenr, OFFERTELIJN=$offertelijn, VOLLEDIG='$volledig', OFFERTETPLN='$offertetpln', 
                        GEVRLEVDAT=STR_TO_DATE('$gevrledat', '%Y,%m,%d'), BEVLEVDAT=STR_TO_DATE('$bevledat', '%Y,%m,%d'), DOORBESTEL='$doorbestel', 
                        LEVNRBESTEL='$levnrbestel', COMPERC=$comperc, COMMISSIEIV=$commissieiv, TOTCOMIV=$totcomiv, COLLIS=$collis, PALETTEN=$paletten, 
                        JOB='$job', SOORTPRIJS='$soortprijs', REFVORD='$refvord', REFNACALC='$refnacalc', GNBONKORTING='$gnbonkorting', HFDARTLIJNNR=$hfdartlijnnr, 
                        BKMVOLGNR=$bkmvolgnr, BKMGEDRAG='$bkmgedrag', STDPRIJSINCL=$stdprijsincl, OMSCHR='$omschr' WHERE ORDERNR=$ordernr AND LIJNNR=$lijnnr LIMIT 1";

                        if ($mysqli->query($updateOrderdNew) === TRUE) {
                            if ($rowOrderd != $rowOrderdNew) {
                                foreach ($rowOrderd as $x => $val) {
                                    if ($rowOrderdNew["$x"] != $val && $val == "") {
                                        $insertIntoLoggingOrderd = "INSERT INTO LOGGING_ORDERD (ORDERNR, LIJNNR, TypeChange, ColumnName, OldValue, NewValue, DatumTijd)
                                        VALUES ('$ordernr', $lijnnr, 'DELETE', '$x', '". mysqli_real_escape_string($mysqli, $rowOrderdNew["$x"]) ."', '', CURRENT_TIMESTAMP)";
                                        if ($mysqli->query($insertIntoLoggingOrderd) === TRUE) {
                                        } else {
                                            echo "<p>" . mysqli_error($mysqli) ; "</p>";
                                        }
                                    } elseif ($rowOrderdNew["$x"] != $val) {
                                        $insertIntoLoggingOrderd = "INSERT INTO LOGGING_ORDERD (ORDERNR, LIJNNR, TypeChange, ColumnName, OldValue, NewValue, DatumTijd)
                                        VALUES ('$ordernr', $lijnnr, 'UPDATE', '$x', '". mysqli_real_escape_string($mysqli, $rowOrderdNew["$x"]) ."', '". mysqli_real_escape_string($mysqli, $val) ."', CURRENT_TIMESTAMP)";
                                        if ($mysqli->query($insertIntoLoggingOrderd) === TRUE) {
                                        } else {
                                            echo "<p>" . mysqli_error($mysqli) ; "</p>";
                                        }
                                    }
                                }
                            }
                        } else {
                            echo "<p>" . mysqli_error($mysqli) ; "</p>";
                        }
                    }
                }
            } else {
                $insertIntoOrderdNew = "INSERT INTO ORDERD_NEW (ORDERBK, ORDERNR, LIJNNR, TYPELN, TYPELNINDEX, ARTIKEL, BENAMING, AANTAL, 
                STDPRIJS, KORTING1, KORTING2, EENHPR, TOTAAL, BTWKODE, VERKREK, MAGAZIJN, PROJECT, EENHPRIV, TOTAALIV, VALUTA, KODEFC, KLANT, 
                EENHPRINCL, EENHPRINCLIV, KOSTPRIJS, KOSTPRIJSIV, AKWAARDE, KODESAMENST, DATUM, GEHELEN, TPGEHEEL, AFGELEV, ONDERDELEN, 
                OFFERTEBK, OFFERTENR, OFFERTELIJN, VOLLEDIG, OFFERTETPLN, GEVRLEVDAT, BEVLEVDAT, DOORBESTEL, LEVNRBESTEL, COMPERC, COMMISSIEIV, 
                TOTCOMIV, COLLIS, PALETTEN, JOB, SOORTPRIJS, REFVORD, REFNACALC, GNBONKORTING, HFDARTLIJNNR, BKMVOLGNR, BKMGEDRAG, STDPRIJSINCL, 
                OMSCHR) VALUES ('$orderbk', $ordernr, $lijnnr, '$typeln', '$typelnindex', '$artikel', '$benaming', $aantal, $stdprijs, $korting1, 
                $korting2, $eenhpr, $totaal, '$btwkode', '$verkrek', '$magazijn', '$project', $eenhpriv, $totaaliv, '$valuta', '$kodefc', 
                '$klant', $eenhprincl, $eenhprincliv, $kostprijs, $kostprijsiv, $akwaarde, '$kodesamenst', STR_TO_DATE('$datum', '%Y,%m,%d'), 
                $gehelen, '$tpgeheel', $afgelev, $onderdelen, '$offertebk', $offertenr, $offertelijn, '$volledig', '$offertetpln', STR_TO_DATE('$gevrledat', '%Y,%m,%d'), 
                STR_TO_DATE('$bevledat', '%Y,%m,%d'), '$doorbestel', '$levnrbestel', $comperc, $commissieiv, $totcomiv, $collis, $paletten, 
                '$job', '$soortprijs', '$refvord', '$refnacalc', '$gnbonkorting', $hfdartlijnnr, $bkmvolgnr, '$bkmgedrag', $stdprijsincl, 
                '$omschr')";

                if ($mysqli->query($insertIntoOrderdNew) === TRUE) {
                    foreach ($rowOrderd as $x => $val) {
                        if (!empty($val)) {
                            $insertIntoLoggingOrderd = "INSERT INTO LOGGING_ORDERD (ORDERNR, LIJNNR, TypeChange, ColumnName, OldValue, NewValue, DatumTijd)
                            VALUES ('$ordernr', $lijnnr, 'INSERT', '$x', '', '". mysqli_real_escape_string($mysqli, $val) ."', CURRENT_TIMESTAMP)";
                            if ($mysqli->query($insertIntoLoggingOrderd) === TRUE) {
                            } else {
                                echo "<p>" . mysqli_error($mysqli) ; "</p>";
                            }
                        }
                    }
                } else {
                    echo "<p>" . mysqli_error($mysqli) ; "</p>";
                }
            }
            $updateOrderd = "UPDATE ORDERD SET KODESAMENST='1' WHERE ORDERNR=$ordernr AND LIJNNR=$lijnnr";
            if ($mysqli->query($updateOrderd) === TRUE) {
            } else {
                echo "<p>" . mysqli_error($mysqli) ; "</p>";
            }
        }
    } else {
        echo 'niets gebeurt';
    }
?>