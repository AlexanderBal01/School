<!DOCTYPE html>
<html>

<head>
    <title>E-Fact - Laminaatshop</title>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css" integrity="sha384-zCbKRCUGaJDkqS1kPbPd7TveP5iyJE0EjAuZQTgFLD2ylzuqKfdKlfG/eSrtxUkn" crossorigin="anonymous">
    <link rel="stylesheet" href="./Source/CSS/Artikel.css" type="text/css">

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>


</head>

<body>

    <h1>E-Fact - Laminaatshop</h1>
    <div class="container">
        <div class="row">
            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 d-flex justify-content-center">
            </div>
            <div class="col-lg-6 col-md-6 col-sm-12 zoeken">
                <form class="d-flex justify-content-start" id="Artikelnummerform" action="" onsubmit="return false">
                    <label class="input-margin-right"><strong>Artikelnummer: </strong></label>
                    <input class="input-margin-right input-margin-left" type="text" placeholder="Artikelnummer" id="InputArtikelnummer" name="InputArtikelnummer" onkeydown="" />
                    <a data-toggle="modal" href="#zoekModal" id="ArtikelZoeken" class="zoekvensteropenen input-margin-left">Zoeken</a>
                </form>

            </div>
        </div>
    </div>

    <div class="container">
        <div class="d-flex justify-content-center">
            <input type="button" value="Delete Row" onclick="DeleteRow('artikelsTabel')" />
        </div>
        <div class="d-flex justify-content-center">
            <table id="artikelsTabel">
                <tr>
                    <th></th>
                    <th>Artikel</th>
                    <th>Omschrijving</th>
                    <th>Aantal</th>
                    <th>Std Prijs</th>
                    <th>korting</th>
                    <th>Eenheidsprijs</th>
                    <th>Eenheid</th>
                    <th>BTW code</th>
                    <th>BTW %</th>
                    <th>Totaal ex. BTW</th>
                    <th>Totaal incl. BTW</th>
                    <th>Stocks</th>
                </tr>
            </table>
        </div>
    </div>

    <div id="test10223">

    </div>

    <div class="modal fade" id="zoekModal" tabindex="-1" aria-labelledby="zoekModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-scrollable modal-xl">
            <div class="modal-content">
                <div class="modal-header">
                    <div class="tab">
                        <button class="tablinks active" onclick="OpenModalMenuItem(event, 'Naam')">Naam</button>
                        <button class="tablinks" onclick="OpenModalMenuItem(event, 'Adres')">Adres</button>
                        <button class="tablinks" onclick="OpenModalMenuItem(event, 'Telefoonnummer')">Telefoonnummer</button>
                        <button class="tablinks" onclick="OpenModalMenuItem(event, 'Email')">Email</button>
                        <button class="tablinks" onclick="OpenModalMenuItem(event, 'BTW_nummer')">BTW nummer</button>
                    </div>
                </div>
                <div class="modal-body">
                    <div id="Naam" class="tabcontent active" style="display: block;">
                        <h3>Zoeken op naam</h3>
                        <form action="" onsubmit="return false">
                            <input type="text" placeholder="Naam" id="InputNaam" name="InputNaam" onkeyup="ShowCustomerOnNaam(this.value)" />
                        </form>
                        <div id="geavanceerdSelectedItemNaam">
                        </div>
                    </div>

                    <div id="Adres" class="tabcontent">
                        <h3>Zoeken op adres</h3>
                        <form action="" onsubmit="return false">
                            <input type="text" placeholder="Adres" id="InputStraat" name="InputStraat" onkeyup="AddStraatToAdres(this.value), ShowCustomerOnAdres()" />
                            <input type="text" placeholder="Postcode" id="InputPostcode" name="InputPostcode" onkeyup="AddPostcodeToAdres(this.value), ShowCustomerOnAdres()" />
                            <input type="text" placeholder="Gemeente" id="InputGemeente" name="InputGemeente" onkeyup="AddGemeenteToAdres(this.value), ShowCustomerOnAdres()" />
                        </form>
                        <div id="geavanceerdSelectedItemAdres">
                        </div>
                    </div>

                    <div id="Telefoonnummer" class="tabcontent">
                        <h3>Zoeken op telefoonnummer</h3>
                        <form action="" onsubmit="return false">
                            <input type="text" placeholder="telefoonnummer" id="Inputtelefoonnummer" name="Inputtelefoonnummer" onkeyup="ShowCustomerOnTelefoonnummer(this.value)" />
                        </form>
                        <div id="geavanceerdSelectedItemTelefoon">
                        </div>
                    </div>

                    <div id="Email" class="tabcontent">
                        <h3>Zoeken op email</h3>
                        <form action="" onsubmit="return false">
                            <input type="text" placeholder="email" id="Inputemail" name="Inputemail" onkeyup="ShowCustomerOnEmail(this.value)" />
                        </form>
                        <div id="geavanceerdSelectedItemEmail">
                        </div>
                    </div>

                    <div id="BTW_nummer" class="tabcontent">
                        <h3>Zoeken op BTW nummer</h3>
                        <form action="" onsubmit="return false">
                            <input type="text" placeholder="BTW nummer" id="InputBTW_nummer" name="InputBTW_nummer" value="BE" onkeyup="ShowCustomerOnBTWnummer(this.value)" />
                        </form>
                        <div id="geavanceerdSelectedItemBTW">
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="./Source/JS/ZoekArtikel.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
    
    <script src="./Source/JS/ArtikelTable.js"></script>

    <script>
        function OpenModalMenuItem(evt, item) {
            var i, tabcontent, tablinks;
            tabcontent = document.getElementsByClassName("tabcontent");
            for (i = 0; i < tabcontent.length; i++) {
                tabcontent[i].style.display = "none";
            }
            tablinks = document.getElementsByClassName("tablinks");
            for (i = 0; i < tablinks.length; i++) {
                tablinks[i].className = tablinks[i].className.replace(" active", "");
            }
            document.getElementById(item).style.display = "block";
            evt.currentTarget.className += " active";
        }
    </script>
</body>

</html>