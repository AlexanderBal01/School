<?php
    include_once $_SERVER['DOCUMENT_ROOT'] . "/config/config.php";
?>

<?php
    $selectOffd = "SELECT * FROM OFFD WHERE KODESAMENST <> '1'";
    $resultsOffd = $mysqli->query($selectOffd);
    if ($resultsOffd->num_rows > 0) {
        while ($rowOffd = $resultsOffd->fetch_assoc()) {
            $offertebk = mysqli_real_escape_string($mysqli, $rowOffd['OFFERTEBK']);
            $offertenr = mysqli_real_escape_string($mysqli, $rowOffd['OFFERTENR']);
            $lijnnr = mysqli_real_escape_string($mysqli, $rowOffd['LIJNNR']);
            $typeln = mysqli_real_escape_string($mysqli, $rowOffd['TYPELN']);
            $typelnindex = mysqli_real_escape_string($mysqli, $rowOffd['TYPELNINDEX']);
            $artikel = mysqli_real_escape_string($mysqli, $rowOffd['ARTIKEL']);
            $benaming = mysqli_real_escape_string($mysqli, $rowOffd['BENAMING']);
            $aantal = mysqli_real_escape_string($mysqli, $rowOffd['AANTAL']);
            $stdprijs = mysqli_real_escape_string($mysqli, $rowOffd['STDPRIJS']);
            $korting1 = mysqli_real_escape_string($mysqli, $rowOffd['KORTING1']);
            $korting2 = mysqli_real_escape_string($mysqli, $rowOffd['KORTING2']);
            $eenhpr = mysqli_real_escape_string($mysqli, $rowOffd['EENHPR']);
            $totaal = mysqli_real_escape_string($mysqli, $rowOffd['TOTAAL']);
            $btwkode = mysqli_real_escape_string($mysqli, $rowOffd['BTWKODE']);
            $verkrek = mysqli_real_escape_string($mysqli, $rowOffd['VERKREK']);
            $magazijn = mysqli_real_escape_string($mysqli, $rowOffd['MAGAZIJN']);
            $project = mysqli_real_escape_string($mysqli, $rowOffd['PROJECT']);
            $eenhpriv = mysqli_real_escape_string($mysqli, $rowOffd['EENHPRIV']);
            $totaaliv = mysqli_real_escape_string($mysqli, $rowOffd['TOTAALIV']);
            $valuta = mysqli_real_escape_string($mysqli, $rowOffd['VALUTA']);
            $kodefc = mysqli_real_escape_string($mysqli, $rowOffd['KODEFC']);
            $klant = mysqli_real_escape_string($mysqli, $rowOffd['KLANT']);
            $kostprijs = mysqli_real_escape_string($mysqli, $rowOffd['KOSTPRIJS']);
            $kostprijsiv = mysqli_real_escape_string($mysqli, $rowOffd['KOSTPRIJSIV']);
            $kodesamenst = mysqli_real_escape_string($mysqli, $rowOffd['KODESAMENST']);
            $gehelen = mysqli_real_escape_string($mysqli, $rowOffd['GEHELEN']);
            $onderdelen = mysqli_real_escape_string($mysqli, $rowOffd['ONDERDELEN']);
            $datum = mysqli_real_escape_string($mysqli, str_replace('-', ',', $rowOffd['DATUM']));
            $comperc = mysqli_real_escape_string($mysqli, $rowOffd['COMPERC']);
            $commissieiv = mysqli_real_escape_string($mysqli, $rowOffd['COMMISSIEIV']);
            $totcomiv = mysqli_real_escape_string($mysqli, $rowOffd['TOTCOMIV']);
            $collis = mysqli_real_escape_string($mysqli, $rowOffd['COLLIS']);
            $paletten = mysqli_real_escape_string($mysqli, $rowOffd['PALETTEN']);
            $soortprijs = mysqli_real_escape_string($mysqli, $rowOffd['SOORTPRIJS']);
            $refvord = mysqli_real_escape_string($mysqli, $rowOffd['REFVORD']);
            $refnacalc = mysqli_real_escape_string($mysqli, $rowOffd['REFNACALC']);
            $veld3 = mysqli_real_escape_string($mysqli, $rowOffd['VELD3']);
            $formule = mysqli_real_escape_string($mysqli, $rowOffd['FORMULE']);
            $eenheid = mysqli_real_escape_string($mysqli, $rowOffd['EENHEID']);
            $job = mysqli_real_escape_string($mysqli, $rowOffd['JOB']);
            $gnbonkorting = mysqli_real_escape_string($mysqli, $rowOffd['GNBONKORTING']);
            $hfdartlijnnr = mysqli_real_escape_string($mysqli, $rowOffd['HFDARTLIJNNR']);
            $bkmvolgnr = mysqli_real_escape_string($mysqli, $rowOffd['BKMVOLGNR']);
            $bkmgedrag = mysqli_real_escape_string($mysqli, $rowOffd['BKMGEDRAG']);
            $stdprijsincl = mysqli_real_escape_string($mysqli, $rowOffd['STDPRIJSINCL']);
            $eenhprincl = mysqli_real_escape_string($mysqli, $rowOffd['EENHPRINCL']);
            $eenhprincliv = mysqli_real_escape_string($mysqli, $rowOffd['EENHPRINCLIV']);
            $omschr = mysqli_real_escape_string($mysqli, $rowOffd['OMSCHR']);

            $selectOffdNew = "SELECT * FROM OFFD_NEW WHERE OFFERTENR=$offertenr AND LIJNNR=$lijnnr LIMIT 1";
            $resultsOffdNew = $mysqli->query($selectOffdNew);
            if ($resultsOffdNew->num_rows > 0 ) {
                while ($rowOffdNew = $resultsOffdNew->fetch_assoc()) {
                   if ($rowOffdNew == $rowOffd) {
                    } else {
                        $updateOffdNew = "UPDATE OFFD_NEW SET OFFERTEBK='$offertebk', OFFERTENR=$offertenr, LIJNNR=$lijnnr, TYPELN='$typeln', 
                        TYPELNINDEX='$typelnindex', ARTIKEL='$artikel', BENAMING='$benaming', AANTAL=$aantal, STDPRIJS=$stdprijs, KORTING1=$korting1, 
                        KORTING2=$korting2, EENHPR=$eenhpr, TOTAAL=$totaal, BTWKODE='$btwkode', VERKREK='$verkrek', MAGAZIJN='$magazijn', 
                        PROJECT='$project', EENHPRIV=$eenhpriv, TOTAALIV=$totaaliv, VALUTA='$valuta', KODEFC='$kodefc', KLANT='$klant', KOSTPRIJS=$kostprijs, 
                        KOSTPRIJSIV=$kostprijsiv, KODESAMENST='$kodesamenst', GEHELEN=$gehelen, ONDERDELEN=$onderdelen, DATUM=STR_TO_DATE('$datum', '%Y,%m,%d'), 
                        COMPERC=$comperc, COMMISSIEIV=$commissieiv, COMMISSIEIV=$totcomiv, COLLIS=$collis, PALETTEN=$paletten, SOORTPRIJS='$soortprijs', 
                        REFVORD='$refvord', REFNACALC='$refnacalc', VELD3=$veld3, FORMULE='$formule', EENHEID='$eenheid', JOB='$job', GNBONKORTING='$gnbonkorting', 
                        HFDARTLIJNNR=$hfdartlijnnr, BKMVOLGNR=$bkmvolgnr, BKMGEDRAG='$bkmgedrag', STDPRIJSINCL=$stdprijsincl, EENHPRINCL=$eenhprincl, 
                        EENHPRINCLIV=$eenhprincliv, OMSCHR='$omschr' WHERE OFFERTENR=$offertenr AND LIJNNR=$lijnnr LIMIT 1";

                        if ($mysqli->query($updateOffdNew) === TRUE) {
                            if ($rowOffd != $rowOffdNew) {
                                foreach ($rowOffd as $x => $val) {
                                    if ($rowOffdNew["$x"] != $val && $val == "") {
                                        $insertIntoLoggingOffd = "INSERT INTO LOGGING_OFFD (OFFERTENR, LIJNNR, TypeChange, ColumnName, OldValue, NewValue, DatumTijd)
                                        VALUES ('$offertenr', $lijnnr, 'DELETE', '$x', '". mysqli_real_escape_string($mysqli, $rowOffdNew["$x"]) ."', '', CURRENT_TIMESTAMP)";
                                        if ($mysqli->query($insertIntoLoggingOffd) === TRUE) {
                                        } else {
                                            echo "<p>" . mysqli_error($mysqli) ; "</p>";
                                        }
                                    } elseif ($rowOffdNew["$x"] != $val) {
                                        $insertIntoLoggingOffd = "INSERT INTO LOGGING_OFFD (OFFERTENR, LIJNNR, TypeChange, ColumnName, OldValue, NewValue, DatumTijd)
                                        VALUES ('$offertenr', $lijnnr, 'UPDATE', '$x', '". mysqli_real_escape_string($mysqli, $rowOffdNew["$x"]) ."', '". mysqli_real_escape_string($mysqli, $val) ."', CURRENT_TIMESTAMP)";
                                        if ($mysqli->query($insertIntoLoggingOffd) === TRUE) {
                                        } else {
                                            echo "<p>" . mysqli_error($mysqli) ; "</p>";
                                        }
                                    }
                                }
                            }
                        } else {
                            echo "<p>" . mysqli_error($mysqli) ; "</p>";
                        }
                    }
                }
            } else {
                $insertIntoOffdNew = "INSERT INTO OFFD_NEW (OFFERTEBK, OFFERTENR, LIJNNR, TYPELN, TYPELNINDEX, ARTIKEL, BENAMING, AANTAL, 
                STDPRIJS, KORTING1, KORTING2, EENHPR, TOTAAL, BTWKODE, VERKREK, MAGAZIJN, PROJECT, EENHPRIV, TOTAALIV, VALUTA, KODEFC, KLANT, 
                KOSTPRIJS, KOSTPRIJSIV, KODESAMENST, GEHELEN, ONDERDELEN, DATUM, COMPERC, COMMISSIEIV, TOTCOMIV, COLLIS, PALETTEN, SOORTPRIJS,
                REFVORD, REFNACALC, VELD3, FORMULE, EENHEID, JOB, GNBONKORTING, HFDARTLIJNNR, BKMVOLGNR, BKMGEDRAG, STDPRIJSINCL, EENHPRINCL, 
                EENHPRINCLIV, OMSCHR) VALUES ('$offertebk', $offertenr, $lijnnr, '$typeln', '$typelnindex', '$artikel', '$benaming', $aantal, 
                $stdprijs, $korting1, $korting2, $eenhpr, $totaal, '$btwkode', '$verkrek', '$magazijn', '$project', $eenhpriv, $totaaliv, 
                '$valuta', '$kodefc', '$klant', $kostprijs, $kostprijsiv, '$kodesamenst', $gehelen, $onderdelen, STR_TO_DATE('$datum', '%Y,%m,%d'), 
                $comperc, $commissieiv, $totcomiv, $collis, $paletten, '$soortprijs', '$refvord', '$refnacalc', $veld3, '$formule', '$eenheid', 
                '$job', '$gnbonkorting', $hfdartlijnnr, $bkmvolgnr, '$bkmgedrag', $stdprijsincl, $eenhprincl, $eenhprincliv, '$omschr')";

                if ($mysqli->query($insertIntoOffdNew) === TRUE) {
                    foreach ($rowOffd as $x => $val) {
                        if (!empty($val)) {
                            $insertIntoLoggingOffd = "INSERT INTO LOGGING_OFFD (OFFERTENR, LIJNNR, TypeChange, ColumnName, OldValue, NewValue, DatumTijd)
                            VALUES ('$offertenr', $lijnnr, 'INSERT', '$x', '', '". mysqli_real_escape_string($mysqli, $rowOffdNew["$x"]) ."', CURRENT_TIMESTAMP)";
                            if ($mysqli->query($insertIntoLoggingOffd) === TRUE) {
                            } else {
                                echo "<p>" . mysqli_error($mysqli) ; "</p>";
                            }
                        }
                    }
                } else {
                    echo "<p>" . mysqli_error($mysqli) ; "</p>";
                }
            }
            $updateOffd = "UPDATE OFFD SET KODESAMENST='1' WHERE OFFERTENR=$offertenr AND LIJNNR=$lijnnr";
            if ($mysqli->query($updateOffd) === TRUE) {
            } else {
                echo "<p>" . mysqli_error($mysqli) ; "</p>";
            }
        }
    } else {
        echo 'niets gebeurt';
    }
?>