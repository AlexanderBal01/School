<?php
    include_once $_SERVER['DOCUMENT_ROOT'] . "/config/config.php";
?>

<?php
    $selectOfferte = "SELECT * FROM OFFERTE WHERE GEWEST <> '1'";
    $resultsOfferte = $mysqli->query($selectOfferte);
    if ($resultsOfferte->num_rows > 0) {
        while ($rowOfferte = $resultsOfferte->fetch_assoc()) {
            $offertebk = mysqli_real_escape_string($mysqli, $rowOfferte['OFFERTEBK']);
            $offertenr = mysqli_real_escape_string($mysqli, $rowOfferte['OFFERTENR']);
            $kodefc = mysqli_real_escape_string($mysqli, $rowOfferte['KODEFC']);
            $datum = mysqli_real_escape_string($mysqli, str_replace('-', ',', $rowOfferte['DATUM']));
            $klant = mysqli_real_escape_string($mysqli, $rowOfferte['KLANT']);
            $lvanr = mysqli_real_escape_string($mysqli, $rowOfferte['LVANR']);
            $naam = mysqli_real_escape_string($mysqli, $rowOfferte['NAAM']);
            $adres1 = mysqli_real_escape_string($mysqli, $rowOfferte['ADRES1']);
            $adres2 = mysqli_real_escape_string($mysqli, $rowOfferte['ADRES2']);
            $adres3 = mysqli_real_escape_string($mysqli, $rowOfferte['ADRES3']);
            $land = mysqli_real_query($mysqli, $rowOfferte['LAND']);
            $postnr = mysqli_real_escape_string($mysqli, $rowOfferte['POSTNR']);
            $gemeente = mysqli_real_escape_string($mysqli, $rowOfferte['GEMEENTE']);
            $valuta = mysqli_real_escape_string($mysqli, $rowOfferte['VALUTA']);
            $koers = mysqli_real_escape_string($mysqli, $rowOfferte['KOERS']);
            $btwregime = mysqli_real_escape_string($mysqli, $rowOfferte['BTWREGIME']);
            $omschr = mysqli_real_escape_string($mysqli, $rowOfferte['OMSCHR']);
            $prijscat = mysqli_real_escape_string($mysqli, $rowOfferte['PRIJSCAT']);
            $globkort = mysqli_real_escape_string($mysqli, $rowOfferte['GLOBKORT']);
            $kortkont = mysqli_real_escape_string($mysqli, $rowOfferte['KORTKONT']);
            $kredbeperk = mysqli_real_escape_string($mysqli, $rowOfferte['KREDBEPERK']);
            $totexcl = mysqli_real_escape_string($mysqli, $rowOfferte['TOTEXCL']);
            $totexcliv = mysqli_real_escape_string($mysqli, $rowOfferte['TOTEXCLIV']);
            $totbtw = mysqli_real_escape_string($mysqli, $rowOfferte['TOTBTW']);
            $totbtwiv = mysqli_real_escape_string($mysqli, $rowOfferte['TOTBTWIV']);
            $tebet = mysqli_real_escape_string($mysqli, $rowOfferte['TEBET']);
            $tebetiv = mysqli_real_escape_string($mysqli, $rowOfferte['TEBETIV']);
            $gevrlevdat = mysqli_real_escape_string($mysqli, str_replace('-', ',', $rowOfferte['GEVRLEVDAT']));
            $bevledat = mysqli_real_escape_string($mysqli, str_replace('-', ',', $rowOfferte['BEVLEVDAT']));
            $persoon = mysqli_real_escape_string($mysqli, $rowOfferte['PERSOON']);
            $vertegenw = mysqli_real_escape_string($mysqli, $rowOfferte['VERTEGENW']);
            $vervwijze = mysqli_real_escape_string($mysqli, $rowOfferte['VERVWIJZE']);
            $transporteur = mysqli_real_escape_string($mysqli, $rowOfferte['TRANSPORTEUR']);
            $bedragkk = mysqli_real_escape_string($mysqli, $rowOfferte['BEDRAGKK']);
            $bedragkb = mysqli_real_escape_string($mysqli, $rowOfferte['BEDRAGKB']);
            $bedraggk = mysqli_real_escape_string($mysqli, $rowOfferte['BEDRAGGK']);
            $project = mysqli_real_escape_string($mysqli, $rowOfferte['PROJECT']);
            $ctpnr = mysqli_real_escape_string($mysqli, $rowOfferte['CTPNR']);
            $contactp = mysqli_real_escape_string($mysqli, $rowOfferte['CONTACTP']);
            $status = mysqli_real_escape_string($mysqli, $rowOfferte['STATUS']);
            $totcomiv = mysqli_real_escape_string($mysqli, $rowOfferte['TOTCOMIV']);
            $referentie = mysqli_real_escape_string($mysqli, $rowOfferte['REFERENTIE']);
            $isprokla = mysqli_real_escape_string($mysqli, $rowOfferte['ISPROKLA']);
            $gewest = mysqli_real_escape_string($mysqli, $rowOfferte['GEWEST']);
            $incoterm = mysqli_real_escape_string($mysqli, $rowOfferte['INCOTERM']);
            $creadatum = mysqli_real_escape_string($mysqli, str_replace('-', ',' , $rowOfferte['CREADATUM']));
            $creauur = mysqli_real_escape_string($mysqli, $rowOfferte['CREAUUR']);
            $creauser = mysqli_real_escape_string($mysqli, $rowOfferte['CREAUSER']);
            $wijzdatum = mysqli_real_escape_string($mysqli, str_replace('-', ',', $rowOfferte['WIJZDATUM']));
            $wijzuur = mysqli_real_escape_string($mysqli, $rowOfferte['WIJZUUR']);
            $wijzuser = mysqli_real_escape_string($mysqli, $rowOfferte['WIJZUSER']);
            $isverltar = mysqli_real_escape_string($mysqli, $rowOfferte['ISVERLTAR']);
            $taalkode = mysqli_real_escape_string($mysqli, $rowOfferte['TAALKODE']);
            $fase = mysqli_real_escape_string($mysqli, $rowOfferte['FASE']);
            $betvoorw = mysqli_real_escape_string($mysqli, $rowOfferte['BETVOORW']);
            $beslisdat = mysqli_real_escape_string($mysqli, str_replace('-', ',', $rowOfferte['BESLISDAT']));
            $slaagkans = mysqli_real_escape_string($mysqli, $rowOfferte['SLAAGKANS']);
            $isbtwincl = mysqli_real_escape_string($mysqli, $rowOfferte['ISBTWINCL']);

            $selectOfferteNew = "SELECT * FROM OFFERTE_NEW WHERE OFFERTENR=$offertenr LIMIT 1";
            $resultsOfferteNew = $mysqli->query($selectOfferteNew);
            if ($resultsOfferteNew->num_rows > 0) {
                while ($rowOfferteNew = $resultsOfferteNew->fetch_assoc()) {
                    if ($rowOfferte == $rowOfferteNew) {
                    } else {
                        $updateOfferteNew = "UPDATE OFFERTE_NEW SET OFFERTEBK='$offertebk', OFFERTENR=$offertenr, KODEFC='$kodefc', DATUM=STR_TO_DATE('$datum', '%Y,%m,%d'), 
                        KLANT='$klant', LVANR=$lvanr, NAAM='$naam', ADRES1='$adres1', ADRES2='$adres2', ADRES3='$adres3', LAND='$land', POSTNR='$postnr', 
                        GEMEENTE='$gemeente', VALUTA='$valuta', KOERS=$koers, BTWREGIME='$btwregime', OMSCHR='$omschr', PRIJSCAT='$prijscat', 
                        GLOBKORT=$globkort, KORTKONT=$kortkont, KREDBEPERK=$kredbeperk, TOTEXCL=$totexcl, TOTEXCLIV=$totexcliv, TOTBTW=$totbtw, 
                        TOTBTWIV=$totbtwiv, TEBET=$tebet, TEBETIV=$tebetiv, GEVRLEVDAT=STR_TO_DATE('$gevrlevdat', '%Y,%m,%d'), BEVLEVDAT=STR_TO_DATE('$bevledat', '%Y,%m,%d'), 
                        PERSOON='$persoon', VERTEGENW='$vertegenw', VERVWIJZE='$vervwijze', TRANSPORTEUR='$transporteur', BEDRAGKK=$bedragkk, 
                        BEDRAGKB=$bedragkb, BEDRAGGK=$bedraggk, PROJECT='$project', CTPNR=$ctpnr, CONTACTP='$contactp', STATUS='$status', TOTCOMIV=$totcomiv, 
                        REFERENTIE='$referentie', ISPROKLA='$isprokla', GEWEST='$gewest', INCOTERM='$incoterm', CREADATUM=STR_TO_DATE('$creadatum', '%Y,%m,%d'), 
                        CREAUUR='$creauur', CREAUSER='$creauser', WIJZDATUM=STR_TO_DATE('$wijzdatum', '%Y,%m,%d'), WIJZUUR='$wijzuur', WIJZUSER='$wijzuser', 
                        ISVERLTAR='$isverltar', TAALKODE='$taalkode', FASE='$fase', BETVOORW='$betvoorw', BESLISDAT=STR_TO_DATE('$beslisdat', '%Y,%m,%d'), 
                        SLAAGKANS=$slaagkans, ISBTWINCL='$isbtwincl'";

                        if ($mysqli->query($updateOfferteNew) === TRUE) {
                            if ($rowOfferte != $rowOfferteNew) {
                                foreach ($rowOfferte as $x => $val) {
                                    if ($rowOfferteNew["$x"] != $val && $val == "") {
                                        $insertIntoLoggingOfferte = "INSERT INTO LOGGING_OFFERTE (OFFERTENR, TypeChange, ColumnName, OldValue, 
                                        NewValue, DatumTijd) VALUES ('$offertenr', 'DELETE', '$x', '" . mysqli_real_escape_string($mysqli, $rowOfferteNew["$x"]) . "', 
                                        '', CURRENT_TIMESTAMP)";
                                        if ($mysqli->query($insertIntoLoggingOfferte) === TRUE) {
                                        } else {
                                            echo "<p>" . mysqli_error($mysqli) ; "</p>";
                                        }
                                    } elseif ($rowOfferteNew["$x"] != $val) {
                                        $insertIntoLoggingOfferte = "INSERT INTO LOGGING_OFFERTE (OFFERTENR, TypeChange, ColumnName, OldValue, 
                                        NewValue, DatumTijd) VALUES ('$offertenr', 'UPDATE', '$x', '" . mysqli_real_escape_string($mysqli, $rowOfferteNew["$x"]) . "', 
                                        '". mysqli_real_escape_string($mysqli, $val) ."', CURRENT_TIMESTAMP)";
                                        if ($mysqli->query($insertIntoLoggingOfferte) === TRUE) {
                                        } else {
                                            echo "<p>" . mysqli_error($mysqli) ; "</p>";
                                        }
                                    }
                                }
                            }
                        } else {
                            echo "<p>" . mysqli_error($mysqli) ; "</p>";
                        }
                    }
                }
            } else {
                $insertIntoOfferteNew = "INSERT INTO OFFERTE_NEW (OFFERTEBK, OFFERTENR, KODEFC, DATUM, KLANT, LVANR, NAAM, ADRES1, ADRES2, 
                ADRES3, LAND, POSTNR, GEMEENTE, VALUTA, KOERS, BTWREGIME, OMSCHR, PRIJSCAT, GLOBKORT, KORTKONT, KREDBEPERK, TOTEXCL, TOTEXCLIV, 
                TOTBTW, TOTBTWIV, TEBET, TEBETIV, GEVRLEVDAT, BEVLEVDAT, PERSOON, VERTEGENW, VERVWIJZE, TRANSPORTEUR, BEDRAGKK, BEDRAGKB, 
                BEDRAGGK, PROJECT, CTPNR, CONTACTP, STATUS, TOTCOMIV, REFERENTIE, ISPROKLA, GEWEST, INCOTERM, CREADATUM, CREAUUR, CREAUSER, 
                WIJZDATUM, WIJZUUR, WIJZUSER, ISVERLTAR, TAALKODE, FASE, BETVOORW, BESLISDAT, SLAAGKANS, ISBTWINCL) VALUES ('$offertebk', $offertenr, 
                '$kodefc', STR_TO_DATE('$datum', '%Y,%m,%d'), '$klant', $lvanr, '$naam', '$adres1', '$adres2', '$adres3', '$land', '$postnr', 
                '$gemeente', '$valuta', $koers, '$btwregime', '$omschr', '$prijscat', $globkort, $kortkont, $kredbeperk, $totexcl, $totexcliv, 
                $totbtw, $totbtwiv, $tebet, $tebetiv, STR_TO_DATE('$gevrlevdat', '%Y,%m,%d'), STR_TO_DATE('$bevledat', '%Y,%m,%d'), '$persoon', 
                '$vertegenw', '$vervwijze', '$transporteur', $bedragkk, $bedragkb, $bedraggk, '$project', $ctpnr, '$contactp', '$status', $totcomiv, 
                '$referentie', '$isprokla', '$gewest', '$incoterm', STR_TO_DATE('$creadatum', '%Y,%m,%d'), '$creauur', '$creauser', STR_TO_DATE('$wijzdatum', '%Y,%m,%d'), 
                '$wijzuur', '$wijzuser', '$isverltar', '$taalkode', '$fase', '$betvoorw', STR_TO_DATE('$beslisdat', '%Y,%m,%d'), $slaagkans, 
                '$isbtwincl')";

                if ($mysqli->query($insertIntoOfferteNew) === TRUE) {
                    foreach ($rowOfferte as $x => $val) {
                        if(!empty($val)) {
                            $insertIntoLoggingOfferte = "INSERT INTO LOGGING_OFFERTE (OFFERTENR, TypeChange, ColumnName, OldValue, NewValue, 
                            DatumTijd) VALUES ('$offertenr', 'INSERT', '$x', '',  '" . mysqli_real_escape_string($mysqli, $val) . "', CURRENT_TIMESTAMP)";
                            if ($mysqli->query($insertIntoLoggingOfferte) === TRUE) {
                            } else {
                                echo "<p>" . mysqli_error($mysqli) ; "</p>";
                            }
                        }
                    }
                } else {
                    echo "<p>" . mysqli_error($mysqli) ; "</p>";
                }
            }
            $updateOfferte = "UPDATE OFFERTE SET GEWEST='1' WHERE OFFERTENR=$offertenr";
            if ($mysqli->query($updateOfferte) === TRUE) {
            } else {
                echo "<p>" . mysqli_error($mysqli) ; "</p>";
            }
        }
    } else {
        echo 'niets gebeurt';
    }
?>