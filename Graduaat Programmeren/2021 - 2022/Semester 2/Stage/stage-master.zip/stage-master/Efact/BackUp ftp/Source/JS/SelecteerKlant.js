const SelecteerKlant = (klantnr) => {
    let naam = document.getElementById("Naam_" + klantnr).textContent;
    let adres = document.getElementById("Adres_" + klantnr).textContent;
    let gemeente = document.getElementById("Gemeente_" + klantnr).textContent;
    let postcode = document.getElementById("Postcode_" + klantnr).textContent;
    let telefoon = document.getElementById("Telefoon_" + klantnr).textContent;
    let email = document.getElementById("Email_" + klantnr).textContent;
    let btw = document.getElementById("BTW_" + klantnr).textContent;

    let voledigAdres = adres + ", " + postcode + " " + gemeente

    document.getElementById("InputKlant_Klantnummer").setAttribute("Value", klantnr);
    document.getElementById("Klantnaamselected").setAttribute("Value", naam);
    document.getElementById("Klantadresselected").setAttribute("Value", voledigAdres)
    document.getElementById("Klanttelefoonnrselected").setAttribute("Value", telefoon);
    document.getElementById("Klantbtwnummerselected").setAttribute("Value", email);
    document.getElementById("Klantemailselected").setAttribute("Value", btw);
}