<?php
    include_once $_SERVER['DOCUMENT_ROOT'] . "/config/config.php";
?>

<?php
if (isset($_POST)) {
    if (isset($_GET['artikelnr'])) {
        $getartikelnr = $_GET['artikelnr'];
        if (strpos($getartikelnr, '*')) {
            $getartikelnr = str_replace('*', '%', $getartikelnr);
            $selectInputArtikelNr = "SELECT ARTIKEL.*, ARTVP.* FROM ARTIKEL INNER JOIN ARTVP ON ARTIKEL.ARTNR = ARTVP.ARTNR WHERE ARTIKEL.ARTNR LIKE '$getartikelnr'";
            $results = $mysqli->query($selectInputArtikelNr);
            if ($results->num_rows > 0) {
                echo '<table class="test">';
                while ($row = $results->fetch_assoc()) { // hieronder definieren we de velden die we gaan nodig hebben (zoals naam, voornaam, etc)
                    $artikelNrDB = $row['ARTNR'];
                    $NaamDB = $row['ARTNAAM'];
                    $STDPrijsDB = $row['VP'];
                    $EenheidDB = $row['EENHEID'];
                    $BTW_CodeDB = $row['BTWKODE'];

                    echo '<tr>
                            <td class="test" id="ArtikelNummer_' . $artikelNrDB . '">' . $artikelNrDB . '</td>
                            <td class="test" id="Naam_' . $artikelNrDB . '">' . $NaamDB . '</td>
                            <td class="test" id="STDPrijs_' . $artikelNrDB . '">' . $STDPrijsDB . '</td>
                            <td class="test" id="Eenheid_' . $artikelNrDB . '">' . $EenheidDB . '</td>
                            <td class="test" id="BTWCODE_' . $artikelNrDB . '">' . $BTW_CodeDB . '</td>
                            <td class="test"><a class="selecteerklant" id="selectklant' . $artikelNrDB . '" onclick="SelecteerArtikel(\'' . $artikelNrDB . '\')" data-dismiss="modal">Selecteer</a></td>
                        </tr>';
                }
                echo '</table>';
            }
        } else {
            $selectInputArtikelNr = "SELECT ARTIKEL.*, ARTVP.* FROM ARTIKEL INNER JOIN ARTVP ON ARTIKEL.ARTNR = ARTVP.ARTNR WHERE ARTIKEL.ARTNR = '$getartikelnr' LIMIT 1";
            $results = $mysqli->query($selectInputArtikelNr);
            if ($results->num_rows > 0) {
                while ($row = $results->fetch_assoc()) { // hieronder definieren we de velden die we gaan nodig hebben (zoals naam, voornaam, etc)
                    $artikelNrDB = $row['ARTNR'];
                    $beschrijvingDB = $row['ARTNAAM'];
                    $STDPrijsDB = $row['VP'];
                    $EenheidDB = $row['EENHEID'];
                    $BTW_CodeDB = $row['BTWKODE'];
                }
                echo '
                        <input type="text" id="ArtikelNr_Input" name="ArtikelNr_Input" placeholder="Artikelnummer" value="' . $artikelNrDB . '" hidden/>
                        <input type="text" id="Omschrijving_Input" name="Omschrijving_Input" value="' . $beschrijvingDB . '" hidden/>
                        <input type="number" id="STD_Prijs_Input" name="STD_Prijs_Input" value="' . $STDPrijsDB . '" hidden/>
                        <input type="text" id="Eenheid_Input" name="Eenheid_Input" value="' . $EenheidDB . '" hidden/>
                        <input type="text" id="BTW_Code_Input" name="BTW_Code_Input" value="' . $BTW_CodeDB . '" hidden/>
                    ';
            }
        }
    } elseif (isset($_GET['artikelnrModal'])) {
        $getartikelnrModal = $_GET['artikelnrModal'];
        if (strpos($getartikelnrModal, '*')) {
            $getartikelnrModal = str_replace('*', '%', $getartikelnrModal);
            $selectInputArtikelNrModal = "SELECT ARTIKEL.*, ARTVP.* FROM ARTIKEL INNER JOIN ARTVP ON ARTIKEL.ARTNR = ARTVP.ARTNR WHERE ARTIKEL.ARTNR LIKE '$getartikelnrModal'";
            $results = $mysqli->query($selectInputArtikelNrModal);
            if ($results->num_rows > 0) {
                echo '<table class="test">';
                while ($row = $results->fetch_assoc()) { // hieronder definieren we de velden die we gaan nodig hebben (zoals naam, voornaam, etc)
                    $artikelNrDB = $row['ARTNR'];
                    $NaamDB = $row['ARTNAAM'];
                    $STDPrijsDB = $row['VP'];
                    $EenheidDB = $row['EENHEID'];
                    $BTW_CodeDB = $row['BTWKODE'];

                    echo '<tr>
                            <td class="test" id="ArtikelNummer_' . $artikelNrDB . '">' . $artikelNrDB . '</td>
                            <td class="test" id="Naam_' . $artikelNrDB . '">' . $NaamDB . '</td>
                            <td class="test" id="STDPrijs_' . $artikelNrDB . '">' . $STDPrijsDB . '</td>
                            <td class="test" id="Eenheid_' . $artikelNrDB . '">' . $EenheidDB . '</td>
                            <td class="test" id="BTWCODE_' . $artikelNrDB . '">' . $BTW_CodeDB . '</td>
                            <td class="test"><a class="selecteerklant" id="selectklant' . $artikelNrDB . '" onclick="SelecteerArtikel(\'' . $artikelNrDB . '\')" data-dismiss="modal">Selecteer</a></td>
                        </tr>';
                }
                echo '</table>';
            }
        } else {
            $selectInputArtikelNrModal = "SELECT ARTIKEL.*, ARTVP.* FROM ARTIKEL INNER JOIN ARTVP ON ARTIKEL.ARTNR = ARTVP.ARTNR WHERE ARTIKEL.ARTNR LIKE '%$getartikelnrModal%'";
            $results = $mysqli->query($selectInputArtikelNrModal);
            if ($results->num_rows > 0) {
                echo '<table class="test">';
                while ($row = $results->fetch_assoc()) { // hieronder definieren we de velden die we gaan nodig hebben (zoals naam, voornaam, etc)
                    $artikelNrDB = $row['ARTNR'];
                    $NaamDB = $row['ARTNAAM'];
                    $STDPrijsDB = $row['VP'];
                    $EenheidDB = $row['EENHEID'];
                    $BTW_CodeDB = $row['BTWKODE'];

                    echo '<tr>
                            <td class="test" id="ArtikelNummer_' . $artikelNrDB . '">' . $artikelNrDB . '</td>
                            <td class="test" id="Naam_' . $artikelNrDB . '">' . $NaamDB . '</td>
                            <td class="test" id="STDPrijs_' . $artikelNrDB . '">' . $STDPrijsDB . '</td>
                            <td class="test" id="Eenheid_' . $artikelNrDB . '">' . $EenheidDB . '</td>
                            <td class="test" id="BTWCODE_' . $artikelNrDB . '">' . $BTW_CodeDB . '</td>
                            <td class="test"><a class="selecteerklant" id="selectklant' . $artikelNrDB . '" onclick="SelecteerArtikel(\'' . $artikelNrDB . '\')" data-dismiss="modal">Selecteer</a></td>
                        </tr>';
                }
                echo '</table>';
            }
        }
    } elseif (isset($_GET['artikelNaamModal'])) {
        $getartikelNaamModal = $_GET['artikelNaamModal'];
        $selectInputArtikelNaamModal = "SELECT ARTIKEL.*, ARTVP.* FROM ARTIKEL INNER JOIN ARTVP ON ARTIKEL.ARTNR = ARTVP.ARTNR WHERE ARTIKEL.ARTNAAM LIKE '%$getartikelNaamModal%'";
        $results = $mysqli->query($selectInputArtikelNaamModal);
        if ($results->num_rows > 0) {
            echo '<table class="test">';
            while ($row = $results->fetch_assoc()) { // hieronder definieren we de velden die we gaan nodig hebben (zoals naam, voornaam, etc)
                $artikelNrDB = $row['ARTNR'];
                $NaamDB = $row['ARTNAAM'];
                $STDPrijsDB = $row['VP'];
                $EenheidDB = $row['EENHEID'];
                $BTW_CodeDB = $row['BTWKODE'];

                echo '<tr>
                        <td class="test" id="ArtikelNummer_' . $artikelNrDB . '">' . $artikelNrDB . '</td>
                        <td class="test" id="Naam_' . $artikelNrDB . '">' . $NaamDB . '</td>
                        <td class="test" id="STDPrijs_' . $artikelNrDB . '">' . $STDPrijsDB . '</td>
                        <td class="test" id="Eenheid_' . $artikelNrDB . '">' . $EenheidDB . '</td>
                        <td class="test" id="BTWCODE_' . $artikelNrDB . '">' . $BTW_CodeDB . '</td>
                        <td class="test"><a class="selecteerklant" id="selectklant' . $artikelNrDB . '" onclick="SelecteerArtikel(\'' . $artikelNrDB . '\')" data-dismiss="modal">Selecteer</a></td>
                    </tr>';
            }
            echo '</table>';
        }
    } else {
        echo "";
    }
}
?>