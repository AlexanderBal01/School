<?php
    // definiëren databank login gegevens in variabellen
    define('DB_SERVER', 'ID140239_testalexander.db.webhosting.be');
    define('DB_USERNAME', 'ID140239_testalexander');
    define('DB_PASSWORD', 'vB6zw03X392pGv550oPf');
    define('DB_NAME', 'ID140239_testalexander');
    //

    // Deze lijn zorgt voor de verbinding met de databank
    $mysqli = new mysqli(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);
    //

    // Controle of verbinding met databank is gelukt
    if($mysqli === false) {
        die("ERROR: Could not connect. " . $mysqli->connect_error);
    } elseif($mysqli === true) {
        echo "Connected with database.";
    }
    //

?>