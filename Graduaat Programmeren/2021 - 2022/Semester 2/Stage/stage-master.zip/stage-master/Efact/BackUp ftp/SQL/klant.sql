Create Table Klant (
    Klantnummer INT NOT NULL AUTO_INCREMENT,
    Naam VARCHAR(255) NOT NULL,
    Adres VARCHAR(500) NOT NULL,
    Gemeente VARCHAR(255) NOT NULL,
    Postcode INT NOT NULL,
    BTW_Nummer VARCHAR(255),
    TelefoonNummer VARCHAR(255) NOT NULL,
    Email Varchar(1000) NOT NULL,
    PRIMARY KEY (Klantnummer)
);