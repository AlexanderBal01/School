const AddNewRowToTable = (tableID) => {
    let table = document.getElementById(tableID);

    let rowCount = table.rows.length;
    let row = table.insertRow(rowCount);

    let cell0 = row.insertCell(0);
    let element0 = document.createElement("input");
    element0.type = "checkbox";
    element0.name="chkbox[]";
    cell0.appendChild(element0);

    let cell1 = row.insertCell(1);
    let form1 = document.createElement("form");
    form1.id = "Artikelnummerform";
    form1.setAttribute("action", "");
    form1.setAttribute("onsubmit", "return false")
    let input1 = document.createElement("input");
    input1.type = "text";
    input1.name = "ArtikelNr";
    input1.id = "ArtikelNr";
    input1.placeholder = "Artikelnummer";
    input1.setAttribute("onkeydown", "");
    form1.appendChild(input1);
    cell1.appendChild(form1);

    let cell2 = row.insertCell(2);

    let cell3 = row.insertCell(3);

    let cell4 = row.insertCell(4);

    let cell5 = row.insertCell(5);

    let cell6 = row.insertCell(6);

    let cell7 = row.insertCell(7);

    let cell8 = row.insertCell(8);

    let cell9 = row.insertCell(9);

    let cell10 = row.insertCell(10);

    let cell11 = row.insertCell(11);
    
    let cell12 = row.insertCell(12);
}