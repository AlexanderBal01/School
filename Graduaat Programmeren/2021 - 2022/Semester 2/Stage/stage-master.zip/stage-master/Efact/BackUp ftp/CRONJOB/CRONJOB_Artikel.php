<?php
    include_once $_SERVER['DOCUMENT_ROOT'] . "/config/config.php";
?>

<?php
    $selectArtikel = "SELECT * FROM ARTIKEL WHERE WEBAFBEELD <> 'UP'";
    $resultsArtikel = $mysqli->query($selectArtikel);
    if ($resultsArtikel->num_rows > 0) {
        while ($rowArtikel = $resultsArtikel->fetch_assoc()) {
            $artnr = mysqli_real_escape_string($mysqli, $rowArtikel['ARTNR']);
            $eankode = mysqli_real_escape_string($mysqli, $rowArtikel['EANKODE']);
            $artnaam = mysqli_real_escape_string($mysqli, $rowArtikel['ARTNAAM']);
            $verkrek = mysqli_real_escape_string($mysqli, $rowArtikel['VERKREK']);
            $btwkode = mysqli_real_escape_string($mysqli, $rowArtikel['BTWKODE']);
            $verpakking = mysqli_real_escape_string($mysqli, $rowArtikel['VERPAKKING']);
            $hfdgrp = mysqli_real_escape_string($mysqli, $rowArtikel['HFDGRP']);
            $subgrp = mysqli_real_escape_string($mysqli, $rowArtikel['SUBGRP']);
            $maglok = mysqli_real_escape_string($mysqli, $rowArtikel['MAGLOK']);
            $minvoorr = mysqli_real_escape_string($mysqli, $rowArtikel['MINVOORR']);
            $maxvoorr = mysqli_real_escape_string($mysqli, $rowArtikel['MAXVOORR']);
            $levserienr = mysqli_real_escape_string($mysqli, $rowArtikel['LEVSERIENR']);
            $klaserienr = mysqli_real_escape_string($mysqli, $rowArtikel['KLASERIENR']);
            $issamenst = mysqli_real_escape_string($mysqli, $rowArtikel['ISSAMENST']);
            $stockbeh = mysqli_real_escape_string($mysqli, $rowArtikel['STOCKBEH']);
            $netto = mysqli_real_escape_string($mysqli, $rowArtikel['NETTO']);
            $m3 = mysqli_real_escape_string($mysqli, $rowArtikel['M3']);
            $goedcode = mysqli_real_escape_string($mysqli, $rowArtikel['GOEDCODE']);
            $assortim = mysqli_real_escape_string($mysqli, $rowArtikel['ASSORTIM']);
            $pretik = mysqli_real_escape_string($mysqli, $rowArtikel['PRETIK']);
            $layoutetik = mysqli_real_escape_string($mysqli, $rowArtikel['LAYOUTETIK']);
            $kostprijs = mysqli_real_escape_string($mysqli, $rowArtikel['KOSTPRIJS']);
            $kpisprsam = mysqli_real_escape_string($mysqli, $rowArtikel['KPISPRSAM']);
            $leeggdart = mysqli_real_escape_string($mysqli, $rowArtikel['LEEGGDART']);
            $aankrek = mysqli_real_escape_string($mysqli, $rowArtikel['AANKREK']);
            $eenheid = mysqli_real_escape_string($mysqli, $rowArtikel['EENHEID']);
            $aankoopprijs = mysqli_real_escape_string($mysqli, $rowArtikel['AANKOOPPRIJS']);
            $gnkorting = mysqli_real_escape_string($mysqli, $rowArtikel['GNKORTING']);
            $ivk = mysqli_real_escape_string($mysqli, $rowArtikel['IVK']);
            $factorae = mysqli_real_escape_string($mysqli, $rowArtikel['FACTORAE']);
            $levnr = mysqli_real_escape_string($mysqli, $rowArtikel['LEVNR']);
            $eenhpersam = mysqli_real_escape_string($mysqli, $rowArtikel['EENHPERSAM']);
            $job = mysqli_real_escape_string($mysqli, $rowArtikel['JOB']);
            $creadatum = mysqli_real_escape_string($mysqli, str_replace('-', ',', $rowArtikel['CREADATUM']));
            $creauur = mysqli_real_escape_string($mysqli, $rowArtikel['CREAUUR']);
            $creauser = mysqli_real_escape_string($mysqli, $rowArtikel['CREAUSER']);
            $wijzdatum = mysqli_real_escape_string($mysqli, str_replace('-', ',', $rowArtikel['WIJZDATUM']));
            $wijzuur = mysqli_real_escape_string($mysqli, $rowArtikel['WIJZUUR']);
            $wijzuser = mysqli_real_escape_string($mysqli, $rowArtikel['WIJZUSER']);
            $web = mysqli_real_escape_string($mysqli, $rowArtikel['WEB']);
            $webafbeeld = mysqli_real_escape_string($mysqli, $rowArtikel['WEBAFBEELD']);
            $ntopklakaart = mysqli_real_escape_string($mysqli, $rowArtikel['NTOPKLAKAART']);
            $rechtomzet = mysqli_real_escape_string($mysqli, $rowArtikel['RECHTOMZET']);
            $gnbonkorting = mysqli_real_escape_string($mysqli, $rowArtikel['GNBONKORTING']);
            $artnrfab = mysqli_real_escape_string($mysqli, $rowArtikel['ARTNRFAB']);
            $landori = mysqli_real_escape_string($mysqli, $rowArtikel['LANDORI']);

            $selectArtikelNew = "SELECT * FROM ARTIKEL_NEW WHERE ARTNR='$artnr' LIMIT 1";
            $resultsArtikelNew = $mysqli->query($selectArtikelNew);
            if ($resultsArtikelNew->num_rows > 0) {
                while ($rowArtikelNew = $resultsArtikelNew->fetch_assoc()) {
                    if ($rowArtikel == $rowArtikelNew) {
                    } else {
                        $updateArtikelNew = "UPDATE ARTIKEL_NEW SET ARTNR='$artnr', EANKODE='$eankode', ARTNAAM='$artnaam', VERKREK='$verkrek', 
                        BTWKODE='$btwkode', VERPAKKING='$verpakking', HFDGRP='$hfdgrp', SUBGRP='$subgrp', MAGLOK='$maglok', MINVOORR=$minvoorr, 
                        MAXVOORR=$maxvoorr, LEVSERIENR='$levserienr', KLASERIENR='$klaserienr', ISSAMENST='$issamenst', STOCKBEH='$stockbeh', 
                        NETTO=$netto, M3=$m3, Goedcode='$goedcode', ASSORTIM='$assortim', PRETIK='$pretik', LAYOUTETIK='$layoutetik', KOSTPRIJS=$kostprijs, 
                        KPISPRSAM='$kpisprsam', LEEGGDART='$leeggdart', AANKREK='$aankrek', EENHEID='$eenheid', AANKOOPPRIJS=$aankoopprijs, 
                        GNKORTING='$gnkorting', IVK=$ivk, FACTORAE=$factorae, LEVNR='$levnr', EENHPERSAM=$eenhpersam, JOB='$job', CREADATUM=STR_TO_DATE('$creadatum', '%Y,%m,%d'), 
                        CREAUUR='$creauur', CREAUSER='$creauser', WIJZDATUM=STR_TO_DATE('$wijzdatum', '%Y,%m,%d'), WIJZUUR='$wijzuur', WIJZUSER='$wijzuser', 
                        WEB='$web', WEBAFBEELD='$webafbeeld', NTOPKLAKAART='$ntopklakaart', RECHTOMZET=$rechtomzet, GNBONKORTING='$gnbonkorting', 
                        ARTNRFAB='$artnrfab', LANDORI='$landori' WHERE ARTNR='$artnr' LIMIT 1";

                        if ($mysqli->query($updateArtikelNew) === TRUE) {
                            if ($rowArtikel != $rowArtikelNew) {
                                foreach ($rowArtikel as $x => $val) {
                                    if ($rowArtikelNew["$x"] != $val && $val == "") {
                                        $insertIntoLoggingArtikel = "INSERT INTO LOGGING_ARTIKEL (ARTNR, TypeChange, ColumnName, OldValue, NewValue, 
                                        DatumTijd) VALUES ('$artnr', 'DELETE', '$x', '". mysqli_real_escape_string($mysqli, $rowArtikelNew["$x"]) ."', '', CURRENT_TIMESTAMP)";
                                        if ($mysqli->query($insertIntoLoggingArtikel) === TRUE) {
                                        } else {
                                            echo "<p>" . mysqli_error($mysqli) ; "</p>";
                                        }
                                    } elseif ($rowArtikelNew["$x"] != $val) {
                                        $insertIntoLoggingArtikel = "INSERT INTO LOGGING_ARTIKEL (ARTNR, TypeChange, ColumnName, OldValue, NewValue, 
                                        DatumTijd) VALUES ('$artnr', 'UPDATE', '$x', '". mysqli_real_escape_string($mysqli, $rowArtikelNew["$x"]) ."', '". mysqli_real_escape_string($mysqli, $val) ."', CURRENT_TIMESTAMP)";
                                        if ($mysqli->query($insertIntoLoggingArtikel) === TRUE) {
                                        } else {
                                            echo "<p>" . mysqli_error($mysqli) ; "</p>";
                                        }
                                    }
                                }
                            }
                        } else {
                            echo "<p>" . mysqli_error($mysqli) ; "</p>";
                        }
                    }
                }
            } else {
                $insertIntoArtikelNew = "INSERT INTO ARTIKEL_NEW (ARTNR, EANKODE, ARTNAAM, VERKREK, BTWKODE, VERPAKKING, HFDGRP, SUBGRP, MAGLOK, 
                MINVOORR, MAXVOORR, LEVSERIENR, KLASERIENR, ISSAMENST, STOCKBEH, NETTO, M3, GOEDCODE, ASSORTIM, PRETIK, LAYOUTETIK, KOSTPRIJS, 
                KPISPRSAM, LEEGGDART, AANKREK, EENHEID, AANKOOPPRIJS, GNKORTING, IVK, FACTORAE, LEVNR, EENHPERSAM, JOB, CREADATUM, CREAUUR, CREAUSER, 
                WIJZDATUM, WIJZUUR, WIJZUSER, WEB, WEBAFBEELD, NTOPKLAKAART, RECHTOMZET, GNBONKORTING, ARTNRFAB, LANDORI) VALUES ('$artnr', 
                '$eankode', '$artnaam', '$verkrek', '$btwkode', '$verpakking', '$hfdgrp', '$subgrp', '$maglok', $minvoorr, $maxvoorr, '$levserienr', 
                '$klaserienr', '$issamenst', '$stockbeh', $netto, $m3, '$goedcode', '$assortim', '$pretik', '$layoutetik', $kostprijs, '$kpisprsam', 
                '$leeggdart', '$aankrek', '$eenheid', $aankoopprijs, '$gnkorting', $ivk, $factorae, '$levnr', $eenhpersam, '$job', STR_TO_DATE('$creadatum', '%Y,%m,%d'), 
                '$creauur', '$creauser', STR_TO_DATE('$wijzdatum', '%Y,%m,%d'), '$wijzuur', '$wijzuser', '$web', '$webafbeeld', '$ntopklakaart', $rechtomzet, 
                '$gnbonkorting', '$artnrfab', '$landori')";

                if ($mysqli->query($insertIntoArtikelNew) === TRUE) {
                    foreach ($rowArtikel as $x => $val) {
                        if (!empty($val)) {
                            $insertIntoLoggingArtikel = "INSERT INTO LOGGING_ARTIKEL (ARTNR, TypeChange, ColumnName, OldValue, NewValue, 
                            DatumTijd) VALUES ('$artnr', 'INSERT', '$x', '', '". mysqli_real_escape_string($mysqli, $val) ."', CURRENT_TIMESTAMP)";
                            if ($mysqli->query($insertIntoLoggingArtikel) === TRUE) {
                            } else {
                                echo "<p>" . mysqli_error($mysqli) ; "</p>";
                            }
                        }
                    }
                } else {
                    echo "<p>" . mysqli_error($mysqli) ; "</p>";
                }
            }
            $updateArtikel = "UPDATE ARTIKEL SET WEBAFBEELD='UP' WHERE ARTNR='$artnr'";
            if ($mysqli->query($updateArtikel) === TRUE) {
            } else {
                echo "<p>" . mysqli_error($mysqli) ; "</p>";
            }
        }
    } else {
        echo 'Niets gebeurt';
    }
?>