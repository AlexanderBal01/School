<?php
    include_once $_SERVER['DOCUMENT_ROOT'] . "/config/config.php";
?>

<?php
if (isset($_POST)) {
    if (isset($_GET['klantnr'])) {
        $getklantnr = $_GET['klantnr'];
        $postklantnummer = intval($getklantnr);
        $selectInputklantnummer = "SELECT * FROM KLANTEN WHERE NUMMER = $postklantnummer LIMIT 1";
        $results = $mysqli->query($selectInputklantnummer);
        if ($results->num_rows > 0) {
            while ($row = $results->fetch_assoc()) { // hieronder definieren we de velden die we gaan nodig hebben (zoals naam, voornaam, etc)
                $NaamDB = $row['NAAM'];
                $AdresDB = $row['ADRES2'];
                $GemeenteDB = $row['GEMEENTE'];
                $PostcodeDB = $row['POSTNR'];
                $TelefoonNummerDB = $row['TELEFOON2'];
                $EmailDB = $row['URL'];
                $BTW_NummerDB = $row['BTWNR'];
            }
            $voledigAdres = strval($AdresDB) . ", " . strval($PostcodeDB) . " " . $GemeenteDB;
            echo '<div class="container">
                        <div class="row">
                            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 d-flex justify-content-center">
                            </div>
                            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 d-flex justify-content-center">
                                <form class="w-100" action="" onsubmit="return false">
                                    <input type="text" class="w-100" id="naamselected" name="naam" value="' . $NaamDB . '" disabled>
                                </form>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 d-flex justify-content-center">
                            </div>
                            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 d-flex justify-content-center">
                                <form class="w-100" action="" onsubmit="return false">
                                    <input type="text" class="w-100" id="adresselected" name="adres" value="' . $voledigAdres . '" disabled>
                                </form>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 d-flex justify-content-center">
                            </div>
                            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 d-flex justify-content-center">
                                <form class="w-100" action="" onsubmit="return false">
                                    <input type="text" class="w-100" id="telefoonnrselected" name="telefoonnr" value="' . $TelefoonNummerDB . '" disabled>
                                </form>
                            </div>
                            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 d-flex justify-content-center">
                                <form class="w-100" action="" onsubmit="return false">
                                    <input type="text" class="w-100" id="btwnummerselected" name="btwnummer" value="' . $BTW_NummerDB . '" disabled>
                                </form>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 d-flex justify-content-center">
                            </div>
                            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 d-flex justify-content-center">
                                <form class="w-100" action="" onsubmit="return false">
                                    <input type="text" class="w-100" id="emailselected" name="email" value="' . $EmailDB . '" disabled>
                                </form>
                            </div>
                        </div>
                </div>';
        }
    } elseif (isset($_GET['klantNaam'])) {
        $postKlantNaam = $_GET['klantNaam'];
        $selectInputklantNaam = "SELECT * FROM KLANTEN WHERE NAAM LIKE '%" . $postKlantNaam . "%'";
        $results = $mysqli->query($selectInputklantNaam);
        if ($results->num_rows > 0) {
            echo '<table>';
            while ($row = $results->fetch_assoc()) {
                $klantnummerDB = $row['NUMMER'];
                $NaamDB = $row['NAAM'];
                $AdresDB = $row['ADRES2'];
                $GemeenteDB = $row['GEMEENTE'];
                $PostcodeDB = $row['POSTNR'];
                $TelefoonNummerDB = $row['TELEFOON2'];
                $EmailDB = $row['URL'];
                $BTW_NummerDB = $row['BTWNR'];

                echo '<tr>
                        <td id="Naam_' . $klantnummerDB . '">' . $NaamDB . '</td>
                        <td id="Adres_' . $klantnummerDB . '">' . $AdresDB . '</td>
                        <td id="Gemeente_' . $klantnummerDB . '">' . $GemeenteDB . '</td>
                        <td id="Postcode_' . $klantnummerDB . '">' . $PostcodeDB . '</td>
                        <td id="Telefoon_' . $klantnummerDB . '">' . $TelefoonNummerDB . '</td>
                        <td id="Email_' . $klantnummerDB . '">' . $EmailDB . '</td>
                        <td id="BTW_' . $klantnummerDB . '">' . $BTW_NummerDB . '</td>
                        <td><a class="selecteerklant" id="selectklant' . $klantnummerDB . '" onclick="SelecteerKlant(' . $klantnummerDB . ')" data-dismiss="modal">Selecteer</a></td>
                    </tr>';
            }
            echo '</table>';
        }
    } elseif (isset($_GET['klantAdres'])) {
        $postklantAdres = $_GET['klantAdres'];
        $arrayAdres = explode("$", $postklantAdres);
        $straat = $arrayAdres[0];
        $postcode = $arrayAdres[1];
        $gemeente = $arrayAdres[2];
        $selectInputklantAdres = "SELECT * FROM KLANTEN WHERE ADRES2 LIKE '%$straat%' AND POSTNR LIKE '%$postcode%' AND GEMEENTE LIKE '%$gemeente%'";
        $results = $mysqli->query($selectInputklantAdres);
        if ($results->num_rows > 0) {
            echo '<table>';
            while ($row = $results->fetch_assoc()) {
                $klantnummerDB = $row['NUMMER'];
                $NaamDB = $row['NAAM'];
                $AdresDB = $row['ADRES2'];
                $GemeenteDB = $row['GEMEENTE'];
                $PostcodeDB = $row['POSTNR'];
                $TelefoonNummerDB = $row['TELEFOON2'];
                $EmailDB = $row['URL'];
                $BTW_NummerDB = $row['BTWNR'];

                echo '<tr>
                <td id="Naam_' . $klantnummerDB . '">' . $NaamDB . '</td>
                <td id="Adres_' . $klantnummerDB . '">' . $AdresDB . '</td>
                <td id="Gemeente_' . $klantnummerDB . '">' . $GemeenteDB . '</td>
                <td id="Postcode_' . $klantnummerDB . '">' . $PostcodeDB . '</td>
                <td id="Telefoon_' . $klantnummerDB . '">' . $TelefoonNummerDB . '</td>
                <td id="Email_' . $klantnummerDB . '">' . $EmailDB . '</td>
                <td id="BTW_' . $klantnummerDB . '">' . $BTW_NummerDB . '</td>
                <td><a class="selecteerklant" id="selectklant' . $klantnummerDB . '" onclick="SelecteerKlant(' . $klantnummerDB . ')" data-dismiss="modal">Selecteer</a></td>
            </tr>';
            }
            echo '</table>';
        }
    } elseif (isset($_GET['telefoonnummer'])) {
        $postTelefoonnummer = $_GET['telefoonnummer'];
        $TelefoonNummer = substr($postTelefoonnummer, 1);
        $selectInputTelefoonnummer = "SELECT * FROM KLANTEN WHERE TELEFOON2 LIKE '%$TelefoonNummer%'";
        $results = $mysqli->query($selectInputTelefoonnummer);
        if ($results->num_rows > 0) {
            echo '<table>';
            while ($row = $results->fetch_assoc()) {
                $klantnummerDB = $row['NUMMER'];
                $NaamDB = $row['NAAM'];
                $AdresDB = $row['ADRES2'];
                $GemeenteDB = $row['GEMEENTE'];
                $PostcodeDB = $row['POSTNR'];
                $TelefoonNummerDB = $row['TELEFOON2'];
                $EmailDB = $row['URL'];
                $BTW_NummerDB = $row['BTWNR'];

                echo '<tr>
                        <td id="Naam_' . $klantnummerDB . '">' . $NaamDB . '</td>
                        <td id="Adres_' . $klantnummerDB . '">' . $AdresDB . '</td>
                        <td id="Gemeente_' . $klantnummerDB . '">' . $GemeenteDB . '</td>
                        <td id="Postcode_' . $klantnummerDB . '">' . $PostcodeDB . '</td>
                        <td id="Telefoon_' . $klantnummerDB . '">' . $TelefoonNummerDB . '</td>
                        <td id="Email_' . $klantnummerDB . '">' . $EmailDB . '</td>
                        <td id="BTW_' . $klantnummerDB . '">' . $BTW_NummerDB . '</td>
                        <td><a class="selecteerklant" id="selectklant' . $klantnummerDB . '" onclick="SelecteerKlant(' . $klantnummerDB . ')" data-dismiss="modal">Selecteer</a></td>
                    </tr>';
            }
            echo '</table>';
        }
    } elseif (isset($_GET['email'])) {
        $postEmail = $_GET['email'];
        $selectInputEmail = "SELECT * FROM KLANTEN WHERE URL LIKE '%" . $postEmail . "%'";
        $results = $mysqli->query($selectInputEmail);
        if ($results->num_rows > 0) {
            echo '<table>';
            while ($row = $results->fetch_assoc()) {
                $klantnummerDB = $row['NUMMER'];
                $NaamDB = $row['NAAM'];
                $AdresDB = $row['ADRES2'];
                $GemeenteDB = $row['GEMEENTE'];
                $PostcodeDB = $row['POSTNR'];
                $TelefoonNummerDB = $row['TELEFOON2'];
                $EmailDB = $row['URL'];
                $BTW_NummerDB = $row['BTWNR'];

                echo '<tr>
                        <td id="Naam_' . $klantnummerDB . '">' . $NaamDB . '</td>
                        <td id="Adres_' . $klantnummerDB . '">' . $AdresDB . '</td>
                        <td id="Gemeente_' . $klantnummerDB . '">' . $GemeenteDB . '</td>
                        <td id="Postcode_' . $klantnummerDB . '">' . $PostcodeDB . '</td>
                        <td id="Telefoon_' . $klantnummerDB . '">' . $TelefoonNummerDB . '</td>
                        <td id="Email_' . $klantnummerDB . '">' . $EmailDB . '</td>
                        <td id="BTW_' . $klantnummerDB . '">' . $BTW_NummerDB . '</td>
                        <td><a class="selecteerklant" id="selectklant' . $klantnummerDB . '" onclick="SelecteerKlant(' . $klantnummerDB . ')" data-dismiss="modal">Selecteer</a></td>
                    </tr>';
            }
            echo '</table>';
        }
    } elseif (isset($_GET['btwnummer'])) {
        $postbtwnummer = $_GET['btwnummer'];
        $btwnummer = substr($postbtwnummer, 2);
        $selectInputbtwnummer = "SELECT * FROM KLANTEN WHERE BTWNR LIKE '%" . $btwnummer . "%'";
        $results = $mysqli->query($selectInputbtwnummer);
        if ($results->num_rows > 0) {
            echo '<table>';
            while ($row = $results->fetch_assoc()) {
                $klantnummerDB = $row['NUMMER'];
                $NaamDB = $row['NAAM'];
                $AdresDB = $row['ADRES2'];
                $GemeenteDB = $row['GEMEENTE'];
                $PostcodeDB = $row['POSTNR'];
                $TelefoonNummerDB = $row['TELEFOON2'];
                $EmailDB = $row['URL'];
                $BTW_NummerDB = $row['BTWNR'];

                echo '<tr>
                        <td id="Naam_' . $klantnummerDB . '">' . $NaamDB . '</td>
                        <td id="Adres_' . $klantnummerDB . '">' . $AdresDB . '</td>
                        <td id="Gemeente_' . $klantnummerDB . '">' . $GemeenteDB . '</td>
                        <td id="Postcode_' . $klantnummerDB . '">' . $PostcodeDB . '</td>
                        <td id="Telefoon_' . $klantnummerDB . '">' . $TelefoonNummerDB . '</td>
                        <td id="Email_' . $klantnummerDB . '">' . $EmailDB . '</td>
                        <td id="BTW_' . $klantnummerDB . '">' . $BTW_NummerDB . '</td>
                        <td><a class="selecteerklant" id="selectklant' . $klantnummerDB . '" onclick="SelecteerKlant(' . $klantnummerDB . ')" data-dismiss="modal">Selecteer</a></td>
                    </tr>';
            }
            echo '</table>';
        }
    } else {
        echo "<h2>Geen Resultaten</h2>";
    }
}
?>