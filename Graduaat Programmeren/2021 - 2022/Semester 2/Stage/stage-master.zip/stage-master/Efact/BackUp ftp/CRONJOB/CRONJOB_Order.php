<?php
    include_once $_SERVER['DOCUMENT_ROOT'] . "/config/config.php";
?>

<?php
    $selectOrder = "SELECT * FROM ORDER WHERE ISVERLTAR <> '1'";
    $resultsOrder = $mysqli->query($selectOrder);
    if ($resultsOrder->num_rows > 0) {
        while ($rowOrder = $resultsOrder->fetch_assoc()) {
            $orderbk = mysqli_real_escape_string($mysqli, $rowOrder['ORDERBK']);
            $ordernr = mysqli_real_escape_string($mysqli, $rowOrder['ORDERNR']);
            $kodefc = mysqli_real_escape_string($mysqli, $rowOrder['KODEFC']);
            $datum = mysqli_real_escape_string($mysqli, str_replace('-', ',', $rowOrder['DATUM']));
            $klant = mysqli_real_escape_string($mysqli, $rowOrder['KLANT']);
            $lvanr = mysqli_real_escape_string($mysqli, $rowOrder['LVANR']);
            $naam = mysqli_real_escape_string($mysqli, $rowOrder['NAAM']);
            $adres1 = mysqli_real_escape_string($mysqli, $rowOrder['ADRES1']);
            $adres2 = mysqli_real_escape_string($mysqli, $rowOrder['ADRES2']);
            $adres3 = mysqli_real_escape_string($mysqli, $rowOrder['ADRES3']);
            $land = mysqli_real_escape_string($mysqli, $rowOrder['LAND']);
            $postnr = mysqli_real_escape_string($mysqli, $rowOrder['POSTNR']);
            $gemeente = mysqli_real_escape_string($mysqli, $rowOrder['GEMEENTE']);
            $valuta = mysqli_real_escape_string($mysqli, $rowOrder['VALUTA']);
            $koers = mysqli_real_escape_string($mysqli, $rowOrder['KOERS']);
            $btwregime = mysqli_real_escape_string($mysqli, $rowOrder['BTWREGIME']);
            $omschr = mysqli_real_escape_string($mysqli, $rowOrder['OMSCHR']);
            $prijscat = mysqli_real_escape_string($mysqli, $rowOrder['PRIJSCAT']);
            $globkort = mysqli_real_escape_string($mysqli, $rowOrder['GLOBKORT']);
            $kortkont = mysqli_real_escape_string($mysqli, $rowOrder['KORTKONT']);
            $kredbeperk = mysqli_real_escape_string($mysqli, $rowOrder['KREDBEPERK']);
            $totexcl = mysqli_real_escape_string($mysqli, $rowOrder['TOTEXCL']);
            $totexcliv = mysqli_real_escape_string($mysqli, $rowOrder['TOTEXCLIV']);
            $totbtw = mysqli_real_escape_string($mysqli, $rowOrder['TOTBTW']);
            $totbtwiv = mysqli_real_escape_string($mysqli, $rowOrder['TOTBTWIV']);
            $tebet = mysqli_real_escape_string($mysqli, $rowOrder['TEBET']);
            $tebetiv = mysqli_real_escape_string($mysqli, $rowOrder['TEBETIV']);
            $gevrlevdat = mysqli_real_escape_string($mysqli, str_replace('-', ',', $rowOrder['GEVRLEVDAT']));
            $bevlevdat = mysqli_real_escape_string($mysqli, str_replace('-', ',', $rowOrder['BEVLEVDAT']));
            $persoon = mysqli_real_escape_string($mysqli, $rowOrder['PERSOON']);
            $vertegenw = mysqli_real_escape_string($mysqli, $rowOrder['VERTEGENW']);
            $vervwijze = mysqli_real_escape_string($mysqli, $rowOrder['VERVWIJZE']);
            $transporteur = mysqli_real_escape_string($mysqli, $rowOrder['TRANSPORTEUR']);
            $bedragkk = mysqli_real_escape_string($mysqli, $rowOrder['BEDRAGKK']);
            $bedragkb = mysqli_real_escape_string($mysqli, $rowOrder['BEDRAGKB']);
            $bedraggk = mysqli_real_escape_string($mysqli, $rowOrder['BEDRAGGK']);
            $project = mysqli_real_escape_string($mysqli, $rowOrder['PROJECT']);
            $ctpnr = mysqli_real_escape_string($mysqli, $rowOrder['CTPNR']);
            $contactp = mysqli_real_escape_string($mysqli, $rowOrder['CONTACTP']);
            $status = mysqli_real_escape_string($mysqli, $rowOrder['STATUS']);
            $volledig = mysqli_real_escape_string($mysqli, $rowOrder['VOLLEDIG']);
            $totcomiv = mysqli_real_escape_string($mysqli, $rowOrder['TOTCOMIV']);
            $gewicht = mysqli_real_escape_string($mysqli, $rowOrder['GEWICHT']);
            $gewest = mysqli_real_escape_string($mysqli, $rowOrder['GEWEST']);
            $incoterm = mysqli_real_escape_string($mysqli, $rowOrder['INCOTERM']);
            $creadatum = mysqli_real_escape_string($mysqli, str_replace('-', ',', $rowOrder['CREADATUM']));
            $creauur = mysqli_real_escape_string($mysqli, $rowOrder['CREAUUR']);
            $creauser = mysqli_real_escape_string($mysqli, $rowOrder['CREAUSER']);
            $wijzdatum = mysqli_real_escape_string($mysqli, str_replace('-', ',', $rowOrder['WIJZDATUM']));
            $wijzuur = mysqli_real_escape_string($mysqli, $rowOrder['WIJZUUR']);
            $wijzuser = mysqli_real_escape_string($mysqli, $rowOrder['WIJZUSER']);
            $isverltar = mysqli_real_escape_string($mysqli, $rowOrder['ISVERLTAR']);
            $taalkode = mysqli_real_escape_string($mysqli, $rowOrder['TAALKODE']);
            $betvoorw = mysqli_real_escape_string($mysqli, $rowOrder['BETVOORW']);
            $isbtwincl = mysqli_real_escape_string($mysqli, $rowOrder['ISBTWINCL']);
            $referentie = mysqli_real_escape_string($mysqli, $rowOrder['REFERENTIE']);
            $fase = mysqli_real_escape_string($mysqli, $rowOrder['FASE']);

            $selectOrderNew = "SELECT * FROM ORDER_NEW WHERE ORDERNR=$ordernr";
            $resultsOrderNew = $mysqli->query($selectOrderNew);
            if ($resultsOrderNew->num_rows > 0) { 
                while ($rowOrderNew = $resultsOrderNew->fetch_assoc()) {
                    if ($rowOrder == $rowOrderNew) {
                    } else {
                        $updateOrderNew = "UPDATE ORDER_NEW SET ORDERBK='$orderbk', ORDERNR=$ordernr, KODEFC='$kodefc', DATUM=STR_TO_DATE('$datum', '%Y,%m,%d'), 
                        KLANT='$klant', LVANR=$lvanr, NAAM='$naam', ADRES1='$adres1', ADRES2='$adres2', ADRES3='$adres3', LAND='$land', POSTNR='$postnr', 
                        GEMEENTE='$gemeente', VALUTA='$valuta', KOERS=$koers, BTWREGIME='$btwregime', OMSCHR='$omschr', PRIJSCAT='$prijscat', 
                        GLOBKORT=$globkort, KORTKONT=$kortkont, KREDBEPERK=$kredbeperk, TOTEXCL=$totexcl, TOTEXCLIV=$totexcliv, TOTBTW=$totbtw, 
                        TOTBTWIV=$totbtwiv, TEBET=$tebet, TEBETIV=$tebetiv, GEVRLEVDAT=STR_TO_DATE('$gevrlevdat', '%Y,%m,%d'), BEVLEVDAT=STR_TO_DATE('$bevlevdat', '%Y,%m,%d'), 
                        PERSOON='$persoon', VERTEGENW='$vertegenw', VERVWIJZE='$vervwijze', TRANSPORTEUR='$transporteur', BEDRAGKK=$bedragkk, 
                        BEDRAGKB=$bedragkb, BEDRAGGK=$bedraggk, PROJECT='$project', CTPNR=$ctpnr, CONTACTP='$contactp', STATUS='$status', 
                        VOLLEDIG='$volledig', TOTCOMIV=$totcomiv, GEWICHT=$gewicht, GEWEST='$gewest', INCOTERM='$incoterm', CREADATUM=STR_TO_DATE('$creadatum', '%Y,%m,%d'), 
                        CREAUUR='$creauur', CREAUSER='$creauser', WIJZDATUM=STR_TO_DATE('$wijzdatum', '%Y,%m,%d'), WIJZUUR='$wijzuur', WIJZUSER='$wijzuser', 
                        ISVERLTAR='$isverltar', TAALKODE='$taalkode', BETVOORW='$betvoorw', ISBTWINCL='$isbtwincl', REFERENTIE='$referentie', FASE='$fase'";

                        if ($mysqli->query($updateOrderNew) === TRUE) {
                            if ($rowOrder != $rowOrderNew) {
                                foreach ($rowOrder as $x => $val) {
                                    if ($rowOrderNew["$x"] != $val && $val == "") {
                                        $insertIntoLoggingOrder = "INSERT INTO LOGGING_ORDER (ORDERNR, TypeChange, ColumnName, OldValue, 
                                        NewValue, DatumTijd) VALUES ('$ordernr', 'DELETE', '$x', '" . mysqli_real_escape_string($mysqli, $rowOrderNew["$x"]) . "', 
                                        '', CURRENT_TIMESTAMP)";
                                        if ($mysqli->query($insertIntoLoggingOrder) === TRUE) {
                                        } else {
                                            echo "<p>" . mysqli_error($mysqli) ; "</p>";
                                        }
                                    } elseif ($rowOrderNew["$x"] != $val) {
                                        $insertIntoLoggingOrder = "INSERT INTO LOGGING_ORDER (ORDERNR, TypeChange, ColumnName, OldValue, 
                                        NewValue, DatumTijd) VALUES ('$ordernr', 'UPDATE', '$x', '" . mysqli_real_escape_string($mysqli, $rowOrderNew["$x"]) . "', 
                                        '". mysqli_real_escape_string($mysqli, $val) ."', CURRENT_TIMESTAMP)";
                                        if ($mysqli->query($insertIntoLoggingOrder) === TRUE) {
                                        } else {
                                            echo "<p>" . mysqli_error($mysqli) ; "</p>";
                                        }
                                    }
                                }
                            }
                        } else {
                            echo "<p>" . mysqli_error($mysqli) ; "</p>";
                        }
                    }
                }
            } else {
                $insertIntoOrderNew = "INSERT INTO ORDER_NEW (ORDERBK, ORDERNR, KODEFC, DATUM, KLANT, LVANR, NAAM, ADRES1, ADRES2, ADRES3, 
                LAND, POSTNR, GEMEENTE, VALUTA, KOERS, BTWREGIME, OMSCHR, PRIJSCAT, GLOBKORT, KORTKONT, KREDBEPERK, TOTEXCL, TOTEXCLIV, TOTBTW, 
                TOTBTWIV, TEBET, TEBETIV, GEVRLEVDAT, BEVLEVDAT, PERSOON, VERTEGENW, VERVWIJZE, TRANSPORTEUR, BEDRAGKK, BEDRAGKB, BEDRAGGK, 
                PROJECT, CTPNR, CONTACTP, STATUS, VOLLEDIG, TOTCOMIV, GEWICHT, GEWEST, INCOTERM, CREADATUM, CREAUUR, CREAUSER, WIJZDATUM, WIJZUUR, 
                WIJZUSER, ISVERLTAR, TAALKODE, BETVOORW, ISBTWINCL, REFERENTIE, FASE) VALUES ('$orderbk', $ordernr, '$kodefc', STR_TO_DATE('$datum', '%Y,%m,%d'), 
                '$klant', $lvanr, '$naam', '$adres1', '$adres2', '$adres3', '$land', '$postnr', '$gemeente', '$valuta', $koers, '$btwregime', 
                '$omschr', '$prijscat', $globkort, $kortkont,   $kredbeperk, $totexcl, $totexcliv, $totbtw, $totbtwiv, $tebet, $tebetiv, STR_TO_DATE('$gevrlevdat', '%Y,%m,%d'), 
                STR_TO_DATE('$bevlevdat', '%Y,%m,%d'), '$persoon', '$vertegenw', '$vervwijze', '$transporteur', $bedragkk, $bedragkb, $bedraggk, 
                '$project', $ctpnr, '$contactp', '$status', '$volledig', $totcomiv, $gewicht, '$gewest', '$incoterm', STR_TO_DATE('$creadatum', '%Y,%m,%d'), 
                '$creauur', '$creauser', STR_TO_DATE('$wijzdatum', '%Y,%m,%d'), '$wijzuur', '$wijzuser', '$isverltar', '$taalkode', '$betvoorw', 
                '$isbtwincl', '$referentie', '$fase')";

                if ($mysqli->query($insertIntoOrderNew) === TRUE) {
                    foreach ($rowOrder as $x => $val) {
                        if(!empty($val)) {
                            $insertIntoLoggingOrder = "INSERT INTO LOGGING_ORDER (ORDERNR, TypeChange, ColumnName, OldValue, 
                            NewValue, DatumTijd) VALUES ('$ordernr', 'INSERT', '$x', '', 
                            '". mysqli_real_escape_string($mysqli, $val) ."', CURRENT_TIMESTAMP)";
                            if ($mysqli->query($insertIntoLoggingOrder) === TRUE) {
                            } else {
                                echo "<p>" . mysqli_error($mysqli) ; "</p>";
                            }
                        }
                    }
                } else { 
                    echo "<p>" . mysqli_error($mysqli) ; "</p>";
                }
            }
            $updateOrder = "UPDATE ORDER SET ISVERLTAR='1' WHERE ORDERNR=$ordernr";
            if ($mysqli->query($updateOrder) === TRUE) {
            } else {
                echo "<p>" . mysqli_error($mysqli) ; "</p>";
            }
        }
    } else {
        echo 'niets gebeurt';
    }
?>