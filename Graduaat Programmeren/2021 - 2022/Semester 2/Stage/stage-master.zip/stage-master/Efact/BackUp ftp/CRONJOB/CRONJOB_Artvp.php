<?php
    include_once $_SERVER['DOCUMENT_ROOT'] . "/config/config.php";
?>

<?php
    $selectArtvp = "SELECT * FROM ARTVP WHERE WERK <> 1";
    $resultsArtvp = $mysqli->query($selectArtvp);
    if ($resultsArtvp->num_rows > 0) {
        while ($rowArtvp = $resultsArtvp->fetch_assoc()) {
            $artnr = mysqli_real_escape_string($mysqli, $rowArtvp['ARTNR']);
            $valuta = mysqli_real_escape_string($mysqli, $rowArtvp['VALUTA']);
            $prijscat = mysqli_real_escape_string($mysqli, $rowArtvp['PRIJSCAT']);
            $vanaf = mysqli_real_escape_string($mysqli, $rowArtvp['VANAF']);
            $winst = mysqli_real_escape_string($mysqli, $rowArtvp['WINST']);
            $vp = mysqli_real_escape_string($mysqli, $rowArtvp['VP']);
            $vpincl = mysqli_real_escape_string($mysqli, $rowArtvp['VPINCL']);
            $werk = mysqli_real_escape_string($mysqli, $rowArtvp['WERK']);
            $verpakking = mysqli_real_escape_string($mysqli, $rowArtvp['VERPAKKING']);

            $selectArtvpNew = "SELECT * FROM ARTVP_NEW WHERE ARTNR='$artnr' LIMIT 1";
            $resultsArtvpNew = $mysqli->query($selectArtvpNew);
            if ($resultsArtvpNew->num_rows > 0) {
                while ($rowArtvpNew = $resultsArtvpNew->fetch_assoc()) {
                    if ($rowArtvp == $rowArtvpNew) {
                    } else {
                        $updateArtvpNew = "UPDATE ARTVP_NEW SET ARTNR='$artnr', VALUTA='$valuta', PRIJSCAT='$prijscat', VANAF=$vanaf, WINST=$winst, 
                        VP=$vp, VPINCL=$vpincl, WERK=$werk, VERPAKKING=$verpakking WHERE ARTNR='$artnr' LIMIT 1";

                        if ($mysqli->query($updateArtvpNew) === TRUE) {
                            if ($rowArtvp != $rowArtvpNew) {
                                foreach ($rowArtvp as $x => $val) {
                                    if ($rowArtvpNew["$x"] != $val && $val == "") {
                                        $insertIntoLoggingArtvp = "INSERT INTO LOGGING_ARTVP (ARTNR, TypeChange, ColumnName, OldValue, NewValue, 
                                        DatumTijd) VALUES ('$artnr', 'DELETE', '$x', '". mysqli_real_escape_string($mysqli, $rowArtvpNew["$x"]) ."', '', CURRENT_TIMESTAMP)";
                                        if ($mysqli->query($insertIntoLoggingArtvp) === TRUE) {
                                        } else {
                                            echo "<p>" . mysqli_error($mysqli) ; "</p>";
                                        }
                                    } elseif ($rowArtvpNew["$x"] != $val) {
                                        $insertIntoLoggingArtvp = "INSERT INTO LOGGING_ARTVP (ARTNR, TypeChange, ColumnName, OldValue, NewValue, 
                                        DatumTijd) VALUES ('$artnr', 'UPDATE', '$x', '". mysqli_real_escape_string($mysqli, $rowArtikelNew["$x"]) ."', '". mysqli_real_escape_string($mysqli, $val) ."', CURRENT_TIMESTAMP)";
                                        if ($mysqli->query($insertIntoLoggingArtvp) === TRUE) {
                                        } else {
                                            echo "<p>" . mysqli_error($mysqli) ; "</p>";
                                        }
                                    }
                                }
                            }
                        } else {
                            echo "<p>" . mysqli_error($mysqli) ; "</p>";
                        }
                    }
                }
            } else {
                $insertIntoArtvpNew = "INSERT INTO ARTVP_NEW (ARTNR, VALUTA, PRIJSCAT, VANAF, WINST, VP, VPINCL, WERK, VERPAKKING) VALUES
                ('$artnr', '$valuta', '$prijscat', $vanaf, $winst, $vp, $vpincl, $werk, $verpakking)";

                if ($mysqli-> query($insertIntoArtvpNew) === TRUE) {
                    foreach ($rowArtvp as $x => $val) {
                        if (!empty($val)) {
                            $insertIntoLoggingArtvp = "INSERT INTO LOGGING_ARTVP (ARTNR, TypeChange, ColumnName, OldValue, NewValue, 
                            DatumTijd) VALUES ('$artnr', 'INSERT', '$x', '', '". mysqli_real_escape_string($mysqli, $val) ."', CURRENT_TIMESTAMP)";
                            if ($mysqli->query($insertIntoLoggingArtvp) === TRUE) {
                            } else {
                                echo "<p>" . mysqli_error($mysqli) ; "</p>";
                            }
                        }
                    }
                } else {
                    echo "<p>" . mysqli_error($mysqli) ; "</p>";
                }
            }

            $updateArtvp = "UPDATE ARTVP SET WERK=1 WHERE ARTNR='$artnr'";
            if ($mysqli->query($updateArtvp) === TRUE) {
            } else {
                echo "<p>" . mysqli_error($mysqli) ; "</p>";
            }
        }
    } else {
        echo 'niets gebeurt';
    }
?>