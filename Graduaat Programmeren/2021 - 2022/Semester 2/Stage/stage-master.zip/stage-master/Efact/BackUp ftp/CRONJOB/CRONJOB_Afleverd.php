<?php
    include_once $_SERVER['DOCUMENT_ROOT'] . "/config/config.php";
?>

<?php
    $selectAfleverd = "SELECT * FROM AFLEVERD WHERE LANDORI <> 'UP'";
    $resultsAfleverd = $mysqli->query($selectAfleverd);
    if ($resultsAfleverd->num_rows > 0) {
        while ($rowAfleverd = $resultsAfleverd->fetch_assoc()) {
            $afleverbk = mysqli_real_escape_string($mysqli, $rowAfleverd['AFLEVERBK']);
            $aflevernr = mysqli_real_escape_string($mysqli, $rowAfleverd['AFLEVERNR']);
            $lijnnr = mysqli_real_escape_string($mysqli, $rowAfleverd['LIJNNR']);
            $typeln = mysqli_real_escape_string($mysqli, $rowAfleverd['TYPELN']);
            $typelnindex = mysqli_real_escape_string($mysqli, $rowAfleverd['TYPELNINDEX']);
            $artikel = mysqli_real_escape_string($mysqli, $rowAfleverd['ARTIKEL']);
            $benaming = mysqli_real_escape_string($mysqli, $rowAfleverd['BENAMING']);
            $aantal = mysqli_real_escape_string($mysqli, $rowAfleverd['AANTAL']);
            $stdprijs = mysqli_real_escape_string($mysqli, $rowAfleverd['STDPRIJS']);
            $korting1 = mysqli_real_escape_string($mysqli, $rowAfleverd['KORTING1']);
            $korting2 = mysqli_real_escape_string($mysqli, $rowAfleverd['KORTING2']);
            $eenhpr = mysqli_real_escape_string($mysqli, $rowAfleverd['EENHPR']);
            $totaal = mysqli_real_escape_string($mysqli, $rowAfleverd['TOTAAL']);
            $btwkode = mysqli_real_escape_string($mysqli, $rowAfleverd['BTWKODE']);
            $verkrek = mysqli_real_escape_string($mysqli, $rowAfleverd['VERKREK']);
            $magazijn = mysqli_real_escape_string($mysqli, $rowAfleverd['MAGAZIJN']);
            $project = mysqli_real_escape_string($mysqli, $rowAfleverd['PROJECT']);
            $eenhpriv = mysqli_real_escape_string($mysqli, $rowAfleverd['EENHPRIV']);
            $totaaliv = mysqli_real_escape_string($mysqli, $rowAfleverd['TOTAALIV']);
            $valuta = mysqli_real_escape_string($mysqli, $rowAfleverd['VALUTA']);
            $kodefc = mysqli_real_escape_string($mysqli, $rowAfleverd['KODEFC']);
            $klant = mysqli_real_escape_string($mysqli, $rowAfleverd['KLANT']);
            $eenhprincl = mysqli_real_escape_string($mysqli, $rowAfleverd['EENHPRINCL']);
            $eenhprincliv = mysqli_real_escape_string($mysqli, $rowAfleverd['EENHPRINCLIV']);
            $kostprijs = mysqli_real_escape_string($mysqli, $rowAfleverd['KOSTPRIJS']);
            $kostprijsiv = mysqli_real_escape_string($mysqli, $rowAfleverd['KOSTPRIJSIV']);
            $akwaarde = mysqli_real_escape_string($mysqli, $rowAfleverd['AKWAARDE']);
            $kodesamenst = mysqli_real_escape_string($mysqli, $rowAfleverd['KODESAMENST']);
            $datum = mysqli_real_escape_string($mysqli, str_replace('-', ',', $rowAfleverd['DATUM']));
            $stfakt = mysqli_real_escape_string($mysqli, $rowAfleverd['STFAKT']);
            $gehelen = mysqli_real_escape_string($mysqli, $rowAfleverd['GEHELEN']);
            $onderdelen = mysqli_real_escape_string($mysqli, $rowAfleverd['ONDERDELEN']);
            $dagboek = mysqli_real_escape_string($mysqli, $rowAfleverd['DAGBOEK']);
            $boekjaar = mysqli_real_escape_string($mysqli, $rowAfleverd['BOEKJAAR']);
            $faktnr = mysqli_real_escape_string($mysqli, $rowAfleverd['FAKTNR']);
            $faktdat = mysqli_real_escape_string($mysqli, str_replace('-', ',', $rowAfleverd['FAKTDAT']));
            $vervdat = mysqli_real_escape_string($mysqli, str_replace('-', ',', $rowAfleverd['VERVDAT']));
            $orderbk = mysqli_real_escape_string($mysqli, $rowAfleverd['ORDERBK']);
            $ordernr = mysqli_real_escape_string($mysqli, $rowAfleverd['ORDERNR']);
            $ordertpln = mysqli_real_escape_string($mysqli, $rowAfleverd['ORDERTPLN']);
            $orderlijn = mysqli_real_escape_string($mysqli, $rowAfleverd['ORDERLIJN']);
            $offertebk = mysqli_real_escape_string($mysqli, $rowAfleverd['OFFERTEBK']);
            $offertenr = mysqli_real_escape_string($mysqli, $rowAfleverd['OFFERTENR']);
            $offertelijn = mysqli_real_escape_string($mysqli, $rowAfleverd['OFFERTELIJN']);
            $offertetpln = mysqli_real_escape_string($mysqli, $rowAfleverd['OFFERTETPLN']);
            $ordvolledig = mysqli_real_escape_string($mysqli, $rowAfleverd['ORDVOLLEDIG']);
            $job = mysqli_real_escape_string($mysqli, $rowAfleverd['JOB']);
            $collis = mysqli_real_escape_string($mysqli, $rowAfleverd['COLLIS']);
            $paletten = mysqli_real_escape_string($mysqli, $rowAfleverd['PALETTEN']);
            $histdat = mysqli_real_escape_string($mysqli, str_replace('-', ',', $rowAfleverd['HISTDAT']));
            $historiek = mysqli_real_escape_string($mysqli, $rowAfleverd['HISTORIEK']);
            $comperc = mysqli_real_escape_string($mysqli, $rowAfleverd['COMPERC']);
            $commissieiv = mysqli_real_escape_string($mysqli, $rowAfleverd['COMMISSIEIV']);
            $totcomiv = mysqli_real_escape_string($mysqli, $rowAfleverd['TOTCOMIV']);
            $goedcode = mysqli_real_escape_string($mysqli, $rowAfleverd['GOEDCODE']);
            $massakg = mysqli_real_escape_string($mysqli, $rowAfleverd['MASSAKG']);
            $aanveenh = mysqli_real_escape_string($mysqli, $rowAfleverd['AANVEENH']);
            $printetik = mysqli_real_escape_string($mysqli, $rowAfleverd['PRINTETIK']);
            $etikgeprint = mysqli_real_escape_string($mysqli, $rowAfleverd['ETIKGEPRINT']);
            $soortprijs = mysqli_real_escape_string($mysqli, $rowAfleverd['SOORTPRIJS']);
            $refvord = mysqli_real_escape_string($mysqli, $rowAfleverd['REFVORD']);
            $refnacalc = mysqli_real_escape_string($mysqli, $rowAfleverd['REFNACALC']);
            $gnbonkorting = mysqli_real_escape_string($mysqli, $row['GNBONKORTING']);
            $isherst = mysqli_real_escape_string($mysqli, $rowAfleverd['ISHERST']);
            $anp1n1 = mysqli_real_escape_string($mysqli, $rowAfleverd['ANP1N1']);
            $anp1n2 = mysqli_real_escape_string($mysqli, $rowAfleverd['ANP1N2']);
            $anp2n1 = mysqli_real_escape_string($mysqli, $rowAfleverd['ANP2N1']);
            $anp2n2 = mysqli_real_escape_string($mysqli, $rowAfleverd['ANP2N2']);
            $uitvoorraad = mysqli_real_escape_string($mysqli, $rowAfleverd['UITVOORRAAD']);
            $uitvdat = mysqli_real_escape_string($mysqli, str_replace('-', ',', $rowAfleverd['UITVDAT']));
            $hfdartlijnnr = mysqli_real_escape_string($mysqli, $rowAfleverd['HFDARTLIJNNR']);
            $bkmvolgnr = mysqli_real_escape_string($mysqli, $rowAfleverd['BKMVOLGNR']);
            $bkmgedrag = mysqli_real_escape_string($mysqli, $rowAfleverd['BKMGEDRAG']);
            $stdprijsincl = mysqli_real_escape_string($mysqli, $rowAfleverd['STDPRIJSINCL']);
            $landori = mysqli_real_escape_string($mysqli, $rowAfleverd['LANDORI']);
            $omschr = mysqli_real_escape_string($mysqli, $rowAfleverd['OMSCHR']);

            $selectAfleverdNEW = "SELECT * FROM AFLEVERD_NEW WHERE AFLEVERNR=$aflevernr AND LIJNNR=$lijnnr LIMIT 1";
            $resultsAfleverdNEW = $mysqli->query($selectAfleverdNEW);
            if ($resultsAfleverdNEW->num_rows > 0) {
                while ($rowAfleverdNew = $resultsAfleverdNEW->fetch_assoc()) {
                    if ($rowAfleverdNew == $rowAfleverd) {
                    } else {
                        $updateAfleverdNew = "UPDATE AFLEVERD_NEW SET AFLEVERBK='$afleverbk', AFLEVERNR=$aflevernr, LIJNNR=$lijnnr, TYPELN='$typeln',
                        TYPELNINDEX='$typelnindex', ARTIKEL ='$artikel', BENAMING='$benaming', AANTAL=$aantal, STDPRIJS=$stdprijs, KORTING1='$korting1',
                        KORTING2=$korting2, EENHPR=$eenhpr, TOTAAL=$totaal, BTWKODE='$btwkode', VERKREK='$verkrek', MAGAZIJN='$magazijn', 
                        PROJECT='$project', EENHPRIV=$eenhpriv, TOTAALIV=$totaaliv, VALUTA='$valuta', KODEFC='$kodefc', KLANT='$klant', EENHPRINCL=$eenhprincl, 
                        EENHPRINCLIV=$eenhprincliv, KOSTPRIJS=$kostprijs, KOSTPRIJSIV=$kostprijsiv, AKWAARDE=$akwaarde, KODESAMENST='$kodesamenst', 
                        DATUM=STR_TO_DATE('$datum', '%Y,%m,%d'), STFAKT='$stfakt', GEHELEN=$gehelen, ONDERDELEN=$onderdelen, DAGBOEK='$dagboek', 
                        BOEKJAAR=$boekjaar, FAKTNR=$faktnr, FAKTDAT=STR_TO_DATE('$faktdat', '%Y,%m,%d'), VERVDAT=STR_TO_DATE('$vervdat', '%Y,%m,%d'), 
                        ORDERBK='$orderbk', ORDERNR=$ordernr, ORDERTPLN='$ordertpln', ORDERLIJN=$orderlijn, OFFERTEBK='$offertebk', OFFERTENR=$offertenr,
                        OFFERTELIJN=$offertelijn, OFFERTETPLN='$offertetpln', ORDVOLLEDIG='$ordvolledig', JOB='$job', COLLIS=$collis, PALETTEN=$paletten,
                        HISTDAT=STR_TO_DATE('$histdat', '%Y,%m,%d'), HISTORIEK='$historiek', COMPERC=$comperc, COMMISSIEIV=$commissieiv, TOTCOMIV=$totcomiv, 
                        GOEDCODE='$goedcode', MASSAKG=$massakg, AANVEENH=$aanveenh, PRINTETIK=$printetik, ETIKGEPRINT=$etikgeprint, SOORTPRIJS='$soortprijs',
                        REFVORD='$refvord', REFNACALC='$refnacalc', GNBONKORTING='$gnbonkorting', ISHERST='$isherst', ANP1N1='$anp1n1', ANP1N2='$anp1n2',
                        ANP2N1='$anp2n1', ANP2N2='$anp2n2', UITVOORRAAD='$uitvoorraad', UITVDAT=STR_TO_DATE('$uitvdat', '%Y,%m,%d'), HFDARTLIJNNR=$hfdartlijnnr,
                        BKMVOLGNR=$bkmvolgnr, BKMGEDRAG='$bkmgedrag', STDPRIJSINCL=$stdprijsincl, LANDORI='$landori', OMSCHR='$omschr' WHERE AFLEVERNR=$aflevernr AND LIJNNR=$lijnnr LIMIT 1";

                        if ($mysqli->query($updateAfleverdNew) === TRUE) {
                            if ($rowAfleverd != $rowAfleverdNew) {
                                foreach ($rowAfleverd as $x => $val) {
                                    if ($rowAfleverdNew["$x"] != $val && $val =="") {
                                        $insertIntoLoggingAfleverd = "INSERT INTO LOGGING_AFLEVERD (AfleverNummer, LIJNNR, TypeChange, ColumnName, OldValue, NewValue, DatumTijd) 
                                        VALUES ('$aflevernr', $lijnnr, 'DELETE', '$x', '" . mysqli_real_escape_string($mysqli, $rowAfleverdNew["$x"]) . "', '', CURRENT_TIMESTAMP)";
                                        if ($mysqli->query($insertIntoLoggingAfleverd) === TRUE) {
                                        } else {
                                            echo "<p>" . mysqli_error($mysqli) ; "</p>";
                                        }
                                    } elseif ($rowAfleverdNew["$x"] != $val) {
                                        $insertIntoLoggingAfleverd = "INSERT INTO LOGGING_AFLEVERD (AfleverNummer, LIJNNR, TypeChange, ColumnName, OldValue, NewValue, DatumTijd) 
                                        VALUES ('$aflevernr', $lijnnr, 'UPDATE', '$x', '" . mysqli_real_escape_string($mysqli, $rowAfleverdNew["$x"]) . "', '" . mysqli_real_escape_string($mysqli, $val) . "', CURRENT_TIMESTAMP)";
                                        if ($mysqli->query($insertIntoLoggingAfleverd) === TRUE) {
                                        } else {
                                            echo "<p>" . mysqli_error($mysqli) ; "</p>";
                                        }
                                    }
                                }
                            }
                        } else {
                            echo "<p>" . mysqli_error($mysqli) ; "</p>";
                        }
                    }

                    
                }
            } else {
                $insertIntoAfleverdNEW = "INSERT INTO AFLEVERD_NEW (AFLEVERBK, AFLEVERNR, LIJNNR, TYPELN, TYPELNINDEX, ARTIKEL, BENAMING, 
                AANTAL, STDPRIJS, KORTING1, KORTING2, EENHPR, TOTAAL, BTWKODE, VERKREK, MAGAZIJN, PROJECT, EENHPRIV, TOTAALIV, VALUTA, KODEFC, 
                KLANT, EENHPRINCL, EENHPRINCLIV, KOSTPRIJS, KOSTPRIJSIV, AKWAARDE, KODESAMENST, DATUM, STFAKT, GEHELEN, ONDERDELEN, DAGBOEK, 
                BOEKJAAR, FAKTNR, FAKTDAT, VERVDAT, ORDERBK, ORDERNR, ORDERTPLN, ORDERLIJN, OFFERTEBK, OFFERTENR, OFFERTELIJN, OFFERTETPLN, 
                ORDVOLLEDIG, JOB, COLLIS, PALETTEN, HISTDAT, HISTORIEK, COMPERC, COMMISSIEIV, TOTCOMIV, GOEDCODE, MASSAKG, AANVEENH, PRINTETIK, 
                ETIKGEPRINT, SOORTPRIJS, REFVORD, REFNACALC, GNBONKORTING, ISHERST, ANP1N1, ANP1N2, ANP2N1, ANP2N2, UITVOORRAAD, UITVDAT, 
                HFDARTLIJNNR, BKMVOLGNR, BKMGEDRAG, STDPRIJSINCL, LANDORI, OMSCHR) VALUES ('$afleverbk', $aflevernr, $lijnnr, '$typeln', 
                '$typelnindex', '$artikel', '$benaming', $aantal, $stdprijs, $korting1, $korting2, $eenhpr, $totaal, '$btwkode', '$verkrek', 
                '$magazijn', '$project',$eenhpriv, $totaaliv, '$valuta', '$kodefc', '$klant', $eenhprincl, $eenhprincliv, $kostprijs, $kostprijsiv, 
                $akwaarde, '$kodesamenst', STR_TO_DATE('$datum', '%Y,%m,%d'), '$stfakt', $gehelen, $onderdelen, '$dagboek', $boekjaar, $faktnr, STR_TO_DATE('$faktdat', '%Y,%m,%d'), 
                STR_TO_DATE('$vervdat', '%Y,%m,%d'), '$orderbk', $ordernr, '$ordertpln', $orderlijn, '$offertebk', $offertenr, $offertelijn, 
                '$offertetpln', '$ordvolledig', '$job', $collis, $paletten, STR_TO_DATE('$histdat', '%Y,%m,%d'), '$historiek', $comperc, $commissieiv, 
                $totcomiv, '$goedcode', $massakg, $aanveenh, $printetik, $etikgeprint, '$soortprijs', '$refvord', '$refnacalc', '$gnbonkorting', 
                '$isherst', '$anp1n1', '$anp1n2', '$anp2n1', '$anp2n2', '$uitvoorraad', STR_TO_DATE('$uitvdat', '%Y,%m,%d'), $hfdartlijnnr, 
                $bkmvolgnr, '$bkmgedrag', $stdprijsincl, '$landori', '$omschr')";

                if ($mysqli->query($insertIntoAfleverdNEW) === TRUE) {
                    foreach ($rowAfleverd as $x => $val) {
                        if (!empty($val)) {
                            $insertIntoLoggingAfleverd = "INSERT INTO LOGGING_AFLEVERD (AfleverNummer, LIJNNR, TypeChange, ColumnName, OldValue, NewValue, DatumTijd) 
                            VALUES ('$aflevernr', $lijnnr, 'INSERT', '$x', '', '" . mysqli_real_escape_string($mysqli, $val) . "', CURRENT_TIMESTAMP)";
                            if ($mysqli->query($insertIntoLoggingAfleverd) === TRUE) {
                            } else {
                                
                                echo "<p>" . mysqli_error($mysqli) ; "</p>";
                            }
                        }
                    }
                } else {
                    echo "<p>" . mysqli_error($mysqli) ; "</p>";
                }
            }
            $updateAfleverd = "UPDATE AFLEVERD SET LANDORI='UP' WHERE AFLEVERNR=$aflevernr AND LIJNNR=$lijnnr";
            if ($mysqli->query($updateAfleverd) === TRUE) {
            } else {
                echo "<p>" . mysqli_error($mysqli) ; "</p>";
            }
        }
    } else {
        echo 'Niets gebeurt';
    }
?>