// nodig om het adres in 1 lijn te weergeven
let globalAdres = "";
let globalStraat = "";
let globalGemeente = "";
let globalPostcode = "";
//

// haalt de ingetypte value uit het veld waar men mee zoekt en stuurt deze door naar de backend, we gebruiken ajax om ervoor te zorgen
//dat de pagina niet moet herladen
const ShowCustomerOnCustomerid = (str) => {
  if (str == "") {
    return;
  } else if (str.length == 5) {
    $.ajax({
      url: "/Source/backend/backendKlanten.php?klantnr=" + str, 
      success: function(html) {
          var ajaxDisplay = document.getElementById('selectedKlantItem');
          ajaxDisplay.innerHTML = html;
      }
  });
  }
}
//

// haalt de ingetypte value uit het veld waar men mee zoekt en stuurt deze door naar de backend, we gebruiken ajax om ervoor te zorgen
//dat de pagina niet moet herladen
const ShowCustomerOnNaam = (str) => {
  if (str == "" || str.length < 3) {
    document.getElementById("geavanceerdSelectedKlantItemNaam").innerHTML = "";
    return;
  } else if (str.length >= 3) {
    $.ajax({
      url: "/Source/backend/backendKlanten.php?klantNaam=" + str, 
      success: function(html) {
          var ajaxDisplay = document.getElementById('geavanceerdSelectedKlantItemNaam');
          ajaxDisplay.innerHTML = html;
      }
  });
  }
}
//

// voegt de straat toe aan het adres
const AddStraatToAdres = (straat) => {
  globalStraat = straat;
  globalAdres = globalStraat + "$" + globalPostcode + "$" + globalGemeente;
}
//

// voegt de postcode toe aan het adres
const AddPostcodeToAdres = (postcode) => {
  globalPostcode = postcode;
  globalAdres = globalStraat + "$" + globalPostcode + "$" + globalGemeente;
}
//

// voegt de gemeente toe aan het adres
const AddGemeenteToAdres = (gemeente) => {
  globalGemeente = gemeente;
  globalAdres = globalStraat + "$" + globalPostcode + "$" + globalGemeente;
}
//

//geeft het adres weer dat hij terug krijgt uit de backend
const ShowCustomerOnAdres = () => {
  if (globalAdres == "" || globalAdres.length < 5) {
    document.getElementById("geavanceerdSelectedKlantItemAdres").innerHTML = "";
    return;
  } else if (globalAdres.length >= 5) {
    $.ajax({
      url: "/Source/backend/backendKlanten.php?klantAdres=" + globalAdres, 
      success: function(html) {
          var ajaxDisplay = document.getElementById('geavanceerdSelectedKlantItemAdres');
          ajaxDisplay.innerHTML = html;
      }
  });
  }
}
//

// krijgt het gevonden telefoonnummer terug uit de databank
const ShowCustomerOnTelefoonnummer = (str) => {
  if (str == "" || str.length < 5) {
    document.getElementById("geavanceerdSelectedKlantItemTelefoon").innerHTML = "";
    return;
  } else if (str.length >= 5) {
   $.ajax({
      url: "/Source/backend/backendKlanten.php?telefoonnummer=" + str, 
      success: function(html) {
          var ajaxDisplay = document.getElementById('geavanceerdSelectedKlantItemTelefoon');
          ajaxDisplay.innerHTML = html;
      }
  });
  }
}
//

// krijgt het gevonden emailadres terug uit de databank
const ShowCustomerOnEmail = (str) => {
    if (str == "" || str.length < 3) {
      document.getElementById("geavanceerdSelectedKlantItemEmail").innerHTML = "";
      return;
    } else if (str.length >= 3) {
      $.ajax({
        url: "/Source/backend/backendKlanten.php?email=" + str, 
        success: function(html) {
            var ajaxDisplay = document.getElementById('geavanceerdSelectedKlantItemEmail');
            ajaxDisplay.innerHTML = html;
        }
    });
    }
}
//

// krijgt het gevonden btwnummer terug uit de databank
const ShowCustomerOnBTWnummer = (str) => {
    if (str == "" || str.length < 4) {
      document.getElementById("geavanceerdSelectedKlantItemBTW").innerHTML = "";
      return;
    } else if (str.length >= 4) {
      $.ajax({
        url: "/Source/backend/backendKlanten.php?btwnummer=" + str, 
        success: function(html) {
            var ajaxDisplay = document.getElementById('geavanceerdSelectedKlantItemBTW');
            ajaxDisplay.innerHTML = html;
        }
    });
    }
}
//