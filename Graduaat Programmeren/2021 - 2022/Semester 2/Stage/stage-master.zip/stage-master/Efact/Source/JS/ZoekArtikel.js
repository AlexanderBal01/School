// Nodig om te bepalen hoe veel tabelrows er zijn in de tabel met artikellen
let trNr = 0;
//

//voegt de juiste functie om het artikel te zoeken toe aan de het juiste element in de html code op index.php
const ArtikelNr = document.getElementById('InputArtikelnummer');
ArtikelNr.addEventListener('keydown', (e) => {
    if (e.key == 'Enter') {
        const TableArtikelNr = document.getElementById("artikelsTabel");

        if (TableArtikelNr == null || !ArtikelNr.value.includes("*") || TableArtikelNr.value != "") {
            ZoekArtikelOnId();
        } else {
            ZoekArtikelOnId();
        }
    }
});
//

//voegt de juiste functie om het artikel te zoeken toe aan de het juiste element in de html code op index.php
const ArtikelNrmodal = document.getElementById('InputArtikelnummermodal');
ArtikelNrmodal.addEventListener('keydown', (e) => {
    if (e.key == 'Enter') {
        const TableArtikelNr = document.getElementById("artikelsTabel");
        
        if (TableArtikelNr == null || TableArtikelNr.value != "") {
            ZoekArtikelOnIdModal();
        } else {
            ZoekArtikelOnIdModal();
        }
    }
});
//

//voegt de juiste functie om het artikel te zoeken toe aan de het juiste element in de html code op index.php
const ArtikelNaammodal = document.getElementById('InputArtikelNaammodal');
ArtikelNaammodal.addEventListener('keydown', (e) => {
    if (e.key == 'Enter') {
        const TableArtikelNr = document.getElementById("artikelsTabel");
        
        if (TableArtikelNr == null || TableArtikelNr.value != "") {
            ZoekArtikelOnNaamModal();
        } else {
            ZoekArtikelOnNaamModal();
        }
    }
});
//

//haalt de ingetypte value uit het veld waar men mee zoekt en stuurt deze door naar de backend, we gebruiken ajax om ervoor te zorgen
//dat de pagina niet moet herladen
const ZoekArtikelOnId = () => {
    let ArtikelValue = document.getElementById('InputArtikelnummer').value;
    if (ArtikelValue == '' || ArtikelValue.length <= 2) {
        $('#zoekArtikelModal').modal('show');
        document.getElementById('InputArtikelnummermodal').value = ArtikelValue;
        document.getElementById('InputArtikelnummermodal').focus();
    } else {
        $.ajax({
            url: '/Source/backend/backendArtikel.php?artikelnr=' + ArtikelValue,
            success: function (html) {
                if ($.trim(html) !== '') {
                    let ajaxDisplay = '';
                    if (ArtikelValue.includes("*")) {
                        ajaxDisplay = document.getElementById('geavanceerdSelectedItemArtikelNummer');
                        ajaxDisplay.innerHTML = html;
                        $('#zoekArtikelModal').modal({ show: true });
                        document.getElementById('InputArtikelnummermodal').value = ArtikelValue;
                    } else {
                        ajaxDisplay = document.getElementById('VerborgenGevondenArtikelen');
                        ajaxDisplay.innerHTML = html;
                        if (trNr == 0) {
                            trNr++;
                            AddArtikelToTable();
                        } else {
                            trNr++;
                            AddArtikelToTable();
                        }
                    }  
                } else {
                    $('#zoekArtikelModal').modal({ show: true });
                    document.getElementById('InputArtikelnummermodal').value = ArtikelValue;
                }
            }
        });
    }
}
//

// haalt de ingetypte value uit het veld waar men mee zoekt en stuurt deze door naar de backend, we gebruiken ajax om ervoor te zorgen
//dat de pagina niet moet herladen
const ZoekArtikelOnIdModal = () => {
    let ArtikelValue = document.getElementById('InputArtikelnummermodal').value;
    if (ArtikelValue == '' || ArtikelValue.length <= 2) {
        document.getElementById('geavanceerdSelectedItemArtikelNummer').innerHTML ="<h1>Geen Resultaten</h1>";
        document.getElementById('VerborgenGevondenArtikelen').innerHTML ="<h1>Geen Resultaten</h1>";
    } else {
        $.ajax({
            url: '/Source/backend/backendArtikel.php?artikelnrModal=' + ArtikelValue,
            success: function (html) {
                if ($.trim(html) !== '') {
                    let ajaxDisplay = document.getElementById('geavanceerdSelectedItemArtikelNummer');
                    ajaxDisplay.innerHTML = html;
                    document.getElementById('VerborgenGevondenArtikelen').innerHTML ="";
                } else {
                    document.getElementById('geavanceerdSelectedItemArtikelNummer').innerHTML ="<h1>Geen Resultaten</h1>";
                    document.getElementById('VerborgenGevondenArtikelen').innerHTML ="<h1>Geen Resultaten</h1>";
                }
            }
        });
    }
}
//

// haalt de ingetypte value uit het veld waar men mee zoekt en stuurt deze door naar de backend, we gebruiken ajax om ervoor te zorgen
//dat de pagina niet moet herladen
const ZoekArtikelOnNaamModal = () => {
    let ArtikelValue = document.getElementById('InputArtikelNaammodal').value;
    if (ArtikelValue == '' || ArtikelValue.length <= 4) {
        document.getElementById('geavanceerdSelectedItemArtikelNaam').innerHTML ="<h1>Geen Resultaten</h1>";
        document.getElementById('VerborgenGevondenArtikelen').innerHTML ="<h1>Geen Resultaten</h1>";
    } else {
        $.ajax({
            url: '/Source/backend/backendArtikel.php?artikelNaamModal=' + ArtikelValue,
            success: function (html) {
                if ($.trim(html) !== '') {
                    let ajaxDisplay = document.getElementById('geavanceerdSelectedItemArtikelNaam');
                    ajaxDisplay.innerHTML = html;
                    document.getElementById('VerborgenGevondenArtikelen').innerHTML ="";
                } else {
                    document.getElementById('geavanceerdSelectedItemArtikelNaam').innerHTML ="<h1>Geen Resultaten</h1>";
                    document.getElementById('VerborgenGevondenArtikelen').innerHTML ="<h1>Geen Resultaten</h1>";
                }
            }
        });
    }
}
//

// kijkt of er een artikel is in het verborgen veld en voegt deze als er een is toe aan de tabels
const AddArtikelToTable = () => {
    AddNewRowToTable('artikelsTabel');
    let nummer = document.querySelector("input[name='ArtikelNr_Input']").value;
    let tableRows = document.getElementById('artikelsTabel').rows;
    let SelectedArtikelNr = document.getElementById('ArtikelNr_Input').value;
    let SelectedArtikelBeschrijving = document.getElementById('Omschrijving_Input').value;
    let SelectedArtikelSTD_Prijs = document.getElementById('STD_Prijs_Input').value;
    let SelectedArtikelEenheid = document.getElementById('Eenheid_Input').value;
    let SelectedArtikelBTW_Code = document.getElementById('BTW_Code_Input').value;

    tableRows[trNr].cells[1].innerHTML = '<input type="text" class="artikel-width" id="ArtikelNr_' + nummer +'" name="ArtikelNr" value="' + SelectedArtikelNr + '"/>';
    tableRows[trNr].cells[2].innerHTML = '<input type="text" class="artikel-width" id="Omschrijving_' + nummer +'" name="Omschrijving" value="' + SelectedArtikelBeschrijving + '"/>';
    tableRows[trNr].cells[3].innerHTML = '<input type="number" class="artikel-width" id="Aantal_' + nummer +'" name="Aantal" value="1" min="1" onblur="updateAantalArtikel(\''+ nummer +'\')"/>';

    tableRows[trNr].cells[4].id = "STD_Prijs_" + nummer;
    tableRows[trNr].cells[4].innerHTML = SelectedArtikelSTD_Prijs;

    tableRows[trNr].cells[5].innerHTML = '<input type="number" class="artikel-width" id="Korting_' + nummer +'" name="Korting" value="0" min="0" step="any" onblur="updateKortingArtikel(\''+ nummer +'\')"/>';

    let eenheidsprijs = document.getElementById('STD_Prijs_' + nummer).innerHTML * (1 - document.getElementById('Korting_' + nummer).value/100);

    tableRows[trNr].cells[6].innerHTML = '<input type="number" class="artikel-width" id="Eenheidsprijs_' + nummer +'" name="Eenheidsprijs" value="' + eenheidsprijs + '" min="0" step="any" onblur="updateEenheidsPrijsArtikel(\''+ nummer +'\')"/>';

    tableRows[trNr].cells[7].id = "Eenheid_" + nummer;
    tableRows[trNr].cells[7].innerHTML = SelectedArtikelEenheid;

    tableRows[trNr].cells[8].innerHTML = '<input type="number" class="artikel-width" id="BTW_Code_' + nummer +'" name="BTW_Code" value="' + SelectedArtikelBTW_Code + '" min="1" max="4" onblur="updateBTWArtikel(\''+ nummer +'\')"/>';

    if (SelectedArtikelBTW_Code == 1) {
        tableRows[trNr].cells[9].id = "BTW_" + nummer;
        tableRows[trNr].cells[9].innerHTML = 0;
    } else if (SelectedArtikelBTW_Code == 2) {
        tableRows[trNr].cells[9].id = "BTW_" + nummer;
        tableRows[trNr].cells[9].innerHTML = 6;
    } else if (SelectedArtikelBTW_Code == 3) {
        tableRows[trNr].cells[9].id = "BTW_" + nummer;
        tableRows[trNr].cells[9].innerHTML = 12;
    } else if (SelectedArtikelBTW_Code == 4) {
        tableRows[trNr].cells[9].id = "BTW_" + nummer;
        tableRows[trNr].cells[9].innerHTML = 21;
    }
    
    let prijsexbtw = document.getElementById('Eenheidsprijs_' + nummer).value * document.getElementById('Aantal_' + nummer).value;

    tableRows[trNr].cells[10].id = "Prijs_Ex_BTW_" + nummer;
    tableRows[trNr].cells[10].innerHTML = prijsexbtw.toFixed(2).toString().replace('.', ',');

    let prijsinclbtw = parseFloat((document.getElementById('Prijs_Ex_BTW_' + nummer).innerHTML.replace(',', '.') * (1 + document.getElementById('BTW_' + nummer).innerHTML/100)).toFixed(2));

    tableRows[trNr].cells[11].id = "Prijs_Incl_BTW_" + nummer
    tableRows[trNr].cells[11].innerHTML = prijsinclbtw.toFixed(2).toString().replace('.', ',');

    document.getElementById('totaalExclBTW').value = (parseFloat(document.getElementById('totaalExclBTW').value) + parseFloat(document.getElementById("Prijs_Ex_BTW_" + nummer).innerHTML.toString().replace(',', '.'))).toFixed(2);
    document.getElementById('totaalBTW').value = (parseFloat(document.getElementById('totaalBTW').value) + (parseFloat(document.getElementById("Prijs_Incl_BTW_" + nummer).innerHTML.toString().replace(',', '.')) - parseFloat(document.getElementById("Prijs_Ex_BTW_" + nummer).innerHTML.toString().replace(',', '.')))).toFixed(2);
    document.getElementById('totaalTeBetalen').value = (parseFloat(document.getElementById('totaalTeBetalen').value) + parseFloat(document.getElementById("Prijs_Incl_BTW_" + nummer).innerHTML.toString().replace(',', '.'))).toFixed(2);
}
//

// deze functie verwijderd alle rijen waar dat een checkbox gecheckd is
const DeleteRow = (tableID) => {
    try {
        let table = document.getElementById(tableID);
        let rowCount = table.rows.length;

        for (let i = 0; i < rowCount; i++) {
            let row = table.rows[i];
            let chkbox = row.cells[0].childNodes[0];
            let prijsExclBTW = row.cells[10].innerHTML;
            let prijsInclBTW = row.cells[11].innerHTML;
            if (null != chkbox && true == chkbox.checked && rowCount > 1) {
                table.deleteRow(i);
                document.getElementById('totaalExclBTW').value = (parseFloat(document.getElementById('totaalExclBTW').value) - parseFloat(prijsExclBTW.toString().replace(',', '.'))).toFixed(2);
                document.getElementById('totaalBTW').value = Math.abs((parseFloat(document.getElementById('totaalBTW').value) - (parseFloat(prijsInclBTW.toString().replace(',', '.')) - parseFloat(prijsExclBTW.toString().replace(',', '.'))))).toFixed(2);
                document.getElementById('totaalTeBetalen').value = (parseFloat(document.getElementById('totaalTeBetalen').value) - parseFloat(prijsInclBTW.toString().replace(',', '.'))).toFixed(2);
                rowCount--;
                i--;
                trNr--;
            }
        }

        if (rowCount == 1) {
            trNr++;
            let row = table.insertRow(rowCount);

            let cell0 = row.insertCell(0);
            let element0 = document.createElement('input');
            element0.type = 'checkbox';
            element0.name = 'chkbox[]';
            cell0.appendChild(element0);

            let cell1 = row.insertCell(1);

            let cell2 = row.insertCell(2);

            let cell3 = row.insertCell(3);

            let cell4 = row.insertCell(4);

            let cell5 = row.insertCell(5);

            let cell6 = row.insertCell(6);

            let cell7 = row.insertCell(7);

            let cell8 = row.insertCell(8);

            let cell9 = row.insertCell(9);

            let cell10 = row.insertCell(10);

            let cell11 = row.insertCell(11);

            let cell12 = row.insertCell(12);
        }
    } catch (e) {
        alert(e);
    }
}
//

// voegt een nieuwe rij to aan de productentabel
const AddNewRowToTable = (tableID) => {
    let table = document.getElementById(tableID);
    let rowCount = table.rows.length;
    let row = table.insertRow(rowCount);

    let cell0 = row.insertCell(0);
    let element0 = document.createElement('input');
    element0.type = 'checkbox';
    element0.name = 'chkbox[]';
    cell0.appendChild(element0);

    let cell1 = row.insertCell(1);

    let cell2 = row.insertCell(2);

    let cell3 = row.insertCell(3);

    let cell4 = row.insertCell(4);

    let cell5 = row.insertCell(5);

    let cell6 = row.insertCell(6);

    let cell7 = row.insertCell(7);

    let cell8 = row.insertCell(8);

    let cell9 = row.insertCell(9);

    let cell10 = row.insertCell(10);

    let cell11 = row.insertCell(11);

    let cell12 = row.insertCell(12);
}
//

// selecteerd en voegt het geslecteerde artikel toe aan de tabel
const SelecteerArtikel = (nr) => {
    let artikelnr = document.getElementById("ArtikelNummer_" + nr).textContent;
    let naam = document.getElementById("Naam_" + nr).textContent;
    let STDPrijs = document.getElementById("STDPrijs_" + nr).textContent;
    let Eenheid = document.getElementById("Eenheid_" + nr).textContent;
    let BTWCode = document.getElementById("BTWCODE_" + nr).textContent;

    document.getElementById('VerborgenGevondenArtikelen').innerHTML = '<input type="text" id="ArtikelNr_Input" name="ArtikelNr_Input" placeholder="Artikelnummer" value="' + artikelnr + '" hidden/> <input type="text" id="Omschrijving_Input" name="Omschrijving_Input" value="' + naam + '" hidden/><input type="number" id="STD_Prijs_Input" name="STD_Prijs_Input" value="' + STDPrijs + '" hidden/><input type="text" id="Eenheid_Input" name="Eenheid_Input" value="' + Eenheid + '" hidden/><input type="text" id="BTW_Code_Input" name="BTW_Code_Input" value="' + BTWCode + '" hidden/>'

    if (trNr == 0) {
        trNr++;
        AddArtikelToTable();
    } else {
        trNr++;
        AddArtikelToTable();
    }
    document.getElementById('VerborgenGevondenArtikelen').innerHTML = "" ;
}
//

// zorgt er voor dat de prijzen geupdated worden bij een wijziging in het aantal
const updateAantalArtikel = (nr) => {
    let aantal = document.getElementById('Aantal_' + nr).value;
    let btw = document.getElementById('BTW_' + nr).innerHTML;

    let prijsexbtw = document.getElementById('Eenheidsprijs_' + nr).value * aantal;

    let fixedPrijsExBTW = parseFloat(prijsexbtw).toFixed(2);
    let fixedPrijsExBTWAsString = fixedPrijsExBTW.toString().replace('.', ',');
    document.getElementById('Prijs_Ex_BTW_' + nr).innerHTML = fixedPrijsExBTWAsString;

    let prijsinclbtw = parseFloat((prijsexbtw * (1 + btw/100)).toFixed(2));
    let fixedPrijsBTW = prijsinclbtw.toString().replace('.', ',');
    document.getElementById('Prijs_Incl_BTW_' + nr).innerHTML = fixedPrijsBTW;
    
    let table = document.getElementById('artikelsTabel');
    let rowCount = table.rows.length;

    document.getElementById("totaalExclBTW").value = 0.00;
    document.getElementById("totaalBTW").value = 0.00;
    document.getElementById("totaalTeBetalen").value = 0.00;

    for (let i = 1; i < rowCount-1; i++) {
        let row = table.rows[i];

        let subtotaalExclBTW = row.cells[10].innerHTML.toString().replace(',', '.');
        let subtotaalBTW = parseFloat(row.cells[11].innerHTML.toString().replace(',', '.')) - parseFloat(subtotaalExclBTW);
        let subtotaalTeBetalen = parseFloat(row.cells[11].innerHTML.toString().replace(',', '.'));

        document.getElementById("totaalExclBTW").value = (parseFloat(document.getElementById("totaalExclBTW").value) + parseFloat(subtotaalExclBTW)).toFixed(2);
        document.getElementById("totaalBTW").value = (parseFloat(document.getElementById("totaalBTW").value) + parseFloat(subtotaalBTW)).toFixed(2);
        document.getElementById("totaalTeBetalen").value = (parseFloat(document.getElementById("totaalTeBetalen").value) + parseFloat(subtotaalTeBetalen)).toFixed(2);
    }
}
//

// zorgt er voor dat de prijzen geupdated worden bij een wijziging aan de korting
const updateKortingArtikel = (nr) => {
    let aantal = document.getElementById('Aantal_' + nr).value;
    let btw = document.getElementById('BTW_' + nr).innerHTML;
    let stdPrijs = document.getElementById('STD_Prijs_' + nr).innerHTML;
    let Korting = document.getElementById('Korting_' + nr).value;

    let eenheidsprijs = parseFloat((stdPrijs * (1 - Korting/100)).toFixed(2));
    document.getElementById('Eenheidsprijs_' + nr).value = eenheidsprijs;

    let prijsexbtw = (document.getElementById('Eenheidsprijs_' + nr).value * aantal).toFixed(2);
    document.getElementById('Prijs_Ex_BTW_' + nr).innerHTML = prijsexbtw.toString().replace('.', ',');

    let prijsinclbtw = parseFloat((prijsexbtw * (1 + btw/100)).toFixed(2));
    document.getElementById('Prijs_Incl_BTW_' + nr).innerHTML = prijsinclbtw.toString().replace('.', ',');

    let table = document.getElementById('artikelsTabel');
    let rowCount = table.rows.length;

    document.getElementById("totaalExclBTW").value = 0.00;
    document.getElementById("totaalBTW").value = 0.00;
    document.getElementById("totaalTeBetalen").value = 0.00;

    for (let i = 1; i < rowCount-1; i++) {
        let row = table.rows[i];

        let subtotaalExclBTW = row.cells[10].innerHTML.toString().replace(',', '.');
        let subtotaalBTW = parseFloat(row.cells[11].innerHTML.toString().replace(',', '.')) - parseFloat(subtotaalExclBTW);
        let subtotaalTeBetalen = parseFloat(row.cells[11].innerHTML.toString().replace(',', '.'));

        document.getElementById("totaalExclBTW").value = (parseFloat(document.getElementById("totaalExclBTW").value) + parseFloat(subtotaalExclBTW)).toFixed(2);
        document.getElementById("totaalBTW").value = (parseFloat(document.getElementById("totaalBTW").value) + parseFloat(subtotaalBTW)).toFixed(2);
        document.getElementById("totaalTeBetalen").value = (parseFloat(document.getElementById("totaalTeBetalen").value) + parseFloat(subtotaalTeBetalen)).toFixed(2);
    }
}
//

// berekend de korting bij een veranderring in de eenheidsprijs
const updateEenheidsPrijsArtikel = (nr) => {
    let aantal = document.getElementById('Aantal_' + nr).value;
    let btw = document.getElementById('BTW_' + nr).innerHTML;
    let eenheidsprijs = document.getElementById('Eenheidsprijs_' + nr).value;
    let stdPrijs = document.getElementById('STD_Prijs_' + nr).innerHTML;
    
    let getal1 = eenheidsprijs/stdPrijs;
    let neggetal1 = -Math.abs(getal1);
    let wk1 = neggetal1 + 1;
    let korting = (wk1 * 100).toFixed(2);
    
    document.getElementById('Korting_' + nr).value = korting

    let prijsexbtw = (document.getElementById('Eenheidsprijs_' + nr).value * aantal).toFixed(2);
    document.getElementById('Prijs_Ex_BTW_' + nr).innerHTML = prijsexbtw.toString().replace('.', ',');

    let prijsinclbtw = parseFloat((prijsexbtw * (1 + btw/100))).toFixed(2);
    document.getElementById('Prijs_Incl_BTW_' + nr).innerHTML = prijsinclbtw.toString().replace('.', ',');

    let table = document.getElementById('artikelsTabel');
    let rowCount = table.rows.length;

    document.getElementById("totaalExclBTW").value = 0.00;
    document.getElementById("totaalBTW").value = 0.00;
    document.getElementById("totaalTeBetalen").value = 0.00;

    for (let i = 1; i < rowCount-1; i++) {
        let row = table.rows[i];

        let subtotaalExclBTW = row.cells[10].innerHTML.toString().replace(',', '.');
        let subtotaalBTW = parseFloat(row.cells[11].innerHTML.toString().replace(',', '.')) - parseFloat(subtotaalExclBTW);
        let subtotaalTeBetalen = parseFloat(row.cells[11].innerHTML.toString().replace(',', '.'));

        document.getElementById("totaalExclBTW").value = (parseFloat(document.getElementById("totaalExclBTW").value) + parseFloat(subtotaalExclBTW)).toFixed(2);
        document.getElementById("totaalBTW").value = (parseFloat(document.getElementById("totaalBTW").value) + parseFloat(subtotaalBTW)).toFixed(2);
        document.getElementById("totaalTeBetalen").value = (parseFloat(document.getElementById("totaalTeBetalen").value) + parseFloat(subtotaalTeBetalen)).toFixed(2);
    }
}
//

// als je een andere btwcode kiest wordt het btwpercentage geupdated
const updateBTWArtikel = (nr) => {
    if (document.getElementById("BTW_Code_" + nr).value == 1) {
        document.getElementById("BTW_" + nr).innerHTML = 0;
    } else if (document.getElementById("BTW_Code_" + nr).value == 2) {
        document.getElementById("BTW_" + nr).innerHTML = 6;
    } else if (document.getElementById("BTW_Code_" + nr).value == 3) {
        document.getElementById("BTW_" + nr).innerHTML = 12;
    } else if (document.getElementById("BTW_Code_" + nr).value == 4) {
        document.getElementById("BTW_" + nr).innerHTML = 21;
    }

    let prijsexbtw = document.getElementById('Prijs_Ex_BTW_' + nr).innerHTML;
    let btw = document.getElementById('BTW_' + nr).innerHTML;

    let prijsinclbtw = parseFloat((prijsexbtw.replace(',', '.') * (1 + btw/100))).toFixed(2);
    document.getElementById('Prijs_Incl_BTW_' + nr).innerHTML = prijsinclbtw.toString().replace('.', ',');

    let table = document.getElementById('artikelsTabel');
    let rowCount = table.rows.length;

    document.getElementById("totaalExclBTW").value = 0.00;
    document.getElementById("totaalBTW").value = 0.00;
    document.getElementById("totaalTeBetalen").value = 0.00;

    for (let i = 1; i < rowCount-1; i++) {
        let row = table.rows[i];

        let subtotaalExclBTW = row.cells[10].innerHTML.toString().replace(',', '.');
        let subtotaalBTW = parseFloat(row.cells[11].innerHTML.toString().replace(',', '.')) - parseFloat(subtotaalExclBTW);
        let subtotaalTeBetalen = parseFloat(row.cells[11].innerHTML.toString().replace(',', '.'));

        document.getElementById("totaalExclBTW").value = (parseFloat(document.getElementById("totaalExclBTW").value) + parseFloat(subtotaalExclBTW)).toFixed(2);
        document.getElementById("totaalBTW").value = (parseFloat(document.getElementById("totaalBTW").value) + parseFloat(subtotaalBTW)).toFixed(2);
        document.getElementById("totaalTeBetalen").value = (parseFloat(document.getElementById("totaalTeBetalen").value) + parseFloat(subtotaalTeBetalen)).toFixed(2);
    }
}
//