﻿using Figuren;
using System;

namespace Testproject_Alexander_Bal {
    class Program {
        static void Main(string[] args) {
            Cirkel c = new Cirkel();
            c.Straal = 123;
            Console.WriteLine(c.Straal);
        }
    }
}
