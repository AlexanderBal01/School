﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Figuren {
    class Cirkel {
        public double Straal { get; set; }
    }
}
