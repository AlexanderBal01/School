﻿/* 
 Opgave:

    Vul de Filter method aan met de ontbrekende code.

    De Filter method zoekt in het meegegeven array 'getallen' naar de waarden
    die tussen de opgegeven grenzen 'min' en 'max' liggen (grenzen exclusief!).
         
    De method retourneert een nieuw array dat de gevonden waarden bevat.
         
    De volgorde van de waarden is identiek aan hun onderlinge volgorde in het
    'getallen' array.
        
    Je mag ervan uitgaan dat 'min' altijd kleiner of gelijk is aan 'max', je
    hoeft dit dus niet te checken in de method zelf. Je mag er ook van uitgaan
    dat de 'getallen' parameter nooit null zal zijn.
        
    Indien er geen enkele waarde tussen de grenzen gevonden wordt, dan retourneert
    de method een leeg array (dit is een array van lengte zero).
    
    Je mag de meegegeven code aanvullen (bij de TODO), maar niet aanpassen.

 Voorbeeld uitvoer:

    3,6,-1,0
    6
    
*/

using System;

namespace Evaluatiemoment.Oefening1 {

    class Program {

        static void Main() {
            // Het array met waarden die we als voorbeeld gebruiken
            int[] meetwaarden = { 3, 6, 10, -1, -23, 0, -6, 7, 10, -15, -4, 10 };

            // Een variabele voor de return value van een Filter method oproep
            int[] gefilterd;

            // Filter alle getallen die tussen -4 en 7 liggen (grenzen exclusief)
            gefilterd = Filter(meetwaarden, -4, 7);
            Console.WriteLine(String.Join(",", gefilterd));
            // De output is : 3,6,-1,0
            // Let erop dat de volgorde van de waarden in de output gelijk is aan
            // hun onderlinge volgorde in het 'meetwaarden' array!

            // Filter alle getallen die tussen 5 en 7 liggen (grenzen exclusief)
            gefilterd = Filter(meetwaarden, 5, 7);
            Console.WriteLine(String.Join(",", gefilterd));
            // De output is : 6

            // Filter alle getallen die tussen 100 en 200 liggen (grenzen exclusief)
            gefilterd = Filter(meetwaarden, 100, 200);
            Console.WriteLine(String.Join(",", gefilterd));
            // De output is :
            // Let erop dat de output een lege regel is, er zijn immers geen
            // waarden tussen 100 en 200 in 'meetwaarden'. De lengte van
            // array 'gefilterd' is nu dus gelijk aan 0!}
        }

        static int[] Filter(int[] getallen, int min, int max) {

            // ... TODO
            int[] getallenGefilterd = getallen;
            int getal;

            for (int i = 0; i < getallenGefilterd.Length; i++) {
                getal = getallenGefilterd[i];

                if (getal > min && getal < max && getal != 0) {

                }

            }
            return getallenGefilterd;

        }
    }
}
