﻿/* 
 Opgave:

    Vul de meegegeven code naar behoren aan.  In commentaar staat aangegeven wat de bedoeling is, 
    en wat door bepaalde members wordt opgeleverd.
    Maar ook hier krijg je een overzicht mee van wat gewenst is (TODO 1 + TODO 2 + TODO 3)...

    TODO 1:
    Een klasse Factuur met volgende members:
    - een constructor met parameters om het bedrag (een decimal) en de vervaldatum 
      van het te creëren Factuur object in te stellen
    - een property Betaald om na te gaan of de factuur reeds betaald is?
    - een property Vervaldatum (enkel uitleesbaar, niet instelbaar) om de vervaldatum van de factuur
      na te gaan (de datum waarop ten laatste betaald moet zijn)
    - een property Bedrag (enkel uitleesbaar, niet instelbaar) om het bedrag van de factuur op te vragen
    - een method IsAchterstallig met een DateTime parameter om na te gaan of de factuur op de 
      meegegeven datum achterstallig is
    
    Een factuur is achterstallig op een bepaalde datum X indien: 
    ze nog niet betaald is, en de vervaldatum nog niet verder ligt dan datum X.

    Bijvoorbeeld op datum van 11 januari 2021 is...
    - een   betaalde factuur met vervaldatum 10 januari 2021 niet achterstallig
    - een onbetaalde factuur met vervaldatum 10 januari 2021 niet achterstallig
    - een   betaalde factuur met vervaldatum 11 januari 2021 niet achterstallig
    - een onbetaalde factuur met vervaldatum 11 januari 2021 niet achterstallig (onbetaald, maar nog niet voorbij de vervaldatum)
    - een onbetaalde factuur met vervaldatum 12 januari 2021  WEL achterstallig (onbetaald, en voorbij de vervaldatum)
    - een   betaalde factuur met vervaldatum 12 januari 2021 niet achterstallig

    TODO 2:
    Een method PrintFactuurDetails waarmee de details van een factuur kunnen worden afgedrukt.

    TODO 3:
    Een BedragComparer die we bijvoorbeeld kunnen doorgeven aan een Sort method om aan te geven dat 
    een verzameling van Factuur objecten wordt gesorteerd op basis van hun bedrag. 
    Opgelet... dit van groot bedrag naar klein bedrag.
    
    Je mag de meegegeven code aanvullen, maar niet aanpassen.

 Voorbeeld uitvoer:

    Bedrag factuur f4: 300
    Vervaldatum factuur f4: 6/01/2019 0:00:00

    Factuur f3 is betaald: False
    Factuur f4 is betaald: True

    Factuur f1 is achterstallig: False
    Factuur f2 is achterstallig: True
    Factuur f3 is achterstallig: True
    Factuur f4 is achterstallig: False

    Factuur voor bedrag 200 met vervaldatum 6/01/2021 0:00:00.
    Factuur voor bedrag 100 met vervaldatum 6/01/2020 0:00:00.
    Factuur voor bedrag 400 met vervaldatum 6/01/2019 0:00:00.
    Factuur voor bedrag 300 (betaald).

    Factuur voor bedrag 400 met vervaldatum 6/01/2019 0:00:00.
    Factuur voor bedrag 300 (betaald).
    Factuur voor bedrag 200 met vervaldatum 6/01/2021 0:00:00.
    Factuur voor bedrag 100 met vervaldatum 6/01/2020 0:00:00.
*/

using System;
using System.Collections.Generic;

namespace Evaluatiemoment.Oefening3 {

    class Program {
        static void Main() {
            // We maken 4 facturen aan, met elk hun eigen bedrag (een decimal) en 
            // vervaldatum die tijdens creatie van de objecten wordt opgegeven...
            Factuur f1 = new Factuur(200, new DateTime(2021, 1, 6));
            Factuur f2 = new Factuur(100, new DateTime(2020, 1, 6));
            Factuur f3 = new Factuur(400, new DateTime(2019, 1, 6));
            Factuur f4 = new Factuur(300, new DateTime(2019, 1, 6));

            // Het bedrag en de vervaldatum zijn verder (na creatie) niet meer 
            // aan te passen, uiteraard wel op te vragen...
            Console.WriteLine($"Bedrag factuur f4: {f4.Bedrag}");            // 300
            Console.WriteLine($"Vervaldatum factuur f4: {f4.Vervaldatum}");  // 6/01/2019 0:00:00
            Console.WriteLine();
            //f4.Bedrag = 401;                           // zou een compilefout moeten opleveren
            //f4.Vervaldatum = new DateTime(2020, 1, 6); // zou een compilefout moeten opleveren

            // Wel kan men instellen of de factuur al dan niet betaald is...
            f4.Betaald = true;

            // By default zijn facturen nog niet betaald...
            Console.WriteLine($"Factuur f3 is betaald: {f3.Betaald}");    // False
            Console.WriteLine($"Factuur f4 is betaald: {f4.Betaald}");    // True
            Console.WriteLine();

            // Er kan worden nagegaan of een factuur achterstallig is op een bepaalde datum 
            // (de parameterwaarde).
            DateTime dt = new DateTime(2020, 1, 6);
            Console.WriteLine($"Factuur f1 is achterstallig: {f1.IsAchterstallig(dt)}");   // False
            Console.WriteLine($"Factuur f2 is achterstallig: {f2.IsAchterstallig(dt)}");   // True
            Console.WriteLine($"Factuur f3 is achterstallig: {f3.IsAchterstallig(dt)}");   // True
            Console.WriteLine($"Factuur f4 is achterstallig: {f4.IsAchterstallig(dt)}");   // False
            Console.WriteLine();

            // Alle aparte factuur objecten worden aan een lijst toegevoegd...
            List<Factuur> facturen = new List<Factuur>() { f1, f2, f3, f4 };

            // De lijst wordt afgedrukt...
            PrintFacturen(facturen);

            // De lijst wordt gesorteerd op bedag, van groot naar klein, en opnieuw afgedrukt...
            facturen.Sort(new BedragComparer());
            PrintFacturen(facturen);
        }

        static void PrintFacturen(List<Factuur> facturen) {
            foreach (Factuur f in facturen) {
                PrintFactuurDetails(f);
            }
            Console.WriteLine();
        }

        // ... TODO 2

    }

    // ... TODO 1


    // ... TODO 3

}
