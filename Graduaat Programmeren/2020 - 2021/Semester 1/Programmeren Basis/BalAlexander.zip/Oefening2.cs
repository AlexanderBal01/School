﻿/* 
 Opgave:

    Jaarlijks trekken ambtenaren van het 'Agentschap voor Wegen & Verkeer' de straat op om het 
    weggebruik in kaart te brengen.
    Ze houden van alle passanten het middel van transport bij. Om zo te kunnen tellen hoeveel 
    fietsers, voetgangers, vrachtwagenbestuurders, ... passeren.

    Voor deze oefening sturen we er twee ambtenaren op uit (Piet neemt de ochtendshift en Jan
    wisselt hem af op de middag) om de passanten te tellen die ze voorbij zien komen op de Rooiegemlaan.

    Voor elk houden we een dictionary bij van string naar int met de tellingen van dat transportmiddel.
    De string is een verwijzing naar het transportmiddel (bv. "automobilist") en de int is het 
    aantal keren dat dit transportmiddel voorbij kwam (bv. 173).

    TODO 1+2: definieer in de Main method hieronder de dictionaries met tellingen voor Jan en Piet

    Na afloop zouden we graag weten hoeveel en welke transportmiddelen er gespot werden, we doen dit 
    door de tellingen van Jan en Piet samen te voegen.

    TODO 3: definieer een method Combinatie met twee parameters die twee tellingen voorstellen en 
    die een nieuwe dictionary produceert met de gecombineerde tellingen.
     - Indien beide tellingen eenzelfde transportmiddel bevatten dan krijgt de combinatie de som van 
       die twee tellingen. 
     - Indien een transportmiddel slechts in 1 van beide tellingen voorkomt, wordt dat aantal gewoon 
       overgenomen in de combinatie.

    Bijvoorbeeld, indien de 2 tellingen als volgt zijn:
        tellingenA : 5 x fietser, 1 x paardrijder
        tellingenB : 2 x voetganger, 2 x fietser
    Dan bevat het resultaat van Combinatie de volgende tellingen (de volgorde is onbelangrijk):
        7 x fietser, 1 x paardrijder, 2 x voetganger
    
    Je mag de meegegeven code aanvullen (bij de TODO's), maar niet aanpassen.

 Voorbeeld uitvoer (volgorde onbelangrijk):

    [vrachtwagenbestuurder, 215]
    [automobilist, 873]
    [voetganger, 251]
    [fietser, 1061]
    [paardrijder, 1]
    [stepper, 2]
*/

using System;
using System.Collections.Generic;

namespace Evaluatiemoment.Oefening2 {

    class Program {
        static void Main() {
            // ... TODO 1 : definieer een dictionary 'tellingenPiet' waarin we de volgende tellingen van Piet bijhouden :
            // [automobilist, 481]
            // [stepper, 2]
            // [voetganger, 114]
            // [fietser, 573]
            // [vrachtwagenbestuurder, 134]
            Dictionary<string, int> tellingenPiet = new Dictionary<string, int> {
                {"automobilist",  481},
                {"stepper",  2},
                {"voetganger",  114},
                {"fietser",  573},
                {"vrachtwagenbestuurder",  134}
            };

            // ... TODO 2 : definieer een dictionary 'tellingenJan' waarin we de volgende tellingen van Jan bijhouden :
            // [vrachtwagenbestuurder, 81]
            // [automobilist, 392]
            // [voetganger, 137]
            // [fietser, 488]
            // [paardrijder, 1]
            Dictionary<string, int> tellingenJan = new Dictionary<string, int> {
                {"vrachtwagenbestuurder",  81},
                {"automobilist",  392},
                {"voetganger",  137},
                {"fietser",  488},
                {"paardrijder",  1}

            };

            // Voeg beide tellingen samen
            Dictionary<string, int> combo = Combinatie(tellingenJan, tellingenPiet);

            // Toon de samengevoegde tellingen op de console
            string comboAlsTekst = string.Join(Environment.NewLine, combo);
            Console.WriteLine(comboAlsTekst);
            // De output is (volgorde onbelangrijk):
            // [vrachtwagenbestuurder, 215]
            // [automobilist, 873]
            // [voetganger, 251]
            // [fietser, 1061]
            // [paardrijder, 1]
            // [stepper, 2]

        }



        // ... TODO 3 : Definieer hier je Combinatie method
        public static Dictionary<string, int> Combinatie(Dictionary<string, int> tellingenJan, Dictionary<string, int> tellingenPiet) {
            
        }
    }
}
