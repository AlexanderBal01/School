﻿/* 
 Opgave:

    Vul de Expand method aan met de ontbrekende code.

    De Expand method produceert een NIEUW array waarin alle getallen uit het
    meegegeven array gedupliceerd werden. Hoe vaak elk getal moet gedupliceerd
    worden, wordt eveneens als parameter meegegeven. Je mag ervan uitgaan dat
    dit aantal nooit negatief zal zijn.

    Bijvoorbeeld, de reeks 2, 3, -5, 6 via Expand 3x dupliceren geeft :
    2, 2, 2, 3, 3, 3, -5, -5, -5, 6, 6, 6 (elk getal komt 3x voor).
       
    De method retourneert het nieuwe array.
         
    De volgorde van de waarden is identiek aan hun onderlinge volgorde in het
    meegegeven array, alleen komen ze (potentieel) meermaals voor.

    In de Main method staat code die de Expand method oproept, aan de output
    van enkele voorbeelden kun je zien wat de bedoeling.

    Je mag de Main method niet aanpassen.
    
*/

using System;


namespace Evaluatiemoment.Oefening1 {

    class Program {

        static int[] Expand(int aantal, int[] getallen) {
            // Vul hier aan met de ontbrekende code...
            int[] expandedGetallen = new int[getallen.Length * aantal];
            getallen.CopyTo(expandedGetallen, 0);

            for (int index = 0; index < getallen.Length; index++) {
                int getal = getallen[index];

                int teller = 0;
                while (teller < aantal) {
                    teller++;
                }
            }

            return expandedGetallen;
        }

        static void Main() {
            // voorbeeld 1 : een reeks één keer dupliceren
            int[] scores1 = { 2, 3, -5, 6 };
            int[] expanded1 = Expand(1, scores1);
            Console.WriteLine(String.Join(",", expanded1));
            // output is : 2,3,-5,6

            // voorbeeld 2 : een reeks drie keer dupliceren
            int[] scores2 = { 2, 3, -5, 6 };
            int[] expanded2 = Expand(3, scores2);
            Console.WriteLine(String.Join(",", expanded2));
            // de output is : 2,2,2,3,3,3,-5,-5,-5,6,6,6

            // voorbeeld 3 : een reeks nul keer dupliceren
            int[] scores3 = { };
            int[] expanded3 = Expand(0, scores3);
            Console.WriteLine(String.Join(",", expanded3));
            // output is : (een lege regel)
            // (de Expand oproep retourneerde immers een lege array)

            // voorbeeld 4 : een lege reeks 5 keer dupliceren
            int[] scores4 = { };
            int[] expanded4 = Expand(5, scores4);
            Console.WriteLine(String.Join(",", expanded4));
            // output is : (een lege regel)
            // (de Expand oproep retourneerde immers een lege array)
        }
    }
}
