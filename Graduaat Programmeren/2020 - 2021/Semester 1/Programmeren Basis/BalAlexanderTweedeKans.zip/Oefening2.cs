﻿/* 
 Opgave:

    TODO 1) Schrijf een SocialMediaFilter method zoals hieronder beschreven.
    TODO 2) In de Main method, vul bij de TODO2's de code aan om de nodige variabelen en data te definiëren
	
    Het resultaat moet een correct werkend programma opleveren.

    Je mag in de Main method enkel bij de TODO2's code aanvullen, de rest van de Main method wijzig je niet.
    
*/

using System;
using System.Collections.Generic;

namespace Evaluatiemoment.Oefening2 {
    class Program {

        /* 
        Schrijf een method met naam 'SocialMediaFilter' met 2 parameters :
        De eerste parameter is een lijst met woorden
        De tweede parameter is een lijst met verboden woorden

        Je mag ervan uitgaan dat deze parameters nooit null zullen zijn (maar het kan wel gebeuren dat 
        er een of twee lege lijsten worden meegegeven bij een method oproep).

        Je kunt in de Main method zien hoe deze method gebruikt wordt (en daaruit afleiden 
        wat de parametertypes en het returntype moeten zijn).

        Deze method maakt een NIEUWE lijst die gebaseerd is op de lijst met woorden, zodat
        - toegelaten woorden worden integraal overgenomen
        - verboden woorden vervangen worden door sterretjes (evenveel als de lengte van het verboden woord)

        Het vergelijken van de woorden en de verboden woorden is hoofdlettergevoelig.

        De method retourneert de nieuwe list.

        Bijvoorbeeld, een oproep met 
            woorden : rood, grasgroen, blauw, geel, zwart
            verboden woorden : geel, grasgroen
        retourneert een lijst met daarin de strings
            rood, *********, blauw, ****, zwart
        merk op dat het aantal sterretjes overeenkomt met de lengte van het verboden woord.

        Enkele opmerkingen :
        - de meegegeven lijst met woorden en de geretourneerde lijst zullen evenveel strings bevatten
        - de onderlinge volgorde van de woorden in beide lijsten is dezelfde
        - op elke positie zijn de strings in beide lijsten even lang
            - ofwel is het exact hetzelfde woord (en dus sowieso even lang)
            - ofwel is het een reeks sterretjes van dezelfde lengte

        */

        // TODO1 : schrijf hier de method SocialMediaFilter
        private static List<string> SocialMediaFilter(List<string> words, List<string> naughtyWords) {
            List<string> gefilterdeWoorden = new List<string>(words);
            int count = 0;
            foreach (string word in words) {
                if (naughtyWords.Contains(word)) {
                    int lengte = word.Length;
                    string naughtyWordReplace = word;
                    naughtyWordReplace = new string('*', lengte);
                    gefilterdeWoorden.Remove(word);
                    gefilterdeWoorden.Insert(count, naughtyWordReplace);
                }
                count++;
            }


            return gefilterdeWoorden;
        }

        static void Main() {
            // TODO2 : maak een variabele 'words' die wijst naar een List met daarin de volgende woorden : orange, Trump, haar, trump, bedrog, verkiezingen, winnaar
            List<string> words = new List<string>() { "orange", "Trump", "haar", "trump", "bedrog", "verkiezingen", "winnaar" };
            // TODO2 : maak een variabele 'naughtyWords' die wijst naar een List met daarin de woorden : Trump, fraude, verkiezingen
            List<string> naughtyWords = new List<string> { "Trump", "fraude", "verkiezingen" };
            Console.WriteLine(String.Join(",", words));
            // de output hiervan is : orange,Trump,haar,trump,bedrog,verkiezingen,winnaar

            List<string> gecensureerd = SocialMediaFilter(words, naughtyWords);

            Console.WriteLine(String.Join(",", gecensureerd));
            // de output hiervan is : orange,*****,haar,trump,bedrog,************,winnaar
            // (merk op dat het van de hoofd/kleine letters afhangt of Trump/trump gecensureerd werd!)
        }

        
    }
}
