﻿using ConsoleAppSchool.Classes;
using System;

namespace ConsoleAppSchool {
    class Program {
        static void Main(string[] args) {
            Student student1 = new Student("Alexander", "Bal", 19);
            Student student2 = new Student("Isaak", "Stoop", 20);

            Leerkracht leerkracht1 = new Leerkracht("Mark", "Boei", 40);
            Leerkracht leerkracht2 = new Leerkracht("Ericia", "Ooms", 41);

            Directeur directeur1 = new Directeur("Jan", "Durie", 50);
            Directeur directeur2 = new Directeur("Arno", "Wouters", 45);

            Mens[] mensen = new Mens[6];
            mensen[0] = student1;
            mensen[1] = student2;
            mensen[2] = leerkracht1;
            mensen[3] = leerkracht2;
            mensen[4] = directeur1;
            mensen[5] = directeur2;

            foreach (Mens mens in mensen) {
                Console.WriteLine($"{mens.Voornaam} {mens.Achternaam}, {mens.Leeftijd}: {mens.DoeUwDing()}");
            }
        }
    }
}
