﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleAppSchool.Interfaces {
    public interface IMens {
        public abstract string DoeUwDing(); // zorgt er voor dat we in elke klasse hier een apparte string waarde kunnen aan geven.
    }
}
