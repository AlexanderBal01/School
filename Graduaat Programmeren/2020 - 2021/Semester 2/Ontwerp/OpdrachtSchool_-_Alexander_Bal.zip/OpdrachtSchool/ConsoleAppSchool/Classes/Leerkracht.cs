﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleAppSchool.Classes {
    public class Leerkracht : Mens {
        public Leerkracht(string voornaam, string achternaam, int leeftijd) : base(voornaam, achternaam, leeftijd) {

        }

        public override string DoeUwDing() {
            return "Ik geef les.";
        }
    }
}
