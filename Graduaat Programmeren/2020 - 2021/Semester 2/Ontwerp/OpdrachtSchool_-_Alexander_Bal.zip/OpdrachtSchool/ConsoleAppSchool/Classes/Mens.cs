﻿using ConsoleAppSchool.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleAppSchool.Classes {
    public abstract class Mens : IMens {
        public Mens(string voornaam, string achternaam, int leeftijd) {
            Voornaam = voornaam;
            Achternaam = achternaam;
            Leeftijd = leeftijd;
        }

        public string Voornaam { get; set; }
        public string Achternaam { get; set; }
        public int Leeftijd { get; set; }

        public abstract string DoeUwDing();
    }
}
