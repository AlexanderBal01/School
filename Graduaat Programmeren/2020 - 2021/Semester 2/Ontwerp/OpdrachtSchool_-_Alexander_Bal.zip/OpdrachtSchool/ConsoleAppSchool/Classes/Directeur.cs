﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleAppSchool.Classes {
    public class Directeur : Mens {
        public Directeur(string voornaam, string achternaam, int leeftijd) : base(voornaam, achternaam, leeftijd) {

        }

        public override string DoeUwDing() {
            return "Ik doe niets zoals gewoonlijk.";
        }
    }
}
