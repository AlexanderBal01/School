﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassLibraryBridgePattern {
    public class Square : Shape {
        public Square(Color kleur) : base(kleur) {
            this.item = "vierkant";
        }

        public override void SetColor(string kleur) {
            color.SetColor(kleur);
        }
    }
}
