﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassLibraryBridgePattern {
    public class Blue : Color {
        private string color = "blauw";

        public void SetColor(string kleur) {
            this.color = kleur;
        }

        public void ToonDetails(string item) {
            Console.Write($"\nIk teken een {item} in het {color}\n");
        }
    }
}
