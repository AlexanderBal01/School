﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassLibraryBridgePattern {
    public class Circle : Shape {
        public Circle(Color kleur) : base(kleur) {
            this.item = "Cirkel";
        }

        public override void SetColor(string kleur) {
            color.SetColor(kleur);
        }
    }
}
