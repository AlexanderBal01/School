﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassLibraryBridgePattern {
    public interface Color {
        public void ToonDetails(string item);

        public void SetColor(string kleur);
    }
}
