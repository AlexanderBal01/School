﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassLibraryBridgePattern {
    public abstract class Shape {
        public readonly Color color;
        public string item;

        public Shape(Color kleur) {
            this.color = kleur;
        }

        public void ToonDetails() {
            color.ToonDetails(item);
        }

        public abstract void SetColor(string kleur);
    }
}
