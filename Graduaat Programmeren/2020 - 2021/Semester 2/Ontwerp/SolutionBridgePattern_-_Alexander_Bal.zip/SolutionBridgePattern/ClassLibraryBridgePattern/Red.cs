﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassLibraryBridgePattern {
    public class Red : Color {
        private string color = "rood";

        public void ToonDetails(string item) {
            Console.Write($"\nIk teken een {item} in het {color}\n");
        }

        public void SetColor(string kleur) {
            this.color = kleur;
        }
 
    }
}
