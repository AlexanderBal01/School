﻿using ClassLibraryBridgePattern;
using System;

namespace ConsoleAppBridgePattern {
    class Program {
        static void Main(string[] args) {
            Console.WriteLine("We gaan de kleur na van een vierkant.");
            var vierkant = new Square(new Blue());
            vierkant.ToonDetails();

            vierkant = new Square(new Red());
            vierkant.ToonDetails();

            vierkant.SetColor("groen");
            vierkant.ToonDetails();

            Console.WriteLine();
            Console.WriteLine($"----------------------------------------------------\n");

            Console.WriteLine("We gaan de kleur na van een cirkel.");
            var cirkel = new Circle(new Blue());
            cirkel.ToonDetails();

            cirkel = new Circle(new Red());
            cirkel.ToonDetails();

            cirkel.SetColor("roze");
            cirkel.ToonDetails();
        }
    }
}
