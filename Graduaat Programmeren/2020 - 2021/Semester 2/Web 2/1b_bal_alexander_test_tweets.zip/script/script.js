// SCHRIJF HIER AL JE JAVASCRIPT CODE en eventuele opmerkingen voor je docent bovenaan in commentaar
const setup = () => {
    // Voeg alle users toe aan webpagina
    let userList = document.querySelector("select#slcUser");
    for (let i = 0; i <users.length; i++){
        let user = users[i];

        let htmlStr = `<option value="${user.id}">${user.name}</option>`;

        userList.insertAdjacentHTML("beforeend", htmlStr);
    }

    let btnTweets = document.querySelectorAll("#btnTweet");
    for (let i = 0; i<btnTweets.length; i++){
        let btnTweet = btnTweets[i];
        btnTweet.addEventListener("click", addTweet);
    }

}

const addTweet = () => {
    let link = event.target;
    event.preventDefault();



    if (link.value == "Tweet") {
        let optionUsers = document.querySelector("#slcUser");
        let optionUser = optionUsers.options[optionUsers.selectedIndex].value
        let txtTweet = document.getElementById("txtTweet").value;

        let feed = document.querySelector("#feed");

        let htmlstr = ` <div class="tweetBox" style="background-color: ${optionUser.backgroundColor}">
            <img class="userImage" src="${optionUser.imageUrl}">
            <p>${optionUser.name}</p>
            <p>${txtTweet}</p>
            <div class="likeBtnBox">
                <input type="button" class="likeBtn" value="👍">
                <span class="likes" data-likes="3">3 likes</span>
            </div>
            <input type="button" class="deleteBtn" value="❌">
        </div>`;
        feed.insertAdjacentHTML("beforeend", htmlstr);
    }
}

window.addEventListener("load", setup);