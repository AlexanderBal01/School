/* WIJZIG DEZE FILE NIET */

// De lijst met gebruikersdata
// (de urls wijzen naar de afbeeldingen in de /images folder)
let users = [
    {
        id : "0",
        name: "Police Man",
        backgroundColor: "#EDBB99",
        imageUrl : "images/pm.jpg",
    },
    {
        id: "1",
        name: "Normal Guy",
        backgroundColor: "#F9E79F",
        imageUrl : "images/ng.jpg",
    },
    {
        id: "2",
        name: "Butler",
        backgroundColor: "#ABEBC6",
        imageUrl : "images/bt.jpg",
    },
    {
        id: "3",
        name: "Doctor",
        backgroundColor: "#AED6F1",
        imageUrl : "images/dr.jpg",
    },
    {
        id: "4",
        name: "John",
        backgroundColor: "#D7BDE2",
        imageUrl : "images/jn.jpg",
    },
    {
        id: "5",
        name: "Elvis",
        backgroundColor: "#F7F9F9",
        imageUrl: "images/el.jpg",
    }
];

/* WIJZIG DEZE FILE NIET */
