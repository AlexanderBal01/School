// verder aanvullen : plaats al je javascript code in dit bestand$
const setup = () =>{
    const imageList = document.querySelector("#movieList");
    let htmlStr = '';
    for(let i=0;i<movies.length;i++) {
        htmlStr += "<section id='"+movies[i].id+"' class='movie'><img src='"+movies[i].imageUrl+"'/><header>"+movies[i].title+" <a class='likeUnlike' href='#'>like</a></header><div>"+movies[i].description+"</div></section>";
    }

    imageList.insertAdjacentHTML("beforeend", htmlStr);

    const likeUnlikelink = document.querySelector(".likeUnlike");
    likeUnlikelink.addEventListener("click", selectMovie);
}

const selectMovie = () => {
    const clickLike = document.querySelector(".likeUnlike")
    if (clickLike.innerHTML === "like"){
        clickLike.innerHTML ="unlike";
    } else if (clickLike.innerHTML === "unlike") {
        clickLike.innerHTML = "like";
    }
}

window.addEventListener("load", setup);